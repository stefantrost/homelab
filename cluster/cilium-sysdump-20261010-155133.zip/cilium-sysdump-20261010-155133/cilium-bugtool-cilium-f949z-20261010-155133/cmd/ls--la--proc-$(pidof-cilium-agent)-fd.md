total 0
dr-x------ 2 root root 101 Oct 10 11:00 .
dr-xr-xr-x 9 root root   0 Oct 10 11:00 ..
lrwx------ 1 root root  64 Oct 10 13:52 0 -> /dev/null
l-wx------ 1 root root  64 Oct 10 13:52 1 -> pipe:[18331]
lrwx------+1 root root  64 Oct 10 13:52 10 -> socket:[18992]
lrwx------+1 root root  64 Oct 10 11:01 101 -> socket:[21089]
lrwx------+1 root root  64 Oct 10 11:01 109 -> socket:[21094]
lrwx------ 1 root root  64 Oct 10 13:52 11 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 11:01 111 -> socket:[21113]
lrwx------+1 root root  64 Oct 10 13:52 12 -> socket:[19536]
lrwx------ 1 root root  64 Oct 10 13:52 124 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 125 -> anon_inode:bpf-map
lr-x------ 1 root root  64 Oct 10 13:52 13 -> net:[4026531833]
lrwx------ 1 root root  64 Oct 10 13:52 14 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 15 -> socket:[19540]
lrwx------ 1 root root  64 Oct 10 13:52 16 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 17 -> socket:[19022]
lrwx------+1 root root  64 Oct 10 13:52 18 -> socket:[19023]
lrwx------+1 root root  64 Oct 10 13:52 19 -> socket:[19024]
l-wx------ 1 root root  64 Oct 10 13:52 2 -> pipe:[18332]
l-wx------ 1 root root  64 Oct 10 13:52 20 -> /run/cilium/state/route-reconciler.wal
lrwx------ 1 root root  64 Oct 10 13:52 21 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 22 -> socket:[19547]
lrwx------ 1 root root  64 Oct 10 13:52 23 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 24 -> socket:[19590]
lrwx------+1 root root  64 Oct 10 13:52 25 -> socket:[19545]
lrwx------+1 root root  64 Oct 10 13:52 26 -> socket:[19546]
lrwx------+1 root root  64 Oct 10 13:52 27 -> socket:[19591]
lrwx------ 1 root root  64 Oct 10 13:52 28 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 29 -> anon_inode:bpf-map
lr-x------ 1 root root  64 Oct 10 13:52 3 -> /sys/fs/cgroup/cpu.max
lrwx------ 1 root root  64 Oct 10 13:52 30 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 31 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 32 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 33 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 34 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 35 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 36 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 37 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 38 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 39 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 4 -> socket:[19527]
lrwx------ 1 root root  64 Oct 10 13:52 40 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 41 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 42 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 43 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 44 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 45 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 11:00 46 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 47 -> anon_inode:[eventpoll]
lrwx------ 1 root root  64 Oct 10 13:52 48 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 49 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 5 -> anon_inode:[eventpoll]
lrwx------ 1 root root  64 Oct 10 13:52 50 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 51 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 52 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 53 -> socket:[19089]
lrwx------+1 root root  64 Oct 10 13:52 54 -> socket:[19083]
lrwx------+1 root root  64 Oct 10 13:52 55 -> socket:[19090]
lrwx------+1 root root  64 Oct 10 13:52 56 -> socket:[19129]
lrwx------+1 root root  64 Oct 10 13:52 57 -> socket:[19756]
lrwx------+1 root root  64 Oct 10 11:01 58 -> socket:[113159]
lrwx------ 1 root root  64 Oct 10 11:00 59 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 6 -> anon_inode:[eventfd]
lrwx------+1 root root  64 Oct 10 13:52 60 -> socket:[19741]
lrwx------+1 root root  64 Oct 10 13:52 61 -> socket:[19743]
lrwx------ 1 root root  64 Oct 10 11:00 62 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 63 -> socket:[19736]
lr-x------ 1 root root  64 Oct 10 13:52 64 -> anon_inode:btf
lrwx------ 1 root root  64 Oct 10 13:52 65 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 66 -> socket:[20221]
lrwx------ 1 root root  64 Oct 10 13:52 67 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 68 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 69 -> socket:[19156]
l-wx------ 1 root root  64 Oct 10 13:52 7 -> /run/cilium/state/cilium-agent-health-history.log
lrwx------+1 root root  64 Oct 10 13:52 70 -> socket:[19157]
lrwx------+1 root root  64 Oct 10 13:52 71 -> socket:[19158]
lrwx------+1 root root  64 Oct 10 13:52 72 -> socket:[19159]
lrwx------+1 root root  64 Oct 10 13:52 73 -> socket:[19160]
lrwx------+1 root root  64 Oct 10 13:52 74 -> socket:[19161]
l-wx------ 1 root root  64 Oct 10 13:52 75 -> /run/cilium/state/device-reconciler.wal
lrwx------ 1 root root  64 Oct 10 13:52 76 -> anon_inode:[eventpoll]
lrwx------+1 root root  64 Oct 10 11:00 77 -> socket:[112525]
lrwx------ 1 root root  64 Oct 10 13:52 78 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 79 -> anon_inode:[eventfd]
lrwx------+1 root root  64 Oct 10 13:52 8 -> socket:[19532]
lrwx------ 1 root root  64 Oct 10 13:52 80 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 81 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 82 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 11:01 83 -> socket:[127222]
lrwx------+1 root root  64 Oct 10 11:00 84 -> socket:[127223]
lrwx------+1 root root  64 Oct 10 11:00 85 -> socket:[138031]
lrwx------+1 root root  64 Oct 10 11:01 88 -> socket:[138701]
lrwx------+1 root root  64 Oct 10 11:00 89 -> socket:[140094]
lrwx------ 1 root root  64 Oct 10 11:00 9 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 90 -> anon_inode:bpf-prog
lr-x------ 1 root root  64 Oct 10 13:52 91 -> anon_inode:btf
lrwx------ 1 root root  64 Oct 10 13:52 92 -> anon_inode:bpf-prog
lrwx------+1 root root  64 Oct 10 11:01 93 -> socket:[140194]
lrwx------ 1 root root  64 Oct 10 13:52 94 -> anon_inode:[pidfd]
lrwx------+1 root root  64 Oct 10 11:00 95 -> socket:[139593]
lrwx------+1 root root  64 Oct 10 11:01 98 -> socket:[21085]
lrwx------+1 root root  64 Oct 10 11:01 99 -> socket:[21086]
