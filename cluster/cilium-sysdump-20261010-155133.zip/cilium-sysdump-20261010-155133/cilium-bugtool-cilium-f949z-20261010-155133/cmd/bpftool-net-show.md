xdp:

tc:
ens18(2) tcx/ingress cil_from_netdev prog_id 432 link_id 22 
ens18(2) tcx/egress cil_to_netdev prog_id 429 link_id 23 
cilium_net(3) tcx/ingress cil_to_host prog_id 421 link_id 21 
cilium_host(4) tcx/ingress cil_to_host prog_id 401 link_id 18 
cilium_host(4) tcx/egress cil_from_host prog_id 411 link_id 19 
cilium_vxlan(5) tcx/ingress cil_from_overlay prog_id 335 link_id 15 
cilium_vxlan(5) tcx/egress cil_to_overlay prog_id 332 link_id 16 
lxc_health(7) tcx/ingress cil_from_container prog_id 375 link_id 17 
lxc7ec5ba81bca3(9) tcx/ingress cil_from_container prog_id 398 link_id 20 

flow_dissector:

netfilter:

