ID: 3284	Namespace: 	Name: 	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-ingress   5
allow-any-egress    5

ID: 1644	Namespace: 	Name: 	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-ingress   5
allow-any-egress    5

ID: 4046	Namespace: kube-system	Name: coredns-559f6c778d-khtkb	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-ingress   5
allow-any-egress    5


