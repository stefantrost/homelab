key: 6c 06 00 00  value: 7e 01 00 00
key: d4 0c 00 00  value: 98 01 00 00
key: ce 0f 00 00  value: 85 01 00 00
Found 3 elements
