REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     2010      149545     564    bpf_overlay.c
Interface                 INGRESS     28351     17825310   1282   bpf_host.c
Interface                 INGRESS     692       38450      1268   bpf_host.c
Interface                 INGRESS     78441     15906583   1248   bpf_host.c
Stale or unroutable IP    INGRESS     1         112        995    bpf_host.c
Success                   EGRESS      11424     1102778    1389   bpf_lxc.c
Success                   EGRESS      3061      225356     34     encap.h
Success                   EGRESS      6017      671904     1655   bpf_host.c
Success                   EGRESS      60964     9101183    470    nodeport_egress.h
Success                   EGRESS      931       68668      1918   bpf_host.c
Success                   INGRESS     13434     1263536    152    local_delivery.h
Success                   INGRESS     14533     1345813    2316   bpf_lxc.c
Unsupported L3 protocol   EGRESS      16        1196       1841   bpf_lxc.c
