alloc: 59.03MB (61900176 bytes)
total-alloc: 1.34GB (1434897216 bytes)
sys: 108.46MB (113726326 bytes)
lookups: 0
mallocs: 15869322
frees: 15378605
heap-alloc: 59.03MB (61900176 bytes)
heap-sys: 95.97MB (100630528 bytes)
heap-idle: 21.43MB (22470656 bytes)
heap-in-use: 74.54MB (78159872 bytes)
heap-released: 15.88MB (16646144 bytes)
heap-objects: 490717
stack-in-use: 4.03MB (4227072 bytes)
stack-sys: 4.03MB (4227072 bytes)
stack-mspan-inuse: 1.04MB (1089600 bytes)
stack-mspan-sys: 1.11MB (1158720 bytes)
stack-mcache-inuse: 4.48KB (4592 bytes)
stack-mcache-sys: 15.70KB (16072 bytes)
other-sys: 706.77KB (723732 bytes)
gc-sys: 4.84MB (5077776 bytes)
next-gc: when heap-alloc >= 99.59MB (104431850 bytes)
last-gc: 2026-10-10 13:51:17.026427765 +0000 UTC
gc-pause-total: 15.324144ms
gc-pause: 47137
gc-pause-end: 1791640277026427765
num-gc: 96
num-forced-gc: 0
gc-cpu-fraction: 6.583318508611454e-05
enable-gc: true
debug-gc: false
