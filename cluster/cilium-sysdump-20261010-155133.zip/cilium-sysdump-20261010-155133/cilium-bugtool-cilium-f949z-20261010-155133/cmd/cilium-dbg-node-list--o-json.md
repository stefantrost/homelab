[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.244.2.84"
      },
      "ipv6": {}
    },
    "name": "workernode02",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.244.2.0/24",
        "enabled": true,
        "ip": "192.168.178.115"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.244.2.226"
      }
    ],
    "source": "custom-resource"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.244.0.27"
      },
      "ipv6": {}
    },
    "name": "controlplane",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.244.0.0/24",
        "enabled": true,
        "ip": "192.168.178.113"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.244.0.172"
      }
    ],
    "source": "custom-resource"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.244.1.197"
      },
      "ipv6": {}
    },
    "name": "workernode01",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.244.1.0/24",
        "enabled": true,
        "ip": "192.168.178.114"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.244.1.173"
      }
    ],
    "source": "local"
  }
]

