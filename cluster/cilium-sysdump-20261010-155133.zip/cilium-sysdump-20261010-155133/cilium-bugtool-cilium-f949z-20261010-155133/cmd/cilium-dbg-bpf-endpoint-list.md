IP ADDRESS          LOCAL ENDPOINT INFO
10.244.1.173:0      (localhost)                                                                                                                   
192.168.178.114:0   (localhost)                                                                                                                   
10.244.1.214:0      id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0   
10.244.1.197:0      id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0   
