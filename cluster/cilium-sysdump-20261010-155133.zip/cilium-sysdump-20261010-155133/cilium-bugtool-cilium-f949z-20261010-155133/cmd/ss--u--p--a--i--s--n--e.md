Total: 358
TCP:   144 (estab 28, closed 92, orphaned 0, timewait 84)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  11        7         4        
TCP	  52        42        10       
INET	  65        50        15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                     Local Address:Port  Peer Address:PortProcess                                                                                     
UNCONN 0      0                              127.0.0.1:40581      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=53)) ino:19089 sk:1013 fwmark:0xb00 cgroup:/ <->           
UNCONN 0      0                             127.0.0.54:53         0.0.0.0:*                                         uid:989 ino:7446 sk:1 cgroup:unreachable:be6 <->      
UNCONN 0      0                          127.0.0.53%lo:53         0.0.0.0:*                                         uid:989 ino:7444 sk:2 cgroup:unreachable:be6 <->      
UNCONN 0      0                  192.168.178.114%ens18:68         0.0.0.0:*                                         uid:998 ino:15212 sk:3 cgroup:unreachable:10eb <->    
UNCONN 0      0                                0.0.0.0:111        0.0.0.0:*                                         ino:6127 sk:4 cgroup:unreachable:678 <->              
UNCONN 0      0                                0.0.0.0:8472       0.0.0.0:*                                         ino:19291 sk:1014 cgroup:/ <->                        
UNCONN 0      0                              127.0.0.1:323        0.0.0.0:*                                         ino:13248 sk:5 cgroup:unreachable:125f <->            
UNCONN 0      0                                   [::]:111           [::]:*                                         ino:6129 sk:1016 cgroup:unreachable:678 v6only:1 <->  
UNCONN 0      0                                   [::]:8472          [::]:*                                         ino:19290 sk:1015 cgroup:/ v6only:1 <->               
UNCONN 0      0                                  [::1]:323           [::]:*                                         ino:13249 sk:1011 cgroup:unreachable:125f v6only:1 <->
UNCONN 0      0      [fe80::be24:11ff:fede:cb0c]%ens18:546           [::]:*                                         uid:998 ino:14137 sk:1012 cgroup:unreachable:10eb v6only:1 <->
