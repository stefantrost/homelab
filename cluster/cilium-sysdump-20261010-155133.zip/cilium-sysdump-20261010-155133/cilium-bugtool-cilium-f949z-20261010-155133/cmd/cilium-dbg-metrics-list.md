Metric                                                                   Labels                                                                                Value
cilium_act_processing_time_seconds                                                                                                                             0s / 0s / 0s
cilium_agent_api_process_time_seconds                                    method=DELETE path=/v1/endpoint return_code=200                                       2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=DELETE path=/v1/endpoint return_code=404                                       2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/cluster return_code=200                                           2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/config return_code=200                                            2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/debuginfo return_code=200                                         2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/endpoint return_code=200                                          2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/healthz return_code=200                                           2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=POST path=/v1/ipam return_code=201                                             2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=PUT path=/v1/endpoint return_code=201                                          250ms / 4.5s / 4.95s
cilium_api_limiter_adjustment_factor                                     api_call=endpoint-create                                                              0.933750
cilium_api_limiter_adjustment_factor                                     api_call=endpoint-delete                                                              51.800803
cilium_api_limiter_adjustment_factor                                     api_call=endpoint-list                                                                100.000000
cilium_api_limiter_processed_requests_total                              api_call=endpoint-create outcome=success return_code=200                              2.000000
cilium_api_limiter_processed_requests_total                              api_call=endpoint-delete outcome=success return_code=200                              1.000000
cilium_api_limiter_processed_requests_total                              api_call=endpoint-list outcome=success return_code=200                                2.000000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-create value=estimated                                              2.000000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-create value=mean                                                   2.141901
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-delete value=estimated                                              0.200000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-delete value=mean                                                   0.003861
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-list value=estimated                                                0.300000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-list value=mean                                                     0.000211
cilium_api_limiter_rate_limit                                            api_call=endpoint-create value=burst                                                  4.000000
cilium_api_limiter_rate_limit                                            api_call=endpoint-create value=limit                                                  0.466875
cilium_api_limiter_rate_limit                                            api_call=endpoint-delete value=burst                                                  0.000000
cilium_api_limiter_rate_limit                                            api_call=endpoint-delete value=limit                                                  0.000000
cilium_api_limiter_rate_limit                                            api_call=endpoint-list value=burst                                                    202.000000
cilium_api_limiter_rate_limit                                            api_call=endpoint-list value=limit                                                    100.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-create value=in-flight                                              0.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-create value=limit                                                  3.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-delete value=in-flight                                              0.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-delete value=limit                                                  105.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-list value=in-flight                                                0.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-list value=limit                                                    101.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-create value=max                                                    60.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-create value=mean                                                   0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-create value=min                                                    0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-delete value=max                                                    0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-delete value=mean                                                   0.000015
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-delete value=min                                                    0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-list value=max                                                      0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-list value=mean                                                     0.000031
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-list value=min                                                      0.000000
cilium_bpf_map_capacity                                                  map_group=cilium_auth_map                                                             524288.000000
cilium_bpf_map_capacity                                                  map_group=cilium_call_policy                                                          65535.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ct4_global                                                           131072.000000
cilium_bpf_map_capacity                                                  map_group=cilium_devices                                                              512.000000
cilium_bpf_map_capacity                                                  map_group=cilium_egresscall_policy                                                    65535.000000
cilium_bpf_map_capacity                                                  map_group=cilium_events                                                               2.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ipcache_v2                                                           512000.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ipv4_frag_datagrams                                                  8192.000000
cilium_bpf_map_capacity                                                  map_group=cilium_l2_responder_v4                                                      4096.000000
cilium_bpf_map_capacity                                                  map_group=cilium_l2_responder_v6                                                      4096.000000
cilium_bpf_map_capacity                                                  map_group=cilium_lxc                                                                  65535.000000
cilium_bpf_map_capacity                                                  map_group=cilium_metrics                                                              1024.000000
cilium_bpf_map_capacity                                                  map_group=cilium_node_map_v2                                                          16384.000000
cilium_bpf_map_capacity                                                  map_group=cilium_nodeport_neigh4                                                      131072.000000
cilium_bpf_map_capacity                                                  map_group=cilium_percpu_trace_id                                                      1.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ratelimit                                                            1024.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ratelimit_metrics                                                    64.000000
cilium_bpf_map_capacity                                                  map_group=cilium_runtime_config                                                       256.000000
cilium_bpf_map_capacity                                                  map_group=cilium_signals                                                              2.000000
cilium_bpf_map_capacity                                                  map_group=cilium_skip_lb4                                                             100.000000
cilium_bpf_map_capacity                                                  map_group=cilium_snat_v4_alloc_retries                                                33.000000
cilium_bpf_map_capacity                                                  map_group=cilium_snat_v4_external                                                     131072.000000
cilium_bpf_map_capacity                                                  map_group=default                                                                     65536.000000
cilium_bpf_map_capacity                                                  map_group=endpoint_policy                                                             16384.000000
cilium_bpf_map_ops_total                                                 map_name=call_policy operation=delete outcome=success                                 1.000000
cilium_bpf_map_ops_total                                                 map_name=ct4_global operation=delete outcome=success                                  2261.000000
cilium_bpf_map_ops_total                                                 map_name=ct_any4_global operation=delete outcome=success                              257.000000
cilium_bpf_map_ops_total                                                 map_name=devices operation=update outcome=success                                     86.000000
cilium_bpf_map_ops_total                                                 map_name=egresscall_policy operation=delete outcome=success                           1.000000
cilium_bpf_map_ops_total                                                 map_name=ipcache_v2 operation=delete outcome=success                                  2.000000
cilium_bpf_map_ops_total                                                 map_name=ipcache_v2 operation=update outcome=success                                  19.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_backends_v3 operation=delete outcome=success                             8.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_backends_v3 operation=update outcome=success                             19.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_reverse_nat operation=update outcome=success                             55.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_services_v2 operation=delete outcome=success                             1.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_services_v2 operation=update outcome=success                             138.000000
cilium_bpf_map_ops_total                                                 map_name=lxc operation=delete outcome=success                                         1.000000
cilium_bpf_map_ops_total                                                 map_name=lxc operation=update outcome=success                                         178.000000
cilium_bpf_map_ops_total                                                 map_name=policy operation=update outcome=success                                      40.000000
cilium_bpf_map_ops_total                                                 map_name=runtime_config operation=update outcome=success                              10269.000000
cilium_bpf_map_ops_total                                                 map_name=snat_v4_external operation=delete outcome=success                            722.000000
cilium_bpf_map_pressure                                                  map_name=ct4_global                                                                   0.001236
cilium_bpf_map_pressure                                                  map_name=ct_any4_global                                                               0.000229
cilium_bpf_map_pressure                                                  map_name=ipcache_v2                                                                   0.000033
cilium_bpf_map_pressure                                                  map_name=lb4_backends_v3                                                              0.000153
cilium_bpf_map_pressure                                                  map_name=lb4_reverse_nat                                                              0.000107
cilium_bpf_map_pressure                                                  map_name=lb4_services_v2                                                              0.000336
cilium_bpf_map_pressure                                                  map_name=lxc                                                                          0.000061
cilium_bpf_maps                                                                                                                                                59.000000
cilium_bpf_maps_virtual_memory_max_bytes                                                                                                                       89379184.000000
cilium_bpf_progs                                                                                                                                               73.000000
cilium_bpf_progs_virtual_memory_max_bytes                                                                                                                      823296.000000
cilium_bpf_ratelimit_dropped_total                                       usage=                                                                                4.000000
cilium_clustermesh_remote_clusters                                                                                                                             0.000000
cilium_controllers_failing                                                                                                                                     0.000000
cilium_controllers_runs_duration_seconds                                 status=success                                                                        2.507ms / 4.513ms / 4.964ms
cilium_controllers_runs_total                                            status=success                                                                        2506.000000
cilium_datapath_conntrack_dump_resets_total                              area=conntrack family=ipv4 name=dump_interrupts                                       0.000000
cilium_datapath_conntrack_gc_duration_seconds                            family=ipv4 protocol=TCP status=completed                                             2.5ms / 4.5ms / 4.95ms
cilium_datapath_conntrack_gc_duration_seconds                            family=ipv4 protocol=non-TCP status=completed                                         2.5ms / 4.5ms / 4.95ms
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=TCP status=alive                                                 16.000000
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=TCP status=deleted                                               788.000000
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=non-TCP status=alive                                             3.000000
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=non-TCP status=deleted                                           65.000000
cilium_datapath_conntrack_gc_interval_seconds                            global=global                                                                         5130.000000
cilium_datapath_conntrack_gc_key_fallbacks_total                         family=ipv4 protocol=TCP                                                              0.000000
cilium_datapath_conntrack_gc_key_fallbacks_total                         family=ipv4 protocol=non-TCP                                                          0.000000
cilium_datapath_conntrack_gc_runs_total                                  family=ipv4 protocol=TCP status=completed                                             13.000000
cilium_datapath_conntrack_gc_runs_total                                  family=ipv4 protocol=non-TCP status=completed                                         13.000000
cilium_drift_checker_config_delta                                                                                                                              0.000000
cilium_drop_bytes_total                                                  direction=EGRESS reason=Unsupported L3 protocol                                       1196.000000
cilium_drop_bytes_total                                                  direction=INGRESS reason=Stale or unroutable IP                                       112.000000
cilium_drop_count_total                                                  direction=EGRESS reason=Unsupported L3 protocol                                       16.000000
cilium_drop_count_total                                                  direction=INGRESS reason=Stale or unroutable IP                                       1.000000
cilium_endpoint                                                                                                                                                3.000000
cilium_endpoint_component_status                                         status=OK type=BPF                                                                    3.000000
cilium_endpoint_component_status                                         status=OK type=Other                                                                  3.000000
cilium_endpoint_component_status                                         status=OK type=Policy                                                                 3.000000
cilium_endpoint_regeneration_time_stats_seconds                          scope=bpfCompilation status=success                                                   5.5s / 9.1s / 9.91s
cilium_endpoint_regeneration_time_stats_seconds                          scope=bpfLoadProg status=success                                                      550ms / 910ms / 991ms
cilium_endpoint_regeneration_time_stats_seconds                          scope=bpfWaitForELF status=success                                                    9.1ms / 7.975s / 9.797s
cilium_endpoint_regeneration_time_stats_seconds                          scope=buildPermitAcquisition status=success                                           5.815µs / 380.6µs / 424ms
cilium_endpoint_regeneration_time_stats_seconds                          scope=endpointPolicyCalculation status=success                                        43.96µs / 88.79µs / 98.88µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=mapSync status=success                                                          33.39µs / 87.08µs / 99.17µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=policyCalculation status=success                                                55.52µs / 91.93µs / 208µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=prepareBuild status=success                                                     55.87µs / 92.56µs / 524.8µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=proxyConfiguration status=success                                               5µs / 9µs / 9.9µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=proxyPolicyCalculation status=success                                           62.8µs / 771.4µs / 985.2µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=proxyWaitForAck status=success                                                  5µs / 9µs / 9.9µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=selectorPolicyCalculation status=success                                        55µs / 91µs / 99.1µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=total status=success                                                            567.7µs / 941.9µs / 4.06s
cilium_endpoint_regeneration_time_stats_seconds                          scope=waitForPolicyCompute status=success                                             5.238µs / 9.429µs / 86.58µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=waitingForCTClean status=success                                                5.057µs / 9.103µs / 262µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=waitingForLock status=success                                                   5.057µs / 9.103µs / 2.08s
cilium_endpoint_regenerations_total                                      error= outcome=success reason=DeviceConfigurationChanged                              4.000000
cilium_endpoint_regenerations_total                                      error= outcome=success reason=LabelsUpdate                                            4.000000
cilium_endpoint_regenerations_total                                      error= outcome=success reason=PeriodicRegeneration                                    256.000000
cilium_endpoint_restoration_duration_seconds                             phase=initial_policy_computation                                                      0.000002
cilium_endpoint_restoration_duration_seconds                             phase=prepare_regeneration                                                            0.125471
cilium_endpoint_restoration_duration_seconds                             phase=read_from_disk                                                                  0.000208
cilium_endpoint_restoration_duration_seconds                             phase=regeneration                                                                    0.034084
cilium_endpoint_restoration_duration_seconds                             phase=restoration                                                                     0.000484
cilium_endpoint_restoration_endpoints                                    outcome=failed phase=read_from_disk                                                   0.000000
cilium_endpoint_restoration_endpoints                                    outcome=failed phase=regeneration                                                     0.000000
cilium_endpoint_restoration_endpoints                                    outcome=failed phase=restoration                                                      0.000000
cilium_endpoint_restoration_endpoints                                    outcome=skipped phase=restoration                                                     0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=initial_policy_computation                                   0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=prepare_regeneration                                         0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=read_from_disk                                               0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=regeneration                                                 0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=restoration                                                  0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=initial_policy_computation                                        0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=prepare_regeneration                                              0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=read_from_disk                                                    0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=regeneration                                                      0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=restoration                                                       0.000000
cilium_endpoint_state                                                    endpoint_state=disconnecting                                                          0.000000
cilium_endpoint_state                                                    endpoint_state=ready                                                                  3.000000
cilium_endpoint_state                                                    endpoint_state=regenerating                                                           0.000000
cilium_endpoint_state                                                    endpoint_state=waiting-for-identity                                                   0.000000
cilium_endpoint_state                                                    endpoint_state=waiting-to-regenerate                                                  0.000000
cilium_errors_warnings_total                                             level=ERROR subsystem=init                                                            0.000000
cilium_errors_warnings_total                                             level=WARN subsystem=init                                                             0.000000
cilium_event_ts                                                          action=DELETE scope=/v1/endpoint source=api                                           1791638923.805857
cilium_event_ts                                                          action=GET scope=/v1/cluster source=api                                               1791640327.088136
cilium_event_ts                                                          action=GET scope=/v1/config source=api                                                1791638923.804598
cilium_event_ts                                                          action=GET scope=/v1/debuginfo source=api                                             1791640327.555130
cilium_event_ts                                                          action=GET scope=/v1/endpoint source=api                                              1791640197.553857
cilium_event_ts                                                          action=GET scope=/v1/healthz source=api                                               1791640327.665379
cilium_event_ts                                                          action=POST scope=/v1/ipam source=api                                                 1791638919.395182
cilium_event_ts                                                          action=PUT scope=/v1/endpoint source=api                                              1791638919.414642
cilium_event_ts                                                          action=create scope=CiliumEndpoint source=k8s                                         1791638919.433273
cilium_event_ts                                                          action=create scope=Pod source=k8s                                                    1791638919.055073
cilium_event_ts                                                          action=delete scope=CiliumEndpoint source=k8s                                         1791638923.815638
cilium_event_ts                                                          action=update scope=CiliumEndpoint source=k8s                                         1791630058.795237
cilium_event_ts                                                          action=update scope=CiliumNode source=k8s                                             1791630058.813909
cilium_event_ts                                                          action=update scope=Node source=k8s                                                   1791640058.298034
cilium_event_ts                                                          action=update scope=Pod source=k8s                                                    1791638924.853098
cilium_feature_adv_connect_and_lb_bandwidth_manager_enabled                                                                                                    0.000000
cilium_feature_adv_connect_and_lb_bgp_enabled                                                                                                                  0.000000
cilium_feature_adv_connect_and_lb_cilium_envoy_config_enabled                                                                                                  0.000000
cilium_feature_adv_connect_and_lb_cilium_node_config_enabled                                                                                                   0.000000
cilium_feature_adv_connect_and_lb_egress_gateway_enabled                                                                                                       0.000000
cilium_feature_adv_connect_and_lb_envoy_proxy_enabled                    mode=standalone                                                                       1.000000
cilium_feature_adv_connect_and_lb_kube_proxy_replacement_enabled                                                                                               1.000000
cilium_feature_adv_connect_and_lb_l2_lb_enabled                                                                                                                0.000000
cilium_feature_adv_connect_and_lb_l2_pod_announcement_enabled                                                                                                  0.000000
cilium_feature_adv_connect_and_lb_node_port_configuration                acceleration=disabled algorithm=random mode=snat                                      1.000000
cilium_feature_adv_connect_and_lb_sctp_enabled                                                                                                                 0.000000
cilium_feature_adv_connect_and_lb_vtep_enabled                                                                                                                 0.000000
cilium_feature_controlplane_cilium_endpoint_slices_enabled                                                                                                     0.000000
cilium_feature_controlplane_identity_allocation                          mode=crd                                                                              1.000000
cilium_feature_controlplane_ipam                                         mode=kubernetes                                                                       1.000000
cilium_feature_datapath_chaining_enabled                                 mode=none                                                                             1.000000
cilium_feature_datapath_config                                           configured_mode=veth operational_mode=veth                                            1.000000
cilium_feature_datapath_endpoint_routes_enabled                                                                                                                0.000000
cilium_feature_datapath_internet_protocol                                address_family=ipv4-only                                                              1.000000
cilium_feature_datapath_kernel_version                                   version=7.0.0                                                                         1.000000
cilium_feature_datapath_network                                          mode=overlay-vxlan                                                                    1.000000
cilium_feature_network_policies_host_firewall_enabled                                                                                                          0.000000
cilium_feature_network_policies_internal_traffic_policy_services_total   action=add                                                                            1.000000
cilium_feature_network_policies_local_redirect_policy_enabled                                                                                                  0.000000
cilium_feature_network_policies_mutual_auth_enabled                                                                                                            0.000000
cilium_feature_network_policies_non_defaultdeny_policies_enabled                                                                                               1.000000
cilium_forward_bytes_total                                               direction=EGRESS                                                                      11169641.000000
cilium_forward_bytes_total                                               direction=INGRESS                                                                     36528929.000000
cilium_forward_count_total                                               direction=EGRESS                                                                      82394.000000
cilium_forward_count_total                                               direction=INGRESS                                                                     137457.000000
cilium_fqdn_gc_deletions_total                                                                                                                                 0.000000
cilium_fqdn_selectors                                                                                                                                          0.000000
cilium_hive_jobs_observer_last_run_duration_seconds                      job_name=k8s-secrets-resource-events-cilium-secrets module_id=envoy-proxy             0.000033
cilium_hive_jobs_observer_last_run_duration_seconds                      job_name=nat-map-next4 module_id=ct-nat-map-gc                                        0.000000
cilium_hive_jobs_observer_run_duration_seconds                           job_name=k8s-secrets-resource-events-cilium-secrets module_id=envoy-proxy             250µs / 450µs / 495µs
cilium_hive_jobs_observer_run_duration_seconds                           job_name=nat-map-next4 module_id=ct-nat-map-gc                                        250µs / 450µs / 495µs
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=certloader-server-tls module_id=hubble                                       0.038726
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=cleanup module_id=map-sweeper                                                0.192374
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=clustermesh-nodemanager-notifier module_id=clustermesh                       0.000001
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=cni-deletion-queue module_id=endpoint-api                                    0.240040
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=enable-gc module_id=ct-nat-map-gc                                            0.263244
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=endpoint-cleanup module_id=stale-endpoint-cleanup                            0.178835
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=finish-endpoint-restore module_id=endpoint-restore                           0.125485
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=hubble module_id=hubble                                                      0.038847
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=init module_id=cilium-health                                                 0.170174
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=init-host-endpoint module_id=agent-infra-endpoints                           0.129775
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=init-periodic-endpoint-controllers module_id=endpoint-manager                0.423290
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=ipset-init-finalizer module_id=ipset                                         0.021280
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=l2-announcer-lease-gc module_id=l2-announcer                                 0.017335
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=per-endpoint-route-initializer module_id=loader                              0.273065
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=pressure-metric-throttle module_id=bwmap                                     0.000050
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=proxy-bootstrapper module_id=dns-proxy                                       0.539721
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=proxy-ports-restore module_id=l7-proxy                                       0.006261
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=registry module_id=registry                                                  0.000015
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=release-local-identities module_id=ipcache                                   30.430308
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=start-reconciler module_id=loadbalancer-reconciler                           0.000831
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=sync-crds module_id=k8s-synced-crdsync                                       0.050755
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=unlock-lockfile module_id=endpoint-api                                       0.147259
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=update-config-metric module_id=enabled-features                              0.000139
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=wait-for-endpoint-restore module_id=ep-bpf-prog-watchdog                     0.164434
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=wait-for-endpoint-restore module_id=namemanager                              0.427059
cilium_hive_jobs_runs_total                                              job_name=certloader-server-tls module_id=hubble                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=cleanup module_id=map-sweeper                                                1.000000
cilium_hive_jobs_runs_total                                              job_name=cleanup module_id=metrics                                                    2.000000
cilium_hive_jobs_runs_total                                              job_name=clustermesh-nodemanager-notifier module_id=clustermesh                       1.000000
cilium_hive_jobs_runs_total                                              job_name=cni-deletion-queue module_id=endpoint-api                                    1.000000
cilium_hive_jobs_runs_total                                              job_name=dns-garbage-collector-job module_id=namemanager                              171.000000
cilium_hive_jobs_runs_total                                              job_name=enable-gc module_id=ct-nat-map-gc                                            1.000000
cilium_hive_jobs_runs_total                                              job_name=endpoint-cleanup module_id=stale-endpoint-cleanup                            1.000000
cilium_hive_jobs_runs_total                                              job_name=ep-bpf-prog-watchdog module_id=ep-bpf-prog-watchdog                          342.000000
cilium_hive_jobs_runs_total                                              job_name=finish-endpoint-restore module_id=endpoint-restore                           1.000000
cilium_hive_jobs_runs_total                                              job_name=hubble module_id=hubble                                                      1.000000
cilium_hive_jobs_runs_total                                              job_name=hubble-namespace-cleanup module_id=hubble                                    34.000000
cilium_hive_jobs_runs_total                                              job_name=init module_id=cilium-health                                                 1.000000
cilium_hive_jobs_runs_total                                              job_name=init-host-endpoint module_id=agent-infra-endpoints                           1.000000
cilium_hive_jobs_runs_total                                              job_name=init-periodic-endpoint-controllers module_id=endpoint-manager                1.000000
cilium_hive_jobs_runs_total                                              job_name=ipset-init-finalizer module_id=ipset                                         1.000000
cilium_hive_jobs_runs_total                                              job_name=k8s-secrets-resource-events-cilium-secrets module_id=envoy-proxy             1.000000
cilium_hive_jobs_runs_total                                              job_name=l2-announcer-lease-gc module_id=l2-announcer                                 1.000000
cilium_hive_jobs_runs_total                                              job_name=nat-map-next4 module_id=ct-nat-map-gc                                        2518.000000
cilium_hive_jobs_runs_total                                              job_name=nat-stats module_id=nat-stats                                                343.000000
cilium_hive_jobs_runs_total                                              job_name=per-endpoint-route-initializer module_id=loader                              1.000000
cilium_hive_jobs_runs_total                                              job_name=pressure-metric-subnet_map module_id=subnet-map                              342.000000
cilium_hive_jobs_runs_total                                              job_name=pressure-metric-throttle module_id=bwmap                                     1.000000
cilium_hive_jobs_runs_total                                              job_name=pressure-metrics-reporter module_id=loadbalancer-maps                        34.000000
cilium_hive_jobs_runs_total                                              job_name=proxy-bootstrapper module_id=dns-proxy                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=proxy-ports-checkpoint module_id=l7-proxy                                    172.000000
cilium_hive_jobs_runs_total                                              job_name=proxy-ports-restore module_id=l7-proxy                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=registry module_id=registry                                                  1.000000
cilium_hive_jobs_runs_total                                              job_name=release-local-identities module_id=ipcache                                   1.000000
cilium_hive_jobs_runs_total                                              job_name=start-reconciler module_id=loadbalancer-reconciler                           1.000000
cilium_hive_jobs_runs_total                                              job_name=sync module_id=link-cache                                                    684.000000
cilium_hive_jobs_runs_total                                              job_name=sync-crds module_id=k8s-synced-crdsync                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=sync-userspace-and-datapath module_id=utime                                  172.000000
cilium_hive_jobs_runs_total                                              job_name=unlock-lockfile module_id=endpoint-api                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=update-config-metric module_id=enabled-features                              1.000000
cilium_hive_jobs_runs_total                                              job_name=validate-unchanged-daemon-config module_id=daemonconfig                      168.000000
cilium_hive_jobs_runs_total                                              job_name=version-check module_id=envoy-proxy                                          85.000000
cilium_hive_jobs_runs_total                                              job_name=wait-for-endpoint-restore module_id=ep-bpf-prog-watchdog                     1.000000
cilium_hive_jobs_runs_total                                              job_name=wait-for-endpoint-restore module_id=namemanager                              1.000000
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=cleanup module_id=metrics                                                    0.000072
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=dns-garbage-collector-job module_id=namemanager                              0.000024
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=ep-bpf-prog-watchdog module_id=ep-bpf-prog-watchdog                          0.000636
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=hubble-namespace-cleanup module_id=hubble                                    0.000002
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=nat-stats module_id=nat-stats                                                0.000318
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=pressure-metric-subnet_map module_id=subnet-map                              0.000001
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=pressure-metrics-reporter module_id=loadbalancer-maps                        0.000471
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=proxy-ports-checkpoint module_id=l7-proxy                                    0.000225
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=sync module_id=link-cache                                                    0.000207
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=sync-userspace-and-datapath module_id=utime                                  0.000100
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=validate-unchanged-daemon-config module_id=daemonconfig                      0.000068
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=version-check module_id=envoy-proxy                                          0.002386
cilium_hive_jobs_timer_run_duration_seconds                              job_name=cleanup module_id=metrics                                                    250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=dns-garbage-collector-job module_id=namemanager                              250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=ep-bpf-prog-watchdog module_id=ep-bpf-prog-watchdog                          750.7µs / 951.3µs / 996.5µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=hubble-namespace-cleanup module_id=hubble                                    250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=nat-stats module_id=nat-stats                                                251.5µs / 452.6µs / 497.9µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=pressure-metric-subnet_map module_id=subnet-map                              250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=pressure-metrics-reporter module_id=loadbalancer-maps                        303.6µs / 716.7µs / 971.7µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=proxy-ports-checkpoint module_id=l7-proxy                                    251.5µs / 452.6µs / 497.9µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=sync module_id=link-cache                                                    250.4µs / 450.7µs / 495.7µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=sync-userspace-and-datapath module_id=utime                                  251.5µs / 452.6µs / 497.9µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=validate-unchanged-daemon-config module_id=daemonconfig                      250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=version-check module_id=envoy-proxy                                          1.873ms / 3.229ms / 4.823ms
cilium_hive_populate_duration                                                                                                                                  0.353099
cilium_hive_start_duration                                                                                                                                     0.352424
cilium_hive_status                                                       status=ok                                                                             78.000000
cilium_identity                                                          type=cluster_local                                                                    1.000000
cilium_identity                                                          type=reserved                                                                         14.000000
cilium_identity_label_sources                                            source=gen                                                                            1.000000
cilium_identity_label_sources                                            source=k8s                                                                            1.000000
cilium_identity_label_sources                                            source=reserved                                                                       14.000000
cilium_identity_updater_timer_duration                                   name=id-alloc-update-policy-maps                                                      2.5m / 4.5m / 4.95m
cilium_identity_updater_timer_trigger_folds                              name=id-alloc-update-policy-maps                                                      750m / 950m / 995m
cilium_identity_updater_timer_trigger_latency                            name=id-alloc-update-policy-maps                                                      2.5m / 4.5m / 4.95m
cilium_ip_addresses                                                      family=ipv4                                                                           3.000000
cilium_ip_addresses                                                      family=ipv6                                                                           0.000000
cilium_ipam_capacity                                                     cidr=10.244.1.0/24 family=ipv4                                                        254.000000
cilium_ipam_events_total                                                 action=allocate family=ipv4                                                           4.000000
cilium_ipam_events_total                                                 action=release family=ipv4                                                            1.000000
cilium_ipcache_errors_total                                              error=cannot_overwrite_by_source type=upsert                                          2.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=DELETE return_code=200                      2.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=200                         484.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=403                         1.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=404                         2.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=POST return_code=201                        3.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=PUT return_code=200                         1.000000
cilium_k8s_client_api_latency_time_seconds                               method=DELETE path=/apis/cilium.io/v2/namespaces/{namespace}/ciliumendpoints/{name}   10ms / 22ms / 24.7ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/api/v1/namespaces/{name}                                             17.5ms / 23.5ms / 24.85ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/apiextensions.k8s.io/v1/customresourcedefinitions               2.5ms / 4.5ms / 4.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/cilium.io/v2/ciliumnodes/{name}                                 7.5ms / 9.5ms / 9.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/cilium.io/v2/namespaces/{namespace}/ciliumendpoints/{name}      2.5ms / 4.5ms / 4.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/coordination.k8s.io/v1/namespaces/{namespace}/leases            17.5ms / 23.5ms / 24.85ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/readyz                                                               2.5ms / 4.5ms / 4.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/version                                                              2.708ms / 4.875ms / 23.05ms
cilium_k8s_client_api_latency_time_seconds                               method=POST path=/apis/cilium.io/v2/ciliumidentities                                  7.5ms / 9.5ms / 9.95ms
cilium_k8s_client_api_latency_time_seconds                               method=POST path=/apis/cilium.io/v2/namespaces/{namespace}/ciliumendpoints            10ms / 22ms / 24.7ms
cilium_k8s_client_api_latency_time_seconds                               method=PUT path=/apis/cilium.io/v2/ciliumnodes/{name}                                 17.5ms / 23.5ms / 24.85ms
cilium_k8s_client_rate_limiter_duration_seconds                                                                                                                2.5ms / 4.5ms / 4.95ms
cilium_k8s_terminating_endpoints_events_total                                                                                                                  0.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumcidrgroup                                                                  1.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumclusterwidenetworkpolicy                                                   1.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumnetworkpolicy                                                              1.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumnode                                                                       8.000000
cilium_k8s_workqueue_adds_total                                          name=networkpolicy                                                                    1.000000
cilium_k8s_workqueue_adds_total                                          name=node                                                                             41.000000
cilium_k8s_workqueue_adds_total                                          name=secret                                                                           1.000000
cilium_k8s_workqueue_depth                                               name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_depth                                               name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_depth                                               name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_depth                                               name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_depth                                               name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_depth                                               name=node                                                                             1.000000
cilium_k8s_workqueue_depth                                               name=secret                                                                           0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=node                                                                             0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=secret                                                                           0.000000
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumcidrgroup                                                                  5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumclusterwidenetworkpolicy                                                   5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumnetworkpolicy                                                              5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumnode                                                                       77.5µs / 64ms / 96.4ms
cilium_k8s_workqueue_queue_duration_seconds                              name=networkpolicy                                                                    5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=node                                                                             6.625µs / 55µs / 95.5µs
cilium_k8s_workqueue_queue_duration_seconds                              name=secret                                                                           55µs / 91µs / 99.1µs
cilium_k8s_workqueue_retries_total                                       name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_retries_total                                       name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_retries_total                                       name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_retries_total                                       name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_retries_total                                       name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_retries_total                                       name=node                                                                             0.000000
cilium_k8s_workqueue_retries_total                                       name=secret                                                                           0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=node                                                                             0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=secret                                                                           0.000000
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumcidrgroup                                                                  5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumclusterwidenetworkpolicy                                                   5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumnetworkpolicy                                                              5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumnode                                                                       550µs / 7.6ms / 9.76ms
cilium_k8s_workqueue_work_duration_seconds                               name=networkpolicy                                                                    5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_work_duration_seconds                               name=node                                                                             60.14µs / 122.5µs / 912.2µs
cilium_k8s_workqueue_work_duration_seconds                               name=secret                                                                           55µs / 91µs / 99.1µs
cilium_kubernetes_events_received_total                                  action=create equal=false scope=CiliumEndpoint valid=true                             5.000000
cilium_kubernetes_events_received_total                                  action=create equal=false scope=Pod valid=true                                        1.000000
cilium_kubernetes_events_received_total                                  action=delete equal=false scope=CiliumEndpoint valid=true                             2.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=CiliumEndpoint valid=true                             1.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=CiliumNode valid=true                                 4.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=Node valid=true                                       36.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=Pod valid=true                                        13.000000
cilium_kubernetes_events_total                                           action=delete scope=CiliumEndpoint status=success                                     2.000000
cilium_kubernetes_events_total                                           action=update scope=CiliumEndpoint status=success                                     6.000000
cilium_kubernetes_events_total                                           action=update scope=CiliumNode status=success                                         7.000000
cilium_kubernetes_events_total                                           action=update scope=Node status=success                                               38.000000
cilium_kubernetes_resource_sync_duration                                 scope=CiliumCIDRGroup                                                                 0.487752
cilium_kubernetes_resource_sync_duration                                 scope=CiliumClusterwideNetworkPolicy                                                  0.487692
cilium_kubernetes_resource_sync_duration                                 scope=CiliumEndpoint                                                                  0.695010
cilium_kubernetes_resource_sync_duration                                 scope=CiliumNetworkPolicy                                                             0.487645
cilium_kubernetes_resource_sync_duration                                 scope=CiliumNode                                                                      0.612379
cilium_kubernetes_resource_sync_duration                                 scope=NetworkPolicy                                                                   0.487570
cilium_kubernetes_resource_sync_duration                                 scope=Node                                                                            0.451809
cilium_kubernetes_resource_sync_duration                                 scope=Secret                                                                          0.494070
cilium_localredirectpolicy_controller_duration_seconds                                                                                                         0s / 0s / 0s
cilium_nat_endpoint_max_connection                                       family=ipv4                                                                           0.000244
cilium_nat_endpoint_max_connection                                       family=ipv6                                                                           0.000000
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=http type=endpoint                                      765.2µs / 2.142ms / 11.8ms
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=http type=node                                          526.9µs / 948.5µs / 2.207ms
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=icmp type=endpoint                                      508.7µs / 915.6µs / 1.93ms
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=icmp type=node                                          500µs / 900µs / 990µs
cilium_node_health_connectivity_status                                   status=reachable type=endpoint                                                        2.000000
cilium_node_health_connectivity_status                                   status=reachable type=node                                                            2.000000
cilium_node_health_connectivity_status                                   status=unknown type=endpoint                                                          0.000000
cilium_node_health_connectivity_status                                   status=unknown type=node                                                              0.000000
cilium_node_health_connectivity_status                                   status=unreachable type=endpoint                                                      1.000000
cilium_node_health_connectivity_status                                   status=unreachable type=node                                                          1.000000
cilium_nodes_all_datapath_validations_total                                                                                                                    369.000000
cilium_nodes_all_events_received_total                                   event_type=add source=custom-resource                                                 2.000000
cilium_nodes_all_events_received_total                                   event_type=add source=local                                                           1.000000
cilium_nodes_all_num                                                                                                                                           3.000000
cilium_policy                                                                                                                                                  0.000000
cilium_policy_change_total                                               operation=delete outcome=fail source=custom-resource                                  0.000000
cilium_policy_change_total                                               operation=delete outcome=fail source=directory                                        0.000000
cilium_policy_change_total                                               operation=delete outcome=fail source=k8s                                              0.000000
cilium_policy_change_total                                               operation=delete outcome=success source=custom-resource                               0.000000
cilium_policy_change_total                                               operation=delete outcome=success source=directory                                     0.000000
cilium_policy_change_total                                               operation=delete outcome=success source=k8s                                           0.000000
cilium_policy_change_total                                               operation=update outcome=fail source=custom-resource                                  0.000000
cilium_policy_change_total                                               operation=update outcome=fail source=directory                                        0.000000
cilium_policy_change_total                                               operation=update outcome=fail source=k8s                                              0.000000
cilium_policy_change_total                                               operation=update outcome=success source=custom-resource                               0.000000
cilium_policy_change_total                                               operation=update outcome=success source=directory                                     0.000000
cilium_policy_change_total                                               operation=update outcome=success source=k8s                                           0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=audit-both                                                                0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=audit-egress                                                              0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=audit-ingress                                                             0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=both                                                                      0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=egress                                                                    0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=ingress                                                                   0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=none                                                                      3.000000
cilium_policy_implementation_delay                                       source=api                                                                            0 / 0 / 0
cilium_policy_implementation_delay                                       source=custom-resource                                                                0 / 0 / 0
cilium_policy_implementation_delay                                       source=k8s                                                                            0 / 0 / 0
cilium_policy_incremental_update_duration                                scope=global                                                                          100µ / 820µ / 982µ
cilium_policy_l7_total                                                   proxy_type=envoy rule=denied                                                          0.000000
cilium_policy_l7_total                                                   proxy_type=envoy rule=forwarded                                                       0.000000
cilium_policy_l7_total                                                   proxy_type=envoy rule=parse_errors                                                    0.000000
cilium_policy_l7_total                                                   proxy_type=envoy rule=received                                                        0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=denied                                                           0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=forwarded                                                        0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=parse_errors                                                     0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=received                                                         0.000000
cilium_policy_max_revision                                                                                                                                     0.000000
cilium_policy_missing_proxy_redirects                                                                                                                          0.000000
cilium_policy_selector_cache_identities                                  type=peer                                                                             18.000000
cilium_policy_selector_cache_operation_duration_seconds                  operation=identity_updates scope=lock type=peer                                       250µs / 450µs / 495µs
cilium_policy_selector_cache_operation_duration_seconds                  operation=identity_updates scope=operation type=peer                                  250µs / 450µs / 495µs
cilium_policy_selector_cache_selectors                                   type=peer                                                                             0.000000
cilium_policy_selector_match_count_max                                   class=cluster                                                                         0.000000
cilium_policy_selector_match_count_max                                   class=fqdn                                                                            0.000000
cilium_policy_selector_match_count_max                                   class=other                                                                           0.000000
cilium_policy_selector_match_count_max                                   class=world                                                                           0.000000
cilium_process_cpu_seconds_total                                                                                                                               200.280000
cilium_process_max_fds                                                                                                                                         524287.000000
cilium_process_network_receive_bytes_total                                                                                                                     23906957.000000
cilium_process_network_transmit_bytes_total                                                                                                                    17228345.000000
cilium_process_open_fds                                                                                                                                        104.000000
cilium_process_resident_memory_bytes                                                                                                                           187035648.000000
cilium_process_start_time_seconds                                                                                                                              1791630056.820000
cilium_process_virtual_memory_bytes                                                                                                                            1567965184.000000
cilium_process_virtual_memory_max_bytes                                                                                                                        18446744073709551616.000000
cilium_subprocess_start_total                                            subsystem=cilium-health                                                               1.000000
cilium_unreachable_health_endpoints                                                                                                                            1.000000
cilium_unreachable_nodes                                                                                                                                       1.000000
cilium_version                                                           arch=linux/amd64 revision=e0dc92bd version=1.20.2                                     0.000000
go_gc_duration_seconds                                                                                                                                         p0(43.81µs) p25(46.91µs) p50(48.71µs) p75(60.34µs) p100(4.35ms)
go_gc_gogc_percent                                                                                                                                             100.000000
go_gc_gomemlimit_bytes                                                                                                                                         10248142848.000000
go_goroutines                                                                                                                                                  377.000000
go_info                                                                  version=go1.26.8                                                                      1.000000
go_memstats_alloc_bytes                                                                                                                                        63610784.000000
go_memstats_alloc_bytes_total                                                                                                                                  1436607824.000000
go_memstats_buck_hash_sys_bytes                                                                                                                                1893410.000000
go_memstats_frees_total                                                                                                                                        15379050.000000
go_memstats_gc_sys_bytes                                                                                                                                       5079824.000000
go_memstats_heap_alloc_bytes                                                                                                                                   63610784.000000
go_memstats_heap_idle_bytes                                                                                                                                    20848640.000000
go_memstats_heap_inuse_bytes                                                                                                                                   79749120.000000
go_memstats_heap_objects                                                                                                                                       495792.000000
go_memstats_heap_released_bytes                                                                                                                                15597568.000000
go_memstats_heap_sys_bytes                                                                                                                                     100597760.000000
go_memstats_last_gc_time_seconds                                                                                                                               1791640277.026428
go_memstats_mallocs_total                                                                                                                                      15874842.000000
go_memstats_mcache_inuse_bytes                                                                                                                                 4592.000000
go_memstats_mcache_sys_bytes                                                                                                                                   16072.000000
go_memstats_mspan_inuse_bytes                                                                                                                                  1089600.000000
go_memstats_mspan_sys_bytes                                                                                                                                    1158720.000000
go_memstats_next_gc_bytes                                                                                                                                      104431850.000000
go_memstats_other_sys_bytes                                                                                                                                    720700.000000
go_memstats_stack_inuse_bytes                                                                                                                                  4259840.000000
go_memstats_stack_sys_bytes                                                                                                                                    4259840.000000
go_memstats_sys_bytes                                                                                                                                          113726326.000000
go_sched_gomaxprocs_threads                                                                                                                                    2.000000
go_sched_latencies_seconds                                                                                                                                     4.613µs / 46.08µs / 80.94µs
go_threads                                                                                                                                                     14.000000

