top - 13:52:07 up  2:51,  0 users,  load average: 1.41, 0.44, 0.26
Tasks:   5 total,   2 running,   3 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.0 us, 34.8 sy,  0.0 ni, 34.8 id,  4.3 wa,  0.0 hi,  0.0 si, 13.0 st 
MiB Mem :   9873.4 total,   7861.1 free,    947.2 used,   1338.2 buff/cache     
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   8926.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1531216 182664  94044 S  10.0   1.8   3:20.27 cilium-+
    100 root      20   0 1264140   6576   4728 S   0.0   0.1   0:00.10 cilium-+
   1118 root      20   0 1270588  14404   9404 S   0.0   0.1   0:00.07 cilium-+
   1150 root      20   0    7592   5016   3040 R   0.0   0.0   0:00.00 top
   1186 root      20   0    9940   2004   1476 R   0.0   0.0   0:00.00 lsmod
