CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
328      cgroup_inet_sock_release multi           cil_sock_release                
329      cgroup_inet4_post_bind multi           cil_sock4_post_bind                
326      cgroup_inet6_post_bind multi           cil_sock6_post_bind                
323      cgroup_inet4_connect multi           cil_sock4_connect                
319      cgroup_inet6_connect multi           cil_sock6_connect                
320      cgroup_inet4_getpeername multi           cil_sock4_getpeername                
325      cgroup_inet6_getpeername multi           cil_sock6_getpeername                
321      cgroup_udp4_sendmsg multi           cil_sock4_sendmsg                
327      cgroup_udp6_sendmsg multi           cil_sock6_sendmsg                
324      cgroup_udp4_recvmsg multi           cil_sock4_recvmsg                
322      cgroup_udp6_recvmsg multi           cil_sock6_recvmsg                
61       cgroup_sysctl   multi           sysctl_monitor                 
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    55       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    54       cgroup_inet_ingress multi           sd_fw_ingress                  
    53       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/polkit.service
    64       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    51       cgroup_inet_ingress multi           sd_fw_ingress                  
    50       cgroup_inet_egress multi           sd_fw_egress                   
    49       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chrony.service
    63       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    52       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    67       cgroup_inet_ingress multi           sd_fw_ingress                  
    66       cgroup_inet_egress multi           sd_fw_egress                   
    65       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd13195dd_935d_471c_90da_2db8b9c8ea55.slice/cri-containerd-bcc7a7b3f1184f6e67139e89580981aa3a7929b2bd07981e92c889fbc8a34a49.scope
    92       cgroup_device   multi           sd_devices                     
    96       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd13195dd_935d_471c_90da_2db8b9c8ea55.slice/cri-containerd-f12b8a99a801738a776069e99e133da93d6b0821cd3666d04b628a6126efecba.scope
    171      cgroup_device   multi           sd_devices                     
    175      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a39a2cd_4183_4902_bb5f_a061bf0af454.slice/cri-containerd-eb8341c36d93aa222e960548f5aea6991fa35464d4ad866e6fb9f0beb6d06193.scope
    87       cgroup_device   multi           sd_devices                     
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a39a2cd_4183_4902_bb5f_a061bf0af454.slice/cri-containerd-2576d376d28d986f4c7b8449c60311e76b75fe4cb109f9842faca3426cd17956.scope
    107      cgroup_device   multi           sd_devices                     
    111      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a39a2cd_4183_4902_bb5f_a061bf0af454.slice/cri-containerd-391beeeb7cf8b75e3e7aaebcb7bc3d17e48df4bb3979fcfb89cae4e8b0d5036c.scope
    127      cgroup_device   multi           sd_devices                     
    131      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a39a2cd_4183_4902_bb5f_a061bf0af454.slice/cri-containerd-928d20fd45710513e59ec9106ab4df78a4682d788a9b5d71f88e439ab91d1f7b.scope
    147      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a39a2cd_4183_4902_bb5f_a061bf0af454.slice/cri-containerd-50f1462ae9874dfbf99f2694c1d108ba7b816091275104bfdab2cbd36526b7ce.scope
    132      cgroup_device   multi           sd_devices                     
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a39a2cd_4183_4902_bb5f_a061bf0af454.slice/cri-containerd-4a04feb8db32a082edae9b5b9e769177257998e56b249cc13ce43b935b7a8a5d.scope
    140      cgroup_device   multi           sd_devices                     
    144      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fc18e80_7bec_4949_81ae_d13059037def.slice/cri-containerd-5ba92be6de704394997c4dfe2e2300ff28eb82e945480e2bbf0d0cd129a541cd.scope
    72       cgroup_device   multi           sd_devices                     
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fc18e80_7bec_4949_81ae_d13059037def.slice/cri-containerd-92afb15149d1298b70ceb50d008a5c179fab4fab0d2d3bc772b1cae990dd5652.scope
    102      cgroup_device   multi           sd_devices                     
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fc18e80_7bec_4949_81ae_d13059037def.slice/cri-containerd-044b64e43c4b74a56ee13c285c76ba03b8dcdf369017971a21b1ad6df6b7b1bc.scope
    139      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fc18e80_7bec_4949_81ae_d13059037def.slice/cri-containerd-fd472eb846b934c0f08cefd6ba3aa030afc1f054c3f70939406222ec886aa9e8.scope
    122      cgroup_device   multi           sd_devices                     
    126      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9268a9b_2a62_462a_8372_701f00e7bdf8.slice/cri-containerd-88a7af6568dff9b6ed4da216af48cfe45acbc701b91ebf21a19c7bbf3c84d55f.scope
    289      cgroup_device   multi           sd_devices                     
    293      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9268a9b_2a62_462a_8372_701f00e7bdf8.slice/cri-containerd-3d4d9f0047ad4a4c5940cb9ee8d9c62f680b7671aecf3a9503ae097338adb416.scope
    308      cgroup_device   multi           sd_devices                     
    312      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec248204_25d4_4a94_9787_4608e9d0afa7.slice/cri-containerd-743997d9c9cb4d830c4120efc1907938de2b67f92a629c4f50efc27dd8cd9783.scope
    117      cgroup_device   multi           sd_devices                     
    121      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec248204_25d4_4a94_9787_4608e9d0afa7.slice/cri-containerd-6e6def07b949a5c860f06703a62c2f9be214d991c70ffb0b7c7bdca87b0c5d0c.scope
    82       cgroup_device   multi           sd_devices                     
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb95c705_554d_4f74_b4f7_bf66d99ea988.slice/cri-containerd-aa6e982a63792ccbbe7468f2cc4caac4a2a33e2b9a391d7c7284712e9d43ca1d.scope
    97       cgroup_device   multi           sd_devices                     
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb95c705_554d_4f74_b4f7_bf66d99ea988.slice/cri-containerd-1a08f8a97ce2f2849ca6a789c24f4a0def16b91fcdebfe79c0f802aa8712eb9e.scope
    77       cgroup_device   multi           sd_devices                     
    81       cgroup_device   multi                                          
