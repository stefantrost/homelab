KVStore:                Disabled   
Kubernetes:             Ok         1.37 (v1.37.1) [linux/amd64]
Kubernetes APIs:        ["cilium/v2::CiliumCIDRGroup", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "core/v1::Pods", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [ens18     192.168.178.114 fda7:7b49:a70a:0:be24:11ff:fede:cb0c 2a02:8071:5301:a0a0:be24:11ff:fede:cb0c fe80::be24:11ff:fede:cb0c (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.20.2 (v1.20.2-e0dc92bd)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 3/254 allocated from 10.244.1.0/24, 
Allocated addresses:
  10.244.1.173 (router)
  10.244.1.197 (health)
  10.244.1.214 (kube-system/coredns-559f6c778d-khtkb)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            TCX
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      18/18 healthy
  Name                                                  Last success   Last error   Count   Message
  cilium-health-ep                                      9s ago         never        0       no error   
  ct-map-pressure                                       10s ago        never        0       no error   
  endpoint-1644-regeneration-recovery                   never          never        0       no error   
  endpoint-3284-regeneration-recovery                   never          never        0       no error   
  endpoint-4046-regeneration-recovery                   never          never        0       no error   
  endpoint-gc                                           1m10s ago      never        0       no error   
  endpoint-periodic-regeneration                        55s ago        never        0       no error   
  ipcache-inject-labels                                 10s ago        never        0       no error   
  k8s-heartbeat                                         10s ago        never        0       no error   
  resolve-identity-1644                                 1m9s ago       never        0       no error   
  resolve-identity-3284                                 1m10s ago      never        0       no error   
  resolve-identity-4046                                 1m6s ago       never        0       no error   
  resolve-labels-kube-system/coredns-559f6c778d-khtkb   2h51m7s ago    never        0       no error   
  sync-policymap-1644                                   6m2s ago       never        0       no error   
  sync-policymap-3284                                   6m2s ago       never        0       no error   
  sync-policymap-4046                                   6m2s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (4046)                     6s ago         never        0       no error   
  write-cni-file                                        2h51m10s ago   never        0       no error   
Proxy Status:            OK, ip 10.244.1.173, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 3.25   Metrics: Disabled
KubeProxyReplacement Details:
  Status:               True
  Socket LB:            Enabled
  Socket LB Tracing:    Enabled
  Socket LB Coverage:   Hostns-only
  Devices:              ens18     192.168.178.114 fda7:7b49:a70a:0:be24:11ff:fede:cb0c 2a02:8071:5301:a0a0:be24:11ff:fede:cb0c fe80::be24:11ff:fede:cb0c (Direct Routing)
  Mode:                 SNAT
  Backend Selection:    Random
  Session Affinity:     Enabled
  NAT46/64 Support:     Disabled
  XDP Acceleration:     Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
  Annotations:
  - service.cilium.io/node
  - service.cilium.io/node-selector
  - service.cilium.io/proxy-delegation
  - service.cilium.io/src-ranges-policy
  - service.cilium.io/type
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoints                     65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  Ratelimit metrics             64
  NAT                           131072
  Neighbor table                131072
  Endpoint policy               16384
  Policy stats                  65536
  Session affinity              65536
  Sock reverse NAT              65536
Encryption:       Disabled        
Cluster health:   2/3 reachable   (2026-10-10T13:50:24Z)   (Probe interval: 1m56.754608943s)
Name              IP              Node                     Endpoints
  workernode01 (localhost):
    Host connectivity to 192.168.178.114:
      ICMP to stack:   OK, RTT=66.284µs   (Last probed: 2026-10-10T13:51:03Z)
      HTTP to agent:   OK, RTT=412.23µs   (Last probed: 2026-10-10T13:51:03Z)
    Endpoint connectivity to 10.244.1.197:
      ICMP to stack:   OK, RTT=105.597µs   (Last probed: 2026-10-10T13:51:23Z)
      HTTP to agent:   OK, RTT=333.271µs   (Last probed: 2026-10-10T13:51:23Z)
  controlplane:
    Host connectivity to 192.168.178.113:
      ICMP to stack:   OK, RTT=260.635µs                                                                                     (Last probed: 2026-10-10T13:50:24Z)
      HTTP to agent:   Get "http://192.168.178.113:4240/hello": dial tcp 192.168.178.113:4240: connect: connection refused   (Last probed: 2026-10-10T13:50:24Z)
    Endpoint connectivity to 10.244.0.27:
      ICMP to stack:   Connection timed out                                                                                              (Last probed: 2026-10-10T13:50:54Z)
      HTTP to agent:   Get "http://10.244.0.27:4240/hello": context deadline exceeded (Client.Timeout exceeded while awaiting headers)   (Last probed: 2026-10-10T13:50:54Z)
  workernode02:
    Host connectivity to 192.168.178.115:
      ICMP to stack:   OK, RTT=296.715µs   (Last probed: 2026-10-10T13:51:42Z)
      HTTP to agent:   OK, RTT=849.463µs   (Last probed: 2026-10-10T13:51:42Z)
    Endpoint connectivity to 10.244.2.84:
      ICMP to stack:   OK, RTT=446.289µs    (Last probed: 2026-10-10T13:52:02Z)
      HTTP to agent:   OK, RTT=1.140212ms   (Last probed: 2026-10-10T13:52:02Z)
Modules Health:        Stopped(0) Degraded(0) OK(78)
  agent
  ├── controlplane
  │   ├── cgroup-manager
  │   │   └── job-process-pod-events                              [OK] Running (171m, x1)
  │   ├── cilium-agent-dynamic-config
  │   │   └── job-k8s-reflector-cilium-configs-cm-cilium-config-kube-system      [OK] 161 upserted, 0 deleted, 161 total objects (171m, x1)
  │   ├── ciliumenvoyconfig
  │   │   ├── job-node-labels                                     [OK] Running (171m, x1)
  │   │   ├── job-reconcile                                       [OK] OK, 0 object(s) (171m, x3)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (21m, x6)
  │   ├── config-drift-checker
  │   │   └── job-drift-checker                                   [OK] Running (171m, x1)
  │   ├── daemonconfig
  │   │   └── timer-job-validate-unchanged-daemon-config          [OK] OK (68.158µs) (22s, x1)
  │   ├── dynamic-lifecycle-manager
  │   │   ├── job-reconcile                                       [OK] OK, 0 object(s) (51m, x4)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (21m, x6)
  │   ├── endpoint-manager
  │   │   ├── cilium-endpoint-1644 (/)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (55s, x88)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-1644 (6m2s, x12)
  │   │   ├── cilium-endpoint-3284 (/)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (55s, x88)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-3284 (6m2s, x12)
  │   │   ├── cilium-endpoint-4046 (kube-system/coredns-559f6c778d-khtkb)
  │   │   │   ├── cep-k8s-sync                                    [OK] sync-to-k8s-ciliumendpoint (4046) (6s, x1028)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (55s, x87)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-4046 (6m2s, x12)
  │   │   ├── endpoint-gc                                         [OK] endpoint-gc (70s, x35)
  │   │   └── job-namespace-updater                               [OK] Running (171m, x1)
  │   ├── envoy-proxy
  │   │   ├── job-accesslog-server                                [OK] Running (171m, x1)
  │   │   ├── job-xds-server                                      [OK] Running (171m, x1)
  │   │   ├── observer-job-k8s-secrets-resource-events-cilium-secrets      [OK] Primed (171m, x1)
  │   │   └── timer-job-version-check                             [OK] OK (2.386014ms) (70s, x1)
  │   ├── ep-bpf-prog-watchdog
  │   │   └── timer-job-ep-bpf-prog-watchdog                      [OK] OK (635.816µs) (10s, x1)
  │   ├── fqdn
  │   │   └── namemanager
  │   │       ├── observer-job-preallocate                        [OK] Primed (171m, x1)
  │   │       └── timer-job-dns-garbage-collector-job             [OK] OK (24.246µs) (10s, x1)
  │   ├── hostip-sync
  │   │   └── job-sync-hostips                                    [OK] Synchronized (10s, x174)
  │   ├── hubble
  │   │   └── timer-job-hubble-namespace-cleanup                  [OK] OK (1.782µs) (70s, x1)
  │   ├── identity-policy-computer
  │   │   └── job-policy-computation-loop                         [OK] Running (171m, x1)
  │   ├── ipam
  │   │   └── ipam-podippool-table
  │   │       └── job-k8s-reflector-podippools-daemon-k8s         [OK] 0 upserted, 0 deleted, 0 total objects (171m, x1)
  │   ├── ipcache
  │   │   └── job-api-server-backend-watcher                      [OK] Running (171m, x1)
  │   ├── k8s-tables
  │   │   ├── job-k8s-reflector-k8s-namespaces-daemon-k8s         [OK] 5 upserted, 0 deleted, 5 total objects (171m, x1)
  │   │   └── job-k8s-reflector-k8s-pods-daemon-k8s               [OK] 1 upserted, 0 deleted, 7 total objects (23m, x6)
  │   ├── l7-proxy
  │   │   └── timer-job-proxy-ports-checkpoint                    [OK] OK (224.586µs) (10s, x1)
  │   ├── loadbalancer-healthserver
  │   │   └── job-control-loop                                    [OK] 0 health servers running (20m, x53)
  │   ├── loadbalancer-maps
  │   │   └── timer-job-pressure-metrics-reporter                 [OK] OK (471.278µs) (70s, x1)
  │   ├── loadbalancer-reconciler
  │   │   ├── job-reconcile                                       [OK] OK, 7 object(s) (20m, x123)
  │   │   ├── job-refresh                                         [OK] Next refresh in 29m40.097178965s (20m, x1)
  │   │   └── socket-termination
  │   │       └── job-socket-termination                          [OK] Running (171m, x1)
  │   ├── loadbalancer-reflectors
  │   │   └── k8s-reflector
  │   │       ├── job-reflect-pods                                [OK] Running (171m, x1)
  │   │       └── job-reflect-services-endpoints                  [OK] Running (171m, x1)
  │   ├── loadbalancer-writer
  │   │   ├── job-node-addr-reconciler                            [OK] Running (171m, x1)
  │   │   └── job-wildcard-addr-reconciler                        [OK] Running (171m, x1)
  │   ├── local-node-store
  │   │   └── job-sync-local-node                                 [OK] Running (171m, x1)
  │   ├── nat-stats
  │   │   └── timer-job-nat-stats                                 [OK] OK (317.577µs) (10s, x1)
  │   ├── node-manager
  │   │   ├── job-backgroundSync                                  [OK] Node validation successful (63s, x123)
  │   │   ├── node-checkpoint-writer                              [OK] node checkpoint written (170m, x2)
  │   │   └── nodes-add                                           [OK] Node adds successful (171m, x3)
  │   ├── policy
  │   │   ├── observer-job-policy-importer                        [OK] Primed (171m, x1)
  │   │   └── timer-job-id-alloc-update-policy-maps               [OK] OK (53.39µs) (23m, x1)
  │   ├── status
  │   │   └── job-probes                                          [OK] Running (171m, x1)
  │   └── ztunnel
  │       └── enrollment-reconciler
  │           └── job-derive-desired-mtls-namespace-enrollments    [OK] Running (171m, x1)
  ├── datapath
  │   ├── agent-liveness-updater
  │   │   └── timer-job-agent-liveness-updater                    [OK] OK (29.004µs) (0s, x1)
  │   ├── device-reconciler
  │   │   ├── job-reconcile                                       [OK] OK, 0 object(s) (21m, x7)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (21m, x6)
  │   ├── iptables
  │   │   ├── ipset
  │   │   │   ├── job-reconcile                                   [OK] OK, 0 object(s) (51m, x4)
  │   │   │   └── job-refresh                                     [OK] Next refresh in 30m0s (21m, x6)
  │   │   └── job-iptables-reconciliation-loop                    [OK] iptables rules full reconciliation completed (21m, x5)
  │   ├── l2-responder
  │   │   └── job-l2-responder-reconciler                         [OK] Running (171m, x1)
  │   ├── link-cache
  │   │   └── timer-job-sync                                      [OK] OK (206.502µs) (10s, x1)
  │   ├── maps
  │   │   ├── ct-nat-map-gc
  │   │   │   ├── observer-job-nat-map-next4                      [OK] OK (637ns) [1666] (10m, x1)
  │   │   │   └── observer-job-nat-map-next6                      [OK] Primed (171m, x1)
  │   │   ├── netdev-map
  │   │   │   └── netdev-map-sync
  │   │   │       └── job-netdev-map-sync                         [OK] Running (171m, x1)
  │   │   └── subnet-map
  │   │       └── timer-job-pressure-metric-subnet_map            [OK] OK (1.38µs) (10s, x1)
  │   ├── mtu
  │   │   ├── job-endpoint-mtu-updater                            [OK] Endpoint MTU updated (171m, x1)
  │   │   └── job-mtu-updater                                     [OK] MTU updated (1500) (171m, x1)
  │   ├── node-address
  │   │   └── job-node-address-update                             [OK] 10.244.1.173 (primary), fe80::cc2:32ff:fe9b:4bfb (171m, x1)
  │   ├── orchestrator
  │   │   └── job-reinitialize                                    [OK] OK (170m, x2)
  │   ├── route-reconciler
  │   │   ├── job-desired-route-refresher                         [OK] Running (171m, x1)
  │   │   ├── job-reconcile                                       [OK] OK, 1 object(s) (20m, x30)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (20m, x5)
  │   ├── sysctl
  │   │   ├── job-reconcile                                       [OK] OK, 20 object(s) (62s, x381)
  │   │   └── job-refresh                                         [OK] Next refresh in 9m51.500987257s (62s, x1)
  │   └── utime
  │       └── timer-job-sync-userspace-and-datapath               [OK] OK (99.853µs) (10s, x1)
  └── infra
      ├── agent-healthz
      │   └── job-agent-healthz-server-ipv4                       [OK] Running (171m, x1)
      ├── metrics
      │   ├── job-collect                                         [OK] Sampled 24 metrics in 2.903526ms, next collection at 2026-10-10 13:55:58.844597982 +0000 UTC m=+10501.361211946 (70s, x1)
      │   └── timer-job-cleanup                                   [OK] OK (71.655µs) (51m, x1)
      └── shell
          └── job-listener                                        [OK] Listening on /var/run/cilium/shell.sock (171m, x1)
  health
  └── job-module-status-metrics                   [OK] Running (171m, x1)
  

