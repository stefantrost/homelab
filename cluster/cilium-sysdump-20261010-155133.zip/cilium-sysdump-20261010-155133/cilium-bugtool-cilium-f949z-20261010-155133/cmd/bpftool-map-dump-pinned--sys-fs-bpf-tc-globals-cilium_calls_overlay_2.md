key: 01 00 00 00  value: 4d 01 00 00
key: 07 00 00 00  value: 4e 01 00 00
key: 0f 00 00 00  value: 50 01 00 00
key: 24 00 00 00  value: 4a 01 00 00
key: 26 00 00 00  value: 4b 01 00 00
key: 2d 00 00 00  value: 51 01 00 00
Found 6 elements
