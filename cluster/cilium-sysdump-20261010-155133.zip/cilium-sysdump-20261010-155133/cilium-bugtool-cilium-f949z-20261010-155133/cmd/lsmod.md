Module                  Size  Used by
tcp_diag               20480  0
xt_TPROXY              12288  2
nf_tproxy_ipv6         16384  1 xt_TPROXY
nf_tproxy_ipv4         16384  1 xt_TPROXY
nft_chain_nat          12288  3
xt_nat                 12288  3
xt_MASQUERADE          16384  1
nf_nat                 61440  3 xt_nat,nft_chain_nat,xt_MASQUERADE
xt_mark                12288  2
xt_CT                  16384  5
xt_tcpudp              16384  0
vxlan                 151552  0
cls_bpf                24576  0
sch_ingress            20480  0
veth                   45056  0
xt_socket              20480  1
nf_socket_ipv4         12288  1 xt_socket
nf_socket_ipv6         16384  1 xt_socket
ip_set                 61440  0
udp_diag               12288  0
inet_diag              24576  2 tcp_diag,udp_diag
geneve                 53248  0
ip6_udp_tunnel         16384  2 geneve,vxlan
udp_tunnel             36864  2 geneve,vxlan
xfrm_user              69632  3
xfrm_algo              16384  1 xfrm_user
xt_conntrack           12288  2
nf_conntrack          196608  5 xt_conntrack,nf_nat,xt_nat,xt_CT,xt_MASQUERADE
nf_defrag_ipv6         24576  3 nf_conntrack,xt_socket,xt_TPROXY
nf_defrag_ipv4         12288  3 nf_conntrack,xt_socket,xt_TPROXY
xt_comment             12288  33
nft_compat             20480  49
x_tables               65536  10 xt_conntrack,nft_compat,xt_socket,xt_tcpudp,xt_nat,xt_comment,xt_TPROXY,xt_CT,xt_MASQUERADE,xt_mark
nf_tables             401408  160 nft_compat,nft_chain_nat
scsi_transport_iscsi   176128  1
qrtr                   53248  2
overlay               233472  18
nfnetlink              20480  7 nft_compat,nf_tables,ip_set
cfg80211             1548288  0
isofs                  61440  0
sunrpc                860160  1
binfmt_misc            24576  1
intel_rapl_msr         20480  0
intel_rapl_common      57344  1 intel_rapl_msr
intel_pmc_core        151552  0
pmt_telemetry          16384  1 intel_pmc_core
pmt_discovery          24576  1 pmt_telemetry
pmt_class              20480  2 pmt_telemetry,pmt_discovery
intel_pmc_ssram_telemetry    16384  1 intel_pmc_core
intel_vsec             24576  2 intel_pmc_ssram_telemetry,pmt_telemetry
nls_iso8859_1          12288  1
kvm_intel             552960  0
kvm                  1527808  1 kvm_intel
irqbypass              16384  1 kvm
rapl                   20480  0
i2c_i801               36864  0
i2c_smbus              20480  1 i2c_i801
i2c_mux                20480  1 i2c_i801
lpc_ich                32768  0
vmgenid                12288  0
snd_hda_intel          65536  0
snd_hda_codec         212992  1 snd_hda_intel
snd_hda_core          151552  2 snd_hda_intel,snd_hda_codec
snd_intel_dspcfg       45056  1 snd_hda_intel
snd_intel_sdw_acpi     16384  1 snd_intel_dspcfg
snd_hwdep              24576  1 snd_hda_codec
snd_pcm               208896  3 snd_hda_intel,snd_hda_codec,snd_hda_core
snd_timer              53248  1 snd_pcm
snd                   147456  5 snd_hwdep,snd_hda_intel,snd_hda_codec,snd_timer,snd_pcm
soundcore              16384  1 snd
bochs                  24576  0
input_leds             12288  0
joydev                 32768  0
mac_hid                12288  0
sch_fq_codel           28672  1
efi_pstore             12288  0
dm_multipath           45056  0
vsock_loopback         12288  0
vmw_vsock_virtio_transport_common    61440  1 vsock_loopback
vmw_vsock_vmci_transport    53248  0
vsock                  73728  3 vmw_vsock_virtio_transport_common,vsock_loopback,vmw_vsock_vmci_transport
vmw_vmci              106496  1 vmw_vsock_vmci_transport
hid_generic            12288  0
ghash_clmulni_intel    12288  0
ahci                   53248  0
psmouse               225280  0
usbhid                 86016  0
hid                   282624  2 usbhid,hid_generic
libahci                57344  1 ahci
serio_raw              20480  0
msr                    12288  0
dmi_sysfs              28672  0
qemu_fw_cfg            24576  0
autofs4                61440  2
aesni_intel            98304  0
