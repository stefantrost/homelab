{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:47:14.329Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:47:14.329Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:49:14.330Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:49:14.331Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:51:14.332Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:51:14.333Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:53:14.334Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:53:14.334Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:55:14.335Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:55:14.335Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:57:14.337Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:57:14.337Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:59:14.339Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T11:59:14.339Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:01:14.340Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:01:14.341Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:03:14.342Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:03:14.342Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:05:14.344Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:05:14.344Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:07:14.345Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:07:14.345Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:09:14.346Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:09:14.346Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:11:14.347Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:11:14.347Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:13:14.349Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:13:14.349Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:15:14.350Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:15:14.350Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:17:14.351Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:17:14.351Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:19:14.352Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:19:14.352Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:21:14.354Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:21:14.354Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:23:14.355Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:23:14.355Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:25:14.357Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:25:14.357Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:27:14.358Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:27:14.359Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:29:14.359Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:29:14.360Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:31:14.361Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:31:14.361Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:33:14.363Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:33:14.363Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:35:14.364Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:35:14.364Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:37:14.366Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:37:14.366Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:39:14.367Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:39:14.367Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:41:14.368Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:41:14.369Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:43:14.370Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:43:14.370Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:45:14.372Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:45:14.373Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:47:14.373Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:47:14.374Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:49:14.375Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:49:14.376Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:51:14.377Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:51:14.378Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:53:14.379Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:53:14.379Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:55:14.381Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:55:14.381Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:57:14.382Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:57:14.382Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:59:14.383Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:59:14.383Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:01:14.384Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:01:14.385Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:03:14.386Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:03:14.386Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:05:14.387Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:05:14.387Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:07:14.389Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:07:14.389Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:09:14.391Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:09:14.391Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:11:14.392Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:11:14.393Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:13:14.393Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:13:14.393Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:15:14.395Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:15:14.395Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:17:14.396Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:17:14.397Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:19:14.398Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:19:14.399Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:21:14.399Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:21:14.400Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:23:14.400Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:23:14.401Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:25:14.401Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:25:14.402Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:27:14.403Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:27:14.404Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:28:39.556Z",
  "value": "id=1357  sec_id=19386 flags=0x0000 ifindex=11  mac=3A:B3:29:38:B6:F3 nodemac=F6:E8:5F:6A:6F:2D parent_ifindex=0   rt_info:0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.244.1.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:28:43.808Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:29:14.405Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:29:14.405Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:31:14.406Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:31:14.406Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:33:14.408Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:33:14.408Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:35:14.410Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:35:14.410Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:37:14.411Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:37:14.411Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:39:14.412Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:39:14.412Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:41:14.413Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:41:14.413Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:43:14.414Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:43:14.414Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:45:14.415Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:45:14.416Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:47:14.417Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:47:14.417Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:49:14.419Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:49:14.419Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:51:14.420Z",
  "value": "id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.1.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:51:14.420Z",
  "value": "id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0"
}

