{
  "local": {
    "name": "workernode01"
  },
  "nodes": [
    {
      "endpoint": {
        "http": {
          "lastProbed": "2026-10-10T13:50:54Z",
          "status": "Get \"http://10.244.0.27:4240/hello\": context deadline exceeded (Client.Timeout exceeded while awaiting headers)"
        },
        "icmp": {
          "lastProbed": "2026-10-10T13:50:54Z",
          "status": "Connection timed out"
        },
        "ip": "10.244.0.27"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:50:54Z",
            "status": "Get \"http://10.244.0.27:4240/hello\": context deadline exceeded (Client.Timeout exceeded while awaiting headers)"
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:50:54Z",
            "status": "Connection timed out"
          },
          "ip": "10.244.0.27"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:50:24Z",
            "status": "Get \"http://192.168.178.113:4240/hello\": dial tcp 192.168.178.113:4240: connect: connection refused"
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:50:24Z",
            "latency": 260635
          },
          "ip": "192.168.178.113"
        },
        "secondary-addresses": []
      },
      "name": "controlplane"
    },
    {
      "endpoint": {
        "http": {
          "lastProbed": "2026-10-10T13:51:23Z",
          "latency": 333271
        },
        "icmp": {
          "lastProbed": "2026-10-10T13:51:23Z",
          "latency": 105597
        },
        "ip": "10.244.1.197"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:51:23Z",
            "latency": 333271
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:51:23Z",
            "latency": 105597
          },
          "ip": "10.244.1.197"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:51:03Z",
            "latency": 412230
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:51:03Z",
            "latency": 66284
          },
          "ip": "192.168.178.114"
        },
        "secondary-addresses": []
      },
      "name": "workernode01"
    },
    {
      "endpoint": {
        "http": {
          "lastProbed": "2026-10-10T13:52:02Z",
          "latency": 1140212
        },
        "icmp": {
          "lastProbed": "2026-10-10T13:52:02Z",
          "latency": 446289
        },
        "ip": "10.244.2.84"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:52:02Z",
            "latency": 1140212
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:52:02Z",
            "latency": 446289
          },
          "ip": "10.244.2.84"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:51:42Z",
            "latency": 849463
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:51:42Z",
            "latency": 296715
          },
          "ip": "192.168.178.115"
        },
        "secondary-addresses": []
      },
      "name": "workernode02"
    }
  ],
  "probeInterval": "1m56.754608943s",
  "timestamp": "2026-10-10T13:50:24Z"
}

