key: 30 10 00 00 00 00 00 00  c0 a8 b2 71 19 2b 00 00  value: 0a 60 00 01 01 bb 00 06
key: 48 10 00 00 00 00 00 00  c0 a8 b2 71 19 2b 00 00  value: 0a 60 00 01 01 bb 00 06
key: 3f 10 00 00 00 00 00 00  c0 a8 b2 71 19 2b 00 00  value: 0a 60 00 01 01 bb 00 06
Found 3 elements
