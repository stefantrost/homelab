## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3499277369140625           
AgentLiveness   10315364747144             
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_snat_v4_external
Cache is empty


## Map: cilium_lb_affinity_match
Cache is empty


## Map: cilium_lb4_reverse_nat
Key   Value               State   Error
4     10.96.0.10:53               
7     10.101.247.67:443           
3     10.96.0.10:53               
6     10.96.0.1:443               
5     10.96.0.10:9153             
1     10.105.79.192:80            
2     10.97.123.232:80            

## Map: cilium_ct4_global
Key                                                     Value   State   Error
10.244.1.214:59016 --> 10.244.1.173:62751, 6, 1         expires=9724 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9714 TxFlagsSeen=0x1b LastTxReport=9714 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:45718 --> 192.168.178.114:11033, 6, 0   expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10311 TxFlagsSeen=0x1a LastTxReport=10311 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:52890 --> 10.244.1.173:62751, 6, 1         expires=10104 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10094 TxFlagsSeen=0x1b LastTxReport=10094 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:9415 --> 10.244.1.173:62751, 6, 1          expires=9994 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9984 TxFlagsSeen=0x1b LastTxReport=9984 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:23212 --> 10.244.1.173:62751, 6, 1         expires=10264 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10254 TxFlagsSeen=0x1b LastTxReport=10254 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:735 --> 10.244.1.173:36895, 6, 1           expires=10145 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10135 TxFlagsSeen=0x1b LastTxReport=10135 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:22238 --> 10.244.1.173:62751, 6, 1         expires=9714 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9704 TxFlagsSeen=0x1b LastTxReport=9704 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:34999 --> 10.244.1.173:36880, 6, 0          expires=10037 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=9977 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:32416 --> 10.244.1.173:62751, 6, 1         expires=9904 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9894 TxFlagsSeen=0x1b LastTxReport=9894 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:37547 --> 10.244.1.173:36880, 6, 0          expires=10193 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=10133 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.113:53939 --> 192.168.178.114:11033, 6, 0   expires=18315 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10313 TxFlagsSeen=0x1a LastTxReport=10313 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:35000 --> 10.244.1.173:36895, 6, 1         expires=9995 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9985 TxFlagsSeen=0x1b LastTxReport=9985 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:47873 --> 10.96.0.1:11958, 6, 4            expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x1a LastTxReport=10310 Flags=0x0010 [ SeenNonSyn ] RevNAT=6 SourceSecurityID=0 BackendID=9 NatPort=0 
                                                             
10.244.1.214:47808 --> 10.244.1.173:62751, 6, 1         expires=9984 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9974 TxFlagsSeen=0x1b LastTxReport=9974 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:11958 --> 192.168.178.114:11033, 6, 0   expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10310 TxFlagsSeen=0x1a LastTxReport=10310 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:43693 --> 10.244.1.173:36895, 6, 1         expires=10045 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10035 TxFlagsSeen=0x1b LastTxReport=10035 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:37510 --> 10.244.1.173:62751, 6, 1         expires=10284 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10274 TxFlagsSeen=0x1b LastTxReport=10274 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:5778 --> 10.244.1.173:36895, 6, 1          expires=9845 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9835 TxFlagsSeen=0x1b LastTxReport=9835 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:8884 --> 10.244.1.173:62751, 6, 1          expires=10124 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10114 TxFlagsSeen=0x1b LastTxReport=10114 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.115:48260 --> 192.168.178.114:36880, 6, 0   expires=10019 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10009 TxFlagsSeen=0x1b LastTxReport=10009 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.113:64662 --> 192.168.178.114:36880, 6, 0   expires=9948 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=9938 TxFlagsSeen=0x02 LastTxReport=9938 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:32902 --> 10.244.1.173:62751, 6, 1         expires=9954 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9944 TxFlagsSeen=0x1b LastTxReport=9944 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:9939 --> 10.244.1.173:36880, 6, 0           expires=9804 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=9744 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:16057 --> 10.244.1.173:62751, 6, 1         expires=9874 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9864 TxFlagsSeen=0x1b LastTxReport=9864 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.197:4743 --> 10.244.2.226:36880, 6, 1          expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10314 TxFlagsSeen=0x1a LastTxReport=10314 Flags=0x0410 [ SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.1.214:54918 --> 10.244.1.173:36895, 6, 1         expires=9795 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9785 TxFlagsSeen=0x1b LastTxReport=9785 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:47753 --> 10.244.1.173:36895, 6, 1         expires=9965 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9955 TxFlagsSeen=0x1b LastTxReport=9955 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:26336 --> 10.244.1.173:62751, 6, 1         expires=9754 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9744 TxFlagsSeen=0x1b LastTxReport=9744 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:10456 --> 10.244.1.173:62751, 6, 1         expires=9854 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9844 TxFlagsSeen=0x1b LastTxReport=9844 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.115:31898 --> 192.168.178.114:36880, 6, 0   expires=9902 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9892 TxFlagsSeen=0x1b LastTxReport=9892 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:11904 --> 10.244.1.173:62751, 6, 1         expires=10094 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10084 TxFlagsSeen=0x1b LastTxReport=10084 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:64647 --> 10.244.1.173:36895, 6, 1         expires=10165 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10155 TxFlagsSeen=0x1b LastTxReport=10155 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:23769 --> 10.244.1.173:36880, 6, 0          expires=10310 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=10250 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.115:18131 --> 192.168.178.114:36880, 6, 0   expires=10116 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10106 TxFlagsSeen=0x1b LastTxReport=10106 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:37606 --> 10.244.1.173:36895, 6, 1         expires=10005 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9995 TxFlagsSeen=0x1b LastTxReport=9995 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:43230 --> 10.244.1.173:62751, 6, 1         expires=9934 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9924 TxFlagsSeen=0x1b LastTxReport=9924 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:56456 --> 10.244.1.173:36895, 6, 1         expires=10195 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10185 TxFlagsSeen=0x1b LastTxReport=10185 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:10390 --> 10.244.1.173:36895, 6, 1         expires=9935 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9925 TxFlagsSeen=0x1b LastTxReport=9925 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:10373 --> 10.244.1.173:62751, 6, 1         expires=10024 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10014 TxFlagsSeen=0x1b LastTxReport=10014 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:58039 --> 10.244.1.173:36895, 6, 1         expires=9905 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9895 TxFlagsSeen=0x1b LastTxReport=9895 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:53409 --> 10.244.1.173:36895, 6, 1         expires=9975 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9965 TxFlagsSeen=0x1b LastTxReport=9965 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:20103 --> 10.244.1.173:62751, 6, 1         expires=10294 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10284 TxFlagsSeen=0x1b LastTxReport=10284 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:50326 --> 10.244.1.173:36895, 6, 1         expires=10205 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10195 TxFlagsSeen=0x1b LastTxReport=10195 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:48779 --> 10.244.1.173:36895, 6, 1         expires=10285 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10275 TxFlagsSeen=0x1b LastTxReport=10275 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:42635 --> 10.244.1.173:36880, 6, 0          expires=9999 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9989 TxFlagsSeen=0x1b LastTxReport=9989 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.115:1757 --> 192.168.178.114:36880, 6, 0    expires=10272 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10262 TxFlagsSeen=0x1b LastTxReport=10262 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:48817 --> 10.244.1.173:36895, 6, 1         expires=10325 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10315 TxFlagsSeen=0x1b LastTxReport=10315 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:40113 --> 10.244.1.173:36895, 6, 1         expires=9805 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9795 TxFlagsSeen=0x1b LastTxReport=9795 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:33998 --> 10.244.1.173:36895, 6, 1         expires=9895 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9885 TxFlagsSeen=0x1b LastTxReport=9885 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:23703 --> 10.244.1.173:62751, 6, 1         expires=9794 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9784 TxFlagsSeen=0x1b LastTxReport=9784 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:168 --> 10.244.1.173:62751, 6, 1           expires=9974 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9964 TxFlagsSeen=0x1b LastTxReport=9964 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:45204 --> 10.244.1.173:36895, 6, 1         expires=9915 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9905 TxFlagsSeen=0x1b LastTxReport=9905 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:26278 --> 10.244.1.173:62751, 6, 1         expires=10324 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10314 TxFlagsSeen=0x1b LastTxReport=10314 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:24774 --> 10.244.1.173:36895, 6, 1         expires=9775 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9765 TxFlagsSeen=0x1b LastTxReport=9765 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:31446 --> 10.244.1.173:36895, 6, 1         expires=9835 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9825 TxFlagsSeen=0x1b LastTxReport=9825 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:13475 --> 10.244.1.173:36895, 6, 1         expires=9885 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9875 TxFlagsSeen=0x1b LastTxReport=9875 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:16032 --> 10.244.1.173:62751, 6, 1         expires=9844 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9834 TxFlagsSeen=0x1b LastTxReport=9834 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.197:48777 --> 10.244.2.226:36880, 6, 1         expires=10096 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10086 TxFlagsSeen=0x1b LastTxReport=10086 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.1.214:39614 --> 10.244.1.173:62751, 6, 1         expires=10004 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9994 TxFlagsSeen=0x1b LastTxReport=9994 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:64205 --> 10.244.1.173:36895, 6, 1         expires=9755 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9745 TxFlagsSeen=0x1b LastTxReport=9745 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:9366 --> 10.244.1.173:36895, 6, 1          expires=10125 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10115 TxFlagsSeen=0x1b LastTxReport=10115 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:24224 --> 10.244.1.173:36895, 6, 1         expires=10185 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10175 TxFlagsSeen=0x1b LastTxReport=10175 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:1708 --> 10.244.1.173:62751, 6, 1          expires=9944 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9934 TxFlagsSeen=0x1b LastTxReport=9934 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:40140 --> 192.168.178.114:36880, 6, 0   expires=10065 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=10055 TxFlagsSeen=0x02 LastTxReport=10055 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.113:11498 --> 192.168.178.114:11033, 6, 0   expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10314 TxFlagsSeen=0x1a LastTxReport=10314 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.113:29890 --> 192.168.178.114:36880, 6, 0   expires=9832 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=9822 TxFlagsSeen=0x02 LastTxReport=9822 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:59614 --> 10.244.1.173:36895, 6, 1         expires=10085 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10075 TxFlagsSeen=0x1b LastTxReport=10075 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:63708 --> 10.244.1.173:36895, 6, 1         expires=9705 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9695 TxFlagsSeen=0x1b LastTxReport=9695 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:184 --> 10.244.1.173:62751, 6, 1           expires=9894 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9884 TxFlagsSeen=0x1b LastTxReport=9884 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:44681 --> 10.244.1.173:62751, 6, 1         expires=10244 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10234 TxFlagsSeen=0x1b LastTxReport=10234 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:35524 --> 10.244.1.173:62751, 6, 1         expires=9824 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9814 TxFlagsSeen=0x1b LastTxReport=9814 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:24217 --> 10.244.1.173:36895, 6, 1         expires=9825 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9815 TxFlagsSeen=0x1b LastTxReport=9815 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:44168 --> 10.244.1.173:36895, 6, 1         expires=10035 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10025 TxFlagsSeen=0x1b LastTxReport=10025 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:5316 --> 10.244.1.173:62751, 6, 1          expires=10274 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10264 TxFlagsSeen=0x1b LastTxReport=10264 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:59600 --> 10.244.1.173:36895, 6, 1         expires=9765 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9755 TxFlagsSeen=0x1b LastTxReport=9755 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:4762 --> 192.168.178.114:11033, 6, 0    expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10312 TxFlagsSeen=0x1a LastTxReport=10312 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:27777 --> 10.244.1.173:36895, 6, 1         expires=9745 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9735 TxFlagsSeen=0x1b LastTxReport=9735 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:32990 --> 10.244.1.173:62751, 6, 1         expires=10204 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10194 TxFlagsSeen=0x1b LastTxReport=10194 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:5352 --> 192.168.178.114:36880, 6, 0    expires=10104 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=10094 TxFlagsSeen=0x02 LastTxReport=10094 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
192.168.178.115:35524 --> 192.168.178.114:36880, 6, 0   expires=18304 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10304 TxFlagsSeen=0x1a LastTxReport=10304 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:25797 --> 10.244.1.173:36895, 6, 1         expires=9715 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9705 TxFlagsSeen=0x1b LastTxReport=9705 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:1235 --> 192.168.178.114:11033, 6, 0    expires=18311 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10311 TxFlagsSeen=0x1a LastTxReport=10311 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.197:1756 --> 10.244.1.173:36880, 6, 1          expires=18306 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10306 TxFlagsSeen=0x1a LastTxReport=10306 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:50854 --> 10.244.1.173:62751, 6, 1         expires=9914 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9904 TxFlagsSeen=0x1b LastTxReport=9904 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:48282 --> 10.244.1.173:36895, 6, 1         expires=9945 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9935 TxFlagsSeen=0x1b LastTxReport=9935 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:57473 --> 192.168.178.114:36880, 6, 0   expires=9715 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=9705 TxFlagsSeen=0x02 LastTxReport=9705 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.197:33980 --> 10.244.2.226:36880, 6, 1         expires=9726 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9716 TxFlagsSeen=0x1b LastTxReport=9716 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.1.214:1668 --> 10.244.1.173:62751, 6, 1          expires=9814 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9804 TxFlagsSeen=0x1b LastTxReport=9804 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:1765 --> 10.244.1.173:62751, 6, 1          expires=10144 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10134 TxFlagsSeen=0x1b LastTxReport=10134 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:15022 --> 10.244.1.173:62751, 6, 1         expires=10134 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10124 TxFlagsSeen=0x1b LastTxReport=10124 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:50888 --> 10.244.1.173:62751, 6, 1         expires=10224 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10214 TxFlagsSeen=0x1b LastTxReport=10214 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:19641 --> 10.244.1.173:36895, 6, 1         expires=10025 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10015 TxFlagsSeen=0x1b LastTxReport=10015 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:36509 --> 10.244.1.173:36895, 6, 1         expires=10155 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10145 TxFlagsSeen=0x1b LastTxReport=10145 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:63174 --> 10.244.1.173:36895, 6, 1         expires=10015 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10005 TxFlagsSeen=0x1b LastTxReport=10005 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:22684 --> 10.244.1.173:36895, 6, 1         expires=9875 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9865 TxFlagsSeen=0x1b LastTxReport=9865 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:58585 --> 10.244.1.173:36895, 6, 1         expires=10065 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10055 TxFlagsSeen=0x1b LastTxReport=10055 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:4826 --> 10.244.1.173:62751, 6, 1          expires=9964 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9954 TxFlagsSeen=0x1b LastTxReport=9954 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:16060 --> 10.244.1.173:36895, 6, 1         expires=10275 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10265 TxFlagsSeen=0x1b LastTxReport=10265 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.197:64185 --> 10.244.2.226:36880, 6, 1         expires=9901 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9891 TxFlagsSeen=0x1b LastTxReport=9891 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.1.214:46222 --> 10.244.1.173:62751, 6, 1         expires=10064 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10054 TxFlagsSeen=0x1b LastTxReport=10054 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:53990 --> 10.244.1.173:36895, 6, 1         expires=10115 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10105 TxFlagsSeen=0x1b LastTxReport=10105 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:54917 --> 10.244.1.173:36895, 6, 1         expires=10215 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10205 TxFlagsSeen=0x1b LastTxReport=10205 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:59053 --> 10.244.1.173:36895, 6, 1         expires=10245 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10235 TxFlagsSeen=0x1b LastTxReport=10235 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:26292 --> 10.244.1.173:62751, 6, 1         expires=9834 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9824 TxFlagsSeen=0x1b LastTxReport=9824 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:27793 --> 10.244.1.173:62751, 6, 1         expires=9774 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9764 TxFlagsSeen=0x1b LastTxReport=9764 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:60610 --> 10.244.1.173:36880, 6, 0          expires=9921 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=9861 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:35459 --> 10.244.1.173:36895, 6, 1         expires=9815 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9805 TxFlagsSeen=0x1b LastTxReport=9805 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:23213 --> 10.244.1.173:36880, 6, 0          expires=10291 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10281 TxFlagsSeen=0x1b LastTxReport=10281 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.84:32966 --> 10.244.1.173:36880, 6, 0          expires=18308 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10308 TxFlagsSeen=0x1a LastTxReport=10308 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:49840 --> 10.244.1.173:36895, 6, 1         expires=9955 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9945 TxFlagsSeen=0x1b LastTxReport=9945 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:18124 --> 10.244.1.173:36895, 6, 1         expires=10315 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10305 TxFlagsSeen=0x1b LastTxReport=10305 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:34479 --> 10.244.1.173:62751, 6, 1         expires=10044 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10034 TxFlagsSeen=0x1b LastTxReport=10034 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:31913 --> 10.244.1.173:36895, 6, 1         expires=9725 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9715 TxFlagsSeen=0x1b LastTxReport=9715 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:65235 --> 10.244.1.173:36895, 6, 1         expires=10075 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10065 TxFlagsSeen=0x1b LastTxReport=10065 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:18090 --> 10.244.1.173:62751, 6, 1         expires=10194 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10184 TxFlagsSeen=0x1b LastTxReport=10184 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:11958 --> 10.244.1.214:11033, 6, 0      expires=18314 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10310 TxFlagsSeen=0x1a LastTxReport=10310 Flags=0x0010 [ SeenNonSyn ] RevNAT=6 SourceSecurityID=41104 BackendID=0 NatPort=0 
                                                             
10.244.1.214:35528 --> 10.244.1.173:62751, 6, 1         expires=10084 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10074 TxFlagsSeen=0x1b LastTxReport=10074 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:10954 --> 192.168.178.114:36880, 6, 0   expires=10221 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=10211 TxFlagsSeen=0x02 LastTxReport=10211 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.84:44162 --> 10.244.1.173:36880, 6, 0          expires=10136 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10126 TxFlagsSeen=0x1b LastTxReport=10126 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:53954 --> 10.244.1.173:62751, 6, 1         expires=10164 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10154 TxFlagsSeen=0x1b LastTxReport=10154 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:46306 --> 10.244.1.173:62751, 6, 1         expires=9884 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9874 TxFlagsSeen=0x1b LastTxReport=9874 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.115:45715 --> 192.168.178.114:36880, 6, 0   expires=9785 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9775 TxFlagsSeen=0x1b LastTxReport=9775 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:42627 --> 10.244.1.173:62751, 6, 1         expires=9804 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9794 TxFlagsSeen=0x1b LastTxReport=9794 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:39559 --> 10.244.1.173:36895, 6, 1         expires=10255 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10245 TxFlagsSeen=0x1b LastTxReport=10245 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:8908 --> 10.244.1.173:36895, 6, 1          expires=9785 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9775 TxFlagsSeen=0x1b LastTxReport=9775 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:33445 --> 10.244.1.173:36895, 6, 1         expires=10305 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10295 TxFlagsSeen=0x1b LastTxReport=10295 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:40668 --> 10.244.1.173:36895, 6, 1         expires=9855 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9845 TxFlagsSeen=0x1b LastTxReport=9845 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:18105 --> 10.244.1.173:62751, 6, 1         expires=9864 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9854 TxFlagsSeen=0x1b LastTxReport=9854 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:46249 --> 10.244.1.173:36880, 6, 0          expires=10154 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=10094 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:54440 --> 10.244.1.173:62751, 6, 1         expires=10254 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10244 TxFlagsSeen=0x1b LastTxReport=10244 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:33934 --> 10.244.1.173:62751, 6, 1         expires=10034 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10024 TxFlagsSeen=0x1b LastTxReport=10024 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:61097 --> 10.244.1.173:62751, 6, 1         expires=10174 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10164 TxFlagsSeen=0x1b LastTxReport=10164 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:64223 --> 10.244.1.173:62751, 6, 1         expires=10214 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10204 TxFlagsSeen=0x1b LastTxReport=10204 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:11461 --> 10.244.1.173:36895, 6, 1         expires=10265 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10255 TxFlagsSeen=0x1b LastTxReport=10255 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:1773 --> 10.244.1.173:62751, 6, 1          expires=9744 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9734 TxFlagsSeen=0x1b LastTxReport=9734 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:33980 --> 10.244.1.173:62751, 6, 1         expires=9764 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9754 TxFlagsSeen=0x1b LastTxReport=9754 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:58586 --> 10.244.1.173:36895, 6, 1         expires=9865 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9855 TxFlagsSeen=0x1b LastTxReport=9855 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:49812 --> 10.244.1.173:36895, 6, 1         expires=9735 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9725 TxFlagsSeen=0x1b LastTxReport=9725 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:6813 --> 10.244.1.173:36895, 6, 1          expires=10235 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10225 TxFlagsSeen=0x1b LastTxReport=10225 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:64654 --> 10.244.1.173:36895, 6, 1         expires=9985 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9975 TxFlagsSeen=0x1b LastTxReport=9975 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:16005 --> 10.244.1.173:36880, 6, 0          expires=9766 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9756 TxFlagsSeen=0x1b LastTxReport=9756 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:51359 --> 10.244.1.173:62751, 6, 1         expires=10184 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10174 TxFlagsSeen=0x1b LastTxReport=10174 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:11969 --> 10.244.1.173:62751, 6, 1         expires=9734 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9724 TxFlagsSeen=0x1b LastTxReport=9724 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:63186 --> 10.244.1.173:62751, 6, 1         expires=9924 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9914 TxFlagsSeen=0x1b LastTxReport=9914 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:15529 --> 10.244.1.173:62751, 6, 1         expires=10074 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10064 TxFlagsSeen=0x1b LastTxReport=10064 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:22169 --> 10.244.1.173:62751, 6, 1         expires=10154 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10144 TxFlagsSeen=0x1b LastTxReport=10144 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:63698 --> 192.168.178.114:11033, 6, 0   expires=18311 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10307 TxFlagsSeen=0x1a LastTxReport=10307 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:31433 --> 10.244.1.173:36895, 6, 1         expires=10295 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10285 TxFlagsSeen=0x1b LastTxReport=10285 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:28298 --> 10.244.1.173:62751, 6, 1         expires=10234 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10224 TxFlagsSeen=0x1b LastTxReport=10224 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:18134 --> 10.244.1.173:62751, 6, 1         expires=10304 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10294 TxFlagsSeen=0x1b LastTxReport=10294 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:60622 --> 10.244.1.173:36895, 6, 1         expires=10095 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10085 TxFlagsSeen=0x1b LastTxReport=10085 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:13972 --> 10.244.1.173:36895, 6, 1         expires=10105 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10095 TxFlagsSeen=0x1b LastTxReport=10095 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:7340 --> 10.244.1.173:62751, 6, 1          expires=10014 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10004 TxFlagsSeen=0x1b LastTxReport=10004 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:51896 --> 10.244.1.173:36895, 6, 1         expires=10175 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10165 TxFlagsSeen=0x1b LastTxReport=10165 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:10978 --> 10.244.1.173:36895, 6, 1         expires=10225 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10215 TxFlagsSeen=0x1b LastTxReport=10215 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:41608 --> 10.244.1.173:62751, 6, 1         expires=10114 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10104 TxFlagsSeen=0x1b LastTxReport=10104 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:24770 --> 10.244.1.173:36880, 6, 0          expires=9883 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9873 TxFlagsSeen=0x1b LastTxReport=9873 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:23750 --> 10.244.1.173:62751, 6, 1         expires=9704 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9694 TxFlagsSeen=0x1b LastTxReport=9694 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:16015 --> 10.244.1.173:62751, 6, 1         expires=10054 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10044 TxFlagsSeen=0x1b LastTxReport=10044 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:52369 --> 10.244.1.173:36895, 6, 1         expires=9925 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9915 TxFlagsSeen=0x1b LastTxReport=9915 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:31366 --> 10.244.1.173:36895, 6, 1         expires=10055 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10045 TxFlagsSeen=0x1b LastTxReport=10045 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:48860 --> 10.244.1.173:62751, 6, 1         expires=9784 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9774 TxFlagsSeen=0x1b LastTxReport=9774 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:57523 --> 192.168.178.114:11033, 6, 0   expires=18315 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10313 TxFlagsSeen=0x1a LastTxReport=10313 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.1.214:59030 --> 10.244.1.173:62751, 6, 1         expires=10314 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10304 TxFlagsSeen=0x1b LastTxReport=10304 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.214:30952 --> 10.244.1.173:36895, 6, 1         expires=10135 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10125 TxFlagsSeen=0x1b LastTxReport=10125 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             

## Map: cilium_ct_any4_global
Key                                                      Value   State   Error
10.244.1.197:58485 --> 10.244.1.173:0, 1, 1              expires=9706 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9646 TxFlagsSeen=0x00 LastTxReport=9646 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
10.244.1.197:20313 --> 10.244.2.226:0, 1, 1              expires=10017 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9957 TxFlagsSeen=0x00 LastTxReport=9957 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                              
10.244.1.197:63432 --> 10.244.1.173:0, 1, 1              expires=10057 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9997 TxFlagsSeen=0x00 LastTxReport=9997 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
10.244.1.197:26967 --> 10.244.1.173:0, 1, 1              expires=9823 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9763 TxFlagsSeen=0x00 LastTxReport=9763 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
185.125.190.122:37593 --> 192.168.178.114:31488, 17, 0   expires=9991 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9931 TxFlagsSeen=0x00 LastTxReport=9931 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                              
10.244.1.197:42062 --> 10.244.2.226:0, 1, 1              expires=10250 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10190 TxFlagsSeen=0x00 LastTxReport=10190 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                              
10.244.1.197:0 --> 10.244.2.226:0, 1, 3                  expires=10328 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10268 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                              
10.244.1.197:24315 --> 10.244.2.226:0, 1, 1              expires=10056 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9996 TxFlagsSeen=0x00 LastTxReport=9996 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                              
10.244.1.197:0 --> 10.244.1.173:0, 1, 3                  expires=10329 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10269 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
10.244.1.197:41274 --> 10.244.1.173:0, 1, 1              expires=9920 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9860 TxFlagsSeen=0x00 LastTxReport=9860 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
10.244.1.197:49798 --> 10.244.2.226:0, 1, 1              expires=9861 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9801 TxFlagsSeen=0x00 LastTxReport=9801 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                              
10.244.1.197:38548 --> 10.244.1.173:0, 1, 1              expires=10329 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10269 TxFlagsSeen=0x00 LastTxReport=10269 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
10.244.1.197:50437 --> 10.244.1.173:0, 1, 1              expires=10212 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10152 TxFlagsSeen=0x00 LastTxReport=10152 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              
10.244.1.197:8803 --> 10.244.2.226:0, 1, 1               expires=10328 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10268 TxFlagsSeen=0x00 LastTxReport=10268 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                              
10.244.1.214:0 --> 10.244.1.173:0, 1, 3                  expires=10375 Packets=0 Bytes=0 RxFlagsSeen=0x02 LastRxReport=10315 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                              

## Map: cilium_policy_v3_03284
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_auth_map
Cache is empty


## Map: cilium_ratelimit_metrics
Key   Value   State   Error
3     4               

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_lb4_services_v2
Key                         Value                    State   Error
10.96.0.10:53/UDP (2)       16 0[0] (4) [0x0 0x0]            
10.101.247.67:443/TCP (1)   10 0[0] (7) [0x0 0x10]           
10.96.0.1:0/ANY (0)         0 0[0] (0) [0x0 0x0]             
10.105.79.192:80/TCP (1)    12 0[0] (1) [0x0 0x0]            
10.96.0.1:443/TCP (0)       0 1[0] (6) [0x0 0x0]             
10.101.247.67:0/ANY (0)     0 0[0] (0) [0x0 0x0]             
10.97.123.232:80/TCP (0)    0 1[0] (2) [0x0 0x0]             
10.96.0.10:53/TCP (1)       13 0[0] (3) [0x0 0x0]            
10.96.0.10:9153/TCP (1)     17 0[0] (5) [0x0 0x0]            
10.97.123.232:0/ANY (0)     0 0[0] (0) [0x0 0x0]             
10.96.0.1:443/TCP (1)       9 0[0] (6) [0x0 0x0]             
10.105.79.192:0/ANY (0)     0 0[0] (0) [0x0 0x0]             
10.97.123.232:80/TCP (1)    11 0[0] (2) [0x0 0x0]            
10.101.247.67:443/TCP (0)   0 1[0] (7) [0x0 0x10]            
10.96.0.10:9153/TCP (0)     0 2[0] (5) [0x0 0x0]             
10.96.0.10:9153/TCP (2)     18 0[0] (5) [0x0 0x0]            
10.105.79.192:80/TCP (0)    0 1[0] (1) [0x0 0x0]             
10.96.0.10:53/UDP (1)       15 0[0] (4) [0x0 0x0]            
10.96.0.10:0/ANY (0)        0 0[0] (0) [0x0 0x0]             
10.96.0.10:53/UDP (0)       0 2[0] (4) [0x0 0x0]             
10.96.0.10:53/TCP (2)       14 0[0] (3) [0x0 0x0]            
10.96.0.10:53/TCP (0)       0 2[0] (3) [0x0 0x0]             

## Map: cilium_policy_v3_01644
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_ipcache_v2
Key                  Value                                                                        State   Error
192.168.178.115/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.2.84/32       identity=4 encryptkey=0 tunnelendpoint=192.168.178.115 flags=hastunnel       sync    
192.168.178.114/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.1.173/32      identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.0.0/24        identity=2 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       sync    
10.244.0.27/32       identity=4 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       sync    
0.0.0.0/0            identity=2 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.1.197/32      identity=4 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.2.0/24        identity=2 encryptkey=0 tunnelendpoint=192.168.178.115 flags=hastunnel       sync    
192.168.178.113/32   identity=7 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.0.172/32      identity=6 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       sync    
10.244.2.226/32      identity=6 encryptkey=0 tunnelendpoint=192.168.178.115 flags=hastunnel       sync    
10.244.2.31/32       identity=10824 encryptkey=0 tunnelendpoint=192.168.178.115 flags=hastunnel   sync    
10.244.2.11/32       identity=41104 encryptkey=0 tunnelendpoint=192.168.178.115 flags=hastunnel   sync    
10.244.1.214/32      identity=41104 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              sync    
10.244.2.154/32      identity=25785 encryptkey=0 tunnelendpoint=192.168.178.115 flags=hastunnel   sync    

## Map: cilium_lxc
Key                 Value                                                                                                                         State   Error
192.168.178.114:0   (localhost)                                                                                                                   sync    
10.244.1.173:0      (localhost)                                                                                                                   sync    
10.244.1.197:0      id=1644  sec_id=4     flags=0x0000 ifindex=7   mac=7A:89:7C:13:AB:F7 nodemac=A6:85:AC:C3:E3:75 parent_ifindex=0   rt_info:0   sync    
10.244.1.214:0      id=4046  sec_id=41104 flags=0x0000 ifindex=9   mac=1A:8F:7A:5B:A5:4A nodemac=9A:0B:01:4D:9F:5E parent_ifindex=0   rt_info:0   sync    

## Map: cilium_lb4_reverse_sk
Key                             Value                      State   Error
[192.168.178.113]:11033, 4144   [10.96.0.1]:-17663, 1536           
[192.168.178.113]:11033, 4168   [10.96.0.1]:-17663, 1536           
[192.168.178.113]:11033, 4159   [10.96.0.1]:-17663, 1536           

## Map: cilium_devices
Key   Value                 State   Error
2     bc:24:11:de:cb:0c 0           

## Map: cilium_policy_v3_04046
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_percpu_trace_id
Cache is empty


## Map: cilium_ratelimit
Key   Value           State   Error
3     73894618409 0           

## Map: cilium_lb4_backends_v3
Key   Value                   State   Error
15    UDP://10.244.1.214              
14    TCP://10.244.2.11               
18    TCP://10.244.2.11               
12    TCP://10.244.2.154              
13    TCP://10.244.1.214              
17    TCP://10.244.1.214              
16    UDP://10.244.2.11               
10    TCP://192.168.178.114           
9     TCP://192.168.178.113           
11    TCP://10.244.2.31               

## Map: cilium_lb4_maglev
Cache is empty


## Map: cilium_lb4_affinity
Cache is empty


## Map: cilium_metrics
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_policystats
Cache is disabled


## Map: cilium_skip_lb4
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_l2_responder_v6
Cache is disabled


