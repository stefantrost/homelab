goroutine 242 [running]:
runtime/pprof.writeGoroutineStacks({0x79c3bcd2e3d8, 0x1133940126e0})
	/usr/local/go/src/runtime/pprof/pprof.go:819 +0x6b
runtime/pprof.writeGoroutine({0x79c3bcd2e3d8?, 0x1133940126e0?}, 0x113396dbadd0?)
	/usr/local/go/src/runtime/pprof/pprof.go:782 +0x25
runtime/pprof.(*Profile).WriteTo(0x8326720?, {0x79c3bcd2e3d8?, 0x1133940126e0?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:408 +0x149
github.com/google/gops/agent.handle({0x79c3bcd2e3b0, 0x1133940126e0}, {0x1133964ed338?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x28d2
github.com/google/gops/agent.listen({0x4f690b0, 0x113396c55b00})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1b4
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x35c

goroutine 1 [select, 171 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x113394058100, 0x113394356530)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:286 +0x155
github.com/cilium/hive.(*Hive).Run(0x113394058100, 0x113394356530, {0x113395a9fbd8, 0x3, 0x4?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:270 +0x3cd
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x1133945b1b08, {0x4bcd638?, 0x4?, 0x4bcd598?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:50 +0x2ba
github.com/spf13/cobra.(*Command).execute(0x1133945b1b08, {0x113394014050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1019 +0xafb
github.com/spf13/cobra.(*Command).ExecuteC(0x1133945b1b08)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1148 +0x465
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1071
github.com/cilium/cilium/daemon/cmd.Execute(0x113393ed81e0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:89 +0x13
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:15 +0x1f

goroutine 23 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/pidfile.write.DeferTerminationCleanupFunction.func2()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x25
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 1201 [select, 171 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396ded600)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1167
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 224 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x113394e77720)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 226 [chan receive, 24 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:160 +0xb9
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:153 +0x67

goroutine 227 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x113394e779a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 233 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x14d
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 1182 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x1133988292c0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396decc60)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1167
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1268 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113397089ce0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1169
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1171 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396d55080)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 946
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 128870 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983af380, 0x1133964fdb80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983af380, 0x1133959d11e0?, 0x1133959d11f0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 494
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 240 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x14d
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 713 [syscall, 171 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x98
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x13
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:152 +0x1f

goroutine 243 [select, 24 minutes]:
github.com/cilium/statedb.graveyardWorker(0x113395b9a468, {0x4f78970, 0x11339477dc70}, 0x113395753170?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:26 +0x185
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:287 +0x155

goroutine 244 [chan receive, 171 minutes]:
github.com/cilium/lumberjack/v2.(*Logger).millRun(0x11339439c770)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/lumberjack/v2/lumberjack.go:410 +0x77
created by github.com/cilium/lumberjack/v2.(*Logger).mill.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/lumberjack/v2/lumberjack.go:422 +0x9a

goroutine 251 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396ca71e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 255 [select, 24 minutes]:
github.com/cilium/cilium/pkg/policy/compute.(*IdentityPolicyComputer).processRequests(0x1133947fec00, {0x4f78938, 0x11339455a240})
	/go/src/github.com/cilium/cilium/pkg/policy/compute/compute.go:222 +0xac
github.com/cilium/cilium/pkg/policy/compute.NewIdentityPolicyComputer.func1({0x4f78938?, 0x11339455a240?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/policy/compute/cell.go:53 +0x2a
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f16180, {0x4f78938, 0x11339455a240}, {0x4f909a0, 0x113394f16000}, {{{0x113394a3e660, 0x1, 0x1}}, 0x113394d9daa0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 249 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bd168e00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x1133965eed80?, 0x113396d9c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x1133965eed80, {0x113396d9c000, 0x3800, 0x3800})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x1133965eed80, {0x113396d9c000?, 0xc?, 0x113396cafa28?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x113394a97cf8, {0x113396d9c000?, 0x425234?, 0x113396d9c005?})
	/usr/local/go/src/net/net.go:196 +0x45
crypto/tls.(*atLeastReader).Read(0x1133948cadc8, {0x113396d9c000?, 0x113396cafa48?, 0x452688?})
	/usr/local/go/src/crypto/tls/conn.go:815 +0x3b
bytes.(*Buffer).ReadFrom(0x11339599a2a8, {0x4f0dbc0, 0x1133948cadc8})
	/usr/local/go/src/bytes/buffer.go:229 +0x98
crypto/tls.(*Conn).readFromUntil(0x11339599a008, {0x79c3bce2e0e8, 0x1133950826c0}, 0x69e30c?)
	/usr/local/go/src/crypto/tls/conn.go:837 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0x11339599a008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x3db
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x11339599a008, {0x113394390000, 0x1000, 0x113396cafcb0?})
	/usr/local/go/src/crypto/tls/conn.go:1393 +0x145
bufio.(*Reader).Read(0x113395d52720, {0x113396754824, 0x9, 0x5c?})
	/usr/local/go/src/bufio/bufio.go:245 +0x197
io.ReadAtLeast({0x4f08a40, 0x113395d52720}, {0x113396754824, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x8e
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x113396754824, 0x9, 0x1133000003af?}, {0x4f08a40?, 0x113395d52720?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:250 +0x65
golang.org/x/net/http2.(*Framer).ReadFrameHeader(0x1133967547e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:513 +0x6b
golang.org/x/net/http2.(*Framer).ReadFrame(0x1133967547e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:572 +0x18
golang.org/x/net/http2.(*clientConnReadLoop).run(0x113396caffa8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1878 +0xca
golang.org/x/net/http2.(*ClientConn).readLoop(0x11339410b880)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1760 +0x52
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 248
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:554 +0xda5

goroutine 309 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x113396754ad0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x11339714b8e0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x113396754a80, 0x113396d03cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x113396c3b340, {0x4f7afd0, 0x113396c6f730})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x113396c6f730?}, 0x113394654780?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x113396c6f730}, 0x113396d82ea0, {0x4f0fa20, 0x113394654780}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x113396c6f730}, 0x113396d82ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x113396c3b340, {0x4f7afd0, 0x113396c6f730})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x113396ca55e0, 0x113396c6f730)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 258
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 388 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd2300, {0x4f78938, 0x11339487fb30}, {0x4f909a0, 0x1133967a7b00})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x1133963772c0, {0x4f78938, 0x11339487fb30}, {0x4f909a0, 0x113396376ea0}, {{{0x113394244580, 0x1, 0x1}}, 0x113394cd49c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 398 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0xeb
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 427
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 340 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x113394c6fa40, {0x4f78938, 0x1133948601b0}, {0x4f909a0, 0x113395d53800})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:389 +0x24b
github.com/cilium/hive/job.(*jobOneShot).start(0x113395011c80, {0x4f78938, 0x1133948601b0}, {0x4f909a0, 0x113394f17080}, {{{0x113394ae7c40, 0x1, 0x1}}, 0x113394d42e10, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 382 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 353
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 383 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x113394aec300, {0x4f78970, 0x11339589b6d0}, 0x1133941e9880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 353
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 339 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x113396dc12c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 263 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x113396754910, 0x24)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113396255160?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x1133967548c0, 0x113396d02b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x113396c3a9a0, {0x4f7afd0, 0x113396c6f500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x113396c6f500?}, 0x11339455be90?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x113396c6f500}, 0x113396d21ea0, {0x4f0fa20, 0x11339455be90}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x113396c6f500}, 0x113396d21ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x113396c3a9a0, {0x4f7afd0, 0x113396c6f500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x6?, 0x113395784d80?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x113396ca4b40, 0x113396c6f500)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 387 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bd168600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397068380?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113397068380)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113397068380)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x460d20?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x11339488eea0)
	/usr/local/go/src/net/unixsock.go:267 +0x30
google.golang.org/grpc.(*Server).Serve(0x1133959be908, {0x4f66810, 0x11339488eea0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:934 +0x45c
github.com/cilium/cilium/pkg/envoy.(*adsServer).startAdsGRPCServer(0x113394b75540, {0x4f78938, 0x11339487f740})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpcnew.go:83 +0x825
github.com/cilium/cilium/pkg/envoy.(*adsServer).run(0x492cce?, {0x4f78938?, 0x11339487f740?})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds_server_ads.go:138 +0x1d
github.com/cilium/cilium/pkg/envoy.newEnvoyXDSServer.func1({0x4f78938?, 0x11339487f740?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/envoy/cell.go:145 +0x2f
github.com/cilium/hive/job.(*jobOneShot).start(0x113396376ba0, {0x4f78938, 0x11339487f740}, {0x4f909a0, 0x1133963769c0}, {{{0x1133941e6700, 0x1, 0x1}}, 0x113394d9d480, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 312 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 309
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 132152 [select]:
net/http.(*persistConn).writeLoop(0x113396e10dc0)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 132138
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 316 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 313
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 318 [chan receive, 4 minutes]:
github.com/cilium/cilium/pkg/node/sync.(*localNodeSynchronizer).SyncLocalNode(0x11339535cb40, {0x4f78938?, 0x1133948499b0?}, 0x1133948c1ec0)
	/go/src/github.com/cilium/cilium/pkg/node/sync/local_node_sync.go:99 +0xab
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1({0x4f78938?, 0x1133948499b0?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:119 +0x33
github.com/cilium/hive/job.(*jobOneShot).start(0x113395d53440, {0x4f78938, 0x1133948499b0}, {0x4f909a0, 0x113394f16660}, {{{0x113394a7fc40, 0x1, 0x1}}, 0x113394db3a40, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 320 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5000f80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 326 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd20c0, {0x4f78938, 0x113394854ed0}, {0x4f909a0, 0x113395010de0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f16f60, {0x4f78938, 0x113394854ed0}, {0x4f909a0, 0x113394f16de0}, {{{0x113394ae7560, 0x1, 0x1}}, 0x113394dcdc60, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 328 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x1133948b38c0, 0x113396d570a0, 0x113396d57180, 0x113396d571f0, 0x113396d57260)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:367 +0x2f1
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x1133948b38c0, {0x4f78970?, 0x113395ac8aa0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:247 +0x596
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x1133948b38c0, {0x4f78970, 0x113395ac8aa0})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:179 +0x9c
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:153 +0x125

goroutine 329 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:382 +0x25
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:381 +0x146

goroutine 331 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1817 +0x25
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1816 +0x146

goroutine 266 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 263
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 267 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113396c6f500}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113398c12320}, {0x79c3bce2e6b8, 0x1133967548c0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113396c6f500?}, {0x1133959f12a0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113398c12320?}, {0x79c3bce2e6b8?, 0x1133967548c0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x11339510d200, {0x4f7afd0, 0x113396c6f500}, {0x4f5b8e8, 0x113398c12320}, 0x113394571d50)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x11339510d200, {0x4f7afd0, 0x113396c6f500}, {0x4f5b8e8, 0x1133949b9720})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x11339510d200, {0x4f7afd0, 0x113396c6f500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113396c6f500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113396c6f500?}, 0x113395cd7658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113396c6f500}, {0x4f6a460, 0x113396ca4c80}, 0x1, 0x1, 0x113396cadf48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x11339510d200, {0x4f7afd0, 0x113396c6f500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 263
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 127159 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x113397e8e300, 0x11339785d900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x113397e8e300, 0xfcedd7?, 0x11339827d7c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 633
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 330 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x79c3bd168800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113395d53620?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x113395d53620, 0x113396edfd28)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x113396edfd20, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x113394b67620?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:398 +0x91
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:395 +0x33f

goroutine 332 [IO wait, 24 minutes]:
internal/poll.runtime_pollWait(0x79c3bce9d400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113395d53680?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x113395d53680, 0x113396eff870)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x113396eff868, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xb?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1833 +0x91
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1830 +0x33f

goroutine 333 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2617 +0x25
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2616 +0x139

goroutine 381 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x113394aec600, {0x4f78970, 0x11339589b5e0}, 0x1133941e9570)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 356
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 313 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113396c6f730}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x1133981cbb30}, {0x79c3bce2e6b8, 0x113396754a80}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113396c6f730?}, {0x113396554db0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x1133981cbb30?}, {0x79c3bce2e6b8?, 0x113396754a80?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x11339510de00, {0x4f7afd0, 0x113396c6f730}, {0x4f5b8e8, 0x1133981cbb30}, 0x1133941d65b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x11339510de00, {0x4f7afd0, 0x113396c6f730}, {0x4f5b8e8, 0x113394aa0280})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x11339510de00, {0x4f7afd0, 0x113396c6f730})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113396c6f730})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113396c6f730?}, 0x113396d4fe58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113396c6f730}, {0x4f6a460, 0x113396ca5740}, 0x1, 0x1, 0x113396ce7f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x11339510de00, {0x4f7afd0, 0x113396c6f730})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 309
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 317 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x11339510de00, {0x4f78970, 0x113395ac8000}, 0x1133941d65b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 313
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 738 [select, 22 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:148 +0x176
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 528
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:145 +0x226

goroutine 321 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bd169000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113396d25500?, 0x4e04f4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113396d25500)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113396d25500)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x41cffe?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x113394854090)
	/usr/local/go/src/net/unixsock.go:267 +0x30
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x1133948540c0, {0x4f78970, 0x11339459f810}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:81 +0xe3
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:67 +0x1a5

goroutine 323 [select, 24 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x113394f16ba0, {0x4f78938, 0x113394854510}, {0x4f909a0, 0x113394f16ae0}, {{{0x0, 0x0, 0x0}}, 0x113394d9cc50, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 325 [select, 52 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd20c0, {0x4f78938, 0x113394854cc0}, {0x4f909a0, 0x113395010d20})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f16f00, {0x4f78938, 0x113394854cc0}, {0x4f909a0, 0x113394f16de0}, {{{0x113394ae7560, 0x1, 0x1}}, 0x113394dcdc60, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 131393 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0x113397a443c0)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 131391
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 295 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 267
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 296 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x11339510d200, {0x4f78970, 0x1133949b97c0}, 0x113394571d50)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 267
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 302 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:76 +0x2c
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 321
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:75 +0xa5

goroutine 298 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 318
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 301 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 318
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 299 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x113396d1ef58?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 318
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 300 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x1133964f52d0, 0x49)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc34c0, {0x4f78970, 0x113395ae5a40}, 0x113396d811f0, {0x4fa4cb0, 0x113396c936f0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 318
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 334 [IO wait, 24 minutes]:
internal/poll.runtime_pollWait(0x79c3bce9d200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113395d536e0?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x113395d536e0, 0x113396f1fe60)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x113396f1fe58, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x113396f1fed8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2633 +0x85
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2630 +0x325

goroutine 397 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0xeb
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 426
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 335 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.neighSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:431 +0x25
created by github.com/vishvananda/netlink.neighSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:430 +0x1cd

goroutine 336 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bce9d000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113395d53740?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x113395d53740, 0x113396ebfe10)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x113396ebfe08, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x11339704edd0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.neighSubscribeAt.func3()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:444 +0x97
created by github.com/vishvananda/netlink.neighSubscribeAt in goroutine 328
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:441 +0x3f3

goroutine 341 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5003ee0, {0x4f78938, 0x113394860420}, {0x4f909a0, 0x113395d53860})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f17680, {0x4f78938, 0x113394860420}, {0x4f909a0, 0x113394f175c0}, {{{0x113394ba3c00, 0x1, 0x1}}, 0x113394dfaae0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 342 [select, 2 minutes]:
reflect.rselect({0x113397c99970, 0x4, 0x230020?})
	/usr/local/go/src/runtime/select.go:616 +0x3cd
reflect.Select({0x113395df21c0?, 0x4, 0x113397c99b10?})
	/usr/local/go/src/reflect/value.go:3018 +0x5a7
github.com/cilium/statedb.(*WatchSet).Wait(0x11339535ecc0, {0x4f78938, 0x1133948643c0}, 0x5f5e100)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/watchset.go:123 +0x545
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x113394355880, {0x4f78938, 0x1133948643c0}, 0x492cce?, {0x4f909a0, 0x113395d53980})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:259 +0x48
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).register.func1.1({0x4f78938?, 0x1133948643c0?}, {0x4f909a0?, 0x113395d53980?})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:249 +0x45
github.com/cilium/hive/job.(*jobOneShot).start(0x113395712240, {0x4f78938, 0x1133948643c0}, {0x4f909a0, 0x113394f176e0}, {{{0x113394bacc00, 0x1, 0x1}}, 0x113394dfb080, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 343 [chan receive, 170 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runServiceEndpointsReflector({_, _}, {_, _}, {{{}}, 0x113394d18780, 0x113394de1750, {0x4f78c48, 0x113394ba3120}, {0x4f50fe0, ...}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:442 +0x407
github.com/cilium/cilium/pkg/loadbalancer/reflectors.RegisterK8sReflector.func1({0x4f78938?, 0x113394864660?}, {0x4f909a0?, 0x113395d539e0?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:112 +0x94
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f179e0, {0x4f78938, 0x113394864660}, {0x4f909a0, 0x113394f17500}, {{{0x113394ba3160, 0x1, 0x1}}, 0x113394de1750, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 344 [chan receive, 24 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runPodReflector({_, _}, {_, _}, {{{}}, 0x113394d18780, 0x113394de1750, {0x4f78c48, 0x113394ba3120}, {0x4f50fe0, ...}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:198 +0x3ba
github.com/cilium/cilium/pkg/loadbalancer/reflectors.RegisterK8sReflector.func2({0x4f78938?, 0x1133948648a0?}, {0x4f909a0?, 0x113395d537a0?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:120 +0x94
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f17aa0, {0x4f78938, 0x1133948648a0}, {0x4f909a0, 0x113394f17500}, {{{0x113394ba3160, 0x1, 0x1}}, 0x113394de1750, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 972 [syscall, 171 minutes]:
syscall.Syscall6(0xf7, 0x3, 0x5e, 0x113396d88dd8, 0x4, 0x113397d05830, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:96 +0x39
internal/syscall/unix.Waitid(0x0?, 0x0?, 0x113396d88de8?, 0x50d692?, 0x113396d88df0?)
	/usr/local/go/src/internal/syscall/unix/waitid_linux.go:18 +0x39
os.(*Process).pidfdWait.func1(...)
	/usr/local/go/src/os/pidfd_linux.go:108
os.ignoringEINTR(...)
	/usr/local/go/src/os/file_posix.go:263
os.(*Process).pidfdWait(0x1133958dab00)
	/usr/local/go/src/os/pidfd_linux.go:107 +0x1c7
os.(*Process).wait(0x1133958daad0?)
	/usr/local/go/src/os/exec_unix.go:25 +0x1a
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:346
os/exec.(*Cmd).Wait(0x1133959eb6c0)
	/usr/local/go/src/os/exec/exec.go:930 +0x45
github.com/cilium/cilium/pkg/health.(*ciliumHealthManager).launchAsEndpoint.func3()
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_endpoint.go:340 +0x31
created by github.com/cilium/cilium/pkg/health.(*ciliumHealthManager).launchAsEndpoint in goroutine 946
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_endpoint.go:339 +0x10e9

goroutine 346 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9d6c0, {0x4f78938, 0x1133948658f0}, {0x4f909a0, 0x113396376240}, {{{0x113393f02980, 0x1, 0x1}}, 0x113394c87dd0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 347 [select, 2 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd23c0, {0x4f78938, 0x113394865c20}, {0x4f909a0, 0x113395d53c80})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x113396376600, {0x4f78938, 0x113394865c20}, {0x4f909a0, 0x113396376540}, {{{0x1133941909e0, 0x1, 0x1}}, 0x113394ca70c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 348 [select, 2 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd23c0, {0x4f78938, 0x1133948681e0}, {0x4f909a0, 0x113395712de0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x113396376660, {0x4f78938, 0x1133948681e0}, {0x4f909a0, 0x113396376540}, {{{0x1133941909e0, 0x1, 0x1}}, 0x113394ca70c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 349 [select, 171 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396dedb80)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 127981 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983aeac8, 0x5)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113397d069c0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983aeab0, {0x11339709c601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x80?}, {0x11339709c601?, 0x425234?, 0x113397077c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x113396d23180)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x113396d23180)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x113396d23180, {0x418d900, 0x113394cdafc0})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x113394ecf890, {0x11339432c400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x1133968ff9f0, 0x0, {0x4f57f10, 0x1133966b88c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x11339487d520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x1133968ffa40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 637
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 353 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113396e13490}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x1133979a00a0}, {0x4f8fca0, 0x113396d7c6c0}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113396e13490?}, {0x1133958e9c00?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x1133979a00a0?}, {0x4f8fca0?, 0x113396d7c6c0?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x113394aec300, {0x4f7afd0, 0x113396e13490}, {0x4f5b8e8, 0x1133979a00a0}, 0x1133941e9880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x113394aec300, {0x4f7afd0, 0x113396e13490}, {0x4f5b8e8, 0x11339589a690})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x113394aec300, {0x4f7afd0, 0x113396e13490})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113396e13490})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113396e13490?}, 0x113395cd3678?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113396e13490}, {0x4f6a460, 0x113396d7c980}, 0x1, 0x1, 0x113396e19f68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x113394aec300, {0x4f7afd0, 0x113396e13490})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x4a2160?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 341
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 354 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 341
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 355 [select, 2 minutes]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113396e136c0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x1133985e4eb0}, {0x4f8fca0, 0x113396d7c860}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113396e136c0?}, {0x113396b841e8?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x1133985e4eb0?}, {0x4f8fca0?, 0x113396d7c860?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x113394aec400, {0x4f7afd0, 0x113396e136c0}, {0x4f5b8e8, 0x1133985e4eb0}, 0x11339422a070)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x113394aec400, {0x4f7afd0, 0x113396e136c0}, {0x4f5b8e8, 0x113395c560f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x113394aec400, {0x4f7afd0, 0x113396e136c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113396e136c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113396e136c0?}, 0x113395cd8678?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113396e136c0}, {0x4f6a460, 0x113396d7cc00}, 0x1, 0x1, 0x113396e1bf68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x113394aec400, {0x4f7afd0, 0x113396e136c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4fbb200?, 0x4f9f650?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/loadbalancer/reflectors.serviceEvents.ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.serviceEvents.ListerWatcherToObservable.func2 in goroutine 343
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 356 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113396e136c0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x11339838eb90}, {0x4f8fca0, 0x113396d7c900}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113396e136c0?}, {0x113394cfcd08?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x11339838eb90?}, {0x4f8fca0?, 0x113396d7c900?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x113394aec600, {0x4f7afd0, 0x113396e136c0}, {0x4f5b8e8, 0x11339838eb90}, 0x1133941e9570)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x113394aec600, {0x4f7afd0, 0x113396e136c0}, {0x4f5b8e8, 0x11339589b3b0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x113394aec600, {0x4f7afd0, 0x113396e136c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113396e136c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113396e136c0?}, 0x113395cd7678?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113396e136c0}, {0x4f6a460, 0x113396d7ce40}, 0x1, 0x1, 0x113396e33f68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x113394aec600, {0x4f7afd0, 0x113396e136c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x4a2160?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/loadbalancer/reflectors.endpointsEvents.ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.endpointsEvents.ListerWatcherToObservable.func2 in goroutine 343
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 357 [select]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runServiceEndpointsReflector.Buffer[...].func7.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x11a
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.runServiceEndpointsReflector.Buffer[...].func7 in goroutine 343
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 362 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x4f78938, 0x11339486dc20}, 0x113394ca6d30, {0x4f909a0, 0x1133964a9800}, 0x1, 0x113394b75240, 0x113395a9bbb8, 0x113395a9bba8, 0x113395a9bb98, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:203 +0xa90
github.com/cilium/cilium/pkg/datapath/iptables.newManager.func2({0x4f78938, 0x11339486dc20}, {0x4f909a0, 0x1133964a9800})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:483 +0x1dd
github.com/cilium/hive/job.(*jobOneShot).start(0x113396376960, {0x4f78938, 0x11339486dc20}, {0x4f909a0, 0x1133963768a0}, {{{0x113394191cc0, 0x1, 0x1}}, 0x113394ca6d30, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 380 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 356
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 361 [select, 171 minutes]:
github.com/cilium/cilium/pkg/fqdn/namemanager.New.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xe8
created by github.com/cilium/cilium/pkg/fqdn/namemanager.New.FromChannel[...].func2 in goroutine 346
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 450 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x113395ba7860, {0x4f78938, 0x113394dd5440}, {0x4f909a0, 0x113395ba77a0}, {{{0x113394867680, 0x1, 0x1}}, 0x113394e2bc20, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1161 [select, 171 minutes]:
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).processADS(0x1133967a7a40, 0x113396db9860, 0x113396a373b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/ads.go:46 +0xf8
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).process(0x1133967a7a40, {0x79c3bcdf1028, 0x113395331950}, 0x113396a373b0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/xds.go:54 +0x2ea
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).StreamHandler(0x1133967a7a40, {0x79c3bcdf1028, 0x113395331950}, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/server.go:182 +0xca
github.com/envoyproxy/go-control-plane/pkg/server/v3.(*server).StreamHandler(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/v3/server.go:186
github.com/envoyproxy/go-control-plane/pkg/server/v3.(*server).StreamAggregatedResources(0x11339488ef60?, {0x4facdc0?, 0x113395331950?})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/v3/server.go:190 +0x4b
github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3._AggregatedDiscoveryService_StreamAggregatedResources_Handler({0x4b11040?, 0x11339488ef60}, {0x4f9a8c0, 0x1133963eb000})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3/ads_grpc.pb.go:137 +0xd8
google.golang.org/grpc.(*Server).processStreamingRPC(0x1133959be908, {0x4f78938, 0x113394ae20f0}, 0x11339665e1c0, 0x11339488f0e0, 0x836d340, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1729 +0x1192
google.golang.org/grpc.(*Server).handleStream(0x1133959be908, {0x4f7ae10, 0x1133943e1a00}, 0x11339665e1c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1862 +0xaa5
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1078 +0x7f
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1160
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1089 +0x11d

goroutine 384 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 355
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 385 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x113394aec400, {0x4f78970, 0x11339589b720}, 0x11339422a070)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 355
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 400 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 429
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 396 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x11339707c180, {0x4f78938, 0x113394894000}, {0x4f909a0, 0x113396376420}, {{{0x113393f03520, 0x1, 0x1}}, 0x113394ca6950, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 390
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 962 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x113396275860, {0x4f78938, 0x113394cff650}, {0x4f909a0, 0x113396376240}, {{{0x113393f02980, 0x1, 0x1}}, 0x113394c87dd0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 345
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 423 [select, 2 minutes]:
github.com/cilium/cilium/pkg/mtu.(*MTUManager).Updater(0x113394aed600, {0x4f78938, 0x11339488b620}, {0x4f909a0, 0x1133968f1980})
	/go/src/github.com/cilium/cilium/pkg/mtu/manager.go:101 +0x988
github.com/cilium/hive/job.(*jobOneShot).start(0x1133968f1920, {0x4f78938, 0x11339488b620}, {0x4f909a0, 0x113395ba6ae0}, {{{0x11339464e1c0, 0x1, 0x1}}, 0x113394d9ccc0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 424 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/orchestrator.(*orchestrator).reconciler(0x113395e9f808, {0x4f78938, 0x1133948eedb0}, {0x4f909a0, 0x11339707c660})
	/go/src/github.com/cilium/cilium/pkg/datapath/orchestrator/orchestrator.go:271 +0xf5c
github.com/cilium/hive/job.(*jobOneShot).start(0x113395ba6c60, {0x4f78938, 0x1133948eedb0}, {0x4f909a0, 0x113395ba6ba0}, {{{0x11339464f3c0, 0x1, 0x1}}, 0x113394d9c970, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 392 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5000cc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 425 [syscall, 171 minutes]:
syscall.Syscall6(0xe8, 0x2f, 0x113395d27410, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:96 +0x39
golang.org/x/sys/unix.EpollWait(0x299b867?, {0x113395d27410?, 0x4f78778?, 0xc2aaa49aad52e551?}, 0x4c1dcc9d?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x113397104a80, {0x113395d27410, 0x2, 0x2}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:181 +0x225
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x113396755340, 0x1133970b9e68)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:364 +0x2df
github.com/cilium/ebpf/perf.(*Reader).Read(0x113394db37a0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:331 +0x3d
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:271 +0x67
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:268 +0x156

goroutine 399 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x1133970be8c0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113397db0aa0}, {0x4f8fca0, 0x113397086b80}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x1133970be8c0?}, {0x113396595840?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113397db0aa0?}, {0x4f8fca0?, 0x113397086b80?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x113394ee4200, {0x4f7afd0, 0x1133970be8c0}, {0x4f5b8e8, 0x113397db0aa0}, 0x113394206540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x113394ee4200, {0x4f7afd0, 0x1133970be8c0}, {0x4f5b8e8, 0x1133964459a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x113394ee4200, {0x4f7afd0, 0x1133970be8c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x1133970be8c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x1133970be8c0?}, 0x113396e08e78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x1133970be8c0}, {0x4f6a460, 0x113397086c00}, 0x1, 0x1, 0x1133970c5f68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x113394ee4200, {0x4f7afd0, 0x1133970be8c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x90309b?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 429
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 389 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd2300, {0x4f78938, 0x11339487fd10}, {0x4f909a0, 0x1133967a7c20})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x113396377320, {0x4f78938, 0x11339487fd10}, {0x4f909a0, 0x113396376ea0}, {{{0x113394244580, 0x1, 0x1}}, 0x113394cd49c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 386 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bce9ce00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113396e64700?, 0x88ffe62?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113396e64700)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113396e64700)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x460d20?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).AcceptUnix(0x11339488a360)
	/usr/local/go/src/net/unixsock.go:254 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).run(0x1133949b9c20, {0x4f78938, 0x11339487f380})
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x22b
github.com/cilium/cilium/pkg/envoy.newEnvoyAccessLogServer.func1({0x4f78938?, 0x11339487f380?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/envoy/cell.go:208 +0x2a
github.com/cilium/hive/job.(*jobOneShot).start(0x113396376a80, {0x4f78938, 0x11339487f380}, {0x4f909a0, 0x1133963769c0}, {{{0x1133941e6700, 0x1, 0x1}}, 0x113394d9d480, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 418 [select, 24 minutes]:
github.com/cilium/statedb.(*observable[...]).Observe.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/observable.go:46 +0x312
created by github.com/cilium/statedb.(*observable[...]).Observe in goroutine 344
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/observable.go:27 +0xbd

goroutine 417 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).run.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:65 +0x2c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).run in goroutine 386
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:64 +0x197

goroutine 419 [select]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runPodReflector.Buffer[...].func3.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x12b
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.runPodReflector.Buffer[...].func3 in goroutine 344
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 420 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 362
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 421 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 420
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 426 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9f3e0, {0x4f78938, 0x1133948ef140}, {0x4f909a0, 0x113395ba6d20}, {{{0x113394653180, 0x1, 0x1}}, 0x113394db3390, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 427 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9f3e0, {0x4f78938, 0x1133948ef320}, {0x4f909a0, 0x113395ba6d20}, {{{0x113394653180, 0x1, 0x1}}, 0x113394db3390, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 963 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x11339429c160)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 944
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 429 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5004060, {0x4f78938, 0x1133948ef710}, {0x4f909a0, 0x11339707c7e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x113395ba6ea0, {0x4f78938, 0x1133948ef710}, {0x4f909a0, 0x113394f175c0}, {{{0x113394ba3c00, 0x1, 0x1}}, 0x113394dfaae0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 430 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x50005e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 431 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5006b80, {0x4f78938, 0x1133948efa40}, {0x4f909a0, 0x113396ffcba0})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x113395ba7200, {0x4f78938, 0x1133948efa40}, {0x4f909a0, 0x113395ba7140}, {{{0x11339467a9e0, 0x1, 0x1}}, 0x113394dcddc0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1277 [select]:
net/http.(*persistConn).writeLoop(0x11339442a640)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 1275
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 433 [select, 24 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x1133941eb500, {0x4f78938, 0x1133948f41e0}, {0x11339711bc20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:213 +0xc5
github.com/cilium/hive/job.(*jobOneShot).start(0x113395ba76e0, {0x4f78938, 0x1133948f41e0}, {0x4f909a0, 0x113395ba7620}, {{{0x1133948667e0, 0x1, 0x1}}, 0x113394e2b260, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 434 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113397124150}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113397ae6eb0}, {0x4f8fca0, 0x113396fd1920}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113397124150?}, {0x11339417ca80?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113397ae6eb0?}, {0x4f8fca0?, 0x113396fd1920?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x113394ca4400, {0x4f7afd0, 0x113397124150}, {0x4f5b8e8, 0x113397ae6eb0}, 0x1133942060e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x113394ca4400, {0x4f7afd0, 0x113397124150}, {0x4f5b8e8, 0x1133964455e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x113394ca4400, {0x4f7afd0, 0x113397124150})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113397124150})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113397124150?}, 0x113397117678?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113397124150}, {0x4f6a460, 0x113396fd1a60}, 0x1, 0x1, 0x11339711df68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x113394ca4400, {0x4f7afd0, 0x113397124150})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 431
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 435 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 431
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 129495 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983afcc8, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113395c36400?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983afcb0, {0x1133988bc601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x8b?}, {0x1133988bc601?, 0x425234?, 0x113397153c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x113398842f00)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x113398842f00)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x113398842f00, {0x418d900, 0x113395154e70})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x1133954c1d70, {0x1133983c4c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x1133972d8280, 0x0, {0x4f57f10, 0x113398336400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113395a70900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x1133972d82d0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 641
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 438 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 434
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 439 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x113394ca4400, {0x4f78970, 0x1133964458b0}, 0x1133942060e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 434
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 441 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 399
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 442 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x113394ee4200, {0x4f78970, 0x113396445a90}, 0x113394206540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 399
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 443 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 444 [select, 171 minutes]:
github.com/cilium/stream.ToTruncatingChannel[...].func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sinks.go:161 +0x194
created by github.com/cilium/stream.ToTruncatingChannel[...] in goroutine 424
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sinks.go:154 +0xb9

goroutine 445 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 443
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 452 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9b600, {0x4f78938, 0x113394dd5aa0}, {0x4f909a0, 0x113394f16ae0}, {{{0x1133948845e0, 0x1, 0x1}}, 0x113394d9cc50, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 446 [select, 171 minutes]:
github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.FromChannel[...].func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb9
created by github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.FromChannel[...].func1 in goroutine 452
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 447 [select]:
github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.Buffer[...].func2.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x137
created by github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.Buffer[...].func2 in goroutine 452
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 453 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x113395ba7da0, {0x4f78938, 0x113394c203f0}, {0x4f909a0, 0x113396ffd380})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:115 +0x365
github.com/cilium/hive/job.(*jobOneShot).start(0x113395ba7e00, {0x4f78938, 0x113394c203f0}, {0x4f909a0, 0x113395ba7ce0}, {{{0x1133948857c0, 0x1, 0x1}}, 0x113394f38000, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 454 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 455 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x113393faaf58?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 456 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc34c0, {0x4f78970, 0x1133964b8870}, 0x1133970bf5e0, {0x4fa4cb0, 0x113396c936f0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:591 +0x551
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 457 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 1159 [select, 50 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x1133943e1a00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1214 +0x1e5
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1157
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:371 +0x1929

goroutine 129615 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133997d6dc8, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x1133978e0380?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133997d6db0, {0x113396d92c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x82?}, {0x113396d92c01?, 0x425234?, 0x113396e53c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x113397be2a00)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x113397be2a00)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x113397be2a00, {0x418d900, 0x11339457fae8})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x113394ece780, {0x113397e22800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113397ae6e60, 0x0, {0x4f57f10, 0x113394d74a80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x11339487d540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113397ae6eb0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 434
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 512 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:149 +0x18c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:147 +0x3a7

goroutine 459 [select, 24 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:188 +0x245
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:159 +0xf2

goroutine 500 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bce37400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397211980?, 0xfffffffffffffffc?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113397211980)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113397211980)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x113397244800)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x113397244800)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*wrappedTCPListener).Accept(0x113395afd980)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:1354 +0x24
github.com/cilium/dns.(*Server).serveTCP(0x113394ee5500, {0x4f70c30, 0x113395afd980})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0x107
github.com/cilium/dns.(*Server).ActivateAndServe(0x113394ee5500)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x22b
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen.func1(0x113394ee5500)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:665 +0x29b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen in goroutine 451
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:654 +0x46e

goroutine 924 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x1133970bfb20?, 0x113394b6f010?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x11339713c550?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 546
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 462 [chan receive, 24 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:125 +0x10d
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:122 +0x12e

goroutine 464 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:85 +0x119
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:82 +0x12e

goroutine 933 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x1133969fd1e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 322
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 482 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x11339720e0cc?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 483 [sync.Cond.Wait, 24 minutes]:
sync.runtime_notifyListWait(0x1133970a3890, 0x12)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc3140, {0x4f78970, 0x1133964b8d70}, 0x1133970bfe30, {0x4fa4a80, 0x113397091be0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 462
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 484 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 462
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 486 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 464
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 487 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 464
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 488 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x1133970a3990, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc3440, {0x4f78970, 0x1133964b8eb0}, 0x113397216150, {0x4fa4c60, 0x113396d3c6c0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 464
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 489 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 464
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 490 [sync.Cond.Wait, 24 minutes]:
sync.runtime_notifyListWait(0x113394f50ad0, 0x8)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x1133950bdbe0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x113394f50a80, 0x1133970a3ac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133962b7ad0, {0x4f7afd0, 0x113396d80e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x113396d80e00?}, 0x113394c21c20?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x113396d80e00}, 0x11339722fea0, {0x4f0fa20, 0x113394c21c20}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x113396d80e00}, 0x11339721dea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133962b7ad0, {0x4f7afd0, 0x113396d80e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x113397087800, 0x113396d80e00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 319
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 496 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 493 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 490
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 494 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x113396d80e00}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113397b46190}, {0x79c3bce2e6b8, 0x113394f50a80}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x113396d80e00?}, {0x1133959785a8?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113397b46190?}, {0x79c3bce2e6b8?, 0x113394f50a80?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x113394ee4c00, {0x4f7afd0, 0x113396d80e00}, {0x4f5b8e8, 0x113397b46190}, 0x11339439c620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x113394ee4c00, {0x4f7afd0, 0x113396d80e00}, {0x4f5b8e8, 0x1133964b9770})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x113394ee4c00, {0x4f7afd0, 0x113396d80e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x113396d80e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x113396d80e00?}, 0x113397114e58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x113396d80e00}, {0x4f6a460, 0x113397087a20}, 0x1, 0x1, 0x113397155f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x113394ee4c00, {0x4f7afd0, 0x113396d80e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 490
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 922 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/envoy.(*adsServer).startAdsGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpcnew.go:76 +0x35
created by github.com/cilium/cilium/pkg/envoy.(*adsServer).startAdsGRPCServer in goroutine 387
	/go/src/github.com/cilium/cilium/pkg/envoy/grpcnew.go:75 +0x807

goroutine 1272 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x11339767cb00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1183
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 102954 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bbf2f600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113394469880?, 0x113394c0c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113394469880, {0x113394c0c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113394469880, {0x113394c0c000?, 0x50ce20?, 0x113394469880?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133999e9508, {0x113394c0c000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x1133977abcc0, {0x113394c0c000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x113394d354a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113394d354a0, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x113396b96cf0, {0x4f78938, 0x113394caf260})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 1302
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 1203 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396e26580)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1201
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1183 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x113396597a40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1167
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 1184 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396ded340)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1167
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1273 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x1133989db360)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 924
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 127999 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983aea80, 0x113397a00000, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983aea80, 0x4f78938?, 0x113394cff4d0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 637
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 1267 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x113396e38be0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1169
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 126217 [select, 8 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x113397e8e180, 0x113394fbe280, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x113397e8e180, 0xfcedd7?, 0x113398ad2500?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 613
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 498 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x11339717c160)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 513 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 496
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 520 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 494
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 131392 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x79c3bbf2f400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x1133997db000?, 0x113397a52000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x1133997db000, {0x113397a52000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x1133997db000, {0x113397a52000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133999bd070, {0x113397a52000?, 0x1133949db260?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x113397a443c0, {0x113397a52000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x113397292a20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113397292a20, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x113397a443c0)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 131391
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 521 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x113394ee4c00, {0x4f78970, 0x1133964b9860}, 0x11339439c620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 494
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 740 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func7()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:371 +0x2c
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:370 +0x1adf

goroutine 501 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bce9d800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397211a00?, 0x113397109000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x113397211a00, {0x113397109000, 0x200, 0x200}, {0x113394e133b0, 0x2c, 0x2c}, 0x0, 0x113396d86aa8)
	/usr/local/go/src/internal/poll/fd_unix.go:322 +0x32a
net.(*netFD).readMsgInet4(0x113397211a00, {0x113397109000?, 0x113396d86a80?, 0x476d0c?}, {0x113394e133b0?, 0x3f004000a5000a?, 0x113396d86a80?}, 0x4f0?, 0x4f?)
	/usr/local/go/src/net/fd_posix.go:97 +0x31
net.(*UDPConn).readMsg(0x48dd3b?, {0x113397109000?, 0x9617a5338ce?, 0x0?}, {0x113394e133b0?, 0x441d680?, 0x79c3bce9d920?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x175
net.(*UDPConn).ReadMsgUDPAddrPort(0x113394f4d168, {0x113397109000?, 0x4a0edd?, 0x83b0f80?}, {0x113394e133b0?, 0x113396d86c08?, 0x4a0ce5?})
	/usr/local/go/src/net/udpsock.go:200 +0x3e
net.(*UDPConn).ReadMsgUDP(0x113397179ac8?, {0x113397109000?, 0x4381ca0?, 0x113397211a00?}, {0x113394e133b0?, 0x113396d86c68?, 0x425c85?})
	/usr/local/go/src/net/udpsock.go:188 +0x25
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x113394f4d168?, 0x113394f4d168)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:163 +0x5f
github.com/cilium/dns.(*Server).readUDP(0x113394ca4e00, 0x113394f4d168, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0xe2
github.com/cilium/dns.defaultReader.ReadUDP({0x113394ca4e00?}, 0x441b1a0?, 0x3dfaee0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x13
github.com/cilium/dns.(*Server).serveUDP(0x113394ca4e00, {0x4fa4290, 0x113394f4d168})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x242
github.com/cilium/dns.(*Server).ActivateAndServe(0x113394ca4e00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x19a
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen.func1(0x113394ca4e00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:665 +0x29b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen in goroutine 451
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:654 +0x46e

goroutine 531 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x113397133ae0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 1160 [IO wait, 52 minutes]:
internal/poll.runtime_pollWait(0x79c3bcdda400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x42?, 0x804f53300?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x113396a09100, 0x113395331800)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
net.(*rawConn).Read(0x1133963e4958, 0x113396d4cbb8?)
	/usr/local/go/src/net/rawconn.go:44 +0x36
google.golang.org/grpc/internal/transport/readyreader.(*nonBlockingReader).ReadOnReady(0x113396a034a0, 0x113396d4cc18?, {0x4f57668, 0x113394a29620})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/readyreader/ready_reader.go:114 +0xa7
google.golang.org/grpc/internal/transport/readyreader.(*bufReadyReader).Read(0x11339686f260, {0x113395df23c4, 0x9, 0x4696740?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/readyreader/ready_reader.go:221 +0x174
io.ReadAtLeast({0x4f0e6e0, 0x11339686f260}, {0x113395df23c4, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x8e
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x113395df23c4, 0x9, 0xaedad2?}, {0x4f0e6e0?, 0x11339686f260?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:250 +0x65
golang.org/x/net/http2.(*Framer).ReadFrameHeader(0x113395df2380)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:513 +0x6b
google.golang.org/grpc/internal/transport.(*framer).readFrame(0x113396a09200)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http_util.go:493 +0x45
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x1133943e1a00, {0x4f78938, 0x113394a29ad0}, 0x113394a29b00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:646 +0xff
google.golang.org/grpc.(*Server).serveStreams(0x1133959be908, {0x4f78778?, 0x88ffe40?}, {0x4f7ae10, 0x1133943e1a00}, {0x4faaec0?, 0x1133963e4950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1072 +0x368
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1006 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1157
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1005 +0x1cb

goroutine 656 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x113394f01220, {0x4f78938, 0x113394f1b4a0}, {0x4f54778, 0x1133979f8180}, 0x1133976a9180)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:228 +0x369
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x113394f01220, {0x4f78938, 0x113394f1b4a0}, {0x1133979f7c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:155 +0x29d
github.com/cilium/hive/job.(*jobOneShot).start(0x113395594720, {0x4f78938, 0x113394f1b4a0}, {0x4f909a0, 0x1133955945a0}, {{{0x1133965ecee0, 0x1, 0x1}}, 0x1133965e31f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 527 [select]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x113397702280)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:165 +0xa5
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 534
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:151 +0x356

goroutine 532 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x113397296700?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 125004 [select, 10 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x113397e8f500, 0x11339768b040, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x113397e8f500, 0xfcedd7?, 0x113397cf4a50?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 353
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 739 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bcddae00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397d00880?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113397d00880)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113397d00880)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x1133978eb000)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x1133978eb000)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
google.golang.org/grpc.(*Server).Serve(0x113395a19208, {0x4f690b0, 0x1133978eb000})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:934 +0x45c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:94
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func6()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:361 +0x4a
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:360 +0x1a77

goroutine 535 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x113395712900, {0x4f78938, 0x113394ca36b0}, {0x4f909a0, 0x113395712840}, {{{0x113394bc16c0, 0x1, 0x1}}, 0x1133952152f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 536 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x113395712ae0, {0x4f78938, 0x113394ca38c0}, {0x4f909a0, 0x113395712420}, {{{0x113394b65ea0, 0x1, 0x1}}, 0x1133951fb5a0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 741 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 658
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 538 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/status.newStatusCollector.func1({0x4f78938, 0x113394ca3e90}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/status/cell.go:160 +0x394
github.com/cilium/hive/job.(*jobOneShot).start(0x113395713140, {0x4f78938, 0x113394ca3e90}, {0x4f909a0, 0x113395d52180}, {{{0x113394892200, 0x1, 0x1}}, 0x113394f398c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 539 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x79c3bce37200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x1133972b0580?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x1133972b0580)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x1133972b0580)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x1133976acdf8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x113394c400f0)
	/usr/local/go/src/net/unixsock.go:267 +0x30
net/http.(*Server).Serve(0x113394ca5500, {0x4f66810, 0x113394c400f0})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x4f66810?, 0x113394c400f0?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:453 +0x72
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:451 +0x4a5

goroutine 540 [select, 2 minutes]:
github.com/cilium/cilium/pkg/metrics.(*sampler).collectLoop(0x113394b969f0, {0x4f78938, 0x113394c40390}, {0x4f909a0, 0x113397768960})
	/go/src/github.com/cilium/cilium/pkg/metrics/sampler.go:305 +0x119
github.com/cilium/hive/job.(*jobOneShot).start(0x1133969cf3e0, {0x4f78938, 0x113394c40390}, {0x4f909a0, 0x113394d35020}, {{{0x113394892cc0, 0x1, 0x1}}, 0x113394d437f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 541 [select, 52 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x1133969cf440, {0x4f78938, 0x113394c405d0}, {0x4f909a0, 0x113394d35020}, {{{0x113394892cc0, 0x1, 0x1}}, 0x113394d437f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 542 [chan receive, 171 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x11339729ca80, {0x4f78970, 0x11339681e730})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:259 +0x68
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:110 +0x1c5

goroutine 697 [chan receive, 171 minutes]:
github.com/cilium/hive/shell.shell.listener.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/shell/server.go:80 +0x3e
created by github.com/cilium/hive/shell.shell.listener in goroutine 544
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/shell/server.go:79 +0x26c

goroutine 544 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bce37000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x11339782a780?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x11339782a780)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x11339782a780)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x0?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x113394daf320)
	/usr/local/go/src/net/unixsock.go:267 +0x30
github.com/cilium/hive/shell.shell.listener({{0x4f50fe0, 0x1133969cfb00}, 0x113395a50650, 0x113394b994a0, {{0x4c2d4ba, 0x1a}}}, {0x4f78938, 0x113394c40f30}, {0x4f909a0, 0x1133977ee5a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/shell/server.go:90 +0x430
github.com/cilium/hive/job.(*jobOneShot).start(0x1133969cfb60, {0x4f78938, 0x113394c40f30}, {0x4f909a0, 0x1133969cfaa0}, {{{0x0, 0x0, 0x0}}, 0x113394be6500, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 545 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bce36c00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x11339782ae00?, 0x900000036?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x11339782ae00)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x11339782ae00)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x113397846040)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x113397846040)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
net/http.(*Server).Serve(0x113394ee5700, {0x4f690b0, 0x113397846040})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
github.com/cilium/cilium/daemon/healthz.registerAgentHealthHTTPService.func1({0x4f78938, 0x113394c410b0}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/daemon/healthz/agenthealth.go:107 +0x4ff
github.com/cilium/hive/job.(*jobOneShot).start(0x1133969cfd40, {0x4f78938, 0x113394c410b0}, {0x4f909a0, 0x1133969cfbc0}, {{{0x1133955b5ec0, 0x1, 0x1}}, 0x113395ac51c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 928 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 927
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 923 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x113395edf860})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396325ce0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 546
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 548 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpointmanager.(*namespaceUpdater).run(0x113395294a80, {0x4f78938, 0x113394c415f0}, {0x113397855c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/endpointmanager/namespace_updater.go:82 +0x20d
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f262a0, {0x4f78938, 0x113394c415f0}, {0x4f909a0, 0x113394f161e0}, {{{0x113394a3f020, 0x1, 0x1}}, 0x113394d9dec0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 132151 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bbf4e200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x1133965efc80?, 0x11339731e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x1133965efc80, {0x11339731e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x1133965efc80, {0x11339731e000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133963e53e8, {0x11339731e000?, 0x1133949db260?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x113396e10dc0, {0x11339731e000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x1133971fa360)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x1133971fa360, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x113396e10dc0)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 132138
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 552 [select, 171 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/writer.(*nodePortAddrReconciler).nodePortAddressReconcilerLoop(0x113395746980, {0x4f78938, 0x113394d1e3f0}, {0x113397869c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/writer/node_addr_reconciler.go:83 +0x14d
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f26720, {0x4f78938, 0x113394d1e3f0}, {0x4f909a0, 0x113394f26660}, {{{0x1133951e2e60, 0x1, 0x1}}, 0x113394dfaee0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 553 [select, 171 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/writer.(*wildcardAddressReconciler).wildcardAddressReconcilerLoop(0x113395746f00, {0x4f78938, 0x113394d1e6f0}, {0x11339786bc20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/writer/wild_addr_reconciler.go:84 +0x14d
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f267e0, {0x4f78938, 0x113394d1e6f0}, {0x4f909a0, 0x113394f26660}, {{{0x1133951e2e60, 0x1, 0x1}}, 0x113394dfaee0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 554 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x113394f26a80, {0x4f78938, 0x113394d1e8d0}, {0x4f909a0, 0x113394f269c0}, {{{0x1133953d9ae0, 0x1, 0x1}}, 0x113394d42b70, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 555 [select, 170 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/reconciler.socketTerminationLoop({{{}}, {0x4f50fe0, 0x113394f26ba0}, 0x1133950fd530, {0x4ffc8f8, 0x113394355a40}, 0x113395777480, {{0x3b9aca00, 0xdf8475800, 0x10000, ...}, ...}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reconciler/termination.go:181 +0x406
github.com/cilium/cilium/pkg/loadbalancer/reconciler.registerSocketTermination.func1({0x4f78938, 0x113394d1ede0}, {0x4f909a0, 0x1133977eea80})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reconciler/termination.go:133 +0x1af
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f26d80, {0x4f78938, 0x113394d1ede0}, {0x4f909a0, 0x113394f26b40}, {{{0x113395839900, 0x1, 0x1}}, 0x113395777480, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 556 [select, 20 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/healthserver.(*healthServer).controlLoop(0x1133946a30e0, {0x4f78938, 0x113394d1eff0}, {0x4f909a0, 0x1133977ef680})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/healthserver/healthserver.go:234 +0x457
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f271a0, {0x4f78938, 0x113394d1eff0}, {0x4f909a0, 0x113394f27020}, {{{0x113394f81d20, 0x1, 0x1}}, 0x113395b67490, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 557 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x113394f27200, {0x4f78938, 0x113394d1f1d0}, {0x4f909a0, 0x1133963769c0}, {{{0x1133941e6700, 0x1, 0x1}}, 0x113394d9d480, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 559 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9af00, {0x4f78938, 0x113394d1f4a0}, {0x4f909a0, 0x1133963769c0}, {{{0x1133941e6700, 0x1, 0x1}}, 0x113394d9d480, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 560 [select, 171 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd1be0, {0x4f78938, 0x113394d1f7a0}, {0x4f909a0, 0x11339729ce40})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f273e0, {0x4f78938, 0x113394d1f7a0}, {0x4f909a0, 0x113394f27260}, {{{0x1133955b7500, 0x1, 0x1}}, 0x1133952672f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 561 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd1be0, {0x4f78938, 0x113394d1f980}, {0x4f909a0, 0x11339729cf00})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f27440, {0x4f78938, 0x113394d1f980}, {0x4f909a0, 0x113394f27260}, {{{0x1133955b7500, 0x1, 0x1}}, 0x1133952672f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 562 [select, 171 minutes]:
github.com/cilium/cilium/pkg/ciliumenvoyconfig.(*nodeLabelController).run(0x11339475ca00, {0x4f78938, 0x113394d1fb60}, {0x1133973bdc20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/ciliumenvoyconfig/node_labels_controller.go:92 +0x23c
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f274a0, {0x4f78938, 0x113394d1fb60}, {0x4f909a0, 0x113394f27260}, {{{0x1133955b7500, 0x1, 0x1}}, 0x1133952672f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 563 [select, 170 minutes]:
github.com/cilium/cilium/pkg/ipcache/cell.registerAPIServerBackendWatcher.func1({0x4f78938, 0x113394d1fd40}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/cell/apiserver_watcher.go:79 +0x3d0
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f27560, {0x4f78938, 0x113394d1fd40}, {0x4f909a0, 0x113394d34f60}, {{{0x1133948924a0, 0x1, 0x1}}, 0x113394d43580, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 568 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5001660)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 126052 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133997d6948, 0x8)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113395eca5a0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133997d6930, {0x113395b02d20, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x11339783dcc8?}, {0x113395b02d20?, 0x11339783dcc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x1133997d6900}, {0x113395b02d20, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x113395a0c408, {0x113398902400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x11339838eb40, 0x0, {0x4f57f10, 0x113395bf86c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x1133952afe80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x11339838eb90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 356
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 570 [select, 170 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func2()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:171 +0x528
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:132 +0x230

goroutine 130125 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x113397e8e7c8, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x1133952b3480?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x113397e8e7b0, {0x113396924601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x7b?}, {0x113396924601?, 0x425234?, 0x1133976b5c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x113394c6f2c0)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x113394c6f2c0)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x113394c6f2c0, {0x418d900, 0x113395b3f440})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x1133952c5560, {0x113397e22c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113398bd9680, 0x0, {0x4f57f10, 0x113394248d80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x1133978f1860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113398bd9b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 652
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 572 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5000e20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 822 [select, 2 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1043
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 648
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1039 +0x5a

goroutine 574 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x11339729cae0, {0x4f78938, 0x113394d20c60}, {0x4f909a0, 0x113394f279e0}, {{{0x113395e529a0, 0x1, 0x1}}, 0x113395b546a0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 576 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5003920, {0x4f78938, 0x113394d20e70}, {0x4f909a0, 0x11339729d860})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x113394f27c80, {0x4f78938, 0x113394d20e70}, {0x4f909a0, 0x113394f27b00}, {{{0x113395ec9bc0, 0x1, 0x1}}, 0x113395cbb350, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 577 [select, 52 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd1ca0, {0x4f78938, 0x113394d21050}, {0x4f909a0, 0x11339729d920})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x113394d34060, {0x4f78938, 0x113394d21050}, {0x4f909a0, 0x113394f27ce0}, {{{0x113395eeb2a0, 0x1, 0x1}}, 0x113395d39b00, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 578 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd1ca0, {0x4f78938, 0x113394d21260}, {0x4f909a0, 0x11339729d9e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x113394d340c0, {0x4f78938, 0x113394d21260}, {0x4f909a0, 0x113394f27ce0}, {{{0x113395eeb2a0, 0x1, 0x1}}, 0x113395d39b00, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 579 [select, 171 minutes]:
github.com/cilium/cilium/pkg/driftchecker.checker.watchTableChanges({0x113394dda000, 0x1133951295f0, {0x4ffabe8, 0x113394d8f420}, 0x113395db85c0, {{0x4fc91a8, 0x1133946b7880}}, 0x113394b359b0}, {0x4f78938, 0x113394d21410})
	/go/src/github.com/cilium/cilium/pkg/driftchecker/checker.go:81 +0x23b
github.com/cilium/cilium/pkg/driftchecker.Register.func1({0x4f78938?, 0x113394d21410?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/driftchecker/checker.go:61 +0x4c
github.com/cilium/hive/job.(*jobOneShot).start(0x113394d341e0, {0x4f78938, 0x113394d21410}, {0x4f909a0, 0x113394d34120}, {{{0x113396197080, 0x1, 0x1}}, 0x113395db85c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 615 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 582
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 581 [select, 171 minutes]:
github.com/cilium/statedb.derive[...].loop(0x4fa69a0, {0x4f78938, 0x113394d217a0}, {0x113396fe1c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/derive.go:118 +0x55e
github.com/cilium/hive/job.(*jobOneShot).start(0x113394d34c00, {0x4f78938, 0x113394d217a0}, {0x4f909a0, 0x113394d34ae0}, {{{0x11339629edc0, 0x1, 0x1}}, 0x1133962cc960, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 582 [select, 2 minutes]:
github.com/cilium/cilium/pkg/maps/netdev.syncNetDevMap({{{}}, {0x4f50fe0, 0x113394f16840}, 0x11339639c500, 0x113394e3e558, {0x4ffbe90, 0x113394355420}, {0x4f83548, 0x11339631a740}}, {0x4f78938, ...})
	/go/src/github.com/cilium/cilium/pkg/maps/netdev/netdev_sync.go:64 +0x32f
github.com/cilium/cilium/pkg/maps/netdev.registerNetDevMapSync.func1({0x4f78938?, 0x113394d21980?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/maps/netdev/netdev_sync.go:44 +0x4c
github.com/cilium/hive/job.(*jobOneShot).start(0x1133950101e0, {0x4f78938, 0x113394d21980}, {0x4f909a0, 0x1133953498c0}, {{{0x11339632b580, 0x1, 0x1}}, 0x11339639c500, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 616 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x113396755470, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x113396755420, 0x11339764f540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133972dc840, {0x4f7afd0, 0x1133972c1420})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x1133972c1420?}, 0x113394d41740?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x1133972c1420}, 0x113397661ea0, {0x4f0fa20, 0x113394d41740}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x1133972c1420}, 0x113397661ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133972dc840, {0x4f7afd0, 0x1133972c1420})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x11339747ad20, 0x1133972c1420)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 558
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 584 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x113395594180, {0x4f78938, 0x113394d21d40}, {0x4f909a0, 0x113395594060}, {{{0x113396afa640, 0x1, 0x1}}, 0x11339652b5c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1169 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x11339674e408?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 946
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 586 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x1133955943c0, {0x4f78938, 0x113394d30210}, {0x4f909a0, 0x113395594300}, {{{0x113396580540, 0x1, 0x1}}, 0x11339657e420, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 655 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x113395594540, {0x4f78938, 0x113394f1b0b0}, {0x4f909a0, 0x113395594480}, {{{0x0, 0x0, 0x0}}, 0x1133965bad20, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 588 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 559
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 589 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x1133972d0798?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 559
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 590 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x1133972aeb10, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc2460, {0x4f78970, 0x11339681f9f0}, 0x1133972c1ab0, {0x4fa1f90, 0x11339764ae90})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 559
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 591 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 559
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 592 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...].func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0x118
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...].func1 in goroutine 559
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 593 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 594 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x1133972c6758?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 570
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 595 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x1133972afbd0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc33c0, {0x4f78970, 0x1133968d45a0}, 0x1133972fe460, {0x4fa4c10, 0x11339764aee0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 596 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 597 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 598 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 570
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 599 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x11339742e0d0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc32c0, {0x4f78970, 0x1133968d4730}, 0x1133972fe5b0, {0x4fa4b70, 0x11339764af40})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 600 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 601 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 602 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 570
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 603 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x11339742e4d0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc3240, {0x4f78970, 0x1133968d4870}, 0x1133972fe700, {0x4fa4b20, 0x11339764afa0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 604 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 605 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 606 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x113394f355c0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 570
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 607 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x11339742e8d0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc31c0, {0x4f78970, 0x1133968d4a00}, 0x1133972fe850, {0x4fa4ad0, 0x11339764b000})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 608 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 570
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 609 [select, 170 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.startK8sPolicyWatcher.serviceEventStream.func8.1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:152 +0xd0b
created by github.com/cilium/cilium/pkg/policy/k8s.startK8sPolicyWatcher.serviceEventStream.func8 in goroutine 570
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:72 +0x105

goroutine 610 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 609
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 647 [sync.Cond.Wait, 24 minutes]:
sync.runtime_notifyListWait(0x1133967559b0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x11339747a0c0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x113396755960, 0x1133976a0640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133972dcbb0, {0x4f7afd0, 0x11339769ee70})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x11339769ee70?}, 0x113394c171a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x11339769ee70}, 0x113397c9ddb8, {0x4f0fa20, 0x113394c171a0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x11339769ee70}, 0x1133972f0db8, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133972dcbb0, {0x4f7afd0, 0x11339769ee70})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x11339769ee70?, 0x4cb500?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x1133976a27a0, 0x11339769ee70)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x11339734c580, {0x4f78970, 0x1133967eb3b0}, {0x4f6b170, 0x11339723b198})
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:427 +0x47d
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:271 +0x39
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 529
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 613 [select, 2 minutes]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x11339767f880}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113398d6b360}, {0x4f8fca0, 0x11339747a060}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x11339767f880?}, {0x1133959f0860?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113398d6b360?}, {0x4f8fca0?, 0x11339747a060?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133953ed000, {0x4f7afd0, 0x11339767f880}, {0x4f5b8e8, 0x113398d6b360}, 0x113397c170a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133953ed000, {0x4f7afd0, 0x11339767f880}, {0x4f5b8e8, 0x113397c261e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133953ed000, {0x4f7afd0, 0x11339767f880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x11339767f880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x11339767f880?}, 0x1133972d2e78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x11339767f880}, {0x4f6a460, 0x11339747b1a0}, 0x1, 0x1, 0x1133970c1f68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133953ed000, {0x4f7afd0, 0x11339767f880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 576
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 614 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 576
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 117087 [select]:
net/http.(*persistConn).writeLoop(0x113398acd040)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 117085
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 618 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x113396755550, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x113396755500, 0x11339764f5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133972dc8f0, {0x4f7afd0, 0x1133972fe380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x1133972fe380?}, 0x113394d41b30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x1133972fe380}, 0x1133972efea0, {0x4f0fa20, 0x113394d41b30}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x1133972fe380}, 0x1133972efea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133972dc8f0, {0x4f7afd0, 0x1133972fe380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x11339747ad80, 0x1133972fe380)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 567
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 620 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x113396755710, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x1133967556c0, 0x11339764f640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133972dc9a0, {0x4f7afd0, 0x1133972fe230})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x1133972fe230?}, 0x113394d41ec0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x1133972fe230}, 0x113397674ea0, {0x4f0fa20, 0x113394d41ec0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x1133972fe230}, 0x113397674ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133972dc9a0, {0x4f7afd0, 0x1133972fe230})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x11339747ade0, 0x1133972fe230)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 564
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 128166 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983aed80, 0x113397268780, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983aed80, 0xfcedd7?, 0x113398da8af0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 629
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 622 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x1133967557f0, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x1133967557a0, 0x11339764f6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133972dca50, {0x4f7afd0, 0x1133972fe2a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x1133972fe2a0?}, 0x113394c163f0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x1133972fe2a0}, 0x113397675ea0, {0x4f0fa20, 0x113394c163f0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x1133972fe2a0}, 0x113397675ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133972dca50, {0x4f7afd0, 0x1133972fe2a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x11339747ae40, 0x1133972fe2a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 565
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 1276 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bcdda200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x11339680ae80?, 0x113394a43000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x11339680ae80, {0x113394a43000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x11339680ae80, {0x113394a43000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133981fc3b0, {0x113394a43000?, 0x1133949db260?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x11339442a640, {0x113394a43000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x113398eb8900)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113398eb8900, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x11339442a640)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 1275
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 624 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x1133967558d0, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x113396755880, 0x11339764f740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x1133972dcb00, {0x4f7afd0, 0x1133972fe310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x1133972fe310?}, 0x113394c16750?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x1133972fe310}, 0x113397676ea0, {0x4f0fa20, 0x113394c16750}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x1133972fe310}, 0x113397676ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x1133972dcb00, {0x4f7afd0, 0x1133972fe310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x11339747aea0, 0x1133972fe310)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 566
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 705 [select, 171 minutes]:
github.com/cilium/cilium/pkg/mtu.(*endpointUpdater).Updater(0x11339477c5f0, {0x4f78938, 0x113394f1b620}, {0x4f909a0, 0x11339797a8a0})
	/go/src/github.com/cilium/cilium/pkg/mtu/endpoint_updater.go:125 +0x21a
github.com/cilium/hive/job.(*jobOneShot).start(0x113395594900, {0x4f78938, 0x113394f1b620}, {0x4f909a0, 0x113395ba6ae0}, {{{0x11339464e1c0, 0x1, 0x1}}, 0x113394d9ccc0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 628 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 616
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 629 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x1133972c1420}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113397961630}, {0x79c3bce2e6b8, 0x113396755420}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x1133972c1420?}, {0x113395807860?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113397961630?}, {0x79c3bce2e6b8?, 0x113396755420?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133953ed800, {0x4f7afd0, 0x1133972c1420}, {0x4f5b8e8, 0x113397961630}, 0x113397c16770)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133953ed800, {0x4f7afd0, 0x1133972c1420}, {0x4f5b8e8, 0x113397c26280})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133953ed800, {0x4f7afd0, 0x1133972c1420})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x1133972c1420})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x1133972c1420?}, 0x1133972e6658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x1133972c1420}, {0x4f6a460, 0x11339747b500}, 0x1, 0x1, 0x113397443f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133953ed800, {0x4f7afd0, 0x1133972c1420})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 616
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1274 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x11339767c420)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 924
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 632 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 618
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 633 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x1133972fe380}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x11339782c7d0}, {0x79c3bce2e6b8, 0x113396755500}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x1133972fe380?}, {0x1133958835b0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x11339782c7d0?}, {0x79c3bce2e6b8?, 0x113396755500?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133953eda00, {0x4f7afd0, 0x1133972fe380}, {0x4f5b8e8, 0x11339782c7d0}, 0x113397c169a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133953eda00, {0x4f7afd0, 0x1133972fe380}, {0x4f5b8e8, 0x113397c26370})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133953eda00, {0x4f7afd0, 0x1133972fe380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x1133972fe380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x1133972fe380?}, 0x1133972c8658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x1133972fe380}, {0x4f6a460, 0x11339747b820}, 0x1, 0x1, 0x1133970b5f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133953eda00, {0x4f7afd0, 0x1133972fe380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 618
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 636 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 620
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 637 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x1133972fe230}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x1133968ffa40}, {0x79c3bce2e6b8, 0x1133967556c0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x1133972fe230?}, {0x113394ceb300?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x1133968ffa40?}, {0x79c3bce2e6b8?, 0x1133967556c0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133953edb00, {0x4f7afd0, 0x1133972fe230}, {0x4f5b8e8, 0x1133968ffa40}, 0x113397c17420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133953edb00, {0x4f7afd0, 0x1133972fe230}, {0x4f5b8e8, 0x113397c26460})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133953edb00, {0x4f7afd0, 0x1133972fe230})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x1133972fe230})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x1133972fe230?}, 0x1133972c6e58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x1133972fe230}, {0x4f6a460, 0x11339747bb60}, 0x1, 0x1, 0x1133970c7f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133953edb00, {0x4f7afd0, 0x1133972fe230})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 620
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 652 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x11339769ee70}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113398bd9b80}, {0x79c3bce2e6b8, 0x113396755960}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x11339769ee70?}, {0x113395807ed0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113398bd9b80?}, {0x79c3bce2e6b8?, 0x113396755960?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133976bc300, {0x4f7afd0, 0x11339769ee70}, {0x4f5b8e8, 0x113398bd9b80}, 0x113397c17030)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133976bc300, {0x4f7afd0, 0x11339769ee70}, {0x4f5b8e8, 0x113397bfdc70})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133976bc300, {0x4f7afd0, 0x11339769ee70})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x11339769ee70})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x11339769ee70?}, 0x1133976b1e58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x11339769ee70}, {0x4f6a460, 0x1133976a28a0}, 0x1, 0x1, 0x113397449f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133976bc300, {0x4f7afd0, 0x11339769ee70})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 647
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 640 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 622
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 641 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x1133972fe2a0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x1133972d82d0}, {0x79c3bce2e6b8, 0x1133967557a0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x1133972fe2a0?}, {0x1133965b8198?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x1133972d82d0?}, {0x79c3bce2e6b8?, 0x1133967557a0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133953edc00, {0x4f7afd0, 0x1133972fe2a0}, {0x4f5b8e8, 0x1133972d82d0}, 0x113397c16d90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133953edc00, {0x4f7afd0, 0x1133972fe2a0}, {0x4f5b8e8, 0x113397c26500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133953edc00, {0x4f7afd0, 0x1133972fe2a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x1133972fe2a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x1133972fe2a0?}, 0x1133972c7658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x1133972fe2a0}, {0x4f6a460, 0x11339747bea0}, 0x1, 0x1, 0x11339730ff48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133953edc00, {0x4f7afd0, 0x1133972fe2a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 622
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 651 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 647
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 644 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 624
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 645 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x1133972fe310}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x113397b4a8c0}, {0x79c3bce2e6b8, 0x113396755880}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x1133972fe310?}, {0x113394c94f78?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x113397b4a8c0?}, {0x79c3bce2e6b8?, 0x113396755880?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x1133953edd00, {0x4f7afd0, 0x1133972fe310}, {0x4f5b8e8, 0x113397b4a8c0}, 0x113397c16fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x1133953edd00, {0x4f7afd0, 0x1133972fe310}, {0x4f5b8e8, 0x113397c265f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x1133953edd00, {0x4f7afd0, 0x1133972fe310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x1133972fe310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x1133972fe310?}, 0x1133972c7e58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x1133972fe310}, {0x4f6a460, 0x1133976a22e0}, 0x1, 0x1, 0x1133976b7f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x1133953edd00, {0x4f7afd0, 0x1133972fe310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 624
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 102966 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bbf2f000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x1133992fc980?, 0x113395cdb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x1133992fc980, {0x113395cdb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x1133992fc980, {0x113395cdb000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x113399a57588, {0x113395cdb000?, 0x1133986fac30?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x113396d22dc0, {0x113395cdb000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x11339892be00)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x11339892be00, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x113396d22dc0)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 102965
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 658 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 659 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x113397346c80)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:126 +0x97
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:281 +0xab2

goroutine 660 [syscall]:
syscall.Syscall6(0xe8, 0x4c, 0x113397874588, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:96 +0x39
golang.org/x/sys/unix.EpollWait(0x4f085e0?, {0x113397874588?, 0x8?, 0x8?}, 0x113398ff5c58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x1133978eb700, {0x113397874588, 0x2, 0x2}, {0x48af39?, 0x1133976b5d20?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:181 +0x225
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x113394f50e00, 0x113398ff5e58)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:364 +0x2df
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:331
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x113394428fc0, {0x4f78970, 0x113397702f00})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:349 +0x488
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:213 +0xd0

goroutine 661 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bce36e00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397722800?, 0x9a85a5?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113397722800)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113397722800)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x1133978745a0?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x113394d54ba0)
	/usr/local/go/src/net/unixsock.go:267 +0x30
google.golang.org/grpc.(*Server).Serve(0x1133959befc8, {0x4f66810, 0x113394d54ba0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:934 +0x45c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:94
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func4()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:309 +0x4a
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:308 +0x12d4

goroutine 662 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func5()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:317 +0x2c
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:316 +0x133f

goroutine 663 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 664 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 665 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 666 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 667 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 668 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 669 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 670 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 671 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 672 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 673 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 674 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 675 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 676 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 677 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 678 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 679 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 680 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 681 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 682 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 683 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 684 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 685 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 686 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 687 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 688 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 689 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 690 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 691 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 1162 [select, 171 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readMessageHeader(0x11339665e2a8, {0x1133963eb028, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:281 +0xa5
google.golang.org/grpc/internal/transport.(*recvBufferReader).ReadMessageHeader(0x11339665e2a8, {0x1133963eb028?, 0x1133943e1a00?, 0x11339665e1c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:250 +0x77
google.golang.org/grpc/internal/transport.(*transportReader).ReadMessageHeader(0x11339665e288, {0x1133963eb028?, 0x1133972be320?, 0x1133980a7b78?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:561 +0x25
google.golang.org/grpc/internal/transport.(*Stream).ReadMessageHeader(0x11339665e1c0, {0x1133963eb028, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:470 +0xa9
google.golang.org/grpc.(*parser).recvMsg(0x1133963eb018, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:786 +0x3b
google.golang.org/grpc.recvAndDecompress(0x1133963eb018, {0x4f09540, 0x11339665e1c0}, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:945 +0x97
google.golang.org/grpc.recv(0x1133980a7d90?, {0x79c3bcdf1000, 0x88ffe40}, {0x4f09540?, 0x11339665e1c0?}, {0x0?, 0x0?}, {0x49b8200, 0x1133972be3c0}, 0x400000, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:1054 +0xab
google.golang.org/grpc.(*serverStream).RecvMsg(0x1133963eb000, {0x49b8200, 0x1133972be3c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1839 +0x199
github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3.(*aggregatedDiscoveryServiceStreamAggregatedResourcesServer).Recv(0x113395331950)
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3/ads_grpc.pb.go:156 +0x46
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).StreamHandler.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/server.go:168 +0x94
created by github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).StreamHandler in goroutine 1161
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/server.go:165 +0xa7

goroutine 695 [select, 20 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd2000, {0x4f78938, 0x113394daeed0}, {0x4f909a0, 0x113397d38540})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x1133977ee420, {0x4f78938, 0x113394daeed0}, {0x4f909a0, 0x1133969cf620}, {{{0x113394dcbd40, 0x1, 0x1}}, 0x113395a29830, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 543
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 696 [select, 20 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd2000, {0x4f78938, 0x113394daef30}, {0x4f909a0, 0x1133977ee540})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x1133977ee480, {0x4f78938, 0x113394daef30}, {0x4f909a0, 0x1133969cf620}, {{{0x113394dcbd40, 0x1, 0x1}}, 0x113395a29830, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 543
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 698 [chan receive, 171 minutes]:
github.com/cilium/cilium/daemon/healthz.registerAgentHealthHTTPService.func1.1()
	/go/src/github.com/cilium/cilium/daemon/healthz/agenthealth.go:102 +0x2c
created by github.com/cilium/cilium/daemon/healthz.registerAgentHealthHTTPService.func1 in goroutine 545
	/go/src/github.com/cilium/cilium/daemon/healthz/agenthealth.go:101 +0x43f

goroutine 699 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 552
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 700 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 553
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 706 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/linux/route/reconciler.desiredRouteRefresher.func1({0x4f78938, 0x113394f1b980}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/route/reconciler/refresher.go:98 +0x5b1
github.com/cilium/hive/job.(*jobOneShot).start(0x113395594ea0, {0x4f78938, 0x113394f1b980}, {0x4f909a0, 0x113396376ea0}, {{{0x113394244580, 0x1, 0x1}}, 0x113394cd49c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 707 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd2240, {0x4f78938, 0x113394d3c030}, {0x4f909a0, 0x11339797aba0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x113395da1680, {0x4f78938, 0x113394d3c030}, {0x4f909a0, 0x113395da1380}, {{{0x113396c378a0, 0x1, 0x1}}, 0x113396c38330, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 708 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd2240, {0x4f78938, 0x113394d3c390}, {0x4f909a0, 0x11339797ad80})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x113395da16e0, {0x4f78938, 0x113394d3c390}, {0x4f909a0, 0x113395da1380}, {{{0x113396c378a0, 0x1, 0x1}}, 0x113396c38330, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 709 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0x113397bfd9a0, {0x4f78938, 0x113394d3c5d0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x332
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0x1133979f9d80, {0x4f78938, 0x113394d3c5d0}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x10b
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x4f78938, 0x113394d3c5d0}, {{{}}, 0x113395b9a4e0, {0x4ffb678, 0x113394354b60}, {0x4f50fe0, 0x113395da18c0}, 0x1133949d9ec0}, 0x113396c559c0)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:126 +0x356
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x4f78938?, 0x113394d3c5d0?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:79 +0x39
github.com/cilium/hive/job.(*jobOneShot).start(0x113395da1920, {0x4f78938, 0x113394d3c5d0}, {0x4f909a0, 0x113395da1860}, {{{0x113396c5fc80, 0x1, 0x1}}, 0x113394be7620, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 711 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 706
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 712 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 709
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 131375 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x79c3bbf2fa00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113394469800?, 0x113396244000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113394469800, {0x113396244000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113394469800, {0x113396244000?, 0x50ce20?, 0x113394469800?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x113394a96b38, {0x113396244000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x1133959d24c0, {0x113396244000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x113398c07980)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113398c07980, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x113397dc4870, {0x4f78938, 0x113394cff4d0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 1297
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 717 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 629
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 718 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133953ed800, {0x4f78970, 0x113397c262d0}, 0x113397c16770)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 629
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 720 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 633
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 721 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133953eda00, {0x4f78970, 0x113397c263c0}, 0x113397c169a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 633
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 724 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 641
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 725 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133953edc00, {0x4f78970, 0x113397c26550}, 0x113397c16d90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 641
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 126218 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0x113397e8e1c8, 0x7)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113397a418c0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x113397e8e1b0, {0x113396b85e18, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x113396b45cc8?}, {0x113396b85e18?, 0x113396b45cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x113397e8e180}, {0x113396b85e18, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x113395789200, {0x113398925000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113398d6b310, 0x0, {0x4f57f10, 0x113395c6b4c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x1133948665c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113398d6b360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 613
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 727 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 645
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 728 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133953edd00, {0x4f78970, 0x113397c26640}, 0x113397c16fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 645
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 729 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 652
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 730 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133976bc300, {0x4f78970, 0x113397c26690}, 0x113397c17030)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 652
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 731 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 613
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 732 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133953ed000, {0x4f78970, 0x113397c266e0}, 0x113397c170a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 613
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 733 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 637
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 734 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x1133953edb00, {0x4f78970, 0x113397c26730}, 0x113397c17420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 637
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 736 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 702 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 556
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 1158 [select, 52 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x113395980680, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:420 +0x10a
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x113396d59180)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:595 +0x78
google.golang.org/grpc/internal/transport.NewServerTransport.func3()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:350 +0xdc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1157
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:348 +0x18e7

goroutine 129623 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x113397e8e600, 0x113396d6ac80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x113397e8e600, 0xfcedd7?, 0x113397b46190?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 645
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 129613 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x113397e8e648, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x1133978a2700?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x113397e8e630, {0x113396d92001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x7c?}, {0x113396d92001?, 0x425234?, 0x1133970c3c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x113398acda40)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x113398acda40)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x113398acda40, {0x418d900, 0x113399135800})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x11339545fe30, {0x113397e22000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113397b4a870, 0x0, {0x4f57f10, 0x113395060580})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113394bc1e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113397b4a8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 645
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 1271 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x113398068320)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1183
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 128871 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983af3c8, 0x4)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x11339893d640?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983af3b0, {0x113396e6d201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x7b?}, {0x113396e6d201?, 0x425234?, 0x113397c9bc98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x113397c2c000)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x113397c2c000)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x113397c2c000, {0x418d900, 0x113394d19ad0})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x113399a589f0, {0x113398a8ac00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113397a73ea0, 0x0, {0x4f57f10, 0x113397cf7540})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113394190780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113397b46190)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 494
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 132060 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983aef00, 0x113397347180, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983aef00, 0xfcedd7?, 0x11339696dea0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 267
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 128167 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983aedc8, 0x5)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x1133963049a0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983aedb0, {0x113394c39b38, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x113397660cc8?}, {0x113394c39b38?, 0x113397660cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x1133983aed80}, {0x113394c39b38, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x1133957c35c0, {0x113398a8a000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x1133979615e0, 0x0, {0x4f57f10, 0x1133971053c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113394b65220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113397961630)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 629
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 129433 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983af9c8, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x1133950e1c00?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983af9b0, {0x11339583a340, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x113396913cc8?}, {0x11339583a340?, 0x113396913cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x1133983af980}, {0x11339583a340, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x1133955b9b60, {0x113398a8b800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113397db0a50, 0x0, {0x4f57f10, 0x113394f07b80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113394ae6280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113397db0aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 399
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 131437 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0x1133983ae948, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983ae930, {0x113396b84308, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0x113396b84308?, 0x1133965c2cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x1133983ae900}, {0x113396b84308, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x113395888df8, {0x113398924400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x1133985e4e60, 0x0, {0x4f57f10, 0x113394efad80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x1133946593c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x1133985e4eb0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 355
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 1152 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x113396aa5860})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113396d54000)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 946
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1289 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bcddaa00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397d52180?, 0x113398ea9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113397d52180, {0x113398ea9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113397d52180, {0x113398ea9000?, 0x50ce20?, 0x113397d52180?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x113397f82140, {0x113398ea9000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x113395002080, {0x113398ea9000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x11339797b080)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x11339797b080, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x113396660e10, {0x4f78938, 0x113394d67da0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 539
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 131887 [select]:
net/http.(*persistConn).writeLoop(0x1133964fca00)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 131885
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 117086 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bcdd4c00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397107900?, 0x113395efa000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113397107900, {0x113395efa000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113397107900, {0x113395efa000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133946305a0, {0x113395efa000?, 0x113394cff1a0?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x113398acd040, {0x113395efa000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x113397a825a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113397a825a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x113398acd040)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 117085
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 130124 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x113397e8e780, 0x113394c6f040, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x113397e8e780, 0x1133951bbd20?, 0x1133951bbd50?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 652
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 102967 [select]:
net/http.(*persistConn).writeLoop(0x113396d22dc0)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 102965
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 126051 [select, 8 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133997d6900, 0x11339442a500, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133997d6900, 0xfcedd7?, 0x1133979b4fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 356
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 946 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x1133966cf8c0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 533
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 945 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:363 +0x165
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:90
github.com/cilium/cilium/pkg/health.(*CiliumHealth).runServer(0x1133957753c0, 0x74532f736e6f6974?)
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:136 +0x3bd
created by github.com/cilium/cilium/pkg/health.(*ciliumHealthManager).launchCiliumNodeHealth in goroutine 533
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:77 +0x5c5

goroutine 927 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 546
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 934 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x1133969fd760)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 322
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 128869 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983af0c8, 0x4)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x11339893c200?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983af0b0, {0x11339676d801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x77?}, {0x11339676d801?, 0x425234?, 0x113397857c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x1133964fd180)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x1133964fd180)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x1133964fd180, {0x418d900, 0x113394d19b78})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x113394b27e90, {0x113398a8a800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x1133981cbae0, 0x0, {0x4f57f10, 0x113397cf7d80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113396255ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x1133981cbb30)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 313
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 926 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x113395cabce0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 546
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 893 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 128868 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983af080, 0x1133964fcdc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983af080, 0x1133959d11e0?, 0x1133959d11f0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 313
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 940 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x113396275380, {0x4f78938, 0x113394cef950}, {0x4f909a0, 0x113394f264e0}, {{{0x1133950af940, 0x1, 0x1}}, 0x113394fc3090, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 551
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 942 [select, 10 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).enableWithConfig.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:347 +0x931
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 428
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 129432 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983af980, 0x1133972ada40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983af980, 0xfcedd7?, 0x113398880e10?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 399
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 125005 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x113397e8f548, 0x9)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113395d00a00?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x113397e8f530, {0x113396784328, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x113397603cc8?}, {0x113396784328?, 0x113397603cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x113397e8f500}, {0x113396784328, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x1133957c2ac8, {0x1133983c5c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x1133979a0050, 0x0, {0x4f57f10, 0x1133982e8480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x1133946caa60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x1133979a00a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 353
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 130210 [select, 2 minutes]:
reflect.rselect({0x113398ac6540, 0x6, 0x4a19d2?})
	/usr/local/go/src/runtime/select.go:616 +0x3cd
reflect.Select({0x113397224dc0?, 0x6, 0x11339524dfb8?})
	/usr/local/go/src/reflect/value.go:3018 +0x5a7
github.com/cilium/cilium/pkg/common.MergeChannels[...].func1()
	/go/src/github.com/cilium/cilium/pkg/common/utils.go:89 +0x65
created by github.com/cilium/cilium/pkg/common.MergeChannels[...] in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/common/utils.go:87 +0x19f

goroutine 127160 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x113397e8e348, 0x6)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x113395ea3d80?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x113397e8e330, {0x113395bbaf78, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x113397218cc8?}, {0x113395bbaf78?, 0x113397218cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x113397e8e300}, {0x113395bbaf78, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x1133948cb380, {0x113397e22400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x11339782c780, 0x0, {0x4f57f10, 0x1133949ff440})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113396254dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x11339782c7d0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 633
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 1302 [IO wait, 38 minutes]:
internal/poll.runtime_pollWait(0x79c3bd168400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397d52f80?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113397d52f80)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113397d52f80)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x11339524cdf8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x113394caf140)
	/usr/local/go/src/net/unixsock.go:267 +0x30
net/http.(*Server).Serve(0x11339787a300, {0x4f66810, 0x113394caf140})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x4f66810?, 0x113394caf140?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:365 +0x72
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1293
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:363 +0x485

goroutine 1301 [select]:
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:338 +0x95
created by github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices in goroutine 1293
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:334 +0x11c

goroutine 1300 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:467 +0xc5
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1293
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:460 +0x4f

goroutine 132061 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x1133983aef48, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x4248d7?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x1133983aef30, {0x1133959f1730, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0x1133959f1730?, 0x113395897cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x79c3bce2e3e0, 0x1133983aef00}, {0x1133959f1730, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x1133957a3800, {0x113397e23000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x113398c122d0, 0x0, {0x4f57f10, 0x113397a4b600})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x113394190820)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x113398c12320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 267
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 1297 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x79c3bcdda600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397d52c80?, 0x900000036?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x113397d52c80)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x113397d52c80)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x113395003840)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x113395003840)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
net/http.(*Server).Serve(0x113395e46700, {0x4f690b0, 0x113395003840})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
net/http.(*Server).ListenAndServe(0x113395e46700)
	/usr/local/go/src/net/http/server.go:3360 +0x72
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x25
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1292
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x51

goroutine 1293 [sync.WaitGroup.Wait, 171 minutes]:
sync.runtime_SemacquireWaitGroup(0x113394ca6010?, 0xa0?)
	/usr/local/go/src/runtime/sema.go:114 +0x2e
sync.(*WaitGroup).Wait(0x113395a697d0)
	/usr/local/go/src/sync/waitgroup.go:206 +0x85
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x113395a69690)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:318 +0x95
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x113395a69688)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:361 +0x12c
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:380 +0x25
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1291
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:379 +0xd4

goroutine 1292 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x1133958ee120)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xce
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:375 +0x27
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1291
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:374 +0x78

goroutine 1291 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x113395a69688)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:385 +0xe9
github.com/cilium/cilium/pkg/health.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:103 +0x65
created by github.com/cilium/cilium/pkg/health.(*CiliumHealth).runServer in goroutine 945
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:101 +0x19b

goroutine 1288 [select, 171 minutes]:
net/http.(*persistConn).writeLoop(0x113397279180)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 1286
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 1287 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x79c3bcdd5a00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x1133990edc00?, 0x1133988a8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x1133990edc00, {0x1133988a8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x1133990edc00, {0x1133988a8000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x113397f82138, {0x1133988a8000?, 0x113394f91590?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x113397279180, {0x1133988a8000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x11339797b020)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x11339797b020, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x113397279180)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 1286
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 131886 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bbf2f800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397872400?, 0x1133969f7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113397872400, {0x1133969f7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113397872400, {0x1133969f7000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x113399a11c50, {0x1133969f7000?, 0x1133949db260?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x1133964fca00, {0x1133969f7000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x113396a1a480)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113396a1a480, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x1133964fca00)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 131885
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 129507 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983afc80, 0x113398acc140, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983afc80, 0x113394d9cd50?, 0x11339782f810?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 641
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 117088 [IO wait]:
internal/poll.runtime_pollWait(0x79c3bcdda800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397107b80?, 0x113397e68000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113397107b80, {0x113397e68000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113397107b80, {0x113397e68000?, 0x50ce20?, 0x113397107b80?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133946305a8, {0x113397e68000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x113395932840, {0x113397e68000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x1133970546c0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x1133970546c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x113397d347e0, {0x4f78938, 0x113394d67da0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 539
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 129614 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133997d6d80, 0x113397be2780, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133997d6d80, 0xfcedd7?, 0x1133981cbb30?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 434
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 131436 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x1133983ae900, 0x113397b9ac80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x1133983ae900, 0xfcedd7?, 0x113398a694a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 355
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 130385 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x79c3bbf2fc00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x113397d52880?, 0x113396a66000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x113397d52880, {0x113396a66000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x113397d52880, {0x113396a66000?, 0x50ce20?, 0x113397d52880?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x1133963e5458, {0x113396a66000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x1133953efc00, {0x113396a66000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x113398c57680)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x113398c57680, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x113396672240, {0x4f78938, 0x113394cff4d0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 1297
	/usr/local/go/src/net/http/server.go:3464 +0x485
