# Cilium debug information

#### Cilium memory map


```
00400000-03adb000 r-xp 00000000 00:34 511161                             /usr/bin/cilium-agent
03adb000-08271000 r--p 036db000 00:34 511161                             /usr/bin/cilium-agent
08271000-08397000 rw-p 07e71000 00:34 511161                             /usr/bin/cilium-agent
08397000-0a92f000 rw-p 00000000 00:00 0 
113390000000-113393c00000 ---p 00000000 00:00 0                          [anon: Go: heap reservation]
113393c00000-11339a000000 rw-p 00000000 00:00 0                          [anon: Go: heap]
11339a000000-11339c000000 ---p 00000000 00:00 0                          [anon: Go: heap reservation]
79c3bbf13000-79c3bbf53000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bbf57000-79c3bbf67000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c3bc629000-79c3bc63b000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bc63b000-79c3bc63c000 rw-s 00000000 00:11 1099                       anon_inode:bpf-map
79c3bc63c000-79c3bc67c000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bc67c000-79c3bc6bd000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
79c3bc6bd000-79c3bc6fe000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
79c3bcd1b000-79c3bcd9b000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bcda4000-79c3bcdb4000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c3bcdb4000-79c3bcdbc000 rw-p 00000000 00:00 0                          [anon: Go: GC span queue]
79c3bcdbc000-79c3bcdbe000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
79c3bcdbe000-79c3bcdc0000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
79c3bcdc0000-79c3bce40000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bce40000-79c3bce60000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c3bce60000-79c3bcee0000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bcee0000-79c3bcf00000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c3bcf00000-79c3bcfc0000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bcfc0000-79c3bcfd0000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c3bcfd0000-79c3bd110000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bd110000-79c3bd120000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c3bd120000-79c3bd1a0000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c3bd1a0000-79c3bd300000 rw-p 00000000 00:00 0                          [anon: Go: profiler hash buckets]
79c3bd300000-79c3bd400000 rw-p 00000000 00:00 0                          [anon: Go: page alloc index]
79c3bd400000-79c3bf400000 rw-p 00000000 00:00 0                          [anon: Go: heap index]
79c3bf400000-79c3d1667000 ---p 00000000 00:00 0                          [anon: Go: scavenge index]
79c3d1667000-79c3d1668000 rw-p 00000000 00:00 0                          [anon: Go: scavenge index]
79c3d1668000-79c3df400000 ---p 00000000 00:00 0                          [anon: Go: scavenge index]
79c3df400000-79c3f1667000 ---p 00000000 00:00 0                          [anon: Go: page summary]
79c3f1667000-79c3f1668000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
79c3f1668000-79c40184c000 ---p 00000000 00:00 0                          [anon: Go: page summary]
79c40184c000-79c40184d000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
79c40184d000-79c403889000 ---p 00000000 00:00 0                          [anon: Go: page summary]
79c403889000-79c40388a000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
79c40388a000-79c403c00000 ---p 00000000 00:00 0                          [anon: Go: page summary]
79c403c00000-79c403c01000 rw-p 00000000 00:00 0                          [anon: Go: getrandom states]
79c403c05000-79c403c6d000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c403c6d000-79c403c7d000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
79c403c7d000-79c403c8d000 rw-p 00000000 00:00 0                          [anon: Go: allspans array]
79c403c8d000-79c403c9f000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c403c9f000-79c403d30000 ---p 00000000 00:00 0                          [anon: Go: page summary]
79c403d30000-79c403d31000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
79c403d31000-79c403d9f000 ---p 00000000 00:00 0                          [anon: Go: page summary]
79c403d9f000-79c403dbf000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
79c403dbf000-79c403dff000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
79c403dff000-79c403e03000 r--p 00000000 00:00 0                          [vvar]
79c403e03000-79c403e05000 r--p 00000000 00:00 0                          [vvar_vclock]
79c403e05000-79c403e07000 r-xp 00000000 00:00 0                          [vdso]
7ffe8186b000-7ffe8188c000 rw-p 00000000 00:00 0                          [stack]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### Cilium version

```
1.20.2 e0dc92bd 2026-09-15T15:51:54Z go version go1.26.8 linux/amd64
```


#### Cilium environment keys

```
enable-datapath-plugins:false
enable-icmp-rules:true
custom-cni-conf:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
proxy-connect-timeout:2
only-masquerade-default-pool:false
exclude-node-label-patterns:
enable-gops:true
enable-health-check-nodeport:true
bpf-lb-rss-ipv4-src-cidr:
proxy-max-connection-duration-seconds:0
enable-standalone-dns-proxy:false
tofqdns-idle-connection-grace-period:0s
status-collector-warning-threshold:15s
enable-pmtu-discovery:false
underlay-protocol:auto
proxy-prometheus-port:0
clustermesh-sync-timeout:1m0s
debug-verbose:
remove-cilium-node-taints:true
bpf-lb-source-range-map-max:0
ipam-cilium-node-update-rate:15s
enable-extended-ip-protocols:false
bpf-lb-map-max:65536
enable-health-checking:true
bpf-lb-sock:false
enable-endpoint-routes:false
kvstore-opt:
egress-gateway-policy-map-max:16384
cluster-health-port:4240
bpf-ct-timeout-service-any:1m0s
proxy-use-original-source-address:true
enable-dynamic-config:true
hubble-export-file-compress:false
proxy-gid:1337
pprof:false
bpf-ct-timeout-service-tcp:2h13m20s
l2-announcements-renew-deadline:5s
hubble-monitor-events:
identity-heartbeat-timeout:30m0s
envoy-keep-cap-netbindservice:false
bgp-router-id-allocation-mode:default
config-dir:/tmp/cilium/config-map
hubble-drop-events:false
enable-ipv4-fragment-tracking:true
lb-retry-backoff-min:1s
enable-ipv4:true
controller-group-metrics:
ip-tracing-option-type:0
tofqdns-max-deferred-connection-deletes:10000
enable-non-default-deny-policies:true
bpf-lb-dsr-dispatch:opt
enable-ipip-termination:false
hubble-export-aggregation-interval:0s
max-controller-interval:0
enable-hubble-open-metrics:false
enable-k8s:true
allow-icmp-frag-needed:true
eni-subnet-tags:
default-lb-service-ipam:lbipam
labels:
k8s-client-burst:20
mesh-auth-mutual-connect-timeout:5s
enable-xdp-prefilter:false
routing-mode:tunnel
debug:false
hubble-network-policy-correlation-enabled:true
multicast-enabled:false
iptables-lock-timeout:5s
enable-ipsec:false
restored-proxy-ports-age-limit:15
ipv6-node:auto
enable-host-legacy-routing:false
dnsproxy-lock-timeout:500ms
local-router-ipv4:
lb-reflector-wait-time:500ms
cni-external-routing:false
enable-dynamic-lifecycle-manager:false
k8s-service-proxy-name:
envoy-log:
hubble-redact-http-urlquery:false
node-port-acceleration:disabled
hubble-prefer-ipv6:false
crd-wait-timeout:5m0s
connectivity-probe-frequency-ratio:0.5
enable-l2-neigh-discovery:false
status-collector-failure-threshold:1m0s
bpf-policy-stats-map-max:65536
bpf-lb-algorithm:random
envoy-config-retry-interval:15s
enable-bpf-tproxy:false
vtep-cidr:
egress-gateway-reconciliation-trigger-interval:1s
ipv4-service-loopback-address:169.254.42.1
envoy-config-timeout:2m0s
dnsproxy-enable-transparent-mode:true
encrypt-node:false
api-rate-limit:
enable-health-check-loadbalancer-ip:false
local-router-ipv6:
conntrack-gc-interval:0s
lb-sock-terminate-all-protos:false
annotate-k8s-node:false
enable-ipv6:false
mesh-auth-signal-backoff-duration:1s
policy-trigger-interval:1s
ipv4-node:auto
enable-k8s-api-discovery:false
boot-id-file:/proc/sys/kernel/random/boot_id
nat-map-stats-interval:30s
enable-cilium-clusterwide-network-policy:true
policy-secrets-namespace:cilium-secrets
policy-cidr-match-mode:
packetization-layer-pmtud-mode:blackhole
bpf-ct-timeout-regular-tcp:2h13m20s
enable-local-node-route:true
enable-ipv4-masquerade:true
bpf-lb-maglev-map-max:0
proxy-portrange-max:20000
http-request-timeout:3600
hubble-redact-http-userinfo:true
hubble-metrics-server-tls-cert-file:
proxy-xff-num-trusted-hops-ingress:0
k8s-require-ipv6-pod-cidr:false
bpf-lb-enable-wildcard-entries:true
enable-encryption-strict-mode-ingress:false
allow-unsafe-policy-skb-usage:false
hubble-metrics-server-tls-client-ca-files:
ipam-default-ip-pool:default
set-cilium-node-taints:true
force-device-detection:false
cni-log-file:/var/run/cilium/cilium-cni.log
standalone-dns-proxy-server-port:10095
endpoint-policy-update-timeout:10s
hubble-redact-http-headers-deny:
monitor-aggregation:medium
lb-state-file-interval:1s
identity-allocation-sync-interval:5m0s
disable-external-ip-mitigation:false
enable-gateway-api:false
bpf-lb-acceleration:disabled
prepend-iptables-chains:true
exclude-local-address:
node-labels:
trace-payloadlen:128
dynamic-lifecycle-config:[]
static-cnp-path:
ipam-max-allocate:0
endpoint-queue-size:25
pprof-block-profile-rate:0
envoy-access-log-buffer-size:4096
bpf-ct-timeout-regular-tcp-syn:1m0s
mesh-auth-gc-interval:5m0s
bpf-distributed-lru:false
status-collector-interval:5s
enable-envoy-config:false
identity-max-jitter:30s
read-cni-conf:
disable-endpoint-crd:false
dns-max-ips-per-restored-rule:1000
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-events-policy-verdict-enabled:true
enable-auto-protect-node-port-range:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
vtep-sync-interval:1m0s
eni-security-groups:
endpoint-gc-interval:5m0s
bpf-lb-service-map-max:0
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-cilium-health-api-server-access:
hubble-export-fieldaggregate:
bpf-lb-maglev-table-size:16381
prometheus-serve-addr:
log-system-load:false
bpf-root:/sys/fs/bpf
config:
hubble-skip-unknown-cgroup-ids:true
lrp-address-matcher-cidrs:
hubble-export-allowlist:
enable-bgp-control-plane-status-report:true
mesh-auth-queue-size:1024
node-port-range:
enable-bgp-legacy-origin-attribute:false
hubble-redact-http-headers-allow:
hubble-redact-enabled:false
alibabacloud-vswitches:
operator-prometheus-serve-addr::9963
iptables-random-fully:false
enable-wireguard:false
agent-liveness-update-interval:1s
bpf-events-trace-enabled:true
eni-subnet-ids:
k8s-client-connection-timeout:30s
policy-audit-mode:false
enable-no-service-endpoints-routable:true
enable-vtep:false
identity-gc-interval:15m0s
enable-sctp:false
ipv6-service-range:auto
hubble-disable-tls:false
alibabacloud-security-groups:
hive-start-timeout:5m0s
ipam-pre-allocate:0
install-uplink-routes-for-delegated-ipam:false
unmanaged-pod-watcher-interval:15s
restore:true
state-dir:/var/run/cilium
identity-change-grace-period:5s
gops-port:9890
hubble-socket-path:/var/run/cilium/hubble.sock
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-listen-address::4244
eni-security-group-tags:
identity-restore-grace-period:30s
bpf-map-event-buffers:
hubble-dynamic-metrics-config-path:
bpf-sock-rev-map-max:0
allow-localhost:auto
vlan-bpf-bypass:
tunnel-source-port-range:0-0
label-prefix-file:
lb-init-wait-timeout:1m0s
hubble-export-denylist:
enable-local-redirect-policy:false
egress-masquerade-interfaces:
conntrack-gc-max-interval:0s
metrics-sampling-interval:5m
hubble-export-file-path:
enable-k8s-networkpolicy:true
eni-exclude-interface-tags:
enable-mke:false
node-port-bind-protection:true
clustermesh-config:/var/lib/cilium/clustermesh/
tofqdns-proxy-response-max-delay:100ms
enable-bandwidth-manager:false
hubble-export-file-max-size-mb:10
encryption-strict-egress-allow-remote-node-identities:false
proxy-admin-port:0
proxy-max-requests-per-connection:0
bpf-filter-priority:1
dnsproxy-concurrency-processing-grace-period:0s
enable-metrics:true
ipam-static-ip-tags:
eni-disable-prefix-delegation:false
bpf-ct-global-any-max:262144
direct-routing-device:
enable-node-selector-labels:false
enable-ip-masq-agent:false
envoy-base-id:0
hubble-flowlogs-config-path:
mesh-auth-rotated-identities-queue-size:1024
enable-k8s-host-firewall-bypass:true
mtu:0
enable-tracing:false
cluster-name:default
install-iptables-rules:true
envoy-default-log-level:
disable-iptables-feeder-rules:
enable-ipv6-masquerade:true
ipam:kubernetes
kvstore-lease-ttl:15m0s
l2-pod-announcements-interface-pattern:
enable-cilium-api-server-access:
vtep-endpoint:
nodes-gc-interval:5m0s
enable-lb-ipam:true
tunnel-port:0
mesh-auth-spiffe-trust-domain:spiffe.cilium
datapath-mode:veth
external-envoy-proxy:true
datapath-plugins-state-dir:/var/run/cilium/plugins
enable-source-ip-verification:true
enable-ciliumnode-crd:true
mesh-auth-enabled:false
k8s-api-server-urls:
hive-log-threshold:100ms
allocator-list-timeout:3m0s
dnsproxy-socket-linger-timeout:10
config-sources:[{"kind":"config-map","namespace":"kube-system","name":"cilium-config"}]
envoy-policy-restore-timeout:3m0s
k8s-sync-timeout:3m0s
bpf-lb-mode:snat
mesh-auth-mutual-listener-port:0
bpf-map-dynamic-size-ratio:0.0025
enable-node-ipam:false
bpf-lb-service-backend-map-max:0
lb-retry-backoff-max:1m0s
derive-masq-ip-addr-from-device:
http-idle-timeout:0
shell-sock-path:/var/run/cilium/shell.sock
lib-dir:/var/lib/cilium
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
ipv6-cluster-alloc-cidr:f00d::/64
agent-labels:
proxy-cluster-max-pending-requests:1024
tofqdns-enable-dns-compression:true
enable-bpf-clock-probe:false
hubble-drop-events-interval:2m0s
alibabacloud-security-group-tags:
bpf-ct-global-tcp-max:524288
cilium-endpoint-gc-interval:5m0s
enable-dynamic-source-lookup-nodeport:false
cni-exclusive:false
eni-use-primary-address:false
enable-cilium-network-policy:true
tofqdns-endpoint-max-ip-per-hostname:1000
wireguard-track-all-ips-fallback:false
auto-create-cilium-node-resource:true
tofqdns-pre-cache:
ipv6-service-loopback-address:fe80::1
enable-active-connection-tracking:false
container-ip-local-reserved-ports:auto
ingress-secrets-namespace:
tofqdns-min-ttl:0
cluster-id:0
bpf-nat-global-max:524288
synchronize-k8s-nodes:true
hubble-drop-events-reasons:
envoy-http-upstream-linger-timeout:-1
hubble-drop-events-extended:false
nat-map-stats-entries:32
enable-monitor:true
keep-config:false
l2-announcements-retry-period:2s
bpf-lb-rev-nat-map-max:0
vtep-mac:
enable-stale-cilium-endpoint-cleanup:true
eni-first-interface-index:0
l2-announcements-lease-duration:15s
enable-ipv6-big-tcp:false
log-opt:
enable-ipsec-xfrm-state-caching:true
bpf-node-map-max:16384
max-internal-timer-delay:0s
alibabacloud-vswitch-tags:
cni-chaining-mode:none
hubble-export-file-max-backups:5
proxy-cluster-max-connections:1024
enable-bpf-masquerade:false
k8s-heartbeat-timeout:30s
enable-l2-announcements:false
k8s-require-ipv4-pod-cidr:false
proxy-max-concurrent-retries:128
enable-cilium-endpoint-slice:false
bpf-lb-nat46x64:false
dnsproxy-lock-count:131
local-max-addr-scope:254
bpf-ct-timeout-regular-tcp-fin:10s
http-stream-idle-timeout:300
policy-accounting:true
monitor-aggregation-interval:5s
enable-ingress-controller:false
bpf-policy-map-full-reconciliation-interval:15m0s
log-driver:
kube-proxy-replacement:true
monitor-queue-size:0
enable-identity-mark:true
azure-interface-name:
srv6-encap-mode:reduced
ipv4-service-range:auto
enable-policy:default
hubble-event-buffer-capacity:4095
route-metric:0
bpf-conntrack-accounting:false
tofqdns-dns-reject-response-code:refused
enable-well-known-identities:false
hubble-metrics-server:
ipv4-pod-subnets:
bpf-lb-sock-hostns-only:true
wireguard-persistent-keepalive:0s
ipsec-key-file:
bpf-lb-external-clusterip:false
enable-srv6:false
proxy-initial-fetch-timeout:30
bpf-auth-map-max:524288
enable-ztunnel:false
envoy-xds-mode:ads
endpoint-regen-interval:2m0s
ignore-flags-drift-checker:
identity-allocation-mode:crd
health-check-icmp-failure-threshold:3
enable-service-topology:false
enable-endpoint-health-checking:true
bpf-fragments-map-max:8192
clustermesh-enable-mcs-api:false
bpf-lb-mode-annotation:false
clustermesh-enable-endpoint-sync:false
identity-allocation-timeout:2m0s
bypass-ip-availability-upon-restore:false
enable-xt-socket-fallback:true
bpf-lb-sock-terminate-pod-connections:true
ipv6-range:auto
ipam-multi-pool-pre-allocation:
vtep-mask:
enable-bbr-hostns-only:false
encryption-strict-egress-cidr:
enable-l7-proxy:true
metrics:
preallocate-bpf-maps:false
monitor-aggregation-flags:all
k8s-kubeconfig-path:
bpf-lb-affinity-map-max:0
status-collector-probe-check-timeout:5m0s
pprof-port:6060
enable-ipsec-key-watcher:true
hubble-metrics-server-tls-key-file:
ipv4-native-routing-cidr:
bpf-lb-ipip-sock-mark:false
k8s-client-qps:10
tofqdns-proxy-port:0
enable-l2-pod-announcements:false
policy-deny-response:none
bpf-lb-algorithm-annotation:false
socket-path:/var/run/cilium/cilium.sock
prefer-ipv6:false
bpf-events-drop-enabled:true
bpf-neigh-global-max:524288
mesh-auth-spire-admin-socket:
pprof-address:localhost
enable-nat46x64-gateway:false
auto-direct-node-routes:false
bpf-events-default-burst-limit:0
hubble-lost-event-send-interval:1s
gateway-api-secrets-namespace:
bpf-lb-source-range-all-types:false
procfs:/host/proc
k8s-namespace:kube-system
certificates-directory:/var/run/cilium/certs
fqdn-regex-compile-lru-size:1024
agent-health-port:9879
proxy-portrange-min:10000
lb-state-file:
bpf-policy-map-pressure-metrics-threshold:0.1
kvstore-max-consecutive-quorum-errors:2
cgroup-root:/run/cilium/cgroupv2
enable-endpoint-lockdown-on-policy-overflow:false
endpoint-bpf-prog-watchdog-interval:30s
direct-routing-skip-unreachable:false
pprof-mutex-profile-fraction:0
subnet-topology:
hubble-metrics:
bpf-lb-rss-ipv6-src-cidr:
disable-envoy-version-check:false
dns-policy-unload-on-shutdown:false
enable-bgp-control-plane:false
proxy-idle-timeout-seconds:60
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
dnsproxy-concurrency-limit:0
devices:
policy-secrets-only-from-secrets-namespace:true
http-retry-timeout:0
fib-table-id-annotation:false
enable-ipv6-fragment-tracking:true
agent-health-require-k8s-connectivity:true
enable-policy-secrets-sync:true
clustermesh-service-v2:prefer-legacy
policy-queue-size:100
ztunnel-endpoint-event-channel-buffer-size:1
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-metrics-server-enable-tls:false
ipv6-native-routing-cidr:
enable-tcx:true
version:false
config-sources-overrides:{"allowConfigKeys":[],"denyConfigKeys":[]}
trace-sock:true
envoy-node-locality-enabled:false
bgp-router-id-allocation-ip-pool:
http-normalize-path:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-drift-checker:true
enable-egress-gateway:false
enable-hubble:true
enable-remote-node-masquerade:false
envoy-secrets-namespace:
use-cilium-internal-ip-for-ipsec:false
enable-bbr:false
tunnel-protocol:vxlan
ipam-min-allocate:0
tofqdns-preallocate-identities:true
clustermesh-default-global-namespace:true
fixed-identity-mapping:
proxy-cluster-max-requests:1024
hubble-drop-events-rate-limit:1
trace-payloadlen-overlay:192
lb-pressure-metrics-interval:5m0s
ipsec-key-rotation-duration:5m0s
cmdref:
kvstore:
ipv6-pod-subnets:
envoy-access-log-enabled:true
enable-host-firewall:false
enable-ipv4-big-tcp:false
k8s-client-connection-keep-alive:30s
nodeport-addresses:
operator-api-serve-addr:127.0.0.1:9234
ipv4-range:auto
enable-route-mtu-for-cni-chaining:false
policy-default-local-cluster:true
cni-chaining-target:
hive-stop-timeout:1m0s
http-retry-count:3
bpf-ct-timeout-regular-any:1m0s
ipv6-mcast-device:
enable-masquerade-to-route-source:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
mke-cgroup-mount:
service-no-backend-response:reject
enable-k8s-cluster-network-policy:false
proxy-max-active-downstream-connections:50000
enable-unreachable-routes:false
install-no-conntrack-iptables-rules:false
clustermesh-cache-ttl:0s
use-full-tls-context:false
proxy-xff-num-trusted-hops-egress:0
eni-delete-on-termination:true
bpf-events-default-rate-limit:0
http-max-grpc-timeout:0
status-collector-stackdump-path:/run/cilium/state/agent.stack.gz
max-connected-clusters:255
enable-ipv6-ndp:false
kube-proxy-replacement-healthz-bind-address:
bpf-policy-map-max:16384
identity-management-mode:agent
set-cilium-is-up-condition:true
clustermesh-mcs-api-install-crds:true
hubble-event-queue-size:0
enable-encryption-strict-mode-egress:false
hubble-export-fieldmask:
```


#### Policy get

```
:
 []
Revision: 1

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=3) {
  (string) (len=12) "10.244.1.173": (string) (len=6) "router",
  (string) (len=12) "10.244.1.197": (string) (len=6) "health",
  (string) (len=12) "10.244.1.214": (string) (len=36) "kube-system/coredns-559f6c778d-khtkb"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=23) "default:192.168.178.114": (string) (len=7) "node-ip"
}

```


#### Cilium encryption



#### Kernel version

```
7.0.0
```


#### Cilium status

```
KVStore:                Disabled   
Kubernetes:             Ok         1.37 (v1.37.1) [linux/amd64]
Kubernetes APIs:        ["cilium/v2::CiliumCIDRGroup", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "core/v1::Pods", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [ens18     192.168.178.114 fda7:7b49:a70a:0:be24:11ff:fede:cb0c 2a02:8071:5301:a0a0:be24:11ff:fede:cb0c fe80::be24:11ff:fede:cb0c (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.20.2 (v1.20.2-e0dc92bd)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 3/254 allocated from 10.244.1.0/24, 
Allocated addresses:
  10.244.1.173 (router)
  10.244.1.197 (health)
  10.244.1.214 (kube-system/coredns-559f6c778d-khtkb)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            TCX
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      18/18 healthy
  Name                                                  Last success   Last error   Count   Message
  cilium-health-ep                                      7s ago         never        0       no error   
  ct-map-pressure                                       8s ago         never        0       no error   
  endpoint-1644-regeneration-recovery                   never          never        0       no error   
  endpoint-3284-regeneration-recovery                   never          never        0       no error   
  endpoint-4046-regeneration-recovery                   never          never        0       no error   
  endpoint-gc                                           1m8s ago       never        0       no error   
  endpoint-periodic-regeneration                        53s ago        never        0       no error   
  ipcache-inject-labels                                 8s ago         never        0       no error   
  k8s-heartbeat                                         8s ago         never        0       no error   
  resolve-identity-1644                                 1m7s ago       never        0       no error   
  resolve-identity-3284                                 1m8s ago       never        0       no error   
  resolve-identity-4046                                 1m5s ago       never        0       no error   
  resolve-labels-kube-system/coredns-559f6c778d-khtkb   2h51m5s ago    never        0       no error   
  sync-policymap-1644                                   6m1s ago       never        0       no error   
  sync-policymap-3284                                   6m0s ago       never        0       no error   
  sync-policymap-4046                                   6m0s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (4046)                     4s ago         never        0       no error   
  write-cni-file                                        2h51m8s ago    never        0       no error   
Proxy Status:            OK, ip 10.244.1.173, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 3.25   Metrics: Disabled
KubeProxyReplacement Details:
  Status:               True
  Socket LB:            Enabled
  Socket LB Tracing:    Enabled
  Socket LB Coverage:   Hostns-only
  Devices:              ens18     192.168.178.114 fda7:7b49:a70a:0:be24:11ff:fede:cb0c 2a02:8071:5301:a0a0:be24:11ff:fede:cb0c fe80::be24:11ff:fede:cb0c (Direct Routing)
  Mode:                 SNAT
  Backend Selection:    Random
  Session Affinity:     Enabled
  NAT46/64 Support:     Disabled
  XDP Acceleration:     Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
  Annotations:
  - service.cilium.io/node
  - service.cilium.io/node-selector
  - service.cilium.io/proxy-delegation
  - service.cilium.io/src-ranges-policy
  - service.cilium.io/type
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoints                     65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  Ratelimit metrics             64
  NAT                           131072
  Neighbor table                131072
  Endpoint policy               16384
  Policy stats                  65536
  Session affinity              65536
  Sock reverse NAT              65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                       IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                          
1644       Disabled           Disabled          4          reserved:health                                                                          10.244.1.197   ready   
3284       Disabled           Disabled          1          reserved:host                                                                                           ready   
4046       Disabled           Disabled          41104      gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181                10.244.1.214   ready   
                                                           gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                                 
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=kube-dns                                                                                            
```

#### BPF Policy Get 1644

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    193489   2382      0        0
Allow    Ingress     11         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    -        -         0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0

```


#### BPF CT List 1644

```
Invalid argument: unknown type 1644
```


#### Endpoint Get 1644

```
[
  {
    "id": 1644,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-1644-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a49dcb25-aba6-4cf6-956d-6d9dbcb12173"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1644",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:51:00.119Z",
            "success-count": 35
          },
          "uuid": "316fa995-a332-43e2-a800-a88edf8ccb23"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1644",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.521Z",
            "success-count": 12
          },
          "uuid": "ac9b98ed-da36-4bf3-b3b9-8d1d16029599"
        }
      ],
      "external-identifiers": {},
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:51:14Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.1.197",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "a6:85:ac:c3:e3:75",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "7a:89:7c:13:ab:f7"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1644

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1644

```
Timestamp              Status   State                   Message
2026-10-10T13:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:51:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:49:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:47:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:47:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:47:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:45:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:45:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:45:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:43:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:41:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:41:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:41:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:39:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:39:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:39:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:37:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:37:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:37:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:35:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:35:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:35:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:33:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:33:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:33:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:31:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:31:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:31:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:29:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:29:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:29:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:27:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:27:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:27:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:25:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:25:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:25:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:23:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:21:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:21:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:21:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:19:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:17:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:17:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:17:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:15:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:13:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:13:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:13:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:11:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:11:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:11:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:09:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:09:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:09:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:09:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:09:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:07:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:07:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:07:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:07:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:07:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:05:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:05:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:05:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:05:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:05:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:03:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:03:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:03:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:03:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:03:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:01:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:01:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:01:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:01:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:01:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:59:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:59:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:59:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:59:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:59:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:57:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:57:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:57:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:57:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:57:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:55:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:55:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:55:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:55:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:55:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:53:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:53:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:53:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:53:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:53:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:51:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:49:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:47:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:47:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:47:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:45:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:45:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:45:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:43:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:41:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:41:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:41:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:39:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:39:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:39:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:37:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:37:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:37:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:35:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:35:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:35:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:33:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:33:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:33:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:31:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:31:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:31:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:29:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:29:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:29:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:27:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:27:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:27:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:25:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:25:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:25:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:23:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:21:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:21:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:21:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:19:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:17:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:17:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:17:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:15:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:13:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:13:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:13:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:11:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:11:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:11:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 3284

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        0
Allow    Ingress     11         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -       -         0        0
Allow    Egress      0          ANY          NONE         disabled    -       -         0        0
Allow    Egress      11         ANY          NONE         disabled    -       -         0        0
Allow    Egress      12         ANY          NONE         disabled    -       -         0        0
Allow    Egress      13         ANY          NONE         disabled    -       -         0        0
Allow    Egress      14         ANY          NONE         disabled    -       -         0        0

```


#### BPF CT List 3284

```
Invalid argument: unknown type 3284
```


#### Endpoint Get 3284

```
[
  {
    "id": 3284,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-3284-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "04235e55-f8b3-4b9f-a7c7-277b6bf7c5b9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3284",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:50:59.030Z",
            "success-count": 35
          },
          "uuid": "e7ee0ba5-04ed-404f-8937-ec5119a2eeeb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3284",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:07.095Z",
            "success-count": 12
          },
          "uuid": "a3628388-9b55-4200-bc18-84e34d9dfb9b"
        }
      ],
      "external-identifiers": {},
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host"
        ]
      },
      "labels": {
        "derived": [
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:51:14Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "0e:c2:32:9b:4b:fb",
        "interface-index": 4,
        "interface-name": "cilium_host",
        "mac": "0e:c2:32:9b:4b:fb"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3284

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3284

```
Timestamp              Status   State                   Message
2026-10-10T13:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:51:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:49:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:47:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:47:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:47:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:45:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:45:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:45:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:43:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:41:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:41:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:41:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:39:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:39:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:39:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:37:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:37:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:37:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:35:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:35:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:35:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:33:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:33:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:33:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:31:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:31:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:31:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:29:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:29:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:29:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:27:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:27:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:27:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:25:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:25:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:25:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:23:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:21:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:21:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:21:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:19:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:17:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:17:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:17:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:15:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:13:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:13:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:13:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:11:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:11:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:11:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:09:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:09:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:09:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:09:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:09:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:07:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:07:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:07:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:07:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:07:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:05:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:05:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:05:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:05:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:05:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:03:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:03:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:03:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:03:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:03:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:01:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:01:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:01:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:01:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:01:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:59:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:59:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:59:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:59:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:59:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:57:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:57:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:57:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:57:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:57:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:55:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:55:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:55:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:55:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:55:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:53:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:53:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:53:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:53:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:53:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:51:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:49:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:47:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:47:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:47:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:45:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:45:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:45:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:43:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:41:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:41:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:41:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:39:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:39:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:39:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:37:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:37:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:37:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:35:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:35:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:35:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:33:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:33:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:33:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:31:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:31:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:31:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:29:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:29:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:29:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:27:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:27:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:27:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:25:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:25:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:25:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:23:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:21:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:21:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:21:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:19:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:17:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:17:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:17:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:15:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:13:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:13:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:13:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:11:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:11:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:11:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 4046

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    983540   11256     0        0
Allow    Ingress     11         ANY          NONE         disabled    349      3         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    93246    1030      0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0

```


#### BPF CT List 4046

```
Invalid argument: unknown type 4046
```


#### Endpoint Get 4046

```
[
  {
    "id": 4046,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-4046-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "85d99862-d38e-4394-8ed7-2df602be6911"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4046",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:51:02.531Z",
            "success-count": 35
          },
          "uuid": "75950d8c-35a7-489d-a1b1-ed3b9ddd992b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-559f6c778d-khtkb",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T11:01:02.511Z",
            "success-count": 1
          },
          "uuid": "71c01b33-c8a6-46b5-9d53-a3f57a6fd638"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-4046",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.659Z",
            "success-count": 12
          },
          "uuid": "7b6f92c1-33e1-46dd-bcb9-f347a8ceb018"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (4046)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:52:03.248Z",
            "success-count": 1028
          },
          "uuid": "16f119d3-cbe2-4e12-94c6-a7e54d7c9cc4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "88a7af6568dff9b6ed4da216af48cfe45acbc701b91ebf21a19c7bbf3c84d55f:eth0"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 41104,
        "labels": [
          "gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080",
          "gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=559f6c778d"
        ],
        "realized": {},
        "security-relevant": [
          "gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181",
          "gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:51:14Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "liveness-probe",
          "port": 8080,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        },
        {
          "name": "readiness-probe",
          "port": 8181,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.1.214",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9a:0b:01:4d:9f:5e",
        "interface-index": 9,
        "interface-name": "lxc7ec5ba81bca3",
        "mac": "1a:8f:7a:5b:a5:4a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 41104,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 41104,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4046

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4046

```
Timestamp              Status   State                   Message
2026-10-10T13:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:51:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:49:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:47:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:47:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:47:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:45:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:45:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:45:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:43:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:41:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:41:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:41:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:39:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:39:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:39:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:37:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:37:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:37:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:35:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:35:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:35:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:33:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:33:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:33:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:31:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:31:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:31:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:29:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:29:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:29:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:27:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:27:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:27:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:25:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:25:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:25:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:23:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:21:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:21:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:21:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:19:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:17:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:17:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:17:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:15:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:13:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:13:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:13:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:11:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:11:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:11:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:09:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:09:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:09:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:09:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:09:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:07:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:07:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:07:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:07:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:07:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:05:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:05:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:05:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:05:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:05:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:03:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:03:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:03:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:03:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:03:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:01:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:01:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:01:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:01:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:01:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:59:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:59:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:59:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:59:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:59:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:57:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:57:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:57:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:57:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:57:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:55:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:55:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:55:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:55:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:55:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:53:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:53:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:53:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:53:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:53:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:51:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:49:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:47:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:47:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:47:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:47:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:45:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:45:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:45:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:45:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:43:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:41:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:41:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:41:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:41:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:39:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:39:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:39:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:39:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:37:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:37:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:37:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:37:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:35:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:35:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:35:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:35:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:33:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:33:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:33:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:33:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:31:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:31:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:31:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:31:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:29:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:29:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:29:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:29:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:27:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:27:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:27:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:27:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:25:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:25:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:25:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:25:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:23:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:21:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:21:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:21:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:21:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:19:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:17:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:17:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:17:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:17:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:15:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:13:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:13:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:13:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:13:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:11:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:11:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:11:14Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:11:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 41104

```
ID      LABELS
41104   gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181
        gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=coredns
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend                Service Type   Backend                                  
1    10.105.79.192:80/TCP    ClusterIP      1 => 10.244.2.154:4245/TCP (active)      
2    10.97.123.232:80/TCP    ClusterIP      1 => 10.244.2.31:8081/TCP (active)       
3    10.96.0.10:53/TCP       ClusterIP      1 => 10.244.1.214:53/TCP (active)        
                                            2 => 10.244.2.11:53/TCP (active)         
4    10.96.0.10:53/UDP       ClusterIP      1 => 10.244.1.214:53/UDP (active)        
                                            2 => 10.244.2.11:53/UDP (active)         
5    10.96.0.10:9153/TCP     ClusterIP      1 => 10.244.1.214:9153/TCP (active)      
                                            2 => 10.244.2.11:9153/TCP (active)       
6    10.96.0.1:443/TCP       ClusterIP      1 => 192.168.178.113:6443/TCP (active)   
7    10.101.247.67:443/TCP   ClusterIP      1 => 192.168.178.114:4244/TCP (active)   
```
