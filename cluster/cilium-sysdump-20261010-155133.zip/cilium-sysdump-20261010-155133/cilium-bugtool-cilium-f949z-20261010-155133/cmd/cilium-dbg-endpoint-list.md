ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                       IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                          
1644       Disabled           Disabled          4          reserved:health                                                                          10.244.1.197   ready   
3284       Disabled           Disabled          1          reserved:host                                                                                           ready   
4046       Disabled           Disabled          41104      gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181                10.244.1.214   ready   
                                                           gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                                 
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=kube-dns                                                                                            
