markdown output at /tmp/cilium-bugtool-20261010-135206.858+0000-UTC-55101440/cmd/cilium-debuginfo-20261010-135207.559+0000-UTC.md
json output at /tmp/cilium-bugtool-20261010-135206.858+0000-UTC-55101440/cmd/cilium-debuginfo-20261010-135207.559+0000-UTC.json
