22: cgroup_array  name cgroup_map  flags 0x0
	key 4B  value 4B  max_entries 1  memlock 320B
23: ringbuf  name written_sysctls  flags 0x0
	key 0B  value 0B  max_entries 262144  memlock 275784B
25: array  name .rodata.str1.1  flags 0x80
	key 4B  value 5B  max_entries 1  memlock 320B
	frozen
52: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 328B
53: lpm_trie  name cilium_ipcache_  flags 0x81
	key 24B  value 24B  max_entries 512000  memlock 1088B
54: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 18840B
55: hash  name cilium_ratelimi  flags 0x1
	key 4B  value 8B  max_entries 64  memlock 1992B
56: hash  name cilium_lxc  flags 0x81
	key 20B  value 48B  max_entries 65535  memlock 1049984B
57: hash  name cilium_node_map  flags 0x81
	key 20B  value 4B  max_entries 16384  memlock 263568B
58: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524592B
	owner_prog_type sched_cls  owner jited
59: prog_array  name cilium_egressca  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524592B
	owner_prog_type sched_cls  owner jited
60: lru_percpu_hash  name cilium_policyst  flags 0x2
	key 12B  value 16B  max_entries 65536  memlock 7865216B
61: percpu_array  name cilium_percpu_t  flags 0x0
	key 4B  value 8B  max_entries 1  memlock 336B
62: lru_hash  name cilium_ratelimi  flags 0x0
	key 8B  value 16B  max_entries 1024  memlock 91008B
63: hash  name cilium_lb_affin  flags 0x81
	key 8B  value 1B  max_entries 65536  memlock 1049472B
64: lpm_trie  name cilium_lb4_sour  flags 0x81
	key 12B  value 1B  max_entries 65536  memlock 0B
65: hash  name cilium_lb4_serv  flags 0x81
	key 12B  value 12B  max_entries 65536  memlock 1051408B
66: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1050272B
67: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 1049976B
69: hash_of_maps  name cilium_lb4_magl  flags 0x81
	key 2B  value 4B  max_entries 65536  memlock 1049472B
70: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 5768064B
71: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6292352B
72: hash  name cilium_skip_lb4  flags 0x81
	key 16B  value 1B  max_entries 100  memlock 2944B
73: hash  name cilium_auth_map  flags 0x81
	key 12B  value 8B  max_entries 524288  memlock 8389504B
	btf_id 139
74: array  name cilium_runtime_  flags 0x80
	key 4B  value 8B  max_entries 256  memlock 2360B
	btf_id 140
75: hash  name cilium_devices  flags 0x1
	key 4B  value 16B  max_entries 512  memlock 9168B
	btf_id 140
76: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 15729536B
	btf_id 140
77: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 17826688B
	btf_id 140
78: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 8913792B
	btf_id 140
79: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 721792B
	btf_id 140
80: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 328B
	btf_id 140
81: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 10486656B
	btf_id 140
82: percpu_array  name cilium_snat_v4_  flags 0x0
	key 4B  value 4B  max_entries 33  memlock 1104B
	btf_id 140
84: array  name .bss  flags 0x400
	key 4B  value 20B  max_entries 1  memlock 8192B
	btf_id 144
86: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 66432B
	btf_id 144
87: hash  name cilium_l2_respo  flags 0x1
	key 24B  value 8B  max_entries 4096  memlock 66432B
	btf_id 144
94: hash_of_maps  name cilium_lb4_magl  flags 0x81
	key 2B  value 4B  max_entries 65536  memlock 1049472B
	btf_id 144
99: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 144
100: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 144
113: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 144
143: array  name .rodata.config  flags 0x480
	key 4B  value 152B  max_entries 1  memlock 8192B
	btf_id 302  frozen
144: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 302
146: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 302
147: array  name .rodata.config  flags 0x480
	key 4B  value 192B  max_entries 1  memlock 8192B
	btf_id 316  frozen
148: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 317  frozen
164: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 317
165: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 363  frozen
166: array  name .rodata.config  flags 0x480
	key 4B  value 249B  max_entries 1  memlock 8192B
	btf_id 364  frozen
167: percpu_array  name cilium_nodeport  flags 0x0
	key 4B  value 18B  max_entries 1  memlock 368B
	btf_id 365
168: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 365
170: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 60B  max_entries 1  memlock 448B
	btf_id 368
171: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 60B  max_entries 1  memlock 448B
	btf_id 393
172: prog_array  name cilium_calls_04  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 393
173: percpu_array  name cilium_nodeport  flags 0x0
	key 4B  value 18B  max_entries 1  memlock 368B
	btf_id 394
174: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 395  frozen
175: array  name .rodata.config  flags 0x480
	key 4B  value 249B  max_entries 1  memlock 8192B
	btf_id 396  frozen
177: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 396
178: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 400  frozen
179: array  name .rodata.config  flags 0x480
	key 4B  value 221B  max_entries 1  memlock 8192B
	btf_id 401  frozen
180: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 401
182: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 401
183: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 401
184: array  name .rodata.config  flags 0x480
	key 4B  value 221B  max_entries 1  memlock 8192B
	btf_id 429  frozen
185: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 429
186: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 430  frozen
188: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 430
189: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 445  frozen
191: array  name .rodata.config  flags 0x480
	key 4B  value 221B  max_entries 1  memlock 8192B
	btf_id 447  frozen
192: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 447
