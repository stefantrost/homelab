1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether bc:24:11:de:cb:0c brd ff:ff:ff:ff:ff:ff
    altname enp6s18
    altname enxbc2411decb0c
    inet 192.168.178.114/24 metric 1024 brd 192.168.178.255 scope global dynamic ens18
       valid_lft 853704sec preferred_lft 853704sec
    inet6 fda7:7b49:a70a:0:be24:11ff:fede:cb0c/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7043sec preferred_lft 3443sec
    inet6 2a02:8071:5301:a0a0:be24:11ff:fede:cb0c/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7043sec preferred_lft 3443sec
    inet6 fe80::be24:11ff:fede:cb0c/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether ae:b4:11:77:61:fd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::acb4:11ff:fe77:61fd/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:c2:32:9b:4b:fb brd ff:ff:ff:ff:ff:ff
    inet 10.244.1.173/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::cc2:32ff:fe9b:4bfb/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default 
    link/ether b6:d1:c6:17:33:c7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b4d1:c6ff:fe17:33c7/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether a6:85:ac:c3:e3:75 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a485:acff:fec3:e375/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
9: lxc7ec5ba81bca3@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:0b:01:4d:9f:5e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::980b:1ff:fe4d:9f5e/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
