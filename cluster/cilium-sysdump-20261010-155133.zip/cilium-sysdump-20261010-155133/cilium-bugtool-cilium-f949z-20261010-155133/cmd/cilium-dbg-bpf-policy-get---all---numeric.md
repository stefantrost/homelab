Endpoint ID: 1644
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_01644

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    193555   2383      0        0
Allow    Ingress     11         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    -        -         0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0


Endpoint ID: 3284
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_03284

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        0
Allow    Ingress     11         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -       -         0        0
Allow    Egress      0          ANY          NONE         disabled    -       -         0        0
Allow    Egress      11         ANY          NONE         disabled    -       -         0        0
Allow    Egress      12         ANY          NONE         disabled    -       -         0        0
Allow    Egress      13         ANY          NONE         disabled    -       -         0        0
Allow    Egress      14         ANY          NONE         disabled    -       -         0        0


Endpoint ID: 4046
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_04046

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    984054   11262     0        0
Allow    Ingress     11         ANY          NONE         disabled    349      3         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    93246    1030      0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0


