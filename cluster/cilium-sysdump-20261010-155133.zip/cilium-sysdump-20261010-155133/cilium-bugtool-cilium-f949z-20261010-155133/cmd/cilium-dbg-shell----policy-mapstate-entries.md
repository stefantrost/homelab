ID: 1644	Namespace: 	Name: 	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress
Egress      13         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress

ID: 3284	Namespace: 	Name: 	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      13         *            0          254            allow     0           0        allow-any-egress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress

ID: 4046	Namespace: kube-system	Name: coredns-559f6c778d-khtkb	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress
Egress      13         *            0          254            allow     0           0        allow-any-egress


