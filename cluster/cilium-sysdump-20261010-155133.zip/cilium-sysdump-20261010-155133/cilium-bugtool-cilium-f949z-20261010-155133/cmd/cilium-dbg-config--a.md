#### Read-only configurations ####
AddressScopeMax                   : 254
AgentNotReadyNodeTaintKey         : node.cilium.io/agent-not-ready
AllocatorListTimeout              : 180000000000
AllowICMPFragNeeded               : true
AnnotateK8sNode                   : false
AuthMapEntries                    : 524288
AutoCreateCiliumNodeResource      : true
BGPRouterIDAllocationIPPool       : 
BGPRouterIDAllocationMode         : default
BGPSecretsNamespace               : 
BPFCompileDebug                   : 
BPFConntrackAccounting            : false
BPFDistributedLRU                 : false
BPFEventsDefaultBurstLimit        : 0
BPFEventsDefaultRateLimit         : 0
BPFEventsDropEnabled              : true
BPFEventsPolicyVerdictEnabled     : true
BPFEventsTraceEnabled             : true
BPFMapEventBuffers
BPFMapsDynamicSizeRatio           : 0.0025
BPFRoot                           : /sys/fs/bpf
BootIDFile                        : /proc/sys/kernel/random/boot_id
BpfDir                            : /var/lib/cilium/bpf
BypassIPAvailabilityUponRestore   : false
CGroupRoot                        : /run/cilium/cgroupv2
CTMapEntriesGlobalAny             : 65536
CTMapEntriesGlobalTCP             : 131072
CTMapEntriesTimeoutAny            : 60000000000
CTMapEntriesTimeoutFIN            : 10000000000
CTMapEntriesTimeoutSVCAny         : 60000000000
CTMapEntriesTimeoutSVCTCP         : 8000000000000
CTMapEntriesTimeoutSVCTCPGrace    : 60000000000
CTMapEntriesTimeoutSYN            : 60000000000
CTMapEntriesTimeoutTCP            : 8000000000000
CgroupPathMKE                     : 
CiliumIdentityMaxJitter           : 30000000000
ClockSource                       : 0
ClusterHealthPort                 : 4240
ClusterID                         : 0
ClusterName                       : default
ConfigDir                         : /tmp/cilium/config-map
ConfigFile                        : 
ConnectivityProbeFrequencyRatio   : 0.5
ContainerIPLocalReservedPorts     : auto
CreationTime                      : 2026-10-10T11:00:57.64718542Z
DNSPolicyUnloadOnShutdown         : false
DNSProxyConcurrencyLimit          : 0
DNSProxyEnableTransparentMode     : true
DNSProxyLockCount                 : 131
DNSProxyLockTimeout               : 500000000
DNSProxySocketLingerTimeout       : 10
DatapathMode                      : veth
Debug                             : false
DebugVerbose                      : []
Devices                           : [ens18]
DirectRoutingSkipUnreachable      : false
DisableCiliumEndpointCRD          : false
DisableExternalIPMitigation       : false
DryMode                           : false
EnableAutoDirectRouting           : false
EnableAutoProtectNodePortRange    : true
EnableBGPControlPlane             : false
EnableBGPControlPlaneStatusReport : true
EnableBPFClockProbe               : false
EnableBPFMasquerade               : false
EnableBPFTProxy                   : false
EnableCiliumClusterwideNetworkPolicy: true
EnableCiliumEndpointSlice         : false
EnableCiliumNetworkPolicy         : true
EnableCiliumNodeCRD               : true
EnableDatapathPlugins             : false
EnableEgressGateway               : false
EnableEncryptionStrictModeEgress  : false
EnableEncryptionStrictModeIngress : false
EnableEndpointHealthChecking      : true
EnableEndpointLockdownOnPolicyOverflow: false
EnableEndpointRoutes              : false
EnableEnvoyConfig                 : false
EnableExtendedIPProtocols         : false
EnableFibTableIDAnnotation        : false
EnableHealthChecking              : true
EnableHostFirewall                : false
EnableICMPRules                   : true
EnableIPIPTermination             : false
EnableIPMasqAgent                 : false
EnableIPv4                        : true
EnableIPv4FragmentsTracking       : true
EnableIPv4Masquerade              : true
EnableIPv6                        : false
EnableIPv6FragmentsTracking       : false
EnableIPv6Masquerade              : false
EnableIPv6NDP                     : false
EnableIdentityMark                : true
EnableK8sClusterNetworkPolicy     : false
EnableK8sNetworkPolicy            : true
EnableL2Announcements             : false
EnableL7Proxy                     : true
EnableLocalNodeRoute              : true
EnableLocalRedirectPolicy         : false
EnableMKE                         : false
EnableMasqueradeRouteSource       : false
EnableNat46X64Gateway             : false
EnableNodeSelectorLabels          : false
EnableNonDefaultDenyPolicies      : true
EnablePMTUDiscovery               : false
EnablePolicy                      : default
EnableRemoteNodeMasquerade        : false
EnableSCTP                        : false
EnableSRv6                        : false
EnableSourceIPVerification        : true
EnableTCX                         : true
EnableTracing                     : false
EnableUnreachableRoutes           : false
EnableVTEP                        : false
EnableXDPPrefilter                : false
EncryptNode                       : false
EncryptionStrictEgressAllowRemoteNodeIdentities: false
EncryptionStrictEgressCIDR        : 
EndpointQueueSize                 : 25
ExcludeLocalAddresses             : <nil>
ExcludeNodeLabelPatterns          : <nil>
ExternalEnvoyProxy                : true
FQDNProxyResponseMaxDelay         : 100000000
FQDNRegexCompileLRUSize           : 1024
FQDNRejectResponse                : refused
FixedIdentityMapping
FixedZoneMapping                  : <nil>
ForceDeviceRequired               : false
FragmentsMapEntries               : 8192
HTTP403Message                    : 
HealthCheckICMPFailureThreshold   : 3
HiveConfig
	LogThreshold              : 100000000
	StartTimeout              : 300000000000
	StopTimeout               : 60000000000
IPAM                              : kubernetes
IPAMCiliumNodeUpdateRate          : 15000000000
IPAMDefaultIPPool                 : default
IPAMMultiPoolPreAllocation
	default                   : 8
IPTracingOptionType               : 0
IPv4NativeRoutingCIDR             : <nil>
IPv4NodeAddr                      : auto
IPv4PodSubnets                    : []
IPv4Range                         : auto
IPv4ServiceRange                  : auto
IPv6ClusterAllocCIDR              : f00d::/64
IPv6ClusterAllocCIDRBase          : f00d::
IPv6MCastDevice                   : 
IPv6NAT46x64CIDR                  : 64:ff9b::/96
IPv6NAT46x64CIDRBase              : 64:ff9b::
IPv6NativeRoutingCIDR             : <nil>
IPv6NodeAddr                      : auto
IPv6PodSubnets                    : []
IPv6Range                         : auto
IPv6ServiceRange                  : auto
IdentityAllocationMode            : crd
IdentityChangeGracePeriod         : 5000000000
IdentityRestoreGracePeriod        : 30000000000
InstallIptRules                   : true
InstallNoConntrackIptRules        : false
InstallUplinkRoutesForDelegatedIPAM: false
K8sNamespace                      : kube-system
K8sRequireIPv4PodCIDR             : true
K8sRequireIPv6PodCIDR             : false
K8sSyncTimeout                    : 180000000000
KeepConfig                        : false
KernelHz                          : 1000
L2AnnouncerLeaseDuration          : 15000000000
L2AnnouncerRenewDeadline          : 5000000000
L2AnnouncerRetryPeriod            : 2000000000
LabelPrefixFile                   : 
Labels                            : []
LibDir                            : /var/lib/cilium
LoadBalancerIPIPSockMark          : false
LoadBalancerRSSv4CIDR             : 
LoadBalancerRSSv6CIDR             : 
LocalRouterIPv4                   : 
LocalRouterIPv6                   : 
LogDriver                         : []
LogOpt
LogSystemLoadConfig               : false
MasqueradeInterfaces              : []
MaxConnectedClusters              : 255
MaxControllerInterval             : 0
MonitorAggregation                : medium
MonitorAggregationFlags           : 255
MonitorAggregationInterval        : 5000000000
NATMapEntriesGlobal               : 131072
NeighMapEntriesGlobal             : 131072
NodeLabels                        : []
NodePortAcceleration              : disabled
NodePortBindProtection            : true
NodePortNat46X64                  : false
PolicyAccounting                  : true
PolicyAuditMode                   : false
PolicyCIDRMatchMode               : []
PolicyDenyResponse                : none
PolicyMapFullReconciliationInterval: 900000000000
PolicyTriggerInterval             : 1000000000
PreAllocateMaps                   : false
PreferIpv6                        : false
ProcFs                            : /host/proc
RestoreState                      : true
ReverseFixedZoneMapping           : <nil>
RouteMetric                       : 0
RoutingMode                       : tunnel
RunDir                            : /var/run/cilium
SRv6EncapMode                     : reduced
ServiceNoBackendResponse          : reject
SizeofCTElement                   : 94
SizeofNATElement                  : 94
SizeofNeighElement                : 24
SizeofSockRevElement              : 52
SocketPath                        : /var/run/cilium/cilium.sock
StateDir                          : /var/run/cilium/state
TCFilterPriority                  : 1
ToFQDNsIdleConnectionGracePeriod  : 0
ToFQDNsMaxDeferredConnectionDeletes: 10000
ToFQDNsMaxIPsPerHost              : 1000
ToFQDNsMinTTL                     : 0
ToFQDNsPreCache                   : 
ToFQDNsProxyPort                  : 0
TracePayloadlen                   : 128
TracePayloadlenOverlay            : 192
UnsafeDaemonConfigOption
	AllowLocalhost            : always
	BPFSocketLBHostnsOnly     : Enabled
	EnableHealthDatapath      : Disabled
	EnableHostLegacyRouting   : Enabled
	EnableIPIPDevices         : Disabled
	EnableSocketLBPeer        : Enabled
	EnableSocketLBPodConnectionTermination: Enabled
	EnableSocketLBTracing     : Enabled
	LoadBalancerRSSv4         : map[IP: Mask:<nil>]
	LoadBalancerRSSv6         : map[IP: Mask:<nil>]
VLANBPFBypass                     : []
VtepCidrMask                      : 
k8s-configuration                 : 
##### Read-write configurations #####
Debug                             : Disabled
DebugLB                           : Disabled
DropNotification                  : Enabled
MonitorAggregationLevel           : Medium
PolicyAuditMode                   : Disabled
PolicyTracing                     : Disabled
PolicyVerdictNotification         : Enabled
SourceIPVerification              : Enabled
TraceNotification                 : Enabled
MonitorNumPages                   : 64
PolicyEnforcement                 : default
