 13:52:07 up  2:51,  0 users,  load average: 1.41, 0.44, 0.26
