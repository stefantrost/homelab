Cluster health:   2/3 reachable   (2026-10-10T13:50:24Z)   (Probe interval: 1m56.754608943s)
Name              IP              Node                     Endpoints
  workernode01 (localhost):
    Host connectivity to 192.168.178.114:
      ICMP to stack:   OK, RTT=66.284µs   (Last probed: 2026-10-10T13:51:03Z)
      HTTP to agent:   OK, RTT=412.23µs   (Last probed: 2026-10-10T13:51:03Z)
    Endpoint connectivity to 10.244.1.197:
      ICMP to stack:   OK, RTT=105.597µs   (Last probed: 2026-10-10T13:51:23Z)
      HTTP to agent:   OK, RTT=333.271µs   (Last probed: 2026-10-10T13:51:23Z)
  controlplane:
    Host connectivity to 192.168.178.113:
      ICMP to stack:   OK, RTT=260.635µs                                                                                     (Last probed: 2026-10-10T13:50:24Z)
      HTTP to agent:   Get "http://192.168.178.113:4240/hello": dial tcp 192.168.178.113:4240: connect: connection refused   (Last probed: 2026-10-10T13:50:24Z)
    Endpoint connectivity to 10.244.0.27:
      ICMP to stack:   Connection timed out                                                                                              (Last probed: 2026-10-10T13:50:54Z)
      HTTP to agent:   Get "http://10.244.0.27:4240/hello": context deadline exceeded (Client.Timeout exceeded while awaiting headers)   (Last probed: 2026-10-10T13:50:54Z)
  workernode02:
    Host connectivity to 192.168.178.115:
      ICMP to stack:   OK, RTT=296.715µs   (Last probed: 2026-10-10T13:51:42Z)
      HTTP to agent:   OK, RTT=849.463µs   (Last probed: 2026-10-10T13:51:42Z)
    Endpoint connectivity to 10.244.2.84:
      ICMP to stack:   OK, RTT=446.289µs    (Last probed: 2026-10-10T13:52:02Z)
      HTTP to agent:   OK, RTT=1.140212ms   (Last probed: 2026-10-10T13:52:02Z)
