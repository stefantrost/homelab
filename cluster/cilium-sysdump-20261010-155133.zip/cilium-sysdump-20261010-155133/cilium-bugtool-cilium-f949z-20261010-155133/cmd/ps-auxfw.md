USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        1118 26.6  0.1 1270332 14132 ?       Ssl  13:52   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        1138  0.0  0.0   6760  3956 ?        R    13:52   0:00  \_ ps auxfw
root        1139  0.0  0.0    444    20 ?        R    13:52   0:00  \_ hostname
root           1  1.9  1.8 1531216 182376 ?      Ssl  11:00   3:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         100  0.0  0.0 1264140 6576 ?        Sl   11:00   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
