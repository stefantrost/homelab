qdisc noqueue 0: dev lo root refcnt 2 
qdisc pfifo_fast 0: dev ens18 root refcnt 2 bands 3 priomap 1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc noqueue 0: dev lxc7ec5ba81bca3 root refcnt 2 
