key: 00 04  value: 0a 60 00 0a 00 35
key: 00 07  value: 0a 65 f7 43 01 bb
key: 00 03  value: 0a 60 00 0a 00 35
key: 00 06  value: 0a 60 00 01 01 bb
key: 00 05  value: 0a 60 00 0a 23 c1
key: 00 01  value: 0a 69 4f c0 00 50
key: 00 02  value: 0a 61 7b e8 00 50
Found 7 elements
