[
  {
    "containers": [
      {
        "cgroup-id": 10175,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9268a9b_2a62_462a_8372_701f00e7bdf8.slice/cri-containerd-3d4d9f0047ad4a4c5940cb9ee8d9c62f680b7671aecf3a9503ae097338adb416.scope"
      }
    ],
    "ips": [
      "10.244.1.214"
    ],
    "name": "coredns-559f6c778d-khtkb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8609,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb95c705_554d_4f74_b4f7_bf66d99ea988.slice/cri-containerd-aa6e982a63792ccbbe7468f2cc4caac4a2a33e2b9a391d7c7284712e9d43ca1d.scope"
      }
    ],
    "ips": [
      "192.168.178.114"
    ],
    "name": "cilium-envoy-vg7jt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10001,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd13195dd_935d_471c_90da_2db8b9c8ea55.slice/cri-containerd-f12b8a99a801738a776069e99e133da93d6b0821cd3666d04b628a6126efecba.scope"
      }
    ],
    "ips": [
      "192.168.178.114"
    ],
    "name": "cilium-f949z",
    "namespace": "kube-system"
  }
]

