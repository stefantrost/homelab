Node 0, zone      DMA      2      2      2      1      2      2      2      2      3      4      0 
Node 0, zone    DMA32     11     12      9      7      6      8      6      9      7      5    454 
Node 0, zone   Normal    393    315     18     68     87     10     18     34     13     16   1481 
