/*
 * This file is not using during compilation of endpoint programs.
 * IPv4 address: invalid IP
 * Identity: 1
 * PolicyMap: cilium_policy_v3_03284
 * NodeMAC: 0e:c2:32:9b:4b:fb
 */

/*
 * Labels:
 * - reserved:host
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define HOST_ENDPOINT 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
