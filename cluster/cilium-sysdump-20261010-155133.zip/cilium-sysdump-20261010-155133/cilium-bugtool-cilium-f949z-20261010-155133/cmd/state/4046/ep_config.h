/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: 88a7af6568dff9b6ed4da216af48cfe45acbc701b91ebf21a19c7bbf3c84d55f
 * Container Interface: eth0
 * IPv4 address: 10.244.1.214
 * Identity: 41104
 * PolicyMap: cilium_policy_v3_04046
 * NodeMAC: 9a:0b:01:4d:9f:5e
 */

/*
 * Labels:
 * - k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
 * - k8s:io.kubernetes.pod.namespace=kube-system
 * - gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080
 * - gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181
 * - k8s:io.cilium.k8s.policy.serviceaccount=coredns
 * - k8s:io.cilium.k8s.policy.cluster=default
 * - k8s:k8s-app=kube-dns
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
