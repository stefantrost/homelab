/*
 * This file is not using during compilation of endpoint programs.
 * IPv4 address: 10.244.1.197
 * Identity: 4
 * PolicyMap: cilium_policy_v3_01644
 * NodeMAC: a6:85:ac:c3:e3:75
 */

/*
 * Labels:
 * - reserved:health
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
