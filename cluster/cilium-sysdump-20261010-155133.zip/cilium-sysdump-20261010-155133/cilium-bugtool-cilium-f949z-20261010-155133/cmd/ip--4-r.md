default via 192.168.178.1 dev ens18 proto dhcp src 192.168.178.114 metric 1024 
10.244.0.0/24 via 10.244.1.173 dev cilium_host proto kernel src 10.244.1.173 mtu 1450 
10.244.1.0/24 via 10.244.1.173 dev cilium_host proto kernel src 10.244.1.173 
10.244.1.173 dev cilium_host proto kernel scope link 
10.244.2.0/24 via 10.244.1.173 dev cilium_host proto kernel src 10.244.1.173 mtu 1450 
192.168.178.0/24 dev ens18 proto kernel scope link src 192.168.178.114 metric 1024 
192.168.178.1 dev ens18 proto dhcp scope link src 192.168.178.114 metric 1024 
