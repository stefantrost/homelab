49: cgroup_device  name sd_devices  tag 9f0126175d483e7a  gpl
	loaded_at 2026-10-10T11:00:18+0000  uid 0
	xlated 504B  jited 311B  memlock 4096B
50: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:18+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
51: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:18+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
52: cgroup_device  name sd_devices  tag 99aee04c1c96cc7e  gpl
	loaded_at 2026-10-10T11:00:19+0000  uid 0
	xlated 464B  jited 290B  memlock 4096B
53: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:19+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
54: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:19+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
55: cgroup_device  name sd_devices  tag 9f0126175d483e7a  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 0
	xlated 504B  jited 311B  memlock 4096B
61: cgroup_sysctl  name sysctl_monitor  tag 2953fbb83d3292b5  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 998
	xlated 1240B  jited 781B  memlock 4096B  map_ids 22,25,23
	btf_id 110
63: cgroup_device  name sd_devices  tag 925aa739a35aee81  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 0
	xlated 560B  jited 353B  memlock 4096B
64: cgroup_device  name sd_devices  tag 470479e7b2a42bb5  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 0
	xlated 184B  jited 103B  memlock 4096B
65: cgroup_device  name sd_devices  tag d82bf1294d9d3136  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 0
	xlated 792B  jited 482B  memlock 4096B
66: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
67: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:21+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
72: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
76: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
77: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
81: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
82: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
86: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
87: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
91: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
92: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
96: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
97: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
101: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
102: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
106: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
107: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
111: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
117: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
121: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
122: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
126: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
127: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
131: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
132: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
136: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
139: cgroup_device  tag b1e4e8bab2078b38
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 64B  jited 42B  memlock 4096B
140: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:51+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
144: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:51+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
147: cgroup_device  tag b1e4e8bab2078b38
	loaded_at 2026-10-10T11:00:51+0000  uid 0
	xlated 64B  jited 42B  memlock 4096B
171: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:57+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
175: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:57+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
210: tracing  name cil_sock_udp_destroy_v4  tag 7352b1c629812875  gpl
	loaded_at 2026-10-10T11:00:58+0000  uid 0
	xlated 328B  jited 199B  memlock 4096B  map_ids 84,70
	btf_id 145
211: tracing  name cil_sock_tcp_destroy_v4  tag 7352b1c629812875  gpl
	loaded_at 2026-10-10T11:00:58+0000  uid 0
	xlated 328B  jited 199B  memlock 4096B  map_ids 84,70
	btf_id 152
289: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:06+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
293: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:06+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
308: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:06+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
312: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:06+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
319: cgroup_sock_addr  name cil_sock6_connect  tag 7c373f75761f9334  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 6624B  jited 3668B  memlock 8192B  map_ids 65,143,53,55,62,52,71,63,66,54,70
	btf_id 303
320: cgroup_sock_addr  name cil_sock4_getpeername  tag ab602e317c4b1b12  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 1616B  jited 937B  memlock 4096B  map_ids 70,65,143,53,54
	btf_id 304
321: cgroup_sock_addr  name cil_sock4_sendmsg  tag 5f2cec8aed4dcc77  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 4384B  jited 2489B  memlock 8192B  map_ids 65,143,53,71,63,66,54,70
	btf_id 305
322: cgroup_sock_addr  name cil_sock6_recvmsg  tag 54a5d2ea66def6a2  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 1848B  jited 1056B  memlock 4096B  map_ids 70,65,143,53,54
	btf_id 306
323: cgroup_sock_addr  name cil_sock4_connect  tag 4ff57d2b97742faf  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 6384B  jited 3538B  memlock 8192B  map_ids 65,143,53,55,62,52,71,63,66,54,70
	btf_id 307
324: cgroup_sock_addr  name cil_sock4_recvmsg  tag ab602e317c4b1b12  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 1616B  jited 937B  memlock 4096B  map_ids 70,65,143,53,54
	btf_id 308
325: cgroup_sock_addr  name cil_sock6_getpeername  tag 54a5d2ea66def6a2  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 1848B  jited 1056B  memlock 4096B  map_ids 70,65,143,53,54
	btf_id 309
326: cgroup_sock  name cil_sock6_post_bind  tag 87bcd2e567b2fc57  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 1416B  jited 838B  memlock 4096B  map_ids 143,53,65
	btf_id 310
327: cgroup_sock_addr  name cil_sock6_sendmsg  tag bb755855efb431aa  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 4600B  jited 2586B  memlock 8192B  map_ids 65,143,53,71,63,66,54,70
	btf_id 311
328: cgroup_sock  name cil_sock_release  tag 2ae0d55b112ace52  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 384B  jited 225B  memlock 4096B  map_ids 70,54
	btf_id 312
329: cgroup_sock  name cil_sock4_post_bind  tag eb9043708ec7115b  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 984B  jited 571B  memlock 4096B  map_ids 65,143,53
	btf_id 313
330: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 97232cce1c60961b  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 12552B  jited 7332B  memlock 16384B  map_ids 147,79,76,54,77,78,146,67,53,148,144,52,75
	btf_id 318
331: sched_cls  name tail_handle_snat_fwd_ipv4  tag 8b605a0fb2ec49fd  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 15584B  jited 8828B  memlock 20480B  map_ids 148,144,147,79,54,146,76,77,78,82,80,52
	btf_id 319
332: sched_cls  name cil_to_overlay  tag 2a5cfff9bcc179bc  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 5824B  jited 3361B  memlock 8192B  map_ids 147,79,54,77,78,67,146
	btf_id 320
333: sched_cls  name tail_drop_notify  tag 22c5d14c4d7ba9da  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 672B  jited 368B  memlock 4096B  map_ids 147,52
	btf_id 321
334: sched_cls  name tail_handle_ipv4  tag 8d8aab9a5d3dff93  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 15008B  jited 8804B  memlock 24576B  map_ids 147,79,65,54,64,77,78,146,148,144,71,63,94,66,56,81,53,58
	btf_id 322
335: sched_cls  name cil_from_overlay  tag 4fa358252a534140  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 1576B  jited 991B  memlock 4096B  map_ids 147,148,144,54,146
	btf_id 323
336: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 4b81b9e59bd814ea  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 13040B  jited 7763B  memlock 16384B  map_ids 147,53,79,76,54,82,80,148,144,52,75,146
	btf_id 324
337: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:10+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 54,146
	btf_id 325
363: sched_cls  name tail_drop_notify  tag d35c1d928a577a35  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 696B  jited 383B  memlock 4096B  map_ids 166,52
	btf_id 370
364: sched_cls  name tail_handle_arp  tag 210da590646efc92  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1616B  jited 928B  memlock 4096B  map_ids 166,54,168
	btf_id 371
365: sched_cls  name tail_ipv4_ct_ingress  tag 96872acfd965f352  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8152B  jited 4708B  memlock 12288B  map_ids 170,166,54,168,77,78,79
	btf_id 372
366: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 54,168
	btf_id 373
367: sched_cls  name cil_lxc_policy_egress  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 374
368: sched_cls  name tail_ipv4_ct_egress  tag ed73af9a5bfb3dc0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8448B  jited 4858B  memlock 12288B  map_ids 170,166,54,168,77,78,79
	btf_id 375
372: sched_cls  name tail_handle_ipv4  tag 02d6eeffe8f139ea  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 10176B  jited 5849B  memlock 16384B  map_ids 166,79,65,77,78,53,54,167,71,63,66,165,164,168
	btf_id 376
374: sched_cls  name tail_ipv4_policy  tag c41ef863ac6002c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12168B  jited 6881B  memlock 20480B  map_ids 166,170,77,78,99,67,60,53,57,73,74,80,52,165,164,54,168
	btf_id 380
375: sched_cls  name cil_from_container  tag b1520d937090b4d6  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1392B  jited 940B  memlock 4096B  map_ids 166,165,164,168,54
	btf_id 382
377: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag df85f70e11817dce  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 7720B  jited 4541B  memlock 12288B  map_ids 166,79,54,168,77,78,67,53,165,164,52,75
	btf_id 383
381: sched_cls  name tail_handle_ipv4_cont  tag 035083e6cc6b8f74  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 15488B  jited 8907B  memlock 28672B  map_ids 167,166,53,170,165,164,99,52,60,57,73,74,80,77,78,54,56,168,58
	btf_id 385
382: sched_cls  name cil_lxc_policy  tag 9e007e2259856a49  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8904B  jited 5186B  memlock 12288B  map_ids 166,170,54,168,77,78,79
	btf_id 389
385: sched_cls  name tail_ipv4_to_endpoint  tag 424019b602880193  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12224B  jited 6751B  memlock 16384B  map_ids 53,166,54,170,77,78,99,67,60,57,73,74,80,52,165,164,168
	btf_id 390
387: sched_cls  name tail_handle_ipv4  tag 02d6eeffe8f139ea  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 10176B  jited 5849B  memlock 16384B  map_ids 175,79,65,77,78,53,54,173,71,63,66,174,177,172
	btf_id 399
388: sched_cls  name tail_ipv4_ct_ingress  tag 96872acfd965f352  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8152B  jited 4708B  memlock 12288B  map_ids 171,175,54,172,77,78,79
	btf_id 405
389: sched_cls  name cil_lxc_policy  tag 9e007e2259856a49  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8904B  jited 5186B  memlock 12288B  map_ids 175,171,54,172,77,78,79
	btf_id 406
390: sched_cls  name cil_lxc_policy_egress  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 407
392: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag df85f70e11817dce  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 7720B  jited 4541B  memlock 12288B  map_ids 175,79,54,172,77,78,67,53,174,177,52,75
	btf_id 409
393: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 54,172
	btf_id 410
394: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 67ca6b118fd84fdf  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 13400B  jited 7999B  memlock 16384B  map_ids 179,53,79,76,54,82,80,178,180,52,75,182
	btf_id 404
395: sched_cls  name tail_ipv4_policy  tag c41ef863ac6002c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12168B  jited 6881B  memlock 20480B  map_ids 175,171,77,78,113,67,60,53,57,73,74,80,52,174,177,54,172
	btf_id 411
396: sched_cls  name tail_drop_notify  tag d35c1d928a577a35  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 696B  jited 383B  memlock 4096B  map_ids 175,52
	btf_id 413
397: sched_cls  name tail_handle_arp  tag 210da590646efc92  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1616B  jited 928B  memlock 4096B  map_ids 175,54,172
	btf_id 414
398: sched_cls  name cil_from_container  tag b1520d937090b4d6  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1392B  jited 940B  memlock 4096B  map_ids 175,174,177,172,54
	btf_id 415
399: sched_cls  name tail_ipv4_ct_egress  tag ed73af9a5bfb3dc0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8448B  jited 4858B  memlock 12288B  map_ids 171,175,54,172,77,78,79
	btf_id 416
400: sched_cls  name tail_handle_ipv4_from_netdev  tag 988163d6b4eaaa87  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 13432B  jited 7826B  memlock 24576B  map_ids 179,79,54,65,64,77,78,182,178,180,71,63,94,66,56,81
	btf_id 412
401: sched_cls  name cil_to_host  tag f50c664f5e67920b  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1112B  jited 660B  memlock 8192B  map_ids 179,178,180,54,182
	btf_id 418
402: sched_cls  name tail_ipv4_to_endpoint  tag 424019b602880193  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12224B  jited 6751B  memlock 16384B  map_ids 53,175,54,171,77,78,113,67,60,57,73,74,80,52,174,177,172
	btf_id 417
403: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag e6b1893e311b4086  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12832B  jited 7642B  memlock 16384B  map_ids 179,79,76,54,77,78,182,67,53,178,180,52,75
	btf_id 419
404: sched_cls  name tail_handle_ipv4_cont  tag 035083e6cc6b8f74  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 15488B  jited 8907B  memlock 28672B  map_ids 173,175,53,171,174,177,113,52,60,57,73,74,80,77,78,54,56,172,58
	btf_id 420
405: sched_cls  name tail_handle_snat_fwd_ipv4  tag 58a967a976e4a8da  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16320B  jited 9341B  memlock 20480B  map_ids 179,178,180,56,79,54,182,76,77,78,52,82,80
	btf_id 421
406: sched_cls  name tail_handle_ipv4_from_host  tag 225a5d1c8fc087f2  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 4504B  jited 2493B  memlock 8192B  map_ids 179,56,53,178,180,54,52,182,58
	btf_id 422
408: sched_cls  name cil_host_policy  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 424
409: sched_cls  name tail_drop_notify  tag 21aecbc2f8151ba0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1232B  jited 694B  memlock 4096B  map_ids 179,52
	btf_id 425
411: sched_cls  name cil_from_host  tag 8f3cbdbfcbadf3c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 4752B  jited 2761B  memlock 8192B  map_ids 179,178,180,54,53,182
	btf_id 427
412: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 67ca6b118fd84fdf  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 13400B  jited 7999B  memlock 16384B  map_ids 184,53,79,76,54,82,80,186,183,52,75,185
	btf_id 432
413: sched_cls  name tail_handle_ipv4_from_host  tag 225a5d1c8fc087f2  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 4504B  jited 2493B  memlock 8192B  map_ids 184,56,53,186,183,54,52,185,58
	btf_id 433
414: sched_cls  name tail_drop_notify  tag 21aecbc2f8151ba0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1232B  jited 694B  memlock 4096B  map_ids 184,52
	btf_id 434
416: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag e6b1893e311b4086  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12832B  jited 7642B  memlock 16384B  map_ids 184,79,76,54,77,78,185,67,53,186,183,52,75
	btf_id 436
418: sched_cls  name tail_handle_snat_fwd_ipv4  tag 58a967a976e4a8da  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16320B  jited 9341B  memlock 20480B  map_ids 184,186,183,56,79,54,185,76,77,78,52,82,80
	btf_id 438
420: sched_cls  name tail_handle_ipv4_from_netdev  tag e284f0cfeabf09ef  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 13408B  jited 7846B  memlock 24576B  map_ids 184,79,54,65,64,77,78,185,186,183,71,63,94,66,56,81
	btf_id 440
421: sched_cls  name cil_to_host  tag f50c664f5e67920b  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1112B  jited 660B  memlock 8192B  map_ids 184,186,183,54,185
	btf_id 441
422: sched_cls  name tail_no_service_ipv4  tag 407d6feccaa41e51  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5984B  jited 3254B  memlock 8192B  map_ids 184,54,185
	btf_id 442
425: sched_cls  name tail_handle_ipv4_from_host  tag 225a5d1c8fc087f2  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 4504B  jited 2493B  memlock 8192B  map_ids 191,56,53,189,188,54,52,192,58
	btf_id 449
426: sched_cls  name tail_handle_ipv4_from_netdev  tag e284f0cfeabf09ef  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 13408B  jited 7846B  memlock 24576B  map_ids 191,79,54,65,64,77,78,192,189,188,71,63,94,66,56,81
	btf_id 450
427: sched_cls  name tail_drop_notify  tag 21aecbc2f8151ba0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1232B  jited 694B  memlock 4096B  map_ids 191,52
	btf_id 451
428: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag e6b1893e311b4086  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12832B  jited 7642B  memlock 16384B  map_ids 191,79,76,54,77,78,192,67,53,189,188,52,75
	btf_id 452
429: sched_cls  name cil_to_netdev  tag 43afcdec1d06a13e  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8840B  jited 5250B  memlock 16384B  map_ids 191,79,54,77,78,67,75,189,188,192,52
	btf_id 453
432: sched_cls  name cil_from_netdev  tag 0ebe730923df919a  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 3944B  jited 2386B  memlock 8192B  map_ids 191,53,189,188,54,192
	btf_id 456
433: sched_cls  name tail_handle_snat_fwd_ipv4  tag 58a967a976e4a8da  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16320B  jited 9341B  memlock 20480B  map_ids 191,189,188,56,79,54,192,76,77,78,52,82,80
	btf_id 457
434: sched_cls  name tail_no_service_ipv4  tag 407d6feccaa41e51  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5984B  jited 3254B  memlock 8192B  map_ids 191,54,192
	btf_id 458
435: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 67ca6b118fd84fdf  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 13400B  jited 7999B  memlock 16384B  map_ids 191,53,79,76,54,82,80,189,188,52,75,192
	btf_id 459
