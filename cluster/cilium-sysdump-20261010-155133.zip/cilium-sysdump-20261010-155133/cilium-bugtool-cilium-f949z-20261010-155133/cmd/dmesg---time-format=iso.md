2026-10-10T11:00:13,501826+00:00 Linux version 7.0.0-38-generic (buildd@lcy02-amd64-070) (x86_64-linux-gnu-gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0, GNU ld (GNU Binutils for Ubuntu) 2.46) #38-Ubuntu SMP PREEMPT_DYNAMIC Fri Sep  4 09:10:14 UTC 2026 (Ubuntu 7.0.0-38.38-generic 7.0.14)
2026-10-10T11:00:13,501826+00:00 Command line: BOOT_IMAGE=/vmlinuz-7.0.0-38-generic root=UUID=747687d9-c20c-41f8-bfb8-7f4a57910c51 ro console=tty1 console=ttyS0
2026-10-10T11:00:13,501826+00:00 KERNEL supported cpus:
2026-10-10T11:00:13,501826+00:00   Intel GenuineIntel
2026-10-10T11:00:13,501826+00:00   AMD AuthenticAMD
2026-10-10T11:00:13,501826+00:00   Hygon HygonGenuine
2026-10-10T11:00:13,501826+00:00   Centaur CentaurHauls
2026-10-10T11:00:13,501826+00:00   zhaoxin   Shanghai  
2026-10-10T11:00:13,501826+00:00 BIOS-provided physical RAM map:
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000002ffff]  System RAM
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000000030000-0x000000000004ffff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000000050000-0x000000000009efff]  System RAM
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000000009f000-0x000000000009ffff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [gap 0x00000000000a0000-0x00000000000fffff]
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000000100000-0x0000000000811fff]  System RAM
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000000812000-0x0000000000812fff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000000813000-0x000000007a1c3fff]  System RAM
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007a1c4000-0x000000007a1c6fff]  ACPI data
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007a1c7000-0x000000007bce5fff]  System RAM
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007bce6000-0x000000007bf65fff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007bf66000-0x000000007bf77fff]  ACPI data
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007bf78000-0x000000007bff7fff]  ACPI NVS
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007bff8000-0x000000007bffffff]  System RAM
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x000000007c000000-0x000000007fffffff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [gap 0x0000000080000000-0x00000000dfffffff]
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x00000000e0000000-0x00000000efffffff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [gap 0x00000000f0000000-0x00000000feffbfff]
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff]  device reserved
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [gap 0x00000000ff000000-0x00000000ffffffff]
2026-10-10T11:00:13,501826+00:00 BIOS-e820: [mem 0x0000000100000000-0x00000002ffffffff]  System RAM
2026-10-10T11:00:13,501826+00:00 NX (Execute Disable) protection: active
2026-10-10T11:00:13,501826+00:00 APIC: Static calls initialized
2026-10-10T11:00:13,501826+00:00 efi: EFI v2.7 by Proxmox distribution of EDK II
2026-10-10T11:00:13,501826+00:00 efi: ACPI=0x7bf77000 ACPI 2.0=0x7bf77014 SMBIOS=0x7bdcb000 MEMATTR=0x7a1cb118 MOKvar=0x7bd78000 INITRD=0x7a1cca18 RNG=0x7bf67018 
2026-10-10T11:00:13,501826+00:00 random: crng init done
2026-10-10T11:00:13,501826+00:00 SMBIOS 2.8 present.
2026-10-10T11:00:13,501826+00:00 DMI: QEMU Standard PC (Q35 + ICH9, 2009), BIOS 4.2026.08-1 08/26/2026
2026-10-10T11:00:13,501826+00:00 DMI: Memory slots populated: 1/1
2026-10-10T11:00:13,501826+00:00 secureboot: Secure boot disabled
2026-10-10T11:00:13,501826+00:00 Hypervisor detected: KVM
2026-10-10T11:00:13,501826+00:00 last_pfn = 0x7c000 max_arch_pfn = 0x400000000
2026-10-10T11:00:13,501826+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2026-10-10T11:00:13,501828+00:00 kvm-clock: using sched offset of 6817629555 cycles
2026-10-10T11:00:13,501830+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2026-10-10T11:00:13,501834+00:00 tsc: Detected 806.400 MHz processor
2026-10-10T11:00:13,501947+00:00 e820: update [mem 0x00000000-0x00000fff] System RAM ==> device reserved
2026-10-10T11:00:13,501958+00:00 e820: remove [mem 0x000a0000-0x000fffff] System RAM
2026-10-10T11:00:13,501968+00:00 last_pfn = 0x300000 max_arch_pfn = 0x400000000
2026-10-10T11:00:13,502006+00:00 MTRR map: 4 entries (2 fixed + 2 variable; max 18), built from 8 variable MTRRs
2026-10-10T11:00:13,502010+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2026-10-10T11:00:13,502058+00:00 last_pfn = 0x7c000 max_arch_pfn = 0x400000000
2026-10-10T11:00:13,510822+00:00 Using GB pages for direct mapping
2026-10-10T11:00:13,511479+00:00 secureboot: Secure boot disabled
2026-10-10T11:00:13,511481+00:00 RAMDISK: [mem 0x7252a000-0x74efcfff]
2026-10-10T11:00:13,511485+00:00 ACPI: Early table checksum verification disabled
2026-10-10T11:00:13,511488+00:00 ACPI: RSDP 0x000000007BF77014 000024 (v02 BOCHS )
2026-10-10T11:00:13,511494+00:00 ACPI: XSDT 0x000000007BF760E8 00005C (v01 BOCHS  BXPC     00000001      01000013)
2026-10-10T11:00:13,511499+00:00 ACPI: FACP 0x000000007BF6D000 0000F4 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:13,511505+00:00 ACPI: DSDT 0x000000007BF6E000 0067CD (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:13,511508+00:00 ACPI: FACS 0x000000007BFD5000 000040
2026-10-10T11:00:13,511511+00:00 ACPI: WSMT 0x000000007BF75000 000028 (v01 INTEL  EDK2     00000002      01000013)
2026-10-10T11:00:13,511514+00:00 ACPI: APIC 0x000000007BF6C000 000080 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:13,511517+00:00 ACPI: SSDT 0x000000007BF6B000 0000CA (v01 BOCHS  VMGENID  00000001 BXPC 00000001)
2026-10-10T11:00:13,511520+00:00 ACPI: MCFG 0x000000007BF6A000 00003C (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:13,511523+00:00 ACPI: WAET 0x000000007BF69000 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:13,511525+00:00 ACPI: BGRT 0x000000007BF68000 000038 (v01 INTEL  EDK2     00000002      01000013)
2026-10-10T11:00:13,511528+00:00 ACPI: Reserving FACP table memory at [mem 0x7bf6d000-0x7bf6d0f3]
2026-10-10T11:00:13,511530+00:00 ACPI: Reserving DSDT table memory at [mem 0x7bf6e000-0x7bf747cc]
2026-10-10T11:00:13,511531+00:00 ACPI: Reserving FACS table memory at [mem 0x7bfd5000-0x7bfd503f]
2026-10-10T11:00:13,511532+00:00 ACPI: Reserving WSMT table memory at [mem 0x7bf75000-0x7bf75027]
2026-10-10T11:00:13,511532+00:00 ACPI: Reserving APIC table memory at [mem 0x7bf6c000-0x7bf6c07f]
2026-10-10T11:00:13,511533+00:00 ACPI: Reserving SSDT table memory at [mem 0x7bf6b000-0x7bf6b0c9]
2026-10-10T11:00:13,511534+00:00 ACPI: Reserving MCFG table memory at [mem 0x7bf6a000-0x7bf6a03b]
2026-10-10T11:00:13,511535+00:00 ACPI: Reserving WAET table memory at [mem 0x7bf69000-0x7bf69027]
2026-10-10T11:00:13,511536+00:00 ACPI: Reserving BGRT table memory at [mem 0x7bf68000-0x7bf68037]
2026-10-10T11:00:13,512131+00:00 No NUMA configuration found
2026-10-10T11:00:13,512135+00:00 Faking a node at [mem 0x0000000000000000-0x00000002ffffffff]
2026-10-10T11:00:13,512150+00:00 NODE_DATA(0) allocated [mem 0x2fffd3280-0x2ffffdfff]
2026-10-10T11:00:13,517769+00:00 ACPI: PM-Timer IO Port: 0x608
2026-10-10T11:00:13,517792+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2026-10-10T11:00:13,517837+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2026-10-10T11:00:13,517840+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2026-10-10T11:00:13,517843+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2026-10-10T11:00:13,517844+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2026-10-10T11:00:13,517845+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2026-10-10T11:00:13,517846+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2026-10-10T11:00:13,517850+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2026-10-10T11:00:13,517860+00:00 e820: update [mem 0x79ccd000-0x79cf0fff] System RAM ==> device reserved
2026-10-10T11:00:13,517874+00:00 TSC deadline timer available
2026-10-10T11:00:13,517877+00:00 CPU topo: Max. logical packages:   1
2026-10-10T11:00:13,517878+00:00 CPU topo: Max. logical nodes:      1
2026-10-10T11:00:13,517879+00:00 CPU topo: Num. nodes per package:  1
2026-10-10T11:00:13,517881+00:00 CPU topo: Max. logical dies:       1
2026-10-10T11:00:13,517882+00:00 CPU topo: Max. dies per package:   1
2026-10-10T11:00:13,517885+00:00 CPU topo: Max. threads per core:   1
2026-10-10T11:00:13,517886+00:00 CPU topo: Num. cores per package:     2
2026-10-10T11:00:13,517887+00:00 CPU topo: Num. threads per package:   2
2026-10-10T11:00:13,517887+00:00 CPU topo: Allowing 2 present CPUs plus 0 hotplug CPUs
2026-10-10T11:00:13,517905+00:00 kvm-guest: APIC: eoi() replaced with kvm_guest_apic_eoi_write()
2026-10-10T11:00:13,517920+00:00 kvm-guest: KVM setup pv remote TLB flush
2026-10-10T11:00:13,517924+00:00 kvm-guest: setup PV sched yield
2026-10-10T11:00:13,517937+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2026-10-10T11:00:13,517939+00:00 PM: hibernation: Registered nosave memory: [mem 0x00030000-0x0004ffff]
2026-10-10T11:00:13,517941+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x000fffff]
2026-10-10T11:00:13,517942+00:00 PM: hibernation: Registered nosave memory: [mem 0x00812000-0x00812fff]
2026-10-10T11:00:13,517943+00:00 PM: hibernation: Registered nosave memory: [mem 0x79ccd000-0x79cf0fff]
2026-10-10T11:00:13,517945+00:00 PM: hibernation: Registered nosave memory: [mem 0x7a1c4000-0x7a1c6fff]
2026-10-10T11:00:13,517946+00:00 PM: hibernation: Registered nosave memory: [mem 0x7bce6000-0x7bff7fff]
2026-10-10T11:00:13,517947+00:00 PM: hibernation: Registered nosave memory: [mem 0x7c000000-0xffffffff]
2026-10-10T11:00:13,517957+00:00 [gap 0x80000000-0xdfffffff] available for PCI devices
2026-10-10T11:00:13,517959+00:00 Booting paravirtualized kernel on KVM
2026-10-10T11:00:13,517961+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2026-10-10T11:00:13,517993+00:00 Zone ranges:
2026-10-10T11:00:13,517994+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2026-10-10T11:00:13,517996+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2026-10-10T11:00:13,517997+00:00   Normal   [mem 0x0000000100000000-0x00000002ffffffff]
2026-10-10T11:00:13,517999+00:00   Device   empty
2026-10-10T11:00:13,518000+00:00 Movable zone start for each node
2026-10-10T11:00:13,518002+00:00 Early memory node ranges
2026-10-10T11:00:13,518002+00:00   node   0: [mem 0x0000000000001000-0x000000000002ffff]
2026-10-10T11:00:13,518003+00:00   node   0: [mem 0x0000000000050000-0x000000000009efff]
2026-10-10T11:00:13,518004+00:00   node   0: [mem 0x0000000000100000-0x0000000000811fff]
2026-10-10T11:00:13,518005+00:00   node   0: [mem 0x0000000000813000-0x000000007a1c3fff]
2026-10-10T11:00:13,518006+00:00   node   0: [mem 0x000000007a1c7000-0x000000007bce5fff]
2026-10-10T11:00:13,518007+00:00   node   0: [mem 0x000000007bff8000-0x000000007bffffff]
2026-10-10T11:00:13,518008+00:00   node   0: [mem 0x0000000100000000-0x00000002ffffffff]
2026-10-10T11:00:13,518010+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x00000002ffffffff]
2026-10-10T11:00:13,518203+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2026-10-10T11:00:13,518207+00:00 On node 0, zone DMA: 32 pages in unavailable ranges
2026-10-10T11:00:13,518216+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2026-10-10T11:00:13,518224+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2026-10-10T11:00:13,523308+00:00 On node 0, zone DMA32: 3 pages in unavailable ranges
2026-10-10T11:00:13,523315+00:00 On node 0, zone DMA32: 786 pages in unavailable ranges
2026-10-10T11:00:13,544626+00:00 On node 0, zone Normal: 16384 pages in unavailable ranges
2026-10-10T11:00:13,544645+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:2 nr_cpu_ids:2 nr_node_ids:1
2026-10-10T11:00:13,545047+00:00 percpu: Embedded 85 pages/cpu s225280 r8192 d114688 u1048576
2026-10-10T11:00:13,545055+00:00 pcpu-alloc: s225280 r8192 d114688 u1048576 alloc=1*2097152
2026-10-10T11:00:13,545058+00:00 pcpu-alloc: [0] 0 1 
2026-10-10T11:00:13,545102+00:00 kvm-guest: PV spinlocks enabled
2026-10-10T11:00:13,545106+00:00 PV qspinlock hash table entries: 256 (order: 0, 4096 bytes, linear)
2026-10-10T11:00:13,545109+00:00 Kernel command line: BOOT_IMAGE=/vmlinuz-7.0.0-38-generic root=UUID=747687d9-c20c-41f8-bfb8-7f4a57910c51 ro console=tty1 console=ttyS0
2026-10-10T11:00:13,545165+00:00 printk: log buffer data + meta data: 262144 + 1114112 = 1376256 bytes
2026-10-10T11:00:13,547778+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2026-10-10T11:00:13,549123+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2026-10-10T11:00:13,549191+00:00 software IO TLB: area num 2.
2026-10-10T11:00:13,565131+00:00 Fallback order for Node 0: 0 
2026-10-10T11:00:13,565137+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 2604136
2026-10-10T11:00:13,565138+00:00 Policy zone: Normal
2026-10-10T11:00:13,565149+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2026-10-10T11:00:13,587696+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2026-10-10T11:00:13,593563+00:00 ftrace: allocating 63997 entries in 252 pages
2026-10-10T11:00:13,593566+00:00 ftrace: allocated 252 pages with 6 groups
2026-10-10T11:00:13,594253+00:00 Dynamic Preempt: lazy
2026-10-10T11:00:13,594492+00:00 rcu: Preemptible hierarchical RCU implementation.
2026-10-10T11:00:13,594494+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=2.
2026-10-10T11:00:13,594496+00:00 	Trampoline variant of Tasks RCU enabled.
2026-10-10T11:00:13,594497+00:00 	Rude variant of Tasks RCU enabled.
2026-10-10T11:00:13,594497+00:00 	Tracing variant of Tasks RCU enabled.
2026-10-10T11:00:13,594498+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2026-10-10T11:00:13,594499+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2026-10-10T11:00:13,594509+00:00 RCU Tasks: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1 rcu_task_cpu_ids=2.
2026-10-10T11:00:13,594511+00:00 RCU Tasks Rude: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1 rcu_task_cpu_ids=2.
2026-10-10T11:00:13,600316+00:00 NR_IRQS: 524544, nr_irqs: 440, preallocated irqs: 16
2026-10-10T11:00:13,600539+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2026-10-10T11:00:13,600548+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2026-10-10T11:00:13,600641+00:00 Console: colour dummy device 80x25
2026-10-10T11:00:13,600645+00:00 printk: legacy console [tty1] enabled
2026-10-10T11:00:13,600990+00:00 printk: console [ttyS0] enabled
2026-10-10T11:00:13,811374+00:00 ACPI: Core revision 20251212
2026-10-10T11:00:13,812288+00:00 APIC: Switch to symmetric I/O mode setup
2026-10-10T11:00:13,813535+00:00 x2apic enabled
2026-10-10T11:00:13,814405+00:00 APIC: Switched APIC routing to: physical x2apic
2026-10-10T11:00:13,815549+00:00 kvm-guest: APIC: send_IPI_mask() replaced with kvm_send_ipi_mask()
2026-10-10T11:00:13,817043+00:00 kvm-guest: APIC: send_IPI_mask_allbutself() replaced with kvm_send_ipi_mask_allbutself()
2026-10-10T11:00:13,818894+00:00 kvm-guest: setup PV IPIs
2026-10-10T11:00:13,820603+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0xb9fb05486c, max_idle_ns: 440795231721 ns
2026-10-10T11:00:13,822717+00:00 Calibrating delay loop (skipped) preset value.. 1612.80 BogoMIPS (lpj=806400)
2026-10-10T11:00:13,823712+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2026-10-10T11:00:13,823712+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2026-10-10T11:00:13,823712+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2026-10-10T11:00:13,823712+00:00 mitigations: Enabled attack vectors: user_kernel, user_user, guest_host, guest_guest, SMT mitigations: auto
2026-10-10T11:00:13,823712+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl
2026-10-10T11:00:13,823712+00:00 Spectre V2 : Mitigation: Enhanced / Automatic IBRS
2026-10-10T11:00:13,823712+00:00 Register File Data Sampling: Mitigation: Clear Register File
2026-10-10T11:00:13,823712+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2026-10-10T11:00:13,823712+00:00 Spectre V2 : Enabling IBPB for BPF
2026-10-10T11:00:13,823712+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2026-10-10T11:00:13,823712+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2026-10-10T11:00:13,823712+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2026-10-10T11:00:13,823712+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2026-10-10T11:00:13,823712+00:00 x86/fpu: Supporting XSAVE feature 0x200: 'Protection Keys User registers'
2026-10-10T11:00:13,823712+00:00 x86/fpu: Supporting XSAVE feature 0x800: 'Control-flow User registers'
2026-10-10T11:00:13,823712+00:00 x86/fpu: Supporting XSAVE feature 0x1000: 'Control-flow Kernel registers (KVM only)'
2026-10-10T11:00:13,823712+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2026-10-10T11:00:13,823712+00:00 x86/fpu: xstate_offset[9]:  832, xstate_sizes[9]:    8
2026-10-10T11:00:13,823712+00:00 x86/fpu: xstate_offset[11]:  840, xstate_sizes[11]:   16
2026-10-10T11:00:13,823712+00:00 x86/fpu: xstate_offset[12]:  856, xstate_sizes[12]:   24
2026-10-10T11:00:13,823712+00:00 x86/fpu: Enabled xstate features 0x1a07, context size is 880 bytes, using 'compacted' format.
2026-10-10T11:00:13,823712+00:00 Freeing SMP alternatives memory: 56K
2026-10-10T11:00:13,823712+00:00 pid_max: default: 32768 minimum: 301
2026-10-10T11:00:13,823712+00:00 landlock: Up and running.
2026-10-10T11:00:13,823712+00:00 Yama: becoming mindful.
2026-10-10T11:00:13,823712+00:00 AppArmor: AppArmor initialized
2026-10-10T11:00:13,823712+00:00 AppArmor: AppArmor secmark mediation reserved: ready to be enabled
2026-10-10T11:00:13,823712+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:13,823712+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:13,823712+00:00 VFS: Finished mounting rootfs on nullfs
2026-10-10T11:00:13,823712+00:00 smpboot: CPU0: Intel(R) N100 (family: 0x6, model: 0xbe, stepping: 0x0)
2026-10-10T11:00:13,824001+00:00 Performance Events: Gracemont events, full-width counters, Intel PMU driver.
2026-10-10T11:00:13,824730+00:00 ... version:                   2
2026-10-10T11:00:13,825662+00:00 ... bit width:                 48
2026-10-10T11:00:13,825734+00:00 ... generic counters:          6
2026-10-10T11:00:13,826661+00:00 ... generic bitmap:            000000000000003f
2026-10-10T11:00:13,826723+00:00 ... fixed-purpose counters:    3
2026-10-10T11:00:13,827659+00:00 ... fixed-purpose bitmap:      0000000000000007
2026-10-10T11:00:13,827724+00:00 ... value mask:                0000ffffffffffff
2026-10-10T11:00:13,828723+00:00 ... max period:                00007fffffffffff
2026-10-10T11:00:13,829723+00:00 ... global_ctrl mask:          000000070000003f
2026-10-10T11:00:13,830955+00:00 signal: max sigframe size: 3632
2026-10-10T11:00:13,831816+00:00 rcu: Hierarchical SRCU implementation.
2026-10-10T11:00:13,831820+00:00 rcu: 	Max phase no-delay instances is 400.
2026-10-10T11:00:13,833820+00:00 Timer migration: 1 hierarchy levels; 8 children per group; 1 crossnode level
2026-10-10T11:00:13,835398+00:00 smp: Bringing up secondary CPUs ...
2026-10-10T11:00:13,835910+00:00 smpboot: x86: Booting SMP configuration:
2026-10-10T11:00:13,835919+00:00 .... node  #0, CPUs:      #1
2026-10-10T11:00:13,836772+00:00 smp: Brought up 1 node, 2 CPUs
2026-10-10T11:00:13,836772+00:00 smpboot: Total of 2 processors activated (3225.60 BogoMIPS)
2026-10-10T11:00:13,838814+00:00 Memory: 8747632K/10416544K available (23836K kernel code, 4957K rwdata, 16776K rodata, 5304K init, 5840K bss, 1660496K reserved, 0K cma-reserved)
2026-10-10T11:00:13,839815+00:00 devtmpfs: initialized
2026-10-10T11:00:13,839815+00:00 x86/mm: Memory block size: 128MB
2026-10-10T11:00:13,842036+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x7bf78000-0x7bff7fff] (524288 bytes)
2026-10-10T11:00:13,842036+00:00 posixtimers hash table entries: 1024 (order: 2, 16384 bytes, linear)
2026-10-10T11:00:13,842036+00:00 futex hash table entries: 512 (32768 bytes on 1 NUMA nodes, total 32 KiB, linear).
2026-10-10T11:00:13,842429+00:00 PM: RTC time: 11:00:13, date: 2026-10-10
2026-10-10T11:00:13,843094+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2026-10-10T11:00:13,843593+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2026-10-10T11:00:13,843712+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2026-10-10T11:00:13,843712+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2026-10-10T11:00:13,843712+00:00 audit: initializing netlink subsys (disabled)
2026-10-10T11:00:13,843991+00:00 thermal_sys: Registered thermal governor 'fair_share'
2026-10-10T11:00:13,843994+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2026-10-10T11:00:13,843998+00:00 thermal_sys: Registered thermal governor 'step_wise'
2026-10-10T11:00:13,844000+00:00 thermal_sys: Registered thermal governor 'user_space'
2026-10-10T11:00:13,844002+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2026-10-10T11:00:13,844023+00:00 audit: type=2000 audit(1791630014.199:1): state=initialized audit_enabled=0 res=1
2026-10-10T11:00:13,845726+00:00 cpuidle: using governor ladder
2026-10-10T11:00:13,846725+00:00 cpuidle: using governor menu
2026-10-10T11:00:13,849617+00:00 efi: Freeing EFI boot services memory: 48376K
2026-10-10T11:00:13,849630+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2026-10-10T11:00:13,849630+00:00 PCI: ECAM [mem 0xe0000000-0xefffffff] (base 0xe0000000) for domain 0000 [bus 00-ff]
2026-10-10T11:00:13,849647+00:00 PCI: Using configuration type 1 for base access
2026-10-10T11:00:13,850792+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2026-10-10T11:00:13,854938+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2026-10-10T11:00:13,854946+00:00 HugeTLB: 16380 KiB vmemmap can be freed for a 1.00 GiB page
2026-10-10T11:00:13,854950+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2026-10-10T11:00:13,854952+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2026-10-10T11:00:13,870326+00:00 fbcon: Taking over console
2026-10-10T11:00:13,870364+00:00 ACPI: Added _OSI(Module Device)
2026-10-10T11:00:13,870368+00:00 ACPI: Added _OSI(Processor Device)
2026-10-10T11:00:13,870371+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2026-10-10T11:00:13,877617+00:00 ACPI: 2 ACPI AML tables successfully acquired and loaded
2026-10-10T11:00:13,879735+00:00 ACPI: \_SB_: platform _OSC: OS support mask [006e7eff]
2026-10-10T11:00:13,880058+00:00 ACPI: Interpreter enabled
2026-10-10T11:00:13,880072+00:00 ACPI: PM: (supports S0 S5)
2026-10-10T11:00:13,880075+00:00 ACPI: Using IOAPIC for interrupt routing
2026-10-10T11:00:13,880556+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2026-10-10T11:00:13,880563+00:00 PCI: Ignoring E820 reservations for host bridge windows
2026-10-10T11:00:13,880869+00:00 ACPI: Enabled 3 GPEs in block 00 to 3F
2026-10-10T11:00:13,887853+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2026-10-10T11:00:13,887874+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI EDR HPX-Type3]
2026-10-10T11:00:13,887931+00:00 acpi PNP0A08:00: _OSC: platform does not support [PCIeHotplug LTR DPC]
2026-10-10T11:00:13,888003+00:00 acpi PNP0A08:00: _OSC: OS now controls [SHPCHotplug PME AER PCIeCapability]
2026-10-10T11:00:13,889377+00:00 PCI host bridge to bus 0000:00
2026-10-10T11:00:13,889388+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2026-10-10T11:00:13,889392+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2026-10-10T11:00:13,889396+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:13,889399+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:13,889402+00:00 pci_bus 0000:00: root bus resource [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:13,889405+00:00 pci_bus 0000:00: root bus resource [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:13,889409+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2026-10-10T11:00:13,889628+00:00 pci 0000:00:00.0: [8086:29c0] type 00 class 0x060000 conventional PCI endpoint
2026-10-10T11:00:13,889911+00:00 pci 0000:00:01.0: [1234:1111] type 00 class 0x030000 conventional PCI endpoint
2026-10-10T11:00:13,890712+00:00 pci 0000:00:01.0: BAR 0 [mem 0x80000000-0x80ffffff pref]
2026-10-10T11:00:13,890712+00:00 pci 0000:00:01.0: BAR 2 [mem 0x8224b000-0x8224bfff]
2026-10-10T11:00:13,890712+00:00 pci 0000:00:01.0: ROM [mem 0xffff0000-0xffffffff pref]
2026-10-10T11:00:13,890720+00:00 pci 0000:00:01.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2026-10-10T11:00:13,897852+00:00 pci 0000:00:1a.0: [8086:2937] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:13,899002+00:00 pci 0000:00:1a.0: BAR 4 [io  0x8100-0x811f]
2026-10-10T11:00:13,899589+00:00 pci 0000:00:1a.1: [8086:2938] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:13,900712+00:00 pci 0000:00:1a.1: BAR 4 [io  0x80e0-0x80ff]
2026-10-10T11:00:13,900712+00:00 pci 0000:00:1a.2: [8086:2939] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:13,900712+00:00 pci 0000:00:1a.2: BAR 4 [io  0x80c0-0x80df]
2026-10-10T11:00:13,900769+00:00 pci 0000:00:1a.7: [8086:293c] type 00 class 0x0c0320 conventional PCI endpoint
2026-10-10T11:00:13,901712+00:00 pci 0000:00:1a.7: BAR 0 [mem 0x8224a000-0x8224afff]
2026-10-10T11:00:13,901712+00:00 pci 0000:00:1b.0: [8086:293e] type 00 class 0x040300 conventional PCI endpoint
2026-10-10T11:00:13,901712+00:00 pci 0000:00:1b.0: BAR 0 [mem 0x82240000-0x82243fff]
2026-10-10T11:00:13,903712+00:00 pci 0000:00:1c.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:13,904712+00:00 pci 0000:00:1c.0: BAR 0 [mem 0x82249000-0x82249fff]
2026-10-10T11:00:13,904712+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:13,904712+00:00 pci 0000:00:1c.0:   bridge window [mem 0x82000000-0x821fffff]
2026-10-10T11:00:13,904712+00:00 pci 0000:00:1c.0:   bridge window [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:13,904712+00:00 pci 0000:00:1c.0: enabling Extended Tags
2026-10-10T11:00:13,906163+00:00 pci 0000:00:1c.1: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:13,906712+00:00 pci 0000:00:1c.1: BAR 0 [mem 0x82248000-0x82248fff]
2026-10-10T11:00:13,906712+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:13,906712+00:00 pci 0000:00:1c.1:   bridge window [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:13,906712+00:00 pci 0000:00:1c.1:   bridge window [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:13,906712+00:00 pci 0000:00:1c.1: enabling Extended Tags
2026-10-10T11:00:13,907712+00:00 pci 0000:00:1c.2: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:13,908712+00:00 pci 0000:00:1c.2: BAR 0 [mem 0x82247000-0x82247fff]
2026-10-10T11:00:13,908712+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:13,908712+00:00 pci 0000:00:1c.2:   bridge window [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:13,908803+00:00 pci 0000:00:1c.2:   bridge window [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:13,909085+00:00 pci 0000:00:1c.2: enabling Extended Tags
2026-10-10T11:00:13,909712+00:00 pci 0000:00:1c.3: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:13,910761+00:00 pci 0000:00:1c.3: BAR 0 [mem 0x82246000-0x82246fff]
2026-10-10T11:00:13,910832+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:13,910926+00:00 pci 0000:00:1c.3:   bridge window [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:13,911712+00:00 pci 0000:00:1c.3:   bridge window [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:13,911712+00:00 pci 0000:00:1c.3: enabling Extended Tags
2026-10-10T11:00:13,912712+00:00 pci 0000:00:1d.0: [8086:2934] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:13,912712+00:00 pci 0000:00:1d.0: BAR 4 [io  0x80a0-0x80bf]
2026-10-10T11:00:13,914131+00:00 pci 0000:00:1d.1: [8086:2935] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:13,914712+00:00 pci 0000:00:1d.1: BAR 4 [io  0x8080-0x809f]
2026-10-10T11:00:13,914712+00:00 pci 0000:00:1d.2: [8086:2936] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:13,915712+00:00 pci 0000:00:1d.2: BAR 4 [io  0x8060-0x807f]
2026-10-10T11:00:13,915712+00:00 pci 0000:00:1d.7: [8086:293a] type 00 class 0x0c0320 conventional PCI endpoint
2026-10-10T11:00:13,916712+00:00 pci 0000:00:1d.7: BAR 0 [mem 0x82245000-0x82245fff]
2026-10-10T11:00:13,917235+00:00 pci 0000:00:1e.0: [8086:244e] type 01 class 0x060401 conventional PCI bridge
2026-10-10T11:00:13,917810+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09] (subtractive decode)
2026-10-10T11:00:13,917882+00:00 pci 0000:00:1e.0:   bridge window [io  0x6000-0x7fff]
2026-10-10T11:00:13,917931+00:00 pci 0000:00:1e.0:   bridge window [mem 0x81000000-0x818fffff]
2026-10-10T11:00:13,918712+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:13,919070+00:00 pci 0000:00:1f.0: [8086:2918] type 00 class 0x060100 conventional PCI endpoint
2026-10-10T11:00:13,919712+00:00 pci 0000:00:1f.0: quirk: [io  0x0600-0x067f] claimed by ICH6 ACPI/GPIO/TCO
2026-10-10T11:00:13,919712+00:00 pci 0000:00:1f.2: [8086:2922] type 00 class 0x010601 conventional PCI endpoint
2026-10-10T11:00:13,920849+00:00 pci 0000:00:1f.2: BAR 4 [io  0x8040-0x805f]
2026-10-10T11:00:13,920878+00:00 pci 0000:00:1f.2: BAR 5 [mem 0x82244000-0x82244fff]
2026-10-10T11:00:13,921712+00:00 pci 0000:00:1f.3: [8086:2930] type 00 class 0x0c0500 conventional PCI endpoint
2026-10-10T11:00:13,921827+00:00 pci 0000:00:1f.3: BAR 4 [io  0x8000-0x803f]
2026-10-10T11:00:13,922712+00:00 acpiphp: Slot [0] registered
2026-10-10T11:00:13,922712+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:13,923712+00:00 acpiphp: Slot [0-2] registered
2026-10-10T11:00:13,923712+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:13,925115+00:00 acpiphp: Slot [0-3] registered
2026-10-10T11:00:13,925598+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:13,925712+00:00 acpiphp: Slot [0-4] registered
2026-10-10T11:00:13,925712+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:13,926650+00:00 pci_bus 0000:05: extended config space not accessible
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [0-5] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [5] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [6] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [7] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [8] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [9] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [10] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [11] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [12] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [13] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [14] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [15] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [16] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [17] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [18] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [19] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [20] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [21] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [22] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [23] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [24] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [25] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [26] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [27] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [28] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [29] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [30] registered
2026-10-10T11:00:13,926712+00:00 acpiphp: Slot [31] registered
2026-10-10T11:00:13,927722+00:00 pci 0000:05:01.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:13,928712+00:00 pci 0000:05:01.0: BAR 0 [mem 0x81800000-0x818000ff 64bit]
2026-10-10T11:00:13,928712+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:13,928712+00:00 pci 0000:05:01.0:   bridge window [io  0x7000-0x7fff]
2026-10-10T11:00:13,928712+00:00 pci 0000:05:01.0:   bridge window [mem 0x81600000-0x817fffff]
2026-10-10T11:00:13,929603+00:00 pci 0000:05:01.0:   bridge window [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:13,929663+00:00 pci 0000:05:02.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:13,931712+00:00 pci 0000:05:02.0: BAR 0 [mem 0x81801000-0x818010ff 64bit]
2026-10-10T11:00:13,931712+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:13,931712+00:00 pci 0000:05:02.0:   bridge window [mem 0x81400000-0x815fffff]
2026-10-10T11:00:13,931712+00:00 pci 0000:05:02.0:   bridge window [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:13,931712+00:00 pci 0000:05:03.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:13,932712+00:00 pci 0000:05:03.0: BAR 0 [mem 0x81802000-0x818020ff 64bit]
2026-10-10T11:00:13,932712+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:13,932712+00:00 pci 0000:05:03.0:   bridge window [mem 0x81200000-0x813fffff]
2026-10-10T11:00:13,933521+00:00 pci 0000:05:03.0:   bridge window [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:13,933712+00:00 pci 0000:05:04.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:13,933761+00:00 pci 0000:05:04.0: BAR 0 [mem 0x81803000-0x818030ff 64bit]
2026-10-10T11:00:13,933816+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:13,934161+00:00 pci 0000:05:04.0:   bridge window [io  0x6000-0x6fff]
2026-10-10T11:00:13,934217+00:00 pci 0000:05:04.0:   bridge window [mem 0x81000000-0x811fffff]
2026-10-10T11:00:13,934712+00:00 pci 0000:05:04.0:   bridge window [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:13,946442+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09] (subtractive decode)
2026-10-10T11:00:13,946626+00:00 pci 0000:00:1e.0:   bridge window [io  0x0000-0x0cf7 window] (subtractive decode)
2026-10-10T11:00:13,946634+00:00 pci 0000:00:1e.0:   bridge window [io  0x0d00-0xffff window] (subtractive decode)
2026-10-10T11:00:13,946638+00:00 pci 0000:00:1e.0:   bridge window [mem 0x000a0000-0x000bffff window] (subtractive decode)
2026-10-10T11:00:13,946641+00:00 pci 0000:00:1e.0:   bridge window [mem 0x80000000-0xdfffffff window] (subtractive decode)
2026-10-10T11:00:13,946645+00:00 pci 0000:00:1e.0:   bridge window [mem 0xf0000000-0xfebfffff window] (subtractive decode)
2026-10-10T11:00:13,946648+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7000000000-0x77ffffffff window] (subtractive decode)
2026-10-10T11:00:13,946712+00:00 pci_bus 0000:06: extended config space not accessible
2026-10-10T11:00:13,946952+00:00 acpiphp: Slot [8-2] registered
2026-10-10T11:00:13,946999+00:00 acpiphp: Slot [18-2] registered
2026-10-10T11:00:13,947049+00:00 acpiphp: Slot [0-6] registered
2026-10-10T11:00:13,947192+00:00 acpiphp: Slot [1] registered
2026-10-10T11:00:13,947237+00:00 acpiphp: Slot [2] registered
2026-10-10T11:00:13,947272+00:00 acpiphp: Slot [3] registered
2026-10-10T11:00:13,947306+00:00 acpiphp: Slot [4] registered
2026-10-10T11:00:13,947359+00:00 acpiphp: Slot [5-2] registered
2026-10-10T11:00:13,947429+00:00 acpiphp: Slot [6-2] registered
2026-10-10T11:00:13,947472+00:00 acpiphp: Slot [7-2] registered
2026-10-10T11:00:13,947510+00:00 acpiphp: Slot [9-2] registered
2026-10-10T11:00:13,947547+00:00 acpiphp: Slot [10-2] registered
2026-10-10T11:00:13,947585+00:00 acpiphp: Slot [11-2] registered
2026-10-10T11:00:13,947636+00:00 acpiphp: Slot [12-2] registered
2026-10-10T11:00:13,947676+00:00 acpiphp: Slot [13-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [14-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [15-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [16-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [17-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [19-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [20-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [21-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [22-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [23-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [24-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [25-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [26-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [27-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [28-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [29-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [30-2] registered
2026-10-10T11:00:13,947712+00:00 acpiphp: Slot [31-2] registered
2026-10-10T11:00:13,952764+00:00 pci 0000:06:08.0: [1af4:1003] type 00 class 0x078000 conventional PCI endpoint
2026-10-10T11:00:13,953766+00:00 pci 0000:06:08.0: BAR 0 [io  0x7040-0x707f]
2026-10-10T11:00:13,953799+00:00 pci 0000:06:08.0: BAR 1 [mem 0x81601000-0x81601fff]
2026-10-10T11:00:13,953879+00:00 pci 0000:06:08.0: BAR 4 [mem 0x7070004000-0x7070007fff 64bit pref]
2026-10-10T11:00:13,959712+00:00 pci 0000:06:12.0: [1af4:1000] type 00 class 0x020000 conventional PCI endpoint
2026-10-10T11:00:13,962550+00:00 pci 0000:06:12.0: BAR 0 [io  0x7000-0x703f]
2026-10-10T11:00:13,962580+00:00 pci 0000:06:12.0: BAR 1 [mem 0x81600000-0x81600fff]
2026-10-10T11:00:13,962647+00:00 pci 0000:06:12.0: BAR 4 [mem 0x7070000000-0x7070003fff 64bit pref]
2026-10-10T11:00:13,962670+00:00 pci 0000:06:12.0: ROM [mem 0xfffc0000-0xffffffff pref]
2026-10-10T11:00:13,967460+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:13,967460+00:00 pci_bus 0000:07: extended config space not accessible
2026-10-10T11:00:13,967460+00:00 acpiphp: Slot [0-7] registered
2026-10-10T11:00:13,967460+00:00 acpiphp: Slot [1-2] registered
2026-10-10T11:00:13,967460+00:00 acpiphp: Slot [2-2] registered
2026-10-10T11:00:13,967460+00:00 acpiphp: Slot [3-2] registered
2026-10-10T11:00:13,967483+00:00 acpiphp: Slot [4-2] registered
2026-10-10T11:00:13,967521+00:00 acpiphp: Slot [5-3] registered
2026-10-10T11:00:13,967571+00:00 acpiphp: Slot [6-3] registered
2026-10-10T11:00:13,967611+00:00 acpiphp: Slot [7-3] registered
2026-10-10T11:00:13,967649+00:00 acpiphp: Slot [8-3] registered
2026-10-10T11:00:13,967697+00:00 acpiphp: Slot [9-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [10-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [11-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [12-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [13-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [14-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [15-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [16-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [17-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [18-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [19-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [20-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [21-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [22-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [23-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [24-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [25-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [26-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [27-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [28-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [29-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [30-3] registered
2026-10-10T11:00:13,967712+00:00 acpiphp: Slot [31-3] registered
2026-10-10T11:00:13,976832+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:13,977712+00:00 pci_bus 0000:08: extended config space not accessible
2026-10-10T11:00:13,977867+00:00 acpiphp: Slot [0-8] registered
2026-10-10T11:00:13,977911+00:00 acpiphp: Slot [1-3] registered
2026-10-10T11:00:13,977962+00:00 acpiphp: Slot [2-3] registered
2026-10-10T11:00:13,978014+00:00 acpiphp: Slot [3-3] registered
2026-10-10T11:00:13,978059+00:00 acpiphp: Slot [4-3] registered
2026-10-10T11:00:13,978112+00:00 acpiphp: Slot [5-4] registered
2026-10-10T11:00:13,978161+00:00 acpiphp: Slot [6-4] registered
2026-10-10T11:00:13,978212+00:00 acpiphp: Slot [7-4] registered
2026-10-10T11:00:13,978252+00:00 acpiphp: Slot [8-4] registered
2026-10-10T11:00:13,978298+00:00 acpiphp: Slot [9-4] registered
2026-10-10T11:00:13,978338+00:00 acpiphp: Slot [10-4] registered
2026-10-10T11:00:13,978377+00:00 acpiphp: Slot [11-4] registered
2026-10-10T11:00:13,978441+00:00 acpiphp: Slot [12-4] registered
2026-10-10T11:00:13,978490+00:00 acpiphp: Slot [13-4] registered
2026-10-10T11:00:13,978539+00:00 acpiphp: Slot [14-4] registered
2026-10-10T11:00:13,978578+00:00 acpiphp: Slot [15-4] registered
2026-10-10T11:00:13,978621+00:00 acpiphp: Slot [16-4] registered
2026-10-10T11:00:13,978660+00:00 acpiphp: Slot [17-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [18-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [19-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [20-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [21-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [22-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [23-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [24-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [25-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [26-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [27-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [28-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [29-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [30-4] registered
2026-10-10T11:00:13,978712+00:00 acpiphp: Slot [31-4] registered
2026-10-10T11:00:13,987196+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:13,987935+00:00 pci_bus 0000:09: extended config space not accessible
2026-10-10T11:00:13,988254+00:00 acpiphp: Slot [1-4] registered
2026-10-10T11:00:13,988305+00:00 acpiphp: Slot [0-9] registered
2026-10-10T11:00:13,988346+00:00 acpiphp: Slot [2-4] registered
2026-10-10T11:00:13,988386+00:00 acpiphp: Slot [3-4] registered
2026-10-10T11:00:13,988427+00:00 acpiphp: Slot [4-4] registered
2026-10-10T11:00:13,988469+00:00 acpiphp: Slot [5-5] registered
2026-10-10T11:00:13,988506+00:00 acpiphp: Slot [6-5] registered
2026-10-10T11:00:13,988544+00:00 acpiphp: Slot [7-5] registered
2026-10-10T11:00:13,988581+00:00 acpiphp: Slot [8-5] registered
2026-10-10T11:00:13,988618+00:00 acpiphp: Slot [9-5] registered
2026-10-10T11:00:13,988658+00:00 acpiphp: Slot [10-5] registered
2026-10-10T11:00:13,988696+00:00 acpiphp: Slot [11-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [12-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [13-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [14-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [15-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [16-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [17-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [18-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [19-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [20-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [21-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [22-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [23-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [24-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [25-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [26-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [27-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [28-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [29-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [30-5] registered
2026-10-10T11:00:13,988712+00:00 acpiphp: Slot [31-5] registered
2026-10-10T11:00:13,988712+00:00 pci 0000:09:01.0: [1af4:1004] type 00 class 0x010000 conventional PCI endpoint
2026-10-10T11:00:13,988745+00:00 pci 0000:09:01.0: BAR 0 [io  0x6000-0x603f]
2026-10-10T11:00:13,988774+00:00 pci 0000:09:01.0: BAR 1 [mem 0x81000000-0x81000fff]
2026-10-10T11:00:13,988861+00:00 pci 0000:09:01.0: BAR 4 [mem 0x7040000000-0x7040003fff 64bit pref]
2026-10-10T11:00:13,998497+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:14,008231+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2026-10-10T11:00:14,008433+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2026-10-10T11:00:14,008620+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 10
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 10
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 11
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 11
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIA configured for IRQ 16
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIB configured for IRQ 17
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIC configured for IRQ 18
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSID configured for IRQ 19
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIE configured for IRQ 20
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIF configured for IRQ 21
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIG configured for IRQ 22
2026-10-10T11:00:14,008712+00:00 ACPI: PCI: Interrupt link GSIH configured for IRQ 23
2026-10-10T11:00:14,009091+00:00 iommu: Default domain type: Translated
2026-10-10T11:00:14,009096+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2026-10-10T11:00:14,009934+00:00 SCSI subsystem initialized
2026-10-10T11:00:14,010760+00:00 libata version 3.00 loaded.
2026-10-10T11:00:14,010807+00:00 ACPI: bus type USB registered
2026-10-10T11:00:14,010830+00:00 usbcore: registered new interface driver usbfs
2026-10-10T11:00:14,010838+00:00 usbcore: registered new interface driver hub
2026-10-10T11:00:14,010854+00:00 usbcore: registered new device driver usb
2026-10-10T11:00:14,010879+00:00 pps_core: LinuxPPS API ver. 1 registered
2026-10-10T11:00:14,010881+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2026-10-10T11:00:14,010886+00:00 PTP clock support registered
2026-10-10T11:00:14,011038+00:00 EDAC MC: Ver: 3.0.0
2026-10-10T11:00:14,012103+00:00 efivars: Registered efivars operations
2026-10-10T11:00:14,013712+00:00 NetLabel: Initializing
2026-10-10T11:00:14,013712+00:00 NetLabel:  domain hash size = 128
2026-10-10T11:00:14,013712+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2026-10-10T11:00:14,013712+00:00 NetLabel:  unlabeled traffic allowed by default
2026-10-10T11:00:14,013712+00:00 mctp: management component transport protocol core
2026-10-10T11:00:14,013712+00:00 NET: Registered PF_MCTP protocol family
2026-10-10T11:00:14,013712+00:00 PCI: Using ACPI for IRQ routing
2026-10-10T11:00:14,213879+00:00 PCI: pci_cache_line_size set to 64 bytes
2026-10-10T11:00:14,214714+00:00 e820: register RAM buffer resource [mem 0x0009f000-0x0009ffff]
2026-10-10T11:00:14,214727+00:00 e820: register RAM buffer resource [mem 0x00812000-0x008fffff]
2026-10-10T11:00:14,214727+00:00 e820: register RAM buffer resource [mem 0x79ccd000-0x7bffffff]
2026-10-10T11:00:14,214727+00:00 e820: register RAM buffer resource [mem 0x7a1c4000-0x7bffffff]
2026-10-10T11:00:14,214727+00:00 e820: register RAM buffer resource [mem 0x7bce6000-0x7bffffff]
2026-10-10T11:00:14,214865+00:00 pci 0000:00:01.0: vgaarb: setting as boot VGA device
2026-10-10T11:00:14,214873+00:00 pci 0000:00:01.0: vgaarb: bridge control possible
2026-10-10T11:00:14,214875+00:00 pci 0000:00:01.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2026-10-10T11:00:14,214884+00:00 vgaarb: loaded
2026-10-10T11:00:14,217727+00:00 clocksource: Switched to clocksource kvm-clock
2026-10-10T11:00:14,217960+00:00 VFS: Disk quotas dquot_6.6.0
2026-10-10T11:00:14,217975+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2026-10-10T11:00:14,222180+00:00 AppArmor: AppArmor Filesystem Enabled
2026-10-10T11:00:14,222217+00:00 acpi PNP0C01:00: Reserved [mem 0xe0000000-0xefffffff]
2026-10-10T11:00:14,222248+00:00 pnp: PnP ACPI init
2026-10-10T11:00:14,222945+00:00 pnp: PnP ACPI: found 4 devices
2026-10-10T11:00:14,229015+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2026-10-10T11:00:14,229114+00:00 NET: Registered PF_INET protocol family
2026-10-10T11:00:14,229460+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2026-10-10T11:00:14,250034+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2026-10-10T11:00:14,250086+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:14,250346+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2026-10-10T11:00:14,250733+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2026-10-10T11:00:14,250884+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2026-10-10T11:00:14,251031+00:00 MPTCP token hash table entries: 16384 (order: 7, 393216 bytes, linear)
2026-10-10T11:00:14,251118+00:00 UDP hash table entries: 8192 (order: 7, 524288 bytes, linear)
2026-10-10T11:00:14,251418+00:00 UDP-Lite hash table entries: 8192 (order: 7, 524288 bytes, linear)
2026-10-10T11:00:14,251542+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2026-10-10T11:00:14,251553+00:00 NET: Registered PF_XDP protocol family
2026-10-10T11:00:14,251563+00:00 pci 0000:06:12.0: ROM [mem 0xfffc0000-0xffffffff pref]: can't claim; no compatible bridge window
2026-10-10T11:00:14,251575+00:00 pci 0000:00:1c.0: bridge window [io  0x1000-0x0fff] to [bus 01] add_size 1000
2026-10-10T11:00:14,251580+00:00 pci 0000:00:1c.1: bridge window [io  0x1000-0x0fff] to [bus 02] add_size 1000
2026-10-10T11:00:14,251584+00:00 pci 0000:00:1c.2: bridge window [io  0x1000-0x0fff] to [bus 03] add_size 1000
2026-10-10T11:00:14,251588+00:00 pci 0000:00:1c.3: bridge window [io  0x1000-0x0fff] to [bus 04] add_size 1000
2026-10-10T11:00:14,251601+00:00 pci 0000:00:1c.0: bridge window [io  0x1000-0x1fff]: assigned
2026-10-10T11:00:14,251605+00:00 pci 0000:00:1c.1: bridge window [io  0x2000-0x2fff]: assigned
2026-10-10T11:00:14,251608+00:00 pci 0000:00:1c.2: bridge window [io  0x3000-0x3fff]: assigned
2026-10-10T11:00:14,251611+00:00 pci 0000:00:1c.3: bridge window [io  0x4000-0x4fff]: assigned
2026-10-10T11:00:14,251616+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:14,251648+00:00 pci 0000:00:1c.0:   bridge window [io  0x1000-0x1fff]
2026-10-10T11:00:14,253684+00:00 pci 0000:00:1c.0:   bridge window [mem 0x82000000-0x821fffff]
2026-10-10T11:00:14,254940+00:00 pci 0000:00:1c.0:   bridge window [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:14,257452+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:14,257512+00:00 pci 0000:00:1c.1:   bridge window [io  0x2000-0x2fff]
2026-10-10T11:00:14,259456+00:00 pci 0000:00:1c.1:   bridge window [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:14,260810+00:00 pci 0000:00:1c.1:   bridge window [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:14,263410+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:14,265408+00:00 pci 0000:00:1c.2:   bridge window [io  0x3000-0x3fff]
2026-10-10T11:00:14,268184+00:00 pci 0000:00:1c.2:   bridge window [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:14,269406+00:00 pci 0000:00:1c.2:   bridge window [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:14,271961+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:14,272026+00:00 pci 0000:00:1c.3:   bridge window [io  0x4000-0x4fff]
2026-10-10T11:00:14,273920+00:00 pci 0000:00:1c.3:   bridge window [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:14,275165+00:00 pci 0000:00:1c.3:   bridge window [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:14,280333+00:00 pci 0000:06:12.0: ROM [mem 0x81640000-0x8167ffff pref]: assigned
2026-10-10T11:00:14,280347+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:14,280376+00:00 pci 0000:05:01.0:   bridge window [io  0x7000-0x7fff]
2026-10-10T11:00:14,282209+00:00 pci 0000:05:01.0:   bridge window [mem 0x81600000-0x817fffff]
2026-10-10T11:00:14,283601+00:00 pci 0000:05:01.0:   bridge window [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:14,286060+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:14,287878+00:00 pci 0000:05:02.0:   bridge window [mem 0x81400000-0x815fffff]
2026-10-10T11:00:14,289153+00:00 pci 0000:05:02.0:   bridge window [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:14,291711+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:14,293963+00:00 pci 0000:05:03.0:   bridge window [mem 0x81200000-0x813fffff]
2026-10-10T11:00:14,294724+00:00 pci 0000:05:03.0:   bridge window [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:14,296269+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:14,296299+00:00 pci 0000:05:04.0:   bridge window [io  0x6000-0x6fff]
2026-10-10T11:00:14,297541+00:00 pci 0000:05:04.0:   bridge window [mem 0x81000000-0x811fffff]
2026-10-10T11:00:14,298423+00:00 pci 0000:05:04.0:   bridge window [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:14,300571+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09]
2026-10-10T11:00:14,300614+00:00 pci 0000:00:1e.0:   bridge window [io  0x6000-0x7fff]
2026-10-10T11:00:14,303371+00:00 pci 0000:00:1e.0:   bridge window [mem 0x81000000-0x818fffff]
2026-10-10T11:00:14,304920+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:14,307979+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2026-10-10T11:00:14,308012+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2026-10-10T11:00:14,308016+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:14,308020+00:00 pci_bus 0000:00: resource 7 [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:14,308023+00:00 pci_bus 0000:00: resource 8 [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:14,308025+00:00 pci_bus 0000:00: resource 9 [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:14,308030+00:00 pci_bus 0000:01: resource 0 [io  0x1000-0x1fff]
2026-10-10T11:00:14,308032+00:00 pci_bus 0000:01: resource 1 [mem 0x82000000-0x821fffff]
2026-10-10T11:00:14,308035+00:00 pci_bus 0000:01: resource 2 [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:14,308039+00:00 pci_bus 0000:02: resource 0 [io  0x2000-0x2fff]
2026-10-10T11:00:14,308041+00:00 pci_bus 0000:02: resource 1 [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:14,308044+00:00 pci_bus 0000:02: resource 2 [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:14,308047+00:00 pci_bus 0000:03: resource 0 [io  0x3000-0x3fff]
2026-10-10T11:00:14,308050+00:00 pci_bus 0000:03: resource 1 [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:14,308052+00:00 pci_bus 0000:03: resource 2 [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:14,308056+00:00 pci_bus 0000:04: resource 0 [io  0x4000-0x4fff]
2026-10-10T11:00:14,308058+00:00 pci_bus 0000:04: resource 1 [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:14,308061+00:00 pci_bus 0000:04: resource 2 [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:14,308065+00:00 pci_bus 0000:05: resource 0 [io  0x6000-0x7fff]
2026-10-10T11:00:14,308067+00:00 pci_bus 0000:05: resource 1 [mem 0x81000000-0x818fffff]
2026-10-10T11:00:14,308070+00:00 pci_bus 0000:05: resource 2 [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:14,308073+00:00 pci_bus 0000:05: resource 4 [io  0x0000-0x0cf7 window]
2026-10-10T11:00:14,308075+00:00 pci_bus 0000:05: resource 5 [io  0x0d00-0xffff window]
2026-10-10T11:00:14,308078+00:00 pci_bus 0000:05: resource 6 [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:14,308081+00:00 pci_bus 0000:05: resource 7 [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:14,308084+00:00 pci_bus 0000:05: resource 8 [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:14,308086+00:00 pci_bus 0000:05: resource 9 [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:14,308090+00:00 pci_bus 0000:06: resource 0 [io  0x7000-0x7fff]
2026-10-10T11:00:14,308092+00:00 pci_bus 0000:06: resource 1 [mem 0x81600000-0x817fffff]
2026-10-10T11:00:14,308095+00:00 pci_bus 0000:06: resource 2 [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:14,308098+00:00 pci_bus 0000:07: resource 1 [mem 0x81400000-0x815fffff]
2026-10-10T11:00:14,308101+00:00 pci_bus 0000:07: resource 2 [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:14,308104+00:00 pci_bus 0000:08: resource 1 [mem 0x81200000-0x813fffff]
2026-10-10T11:00:14,308107+00:00 pci_bus 0000:08: resource 2 [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:14,308110+00:00 pci_bus 0000:09: resource 0 [io  0x6000-0x6fff]
2026-10-10T11:00:14,308113+00:00 pci_bus 0000:09: resource 1 [mem 0x81000000-0x811fffff]
2026-10-10T11:00:14,308115+00:00 pci_bus 0000:09: resource 2 [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:14,308573+00:00 ACPI: \_SB_.GSIA: Enabled at IRQ 16
2026-10-10T11:00:14,309656+00:00 ACPI: \_SB_.GSIB: Enabled at IRQ 17
2026-10-10T11:00:14,310679+00:00 ACPI: \_SB_.GSIC: Enabled at IRQ 18
2026-10-10T11:00:14,311708+00:00 ACPI: \_SB_.GSID: Enabled at IRQ 19
2026-10-10T11:00:14,318268+00:00 PCI: CLS 0 bytes, default 64
2026-10-10T11:00:14,318419+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2026-10-10T11:00:14,318427+00:00 software IO TLB: mapped [mem 0x000000006e52a000-0x000000007252a000] (64MB)
2026-10-10T11:00:14,318486+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0xb9fb05486c, max_idle_ns: 440795231721 ns
2026-10-10T11:00:14,318576+00:00 Trying to unpack rootfs image as initramfs...
2026-10-10T11:00:14,321644+00:00 Initialise system trusted keyrings
2026-10-10T11:00:14,321672+00:00 Key type blacklist registered
2026-10-10T11:00:14,323071+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2026-10-10T11:00:14,323431+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2026-10-10T11:00:14,323563+00:00 fuse: init (API version 7.45)
2026-10-10T11:00:14,343029+00:00 integrity: Platform Keyring initialized
2026-10-10T11:00:14,343041+00:00 integrity: Machine keyring initialized
2026-10-10T11:00:14,364384+00:00 Key type asymmetric registered
2026-10-10T11:00:14,364393+00:00 Asymmetric key parser 'x509' registered
2026-10-10T11:00:14,364431+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 242)
2026-10-10T11:00:14,366017+00:00 io scheduler mq-deadline registered
2026-10-10T11:00:14,372004+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2026-10-10T11:00:14,373964+00:00 pcieport 0000:00:1c.0: PME: Signaling with IRQ 24
2026-10-10T11:00:14,379324+00:00 pcieport 0000:00:1c.0: AER: enabled with IRQ 24
2026-10-10T11:00:14,384163+00:00 pcieport 0000:00:1c.1: PME: Signaling with IRQ 25
2026-10-10T11:00:14,389283+00:00 pcieport 0000:00:1c.1: AER: enabled with IRQ 25
2026-10-10T11:00:14,395028+00:00 pcieport 0000:00:1c.2: PME: Signaling with IRQ 26
2026-10-10T11:00:14,398338+00:00 pcieport 0000:00:1c.2: AER: enabled with IRQ 26
2026-10-10T11:00:14,404222+00:00 pcieport 0000:00:1c.3: PME: Signaling with IRQ 27
2026-10-10T11:00:14,407300+00:00 pcieport 0000:00:1c.3: AER: enabled with IRQ 27
2026-10-10T11:00:14,410281+00:00 shpchp 0000:05:01.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:14,410689+00:00 ACPI: \_SB_.GSIF: Enabled at IRQ 21
2026-10-10T11:00:14,419602+00:00 shpchp 0000:05:01.0: pci_hp_register failed with error -16
2026-10-10T11:00:14,419622+00:00 shpchp 0000:05:01.0: Slot initialization failed
2026-10-10T11:00:14,427667+00:00 shpchp 0000:05:02.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:14,428198+00:00 ACPI: \_SB_.GSIG: Enabled at IRQ 22
2026-10-10T11:00:14,437895+00:00 shpchp 0000:05:02.0: pci_hp_register failed with error -16
2026-10-10T11:00:14,437913+00:00 shpchp 0000:05:02.0: Slot initialization failed
2026-10-10T11:00:14,443856+00:00 shpchp 0000:05:03.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:14,444177+00:00 ACPI: \_SB_.GSIH: Enabled at IRQ 23
2026-10-10T11:00:14,454044+00:00 shpchp 0000:05:03.0: pci_hp_register failed with error -16
2026-10-10T11:00:14,454061+00:00 shpchp 0000:05:03.0: Slot initialization failed
2026-10-10T11:00:14,462006+00:00 shpchp 0000:05:04.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:14,462297+00:00 ACPI: \_SB_.GSIE: Enabled at IRQ 20
2026-10-10T11:00:14,470136+00:00 shpchp 0000:05:04.0: pci_hp_register failed with error -16
2026-10-10T11:00:14,470154+00:00 shpchp 0000:05:04.0: Slot initialization failed
2026-10-10T11:00:14,474347+00:00 input: Power Button as /devices/platform/LNXPWRBN:00/input/input0
2026-10-10T11:00:14,474441+00:00 ACPI: button: Power Button [PWRF]
2026-10-10T11:00:14,491602+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2026-10-10T11:00:14,544392+00:00 00:00: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2026-10-10T11:00:14,571588+00:00 Linux agpgart interface v0.103
2026-10-10T11:00:14,574481+00:00 loop: module loaded
2026-10-10T11:00:14,577133+00:00 virtio_scsi virtio2: 2/0/0 default/read/poll queues
2026-10-10T11:00:14,581227+00:00 scsi host0: Virtio SCSI HBA
2026-10-10T11:00:14,586970+00:00 ACPI: bus type drm_connector registered
2026-10-10T11:00:14,588026+00:00 scsi 0:0:0:0: Direct-Access     QEMU     QEMU HARDDISK    2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:14,590207+00:00 tun: Universal TUN/TAP device driver, 1.6
2026-10-10T11:00:14,596911+00:00 PPP generic driver version 2.4.2
2026-10-10T11:00:14,600450+00:00 uhci_hcd 0000:00:1a.0: UHCI Host Controller
2026-10-10T11:00:14,600471+00:00 uhci_hcd 0000:00:1a.0: new USB bus registered, assigned bus number 1
2026-10-10T11:00:14,600503+00:00 uhci_hcd 0000:00:1a.0: detected 2 ports
2026-10-10T11:00:14,600694+00:00 uhci_hcd 0000:00:1a.0: irq 16, io port 0x00008100
2026-10-10T11:00:14,608511+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:14,608529+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,608534+00:00 usb usb1: Product: UHCI Host Controller
2026-10-10T11:00:14,608537+00:00 usb usb1: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:14,608541+00:00 usb usb1: SerialNumber: 0000:00:1a.0
2026-10-10T11:00:14,610969+00:00 Freeing initrd memory: 42828K
2026-10-10T11:00:14,611160+00:00 hub 1-0:1.0: USB hub found
2026-10-10T11:00:14,611209+00:00 hub 1-0:1.0: 2 ports detected
2026-10-10T11:00:14,612567+00:00 uhci_hcd 0000:00:1a.1: UHCI Host Controller
2026-10-10T11:00:14,612581+00:00 uhci_hcd 0000:00:1a.1: new USB bus registered, assigned bus number 2
2026-10-10T11:00:14,612611+00:00 uhci_hcd 0000:00:1a.1: detected 2 ports
2026-10-10T11:00:14,612827+00:00 uhci_hcd 0000:00:1a.1: irq 17, io port 0x000080e0
2026-10-10T11:00:14,613144+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:14,613151+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,613154+00:00 usb usb2: Product: UHCI Host Controller
2026-10-10T11:00:14,613157+00:00 usb usb2: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:14,613160+00:00 usb usb2: SerialNumber: 0000:00:1a.1
2026-10-10T11:00:14,613309+00:00 hub 2-0:1.0: USB hub found
2026-10-10T11:00:14,613339+00:00 hub 2-0:1.0: 2 ports detected
2026-10-10T11:00:14,621338+00:00 sd 0:0:0:0: Attached scsi generic sg0 type 0
2026-10-10T11:00:14,621348+00:00 sd 0:0:0:0: Power-on or device reset occurred
2026-10-10T11:00:14,621451+00:00 sd 0:0:0:0: [sda] 68157440 512-byte logical blocks: (34.9 GB/32.5 GiB)
2026-10-10T11:00:14,621478+00:00 sd 0:0:0:0: [sda] Write Protect is off
2026-10-10T11:00:14,621482+00:00 sd 0:0:0:0: [sda] Mode Sense: 63 00 10 08
2026-10-10T11:00:14,621522+00:00 sd 0:0:0:0: [sda] Write cache: enabled, read cache: enabled, supports DPO and FUA
2026-10-10T11:00:14,643649+00:00  sda: sda1 sda13 sda14 sda15
2026-10-10T11:00:14,643843+00:00 sd 0:0:0:0: [sda] Attached SCSI disk
2026-10-10T11:00:14,657261+00:00 ehci-pci 0000:00:1a.7: EHCI Host Controller
2026-10-10T11:00:14,657279+00:00 ehci-pci 0000:00:1a.7: new USB bus registered, assigned bus number 3
2026-10-10T11:00:14,657702+00:00 ehci-pci 0000:00:1a.7: irq 19, io mem 0x8224a000
2026-10-10T11:00:14,663048+00:00 ehci-pci 0000:00:1a.7: USB 2.0 started, EHCI 1.00
2026-10-10T11:00:14,663125+00:00 usb usb3: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 7.00
2026-10-10T11:00:14,663132+00:00 usb usb3: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,663136+00:00 usb usb3: Product: EHCI Host Controller
2026-10-10T11:00:14,663139+00:00 usb usb3: Manufacturer: Linux 7.0.0-38-generic ehci_hcd
2026-10-10T11:00:14,663142+00:00 usb usb3: SerialNumber: 0000:00:1a.7
2026-10-10T11:00:14,663236+00:00 hub 3-0:1.0: USB hub found
2026-10-10T11:00:14,663244+00:00 hub 3-0:1.0: 6 ports detected
2026-10-10T11:00:14,684147+00:00 hub 1-0:1.0: USB hub found
2026-10-10T11:00:14,684167+00:00 hub 1-0:1.0: 2 ports detected
2026-10-10T11:00:14,705140+00:00 hub 2-0:1.0: USB hub found
2026-10-10T11:00:14,705157+00:00 hub 2-0:1.0: 2 ports detected
2026-10-10T11:00:14,705251+00:00 ehci-pci 0000:00:1d.7: EHCI Host Controller
2026-10-10T11:00:14,705259+00:00 ehci-pci 0000:00:1d.7: new USB bus registered, assigned bus number 4
2026-10-10T11:00:14,705624+00:00 ehci-pci 0000:00:1d.7: irq 19, io mem 0x82245000
2026-10-10T11:00:14,711059+00:00 ehci-pci 0000:00:1d.7: USB 2.0 started, EHCI 1.00
2026-10-10T11:00:14,711140+00:00 usb usb4: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 7.00
2026-10-10T11:00:14,711147+00:00 usb usb4: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,711150+00:00 usb usb4: Product: EHCI Host Controller
2026-10-10T11:00:14,711153+00:00 usb usb4: Manufacturer: Linux 7.0.0-38-generic ehci_hcd
2026-10-10T11:00:14,711156+00:00 usb usb4: SerialNumber: 0000:00:1d.7
2026-10-10T11:00:14,711265+00:00 hub 4-0:1.0: USB hub found
2026-10-10T11:00:14,711276+00:00 hub 4-0:1.0: 6 ports detected
2026-10-10T11:00:14,711645+00:00 uhci_hcd 0000:00:1a.2: UHCI Host Controller
2026-10-10T11:00:14,711654+00:00 uhci_hcd 0000:00:1a.2: new USB bus registered, assigned bus number 5
2026-10-10T11:00:14,711684+00:00 uhci_hcd 0000:00:1a.2: detected 2 ports
2026-10-10T11:00:14,711884+00:00 uhci_hcd 0000:00:1a.2: irq 18, io port 0x000080c0
2026-10-10T11:00:14,712130+00:00 usb usb5: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:14,712137+00:00 usb usb5: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,712140+00:00 usb usb5: Product: UHCI Host Controller
2026-10-10T11:00:14,712142+00:00 usb usb5: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:14,712145+00:00 usb usb5: SerialNumber: 0000:00:1a.2
2026-10-10T11:00:14,712226+00:00 hub 5-0:1.0: USB hub found
2026-10-10T11:00:14,712234+00:00 hub 5-0:1.0: 2 ports detected
2026-10-10T11:00:14,713439+00:00 uhci_hcd 0000:00:1d.0: UHCI Host Controller
2026-10-10T11:00:14,713449+00:00 uhci_hcd 0000:00:1d.0: new USB bus registered, assigned bus number 6
2026-10-10T11:00:14,713479+00:00 uhci_hcd 0000:00:1d.0: detected 2 ports
2026-10-10T11:00:14,713617+00:00 uhci_hcd 0000:00:1d.0: irq 16, io port 0x000080a0
2026-10-10T11:00:14,713773+00:00 usb usb6: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:14,713779+00:00 usb usb6: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,713782+00:00 usb usb6: Product: UHCI Host Controller
2026-10-10T11:00:14,713784+00:00 usb usb6: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:14,713787+00:00 usb usb6: SerialNumber: 0000:00:1d.0
2026-10-10T11:00:14,713872+00:00 hub 6-0:1.0: USB hub found
2026-10-10T11:00:14,713880+00:00 hub 6-0:1.0: 2 ports detected
2026-10-10T11:00:14,715091+00:00 uhci_hcd 0000:00:1d.1: UHCI Host Controller
2026-10-10T11:00:14,715102+00:00 uhci_hcd 0000:00:1d.1: new USB bus registered, assigned bus number 7
2026-10-10T11:00:14,715132+00:00 uhci_hcd 0000:00:1d.1: detected 2 ports
2026-10-10T11:00:14,715262+00:00 uhci_hcd 0000:00:1d.1: irq 17, io port 0x00008080
2026-10-10T11:00:14,715403+00:00 usb usb7: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:14,715409+00:00 usb usb7: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,715413+00:00 usb usb7: Product: UHCI Host Controller
2026-10-10T11:00:14,715415+00:00 usb usb7: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:14,715418+00:00 usb usb7: SerialNumber: 0000:00:1d.1
2026-10-10T11:00:14,715503+00:00 hub 7-0:1.0: USB hub found
2026-10-10T11:00:14,715511+00:00 hub 7-0:1.0: 2 ports detected
2026-10-10T11:00:14,716638+00:00 uhci_hcd 0000:00:1d.2: UHCI Host Controller
2026-10-10T11:00:14,716650+00:00 uhci_hcd 0000:00:1d.2: new USB bus registered, assigned bus number 8
2026-10-10T11:00:14,716680+00:00 uhci_hcd 0000:00:1d.2: detected 2 ports
2026-10-10T11:00:14,716813+00:00 uhci_hcd 0000:00:1d.2: irq 18, io port 0x00008060
2026-10-10T11:00:14,717365+00:00 usb usb8: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:14,717371+00:00 usb usb8: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:14,717374+00:00 usb usb8: Product: UHCI Host Controller
2026-10-10T11:00:14,717377+00:00 usb usb8: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:14,717379+00:00 usb usb8: SerialNumber: 0000:00:1d.2
2026-10-10T11:00:14,717467+00:00 hub 8-0:1.0: USB hub found
2026-10-10T11:00:14,717475+00:00 hub 8-0:1.0: 2 ports detected
2026-10-10T11:00:14,717727+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2026-10-10T11:00:14,719486+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2026-10-10T11:00:14,719498+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2026-10-10T11:00:14,720086+00:00 mousedev: PS/2 mouse device common for all mice
2026-10-10T11:00:14,720578+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2026-10-10T11:00:14,720704+00:00 rtc_cmos 00:03: RTC can wake from S4
2026-10-10T11:00:14,721902+00:00 rtc_cmos 00:03: registered as rtc0
2026-10-10T11:00:14,722168+00:00 rtc_cmos 00:03: setting system clock to 2026-10-10T11:00:14 UTC (1791630014)
2026-10-10T11:00:14,722275+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram
2026-10-10T11:00:14,722292+00:00 i2c_dev: i2c /dev entries driver
2026-10-10T11:00:14,722317+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2026-10-10T11:00:14,722339+00:00 device-mapper: uevent: version 1.0.3
2026-10-10T11:00:14,722400+00:00 device-mapper: ioctl: 4.50.0-ioctl (2025-04-28) initialised: dm-devel@lists.linux.dev
2026-10-10T11:00:14,722407+00:00 intel_pstate: CPU model not supported
2026-10-10T11:00:14,722621+00:00 simple-framebuffer simple-framebuffer.0: [drm] Registered 1 planes with drm panic
2026-10-10T11:00:14,723434+00:00 [drm] Initialized simpledrm 1.0.0 for simple-framebuffer.0 on minor 0
2026-10-10T11:00:14,727865+00:00 Console: switching to colour frame buffer device 160x50
2026-10-10T11:00:14,728922+00:00 simple-framebuffer simple-framebuffer.0: [drm] fb0: simpledrmdrmfb frame buffer device
2026-10-10T11:00:14,729686+00:00 drop_monitor: Initializing network drop monitor service
2026-10-10T11:00:14,730333+00:00 NET: Registered PF_INET6 protocol family
2026-10-10T11:00:14,730712+00:00 Segment Routing with IPv6
2026-10-10T11:00:14,730732+00:00 In-situ OAM (IOAM) with IPv6
2026-10-10T11:00:14,730769+00:00 NET: Registered PF_PACKET protocol family
2026-10-10T11:00:14,730869+00:00 Key type dns_resolver registered
2026-10-10T11:00:14,732440+00:00 IPI shorthand broadcast: enabled
2026-10-10T11:00:14,734858+00:00 sched_clock: Marking stable (1010004842, 222164738)->(1614314797, -382145217)
2026-10-10T11:00:14,739815+00:00 registered taskstats version 1
2026-10-10T11:00:14,742907+00:00 Loading compiled-in X.509 certificates
2026-10-10T11:00:14,743653+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 6b2b0d62fc3a1216c49fda2b061b13d4dbf474bd'
2026-10-10T11:00:14,744296+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing 2025 Kmod: d541cef61dc7e793b7eb7e899970a2eef0b5dc8c'
2026-10-10T11:00:14,744884+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2026-10-10T11:00:14,745620+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing 2025 Kmod: 4627603d2357a2a3f81006370894c221175893e9'
2026-10-10T11:00:14,746261+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2026-10-10T11:00:14,746277+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2026-10-10T11:00:14,746302+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2026-10-10T11:00:14,746322+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2026-10-10T11:00:14,746343+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2026-10-10T11:00:14,746363+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2026-10-10T11:00:14,746390+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2026-10-10T11:00:14,746415+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2026-10-10T11:00:14,746435+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2026-10-10T11:00:14,746455+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2026-10-10T11:00:14,752922+00:00 Demotion targets for Node 0: null
2026-10-10T11:00:14,753907+00:00 Key type .fscrypt registered
2026-10-10T11:00:14,754697+00:00 Key type fscrypt-provisioning registered
2026-10-10T11:00:14,755585+00:00 Key type big_key registered
2026-10-10T11:00:14,837247+00:00 Key type encrypted registered
2026-10-10T11:00:14,837524+00:00 AppArmor: AppArmor sha256 policy hashing enabled
2026-10-10T11:00:14,837781+00:00 ima: No TPM chip found, activating TPM-bypass!
2026-10-10T11:00:14,838511+00:00 Loading compiled-in module X.509 certificates
2026-10-10T11:00:14,839895+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 6b2b0d62fc3a1216c49fda2b061b13d4dbf474bd'
2026-10-10T11:00:14,840968+00:00 ima: Allocated hash algorithm: sha256
2026-10-10T11:00:14,841260+00:00 ima: No architecture policies found
2026-10-10T11:00:14,841519+00:00 evm: Initialising EVM extended attributes:
2026-10-10T11:00:14,841775+00:00 evm: security.selinux
2026-10-10T11:00:14,842018+00:00 evm: security.SMACK64
2026-10-10T11:00:14,842250+00:00 evm: security.SMACK64EXEC
2026-10-10T11:00:14,842476+00:00 evm: security.SMACK64TRANSMUTE
2026-10-10T11:00:14,842700+00:00 evm: security.SMACK64MMAP
2026-10-10T11:00:14,842933+00:00 evm: security.apparmor
2026-10-10T11:00:14,843163+00:00 evm: security.ima
2026-10-10T11:00:14,843378+00:00 evm: security.capability
2026-10-10T11:00:14,843590+00:00 evm: HMAC attrs: 0x1
2026-10-10T11:00:14,844785+00:00 PM:   Magic number: 14:901:23
2026-10-10T11:00:14,845100+00:00 memory memory63: hash matches
2026-10-10T11:00:14,846111+00:00 RAS: Correctable Errors collector initialized.
2026-10-10T11:00:14,846566+00:00 clk: Disabling unused clocks
2026-10-10T11:00:14,846780+00:00 PM: genpd: Disabling unused power domains
2026-10-10T11:00:14,862963+00:00 Freeing unused decrypted memory: 2028K
2026-10-10T11:00:14,865173+00:00 Freeing unused kernel image (initmem) memory: 5304K
2026-10-10T11:00:14,865436+00:00 Write protecting the kernel read-only data: 43008k
2026-10-10T11:00:14,869054+00:00 Freeing unused kernel image (text/rodata gap) memory: 736K
2026-10-10T11:00:14,871082+00:00 Freeing unused kernel image (rodata/data gap) memory: 1656K
2026-10-10T11:00:14,912314+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2026-10-10T11:00:14,912583+00:00 Run /init as init process
2026-10-10T11:00:14,912797+00:00   with arguments:
2026-10-10T11:00:14,912800+00:00     /init
2026-10-10T11:00:14,912802+00:00   with environment:
2026-10-10T11:00:14,912803+00:00     HOME=/
2026-10-10T11:00:14,912804+00:00     TERM=linux
2026-10-10T11:00:14,952045+00:00 usb 4-1: new high-speed USB device number 2 using ehci-pci
2026-10-10T11:00:15,081267+00:00 usb 4-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2026-10-10T11:00:15,081521+00:00 usb 4-1: New USB device strings: Mfr=1, Product=3, SerialNumber=10
2026-10-10T11:00:15,081723+00:00 usb 4-1: Product: QEMU USB Tablet
2026-10-10T11:00:15,081928+00:00 usb 4-1: Manufacturer: QEMU
2026-10-10T11:00:15,082136+00:00 usb 4-1: SerialNumber: 28754-0000:00:1d.7-1
2026-10-10T11:00:15,254030+00:00 systemd[1]: Inserted module 'autofs4'
2026-10-10T11:00:15,290988+00:00 systemd[1]: Successfully made /usr/ read-only.
2026-10-10T11:00:15,626583+00:00 systemd[1]: systemd 259.5-0ubuntu3.4 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +IPE +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +KMOD +LIBCRYPTSETUP +LIBCRYPTSETUP_PLUGINS +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK +BTF -XKBCOMMON -UTMP +SYSVINIT +LIBARCHIVE)
2026-10-10T11:00:15,627267+00:00 systemd[1]: Detected virtualization kvm.
2026-10-10T11:00:15,627495+00:00 systemd[1]: Detected architecture x86-64.
2026-10-10T11:00:15,627703+00:00 systemd[1]: Running in initrd.
2026-10-10T11:00:15,643858+00:00 systemd[1]: Hostname set to <ubuntu-2604>.
2026-10-10T11:00:15,722008+00:00 systemd[1]: bpf-restrict-fs: BPF LSM hook not enabled in the kernel, BPF LSM not supported.
2026-10-10T11:00:15,820542+00:00 systemd[1]: Queued start job for default target initrd.target.
2026-10-10T11:00:15,831966+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2026-10-10T11:00:15,836440+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-41A1\x2dDD67.device - /dev/disk/by-uuid/41A1-DD67...
2026-10-10T11:00:15,841348+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-618f4c04\x2d0edd\x2d49b3\x2d8ad5\x2d00a29af1f556.device - /dev/disk/by-uuid/618f4c04-0edd-49b3-8ad5-00a29af1f556...
2026-10-10T11:00:15,846611+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-747687d9\x2dc20c\x2d41f8\x2dbfb8\x2d7f4a57910c51.device - /dev/disk/by-uuid/747687d9-c20c-41f8-bfb8-7f4a57910c51...
2026-10-10T11:00:15,853510+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2026-10-10T11:00:15,858177+00:00 systemd[1]: Reached target paths.target - Path Units.
2026-10-10T11:00:15,861746+00:00 systemd[1]: Reached target slices.target - Slice Units.
2026-10-10T11:00:15,865693+00:00 systemd[1]: Reached target swap.target - Swaps.
2026-10-10T11:00:15,868874+00:00 systemd[1]: Reached target timers.target - Timer Units.
2026-10-10T11:00:15,872139+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2026-10-10T11:00:15,876944+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Sockets.
2026-10-10T11:00:15,881963+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Management Netlink Socket.
2026-10-10T11:00:15,886168+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2026-10-10T11:00:15,891082+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2026-10-10T11:00:15,895211+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2026-10-10T11:00:15,901853+00:00 systemd[1]: Starting dracut-cmdline-ask.service - dracut ask for additional cmdline parameters...
2026-10-10T11:00:15,925899+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2026-10-10T11:00:15,933630+00:00 systemd[1]: systemd-battery-check.service - Early Battery Level Check skipped, unmet condition check ConditionDirectoryNotEmpty=/sys/class/power_supply
2026-10-10T11:00:15,940107+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2026-10-10T11:00:15,954876+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2026-10-10T11:00:15,964467+00:00 systemd[1]: Starting systemd-network-generator.service - Generate Network Units from Kernel Command Line...
2026-10-10T11:00:15,975911+00:00 systemd[1]: systemd-pcrphase-initrd.service - TPM PCR Barrier (initrd) skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:15,977853+00:00 systemd[1]: Finished dracut-cmdline-ask.service - dracut ask for additional cmdline parameters.
2026-10-10T11:00:15,982068+00:00 systemd-journald[126]: Collecting audit messages is disabled.
2026-10-10T11:00:15,997199+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2026-10-10T11:00:16,004291+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2026-10-10T11:00:16,021880+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully...
2026-10-10T11:00:16,031662+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2026-10-10T11:00:16,040506+00:00 systemd[1]: Finished systemd-network-generator.service - Generate Network Units from Kernel Command Line.
2026-10-10T11:00:16,047802+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully.
2026-10-10T11:00:16,053323+00:00 systemd[1]: Reached target network-pre.target - Preparation for Network.
2026-10-10T11:00:16,057631+00:00 systemd[1]: Listening on systemd-networkd-resolve-hook.socket - Network Management Resolve Hook Socket.
2026-10-10T11:00:16,065216+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2026-10-10T11:00:16,069665+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2026-10-10T11:00:16,100508+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2026-10-10T11:00:16,116199+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2026-10-10T11:00:16,118527+00:00 systemd[1]: Reached target local-fs-pre.target - Preparation for Local File Systems.
2026-10-10T11:00:16,122316+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2026-10-10T11:00:16,127159+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2026-10-10T11:00:16,664090+00:00 virtio_net virtio1 ens18: renamed from eth0
2026-10-10T11:00:16,824827+00:00 hid: raw HID events driver (C) Jiri Kosina
2026-10-10T11:00:16,833162+00:00 ahci 0000:00:1f.2: AHCI vers 0001.0000, 32 command slots, 1.5 Gbps, SATA mode
2026-10-10T11:00:16,833174+00:00 ahci 0000:00:1f.2: 6/6 ports implemented (port mask 0x3f)
2026-10-10T11:00:16,833181+00:00 ahci 0000:00:1f.2: flags: 64bit ncq only 
2026-10-10T11:00:16,836753+00:00 usbcore: registered new interface driver usbhid
2026-10-10T11:00:16,836760+00:00 usbhid: USB HID core driver
2026-10-10T11:00:16,838521+00:00 scsi host1: ahci
2026-10-10T11:00:16,839379+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2026-10-10T11:00:16,839898+00:00 scsi host2: ahci
2026-10-10T11:00:16,840433+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2026-10-10T11:00:16,840558+00:00 scsi host3: ahci
2026-10-10T11:00:16,840966+00:00 scsi host4: ahci
2026-10-10T11:00:16,842038+00:00 scsi host5: ahci
2026-10-10T11:00:16,842156+00:00 scsi host6: ahci
2026-10-10T11:00:16,842226+00:00 ata1: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244100 irq 38 lpm-pol 1
2026-10-10T11:00:16,842245+00:00 ata2: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244180 irq 38 lpm-pol 1
2026-10-10T11:00:16,842262+00:00 ata3: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244200 irq 38 lpm-pol 1
2026-10-10T11:00:16,842279+00:00 ata4: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244280 irq 38 lpm-pol 1
2026-10-10T11:00:16,842295+00:00 ata5: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244300 irq 38 lpm-pol 1
2026-10-10T11:00:16,842313+00:00 ata6: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244380 irq 38 lpm-pol 1
2026-10-10T11:00:16,915669+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:1d.7/usb4/4-1/4-1:1.0/0003:0627:0001.0001/input/input5
2026-10-10T11:00:16,919435+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:1d.7-1/input0
2026-10-10T11:00:17,156949+00:00 ata4: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:17,157429+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:17,157798+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:17,158189+00:00 ata1: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2026-10-10T11:00:17,158339+00:00 ata1.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2026-10-10T11:00:17,158349+00:00 ata1.00: applying bridge limits
2026-10-10T11:00:17,158642+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:17,159131+00:00 ata2: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2026-10-10T11:00:17,159271+00:00 ata1.00: configured for UDMA/100
2026-10-10T11:00:17,159401+00:00 ata2.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2026-10-10T11:00:17,159408+00:00 ata2.00: applying bridge limits
2026-10-10T11:00:17,159625+00:00 ata2.00: configured for UDMA/100
2026-10-10T11:00:17,159881+00:00 scsi 1:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:17,172597+00:00 sr 1:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2026-10-10T11:00:17,195367+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2026-10-10T11:00:17,210147+00:00 sr 1:0:0:0: Attached scsi CD-ROM sr0
2026-10-10T11:00:17,210378+00:00 sr 1:0:0:0: Attached scsi generic sg1 type 5
2026-10-10T11:00:17,210583+00:00 scsi 2:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:17,235383+00:00 sr 2:0:0:0: [sr1] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2026-10-10T11:00:17,274131+00:00 sr 2:0:0:0: Attached scsi CD-ROM sr1
2026-10-10T11:00:17,274338+00:00 sr 2:0:0:0: Attached scsi generic sg2 type 5
2026-10-10T11:00:17,554601+00:00 EXT4-fs (sda1): orphan cleanup on readonly fs
2026-10-10T11:00:17,554891+00:00 EXT4-fs (sda1): mounted filesystem 747687d9-c20c-41f8-bfb8-7f4a57910c51 ro with ordered data mode. Quota mode: none.
2026-10-10T11:00:17,814869+00:00 systemd-journald[126]: Received SIGTERM from PID 1 (systemd).
2026-10-10T11:00:18,551920+00:00 systemd[1]: systemd 259.5-0ubuntu3.4 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +IPE +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +KMOD +LIBCRYPTSETUP +LIBCRYPTSETUP_PLUGINS +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK +BTF -XKBCOMMON -UTMP +SYSVINIT +LIBARCHIVE)
2026-10-10T11:00:18,551936+00:00 systemd[1]: Detected virtualization kvm.
2026-10-10T11:00:18,551951+00:00 systemd[1]: Detected architecture x86-64.
2026-10-10T11:00:18,560185+00:00 systemd[1]: Hostname set to <workernode01>.
2026-10-10T11:00:18,614954+00:00 systemd[1]: bpf-restrict-fs: BPF LSM hook not enabled in the kernel, BPF LSM not supported.
2026-10-10T11:00:18,671206+00:00 Guest personality initialized and is inactive
2026-10-10T11:00:18,671317+00:00 VMCI host device registered (name=vmci, major=10, minor=262)
2026-10-10T11:00:18,671322+00:00 Initialized host personality
2026-10-10T11:00:18,673782+00:00 NET: Registered PF_VSOCK protocol family
2026-10-10T11:00:18,862841+00:00 systemd[1]: /usr/lib/systemd/system/xfs_scrub_all.service:26: Support for option CPUAccounting= has been removed and it is ignored
2026-10-10T11:00:18,863485+00:00 systemd[1]: /usr/lib/systemd/system/system-xfs_scrub.slice:15: Support for option CPUAccounting= has been removed and it is ignored
2026-10-10T11:00:18,964211+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2026-10-10T11:00:18,964363+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2026-10-10T11:00:18,966502+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2026-10-10T11:00:18,967126+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2026-10-10T11:00:18,968962+00:00 systemd[1]: Created slice system-systemd\x2dfsck.slice - Slice /system/systemd-fsck.
2026-10-10T11:00:18,971147+00:00 systemd[1]: Created slice system-xfs_scrub.slice - xfs_scrub background service slice.
2026-10-10T11:00:18,972884+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2026-10-10T11:00:18,974093+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2026-10-10T11:00:18,975681+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2026-10-10T11:00:18,977071+00:00 systemd[1]: Expecting device dev-disk-by\x2dlabel-BOOT.device - /dev/disk/by-label/BOOT...
2026-10-10T11:00:18,978320+00:00 systemd[1]: Expecting device dev-disk-by\x2dlabel-UEFI.device - /dev/disk/by-label/UEFI...
2026-10-10T11:00:18,979602+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2026-10-10T11:00:18,980791+00:00 systemd[1]: Reached target imports.target - Image Downloads.
2026-10-10T11:00:18,982248+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2026-10-10T11:00:18,983679+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2026-10-10T11:00:18,985027+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2026-10-10T11:00:18,986556+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2026-10-10T11:00:18,988226+00:00 systemd[1]: Reached target slices.target - Slice Units.
2026-10-10T11:00:18,989618+00:00 systemd[1]: Reached target snapd.mounts-pre.target - Mounting snaps.
2026-10-10T11:00:18,991068+00:00 systemd[1]: Reached target snapd.mounts.target - Mounted snaps.
2026-10-10T11:00:18,992423+00:00 systemd[1]: Reached target swap.target - Swaps.
2026-10-10T11:00:18,993570+00:00 systemd[1]: Reached target time-set.target - System Time Set.
2026-10-10T11:00:18,994867+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2026-10-10T11:00:18,996425+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2026-10-10T11:00:18,998065+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2026-10-10T11:00:19,007245+00:00 systemd[1]: Listening on rpcbind.socket - RPCbind Server Activation Socket.
2026-10-10T11:00:19,008891+00:00 systemd[1]: Listening on syslog.socket - Syslog Socket.
2026-10-10T11:00:19,011376+00:00 systemd[1]: Listening on systemd-ask-password.socket - Query the User Interactively for a Password.
2026-10-10T11:00:19,013909+00:00 systemd[1]: Listening on systemd-creds.socket - Credential Encryption/Decryption.
2026-10-10T11:00:19,016540+00:00 systemd[1]: Listening on systemd-factory-reset.socket - Factory Reset Management.
2026-10-10T11:00:19,019474+00:00 systemd[1]: Listening on systemd-mute-console.socket - Console Output Muting Service Socket.
2026-10-10T11:00:19,021235+00:00 systemd[1]: Listening on systemd-networkd-varlink.socket - Network Management Varlink Socket.
2026-10-10T11:00:19,022909+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Management Netlink Socket.
2026-10-10T11:00:19,024496+00:00 systemd[1]: systemd-pcrextend.socket - TPM PCR Measurements skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:19,024534+00:00 systemd[1]: systemd-pcrlock.socket - Make TPM PCR Policy skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:19,024662+00:00 systemd[1]: Listening on systemd-resolved-monitor.socket - Resolve Monitor Varlink Socket.
2026-10-10T11:00:19,026265+00:00 systemd[1]: Listening on systemd-resolved-varlink.socket - Resolve Service Varlink Socket.
2026-10-10T11:00:19,027883+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2026-10-10T11:00:19,029382+00:00 systemd[1]: Listening on systemd-udevd-varlink.socket - udev Varlink Socket.
2026-10-10T11:00:19,032171+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2026-10-10T11:00:19,035960+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2026-10-10T11:00:19,039096+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2026-10-10T11:00:19,045034+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2026-10-10T11:00:19,049331+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2026-10-10T11:00:19,056829+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2026-10-10T11:00:19,061931+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS skipped, unmet condition check ConditionPathExists=/etc/krb5.keytab
2026-10-10T11:00:19,065130+00:00 systemd[1]: Starting keyboard-setup.service - Set the console keyboard layout...
2026-10-10T11:00:19,071248+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2026-10-10T11:00:19,077464+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2026-10-10T11:00:19,080061+00:00 systemd[1]: modprobe@configfs.service - Load Kernel Module configfs skipped, unmet condition check ConditionKernelModuleLoaded=!configfs
2026-10-10T11:00:19,082656+00:00 systemd[1]: Starting modprobe@dm_multipath.service - Load Kernel Module dm_multipath...
2026-10-10T11:00:19,084283+00:00 systemd[1]: modprobe@drm.service - Load Kernel Module drm skipped, unmet condition check ConditionKernelModuleLoaded=!drm
2026-10-10T11:00:19,090280+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2026-10-10T11:00:19,092488+00:00 systemd[1]: modprobe@fuse.service - Load Kernel Module fuse skipped, unmet condition check ConditionKernelModuleLoaded=!fuse
2026-10-10T11:00:19,093789+00:00 systemd[1]: Mounting sys-fs-fuse-connections.mount - FUSE Control File System...
2026-10-10T11:00:19,096472+00:00 systemd[1]: netplan-ovs-cleanup.service - OpenVSwitch configuration for cleanup skipped, unmet condition check ConditionFileIsExecutable=/usr/bin/ovs-vsctl
2026-10-10T11:00:19,096727+00:00 systemd[1]: systemd-hibernate-clear.service - Clear Stale Hibernate Storage Info skipped, unmet condition check ConditionPathExists=/sys/firmware/efi/efivars/HibernateLocation-8cf2644b-4b0b-428f-9387-6d876050dc67
2026-10-10T11:00:19,100884+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2026-10-10T11:00:19,105221+00:00 systemd[1]: systemd-pcrmachine.service - TPM PCR Machine ID Measurement skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:19,105274+00:00 systemd[1]: systemd-pcrproduct.service - TPM NvPCR Product ID Measurement skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:19,107843+00:00 systemd[1]: Starting systemd-remount-fs.service - Remount Root and Kernel File Systems...
2026-10-10T11:00:19,109725+00:00 systemd[1]: systemd-tpm2-setup-early.service - Early TPM SRK Setup skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:19,111370+00:00 systemd[1]: Starting systemd-udev-load-credentials.service - Load udev Rules from Credentials...
2026-10-10T11:00:19,116067+00:00 pstore: Using crash dump compression: deflate
2026-10-10T11:00:19,117227+00:00 systemd-journald[490]: Collecting audit messages is disabled.
2026-10-10T11:00:19,117313+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2026-10-10T11:00:19,125274+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2026-10-10T11:00:19,127931+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2026-10-10T11:00:19,133730+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2026-10-10T11:00:19,137558+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2026-10-10T11:00:19,141905+00:00 pstore: Registered efi_pstore as persistent store backend
2026-10-10T11:00:19,142600+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2026-10-10T11:00:19,146548+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2026-10-10T11:00:19,148790+00:00 systemd[1]: modprobe@dm_multipath.service: Deactivated successfully.
2026-10-10T11:00:19,148984+00:00 systemd[1]: Finished modprobe@dm_multipath.service - Load Kernel Module dm_multipath.
2026-10-10T11:00:19,152518+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2026-10-10T11:00:19,152725+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2026-10-10T11:00:19,155391+00:00 systemd[1]: Mounted sys-fs-fuse-connections.mount - FUSE Control File System.
2026-10-10T11:00:19,159419+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2026-10-10T11:00:19,170089+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2026-10-10T11:00:19,176097+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully...
2026-10-10T11:00:19,179280+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2026-10-10T11:00:19,200929+00:00 EXT4-fs (sda1): re-mounted 747687d9-c20c-41f8-bfb8-7f4a57910c51 r/w.
2026-10-10T11:00:19,270894+00:00 systemd-journald[490]: Received client request to flush runtime journal.
2026-10-10T11:00:20,271229+00:00 Console: switching to colour dummy device 80x25
2026-10-10T11:00:20,309898+00:00 bochs-drm 0000:00:01.0: vgaarb: deactivate vga console
2026-10-10T11:00:20,310477+00:00 [drm] Found bochs VGA, ID 0xb0c5.
2026-10-10T11:00:20,310487+00:00 [drm] Framebuffer size 16384 kB @ 0x80000000, mmio @ 0x8224b000.
2026-10-10T11:00:20,346825+00:00 bochs-drm 0000:00:01.0: [drm] Registered 1 planes with drm panic
2026-10-10T11:00:20,350195+00:00 [drm] Initialized bochs-drm 1.0.0 for 0000:00:01.0 on minor 0
2026-10-10T11:00:20,355241+00:00 fbcon: bochs-drmdrmfb (fb0) is primary device
2026-10-10T11:00:20,392315+00:00 snd_hda_intel 0000:00:1b.0: no codecs found!
2026-10-10T11:00:20,419652+00:00 Console: switching to colour frame buffer device 160x50
2026-10-10T11:00:20,441561+00:00 bochs-drm 0000:00:01.0: [drm] fb0: bochs-drmdrmfb frame buffer device
2026-10-10T11:00:20,575353+00:00 EXT4-fs (sda13): mounted filesystem 618f4c04-0edd-49b3-8ad5-00a29af1f556 r/w with ordered data mode. Quota mode: none.
2026-10-10T11:00:20,704369+00:00 lpc_ich 0000:00:1f.0: I/O space for GPIO uninitialized
2026-10-10T11:00:20,754439+00:00 i801_smbus 0000:00:1f.3: Enabling SMBus device
2026-10-10T11:00:20,754488+00:00 i801_smbus 0000:00:1f.3: SMBus using PCI interrupt
2026-10-10T11:00:20,754802+00:00 i2c i2c-0: Memory type 0x07 not supported yet, not instantiating SPD
2026-10-10T11:00:20,805367+00:00 RAPL PMU: API unit is 2^-32 Joules, 0 fixed counters, 10737418240 ms ovfl timer
2026-10-10T11:00:21,066071+00:00 intel_rapl_msr: PL4 support detected.
2026-10-10T11:00:21,143249+00:00 audit: type=1400 audit(1791630020.920:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="1password" pid=702 comm="apparmor_parser"
2026-10-10T11:00:21,143499+00:00 audit: type=1400 audit(1791630020.920:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Discord" pid=703 comm="apparmor_parser"
2026-10-10T11:00:21,145718+00:00 audit: type=1400 audit(1791630020.922:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name=4D6F6E676F444220436F6D70617373 pid=707 comm="apparmor_parser"
2026-10-10T11:00:21,146974+00:00 audit: type=1400 audit(1791630020.923:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="QtWebEngineProcess" pid=708 comm="apparmor_parser"
2026-10-10T11:00:21,160314+00:00 audit: type=1400 audit(1791630020.937:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="alsamixer" pid=712 comm="apparmor_parser"
2026-10-10T11:00:21,168856+00:00 audit: type=1400 audit(1791630020.943:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="babeld" pid=714 comm="apparmor_parser"
2026-10-10T11:00:21,175541+00:00 audit: type=1400 audit(1791630020.952:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="balena-etcher" pid=717 comm="apparmor_parser"
2026-10-10T11:00:21,176546+00:00 audit: type=1400 audit(1791630020.953:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Xorg" pid=711 comm="apparmor_parser"
2026-10-10T11:00:21,176553+00:00 audit: type=1400 audit(1791630020.953:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Xorg_wrap" pid=711 comm="apparmor_parser"
2026-10-10T11:00:21,182032+00:00 audit: type=1400 audit(1791630020.958:11): apparmor="STATUS" operation="profile_load" profile="unconfined" name="bfdd" pid=720 comm="apparmor_parser"
2026-10-10T11:00:21,289968+00:00 RPC: Registered named UNIX socket transport module.
2026-10-10T11:00:21,289978+00:00 RPC: Registered udp transport module.
2026-10-10T11:00:21,289987+00:00 RPC: Registered tcp transport module.
2026-10-10T11:00:21,290004+00:00 RPC: Registered tcp-with-tls transport module.
2026-10-10T11:00:21,290007+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2026-10-10T11:00:21,705252+00:00 ISO 9660 Extensions: Microsoft Joliet Level 3
2026-10-10T11:00:21,705718+00:00 ISO 9660 Extensions: RRIP_1991A
2026-10-10T11:00:21,872245+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2026-10-10T11:00:21,872557+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2026-10-10T11:00:21,872744+00:00 Loaded X.509 cert 'wens: 61c038651aabdcf94bd0ac7ff06c7248db18c600'
2026-10-10T11:00:23,019782+00:00 NET: Registered PF_QIPCRTR protocol family
2026-10-10T11:00:23,129444+00:00 loop0: detected capacity change from 0 to 8
2026-10-10T11:00:28,211271+00:00 Loading iSCSI transport class v2.0-870.
2026-10-10T11:00:49,260297+00:00 kauditd_printk_skb: 174 callbacks suppressed
2026-10-10T11:00:49,260319+00:00 audit: type=1400 audit(1791630049.843:186): apparmor="STATUS" operation="profile_load" profile="unconfined" name="cri-containerd.apparmor.d" pid=1512 comm="apparmor_parser"
2026-10-10T11:00:49,321300+00:00 audit: type=1400 audit(1791630049.904:187): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="cri-containerd.apparmor.d" pid=1541 comm="apparmor_parser"
2026-10-10T11:00:57,467946+00:00 evm: overlay not supported
2026-10-10T11:00:57,699836+00:00 Initializing XFRM netlink socket
2026-10-10T11:01:01,919082+00:00 eth0: renamed from tmp88a7a
2026-10-10T11:42:30,932205+00:00 clocksource: Long readout interval, skipping watchdog check: cs_nsec: 2659518187 wd_nsec: 503979201
2026-10-10T13:28:36,329639+00:00 eth0: renamed from tmp3cb69
