<stdin>:0: bgp/routes in ipv4 unicast: BGP router manager is not running
error: <stdin>:0: bgp/routes in ipv4 unicast: BGP router manager is not running
> Error while running 'cilium-dbg shell -- bgp/routes -a in ipv4 unicast':  exit status 1

