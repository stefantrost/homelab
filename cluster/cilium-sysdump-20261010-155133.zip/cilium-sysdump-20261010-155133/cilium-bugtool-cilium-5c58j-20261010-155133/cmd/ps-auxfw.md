USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        1119 21.0  0.1 1270588 14452 ?       Rsl  13:52   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        1141  0.0  0.0   6760  3736 ?        R    13:52   0:00  \_ ps auxfw
root           1  2.0  1.8 1531280 184832 ?      Ssl  11:00   3:28 cilium-agent --config-dir=/tmp/cilium/config-map
root         126  0.0  0.0 1329748 6632 ?        Sl   11:00   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
