fe80::36e1:a9ff:fe62:6be6 dev ens18 lladdr 34:e1:a9:62:6b:e6 router STALE 
fda7:7b49:a70a:0:36e1:a9ff:fe62:6be6 dev ens18 lladdr 34:e1:a9:62:6b:e6 router REACHABLE 
