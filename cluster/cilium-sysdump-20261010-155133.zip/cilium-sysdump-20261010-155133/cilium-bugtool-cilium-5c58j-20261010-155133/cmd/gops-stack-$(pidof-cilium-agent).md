goroutine 245 [running]:
runtime/pprof.writeGoroutineStacks({0x7bdc8e8fe7d8, 0x2e9573706028})
	/usr/local/go/src/runtime/pprof/pprof.go:819 +0x6b
runtime/pprof.writeGoroutine({0x7bdc8e8fe7d8?, 0x2e9573706028?}, 0x2e9577395790?)
	/usr/local/go/src/runtime/pprof/pprof.go:782 +0x25
runtime/pprof.(*Profile).WriteTo(0x8326720?, {0x7bdc8e8fe7d8?, 0x2e9573706028?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:408 +0x149
github.com/google/gops/agent.handle({0x7bdc8e8fe7b0, 0x2e9573706028}, {0x2e95750b4228?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x28d2
github.com/google/gops/agent.listen({0x4f690b0, 0x2e957536a2c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1b4
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x35c

goroutine 1 [select, 171 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x2e9572a49800, 0x2e9572e9d2d0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:286 +0x155
github.com/cilium/hive.(*Hive).Run(0x2e9572a49800, 0x2e9572e9d2d0, {0x2e9572dcbbd8, 0x3, 0x4?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:270 +0x3cd
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x2e957344e308, {0x4bcd638?, 0x4?, 0x4bcd598?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:50 +0x2ba
github.com/spf13/cobra.(*Command).execute(0x2e957344e308, {0x2e9572b94050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1019 +0xafb
github.com/spf13/cobra.(*Command).ExecuteC(0x2e957344e308)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1148 +0x465
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1071
github.com/cilium/cilium/daemon/cmd.Execute(0x2e9572a501e0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:89 +0x13
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:15 +0x1f

goroutine 1337 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e957727f5e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1004
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 1001 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e957582eb00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 321
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 10 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/pidfile.write.DeferTerminationCleanupFunction.func2()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x25
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 217 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e9573d0d180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 219 [chan receive, 24 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:160 +0xb9
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:153 +0x67

goroutine 220 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e9573d0d360)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 226 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x14d
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 1349 [select]:
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:338 +0x95
created by github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices in goroutine 1362
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:334 +0x11c

goroutine 1042 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575858dc0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1291 [select, 171 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readMessageHeader(0x2e95771d6468, {0x2e9573ec0928, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:281 +0xa5
google.golang.org/grpc/internal/transport.(*recvBufferReader).ReadMessageHeader(0x2e95771d6468, {0x2e9573ec0928?, 0x2e9574989380?, 0x2e95771d6380?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:250 +0x77
google.golang.org/grpc/internal/transport.(*transportReader).ReadMessageHeader(0x2e95771d6448, {0x2e9573ec0928?, 0x2e957479c0a0?, 0x2e95772f5b78?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:561 +0x25
google.golang.org/grpc/internal/transport.(*Stream).ReadMessageHeader(0x2e95771d6380, {0x2e9573ec0928, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:470 +0xa9
google.golang.org/grpc.(*parser).recvMsg(0x2e9573ec0918, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:786 +0x3b
google.golang.org/grpc.recvAndDecompress(0x2e9573ec0918, {0x4f09540, 0x2e95771d6380}, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:945 +0x97
google.golang.org/grpc.recv(0x2e95772f5d90?, {0x7bdc8ea0a2c0, 0x88ffe40}, {0x4f09540?, 0x2e95771d6380?}, {0x0?, 0x0?}, {0x49b8200, 0x2e957479c280}, 0x400000, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:1054 +0xab
google.golang.org/grpc.(*serverStream).RecvMsg(0x2e9573ec0900, {0x49b8200, 0x2e957479c280})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1839 +0x199
github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3.(*aggregatedDiscoveryServiceStreamAggregatedResourcesServer).Recv(0x2e9575fc3770)
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3/ads_grpc.pb.go:156 +0x46
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).StreamHandler.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/server.go:168 +0x94
created by github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).StreamHandler in goroutine 1290
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/server.go:165 +0xa7

goroutine 130156 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577586f00, 0x2e9575d7d900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577586f00, 0xfcedd7?, 0x2e9576c88af0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 265
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 1290 [select, 171 minutes]:
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).processADS(0x2e9575b12180, 0x2e95763b5860, 0x2e9574287570)
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/ads.go:46 +0xf8
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).process(0x2e9575b12180, {0x7bdc8ea0a2e8, 0x2e9575fc3770}, 0x2e9574287570, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/xds.go:54 +0x2ea
github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3.(*server).StreamHandler(0x2e9575b12180, {0x7bdc8ea0a2e8, 0x2e9575fc3770}, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/sotw/v3/server.go:182 +0xca
github.com/envoyproxy/go-control-plane/pkg/server/v3.(*server).StreamHandler(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/v3/server.go:186
github.com/envoyproxy/go-control-plane/pkg/server/v3.(*server).StreamAggregatedResources(0x2e9573772180?, {0x4facdc0?, 0x2e9575fc3770?})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/pkg/server/v3/server.go:190 +0x4b
github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3._AggregatedDiscoveryService_StreamAggregatedResources_Handler({0x4b11040?, 0x2e9573772180}, {0x4f9a8c0, 0x2e9573ec0900})
	/go/src/github.com/cilium/cilium/vendor/github.com/envoyproxy/go-control-plane/envoy/service/discovery/v3/ads_grpc.pb.go:137 +0xd8
google.golang.org/grpc.(*Server).processStreamingRPC(0x2e9575312008, {0x4f78938, 0x2e9573b04b10}, 0x2e95771d6380, 0x2e9573772300, 0x836d340, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1729 +0x1192
google.golang.org/grpc.(*Server).handleStream(0x2e9575312008, {0x4f7ae10, 0x2e9574989380}, 0x2e95771d6380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1862 +0xaa5
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1078 +0x7f
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1289
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1089 +0x11d

goroutine 243 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x14d
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 854 [syscall, 171 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x98
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x13
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:152 +0x1f

goroutine 246 [select, 170 minutes]:
github.com/cilium/statedb.graveyardWorker(0x2e95739140c0, {0x4f78970, 0x2e957357c960}, 0x200a2c65736c6166?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:26 +0x185
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:287 +0x155

goroutine 247 [chan receive, 171 minutes]:
github.com/cilium/lumberjack/v2.(*Logger).millRun(0x2e9572ee8620)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/lumberjack/v2/lumberjack.go:410 +0x77
created by github.com/cilium/lumberjack/v2.(*Logger).mill.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/lumberjack/v2/lumberjack.go:422 +0x9a

goroutine 297 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 294
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 252 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8ed2c600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575134b00?, 0x2e957580c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9575134b00, {0x2e957580c000, 0x3800, 0x3800})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9575134b00, {0x2e957580c000?, 0xc?, 0x2e95757a9a28?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e95731a1a30, {0x2e957580c000?, 0x425234?, 0x2e957580c005?})
	/usr/local/go/src/net/net.go:196 +0x45
crypto/tls.(*atLeastReader).Read(0x2e9577a3cc78, {0x2e957580c000?, 0x2e95757a9a48?, 0x452688?})
	/usr/local/go/src/crypto/tls/conn.go:815 +0x3b
bytes.(*Buffer).ReadFrom(0x2e9574cec628, {0x4f0dbc0, 0x2e9577a3cc78})
	/usr/local/go/src/bytes/buffer.go:229 +0x98
crypto/tls.(*Conn).readFromUntil(0x2e9574cec388, {0x7bdc8e9e40d0, 0x2e95736ca960}, 0x69e30c?)
	/usr/local/go/src/crypto/tls/conn.go:837 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0x2e9574cec388, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x3db
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x2e9574cec388, {0x2e9573986000, 0x1000, 0x2e95757a9cb0?})
	/usr/local/go/src/crypto/tls/conn.go:1393 +0x145
bufio.(*Reader).Read(0x2e95736b45a0, {0x2e9574cb98c4, 0x9, 0x44?})
	/usr/local/go/src/bufio/bufio.go:245 +0x197
io.ReadAtLeast({0x4f08a40, 0x2e95736b45a0}, {0x2e9574cb98c4, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x8e
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x2e9574cb98c4, 0x9, 0x2e95000003d3?}, {0x4f08a40?, 0x2e95736b45a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:250 +0x65
golang.org/x/net/http2.(*Framer).ReadFrameHeader(0x2e9574cb9880)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:513 +0x6b
golang.org/x/net/http2.(*Framer).ReadFrame(0x2e9574cb9880)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:572 +0x18
golang.org/x/net/http2.(*clientConnReadLoop).run(0x2e95757a9fa8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1878 +0xca
golang.org/x/net/http2.(*ClientConn).readLoop(0x2e95734f3180)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1760 +0x52
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 251
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:554 +0xda5

goroutine 233 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95750bc000)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 237 [select, 171 minutes]:
github.com/cilium/cilium/pkg/policy/compute.(*IdentityPolicyComputer).processRequests(0x2e957323dc80, {0x4f78938, 0x2e95736ec600})
	/go/src/github.com/cilium/cilium/pkg/policy/compute/compute.go:222 +0xac
github.com/cilium/cilium/pkg/policy/compute.NewIdentityPolicyComputer.func1({0x4f78938?, 0x2e95736ec600?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/policy/compute/cell.go:53 +0x2a
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95736b5bc0, {0x4f78938, 0x2e95736ec600}, {0x4f909a0, 0x2e95736b59e0}, {{{0x2e95736f6680, 0x1, 0x1}}, 0x2e9573e31640, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 294 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9574cb9a90, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9574673580?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574cb9a40, 0x2e957536b800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9574cf8790, {0x4f7afd0, 0x2e957502f8f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e957502f8f0?}, 0x2e95736f9980?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e957502f8f0}, 0x2e95758abea0, {0x4f0fa20, 0x2e95736f9980}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e957502f8f0}, 0x2e95758abea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9574cf8790, {0x4f7afd0, 0x2e957502f8f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e9575828020, 0x2e957502f8f0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 240
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 1027 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9574eb9ce0, {0x4f78938, 0x2e9573b39aa0}, {0x4f909a0, 0x2e9574482ae0}, {{{0x2e95733f2160, 0x1, 0x1}}, 0x2e9573b51330, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 358
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 426 [select, 2 minutes]:
github.com/cilium/cilium/pkg/mtu.(*MTUManager).Updater(0x2e9573be4a00, {0x4f78938, 0x2e9573788030}, {0x4f909a0, 0x2e9575b12ae0})
	/go/src/github.com/cilium/cilium/pkg/mtu/manager.go:101 +0x988
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9575b12a80, {0x4f78938, 0x2e9573788030}, {0x4f909a0, 0x2e9574b7b8c0}, {{{0x2e95735a8820, 0x1, 0x1}}, 0x2e9573ce4580, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 370 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95735b2f00, {0x4f78970, 0x2e9574798870}, 0x2e9572e0e230)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 341
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 314 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e957371da00, {0x4f78970, 0x2e95731ae370}, 0x2e9572de4d90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 298
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 345 [select]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runServiceEndpointsReflector.Buffer[...].func7.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x11a
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.runServiceEndpointsReflector.Buffer[...].func7 in goroutine 356
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 261 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0x2e957421cf30, 0x23)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9574512120?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e957421cee0, 0x2e95750b0940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9572abcfd0, {0x4f7afd0, 0x2e957502f6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e957502f6c0?}, 0x2e95736ed320?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e957502f6c0}, 0x2e95750c3ea0, {0x4f0fa20, 0x2e95736ed320}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e957502f6c0}, 0x2e95750c3ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9572abcfd0, {0x4f7afd0, 0x2e957502f6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x2273656c706d6178?, 0x202020200a7b203a?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e95750ba4a0, 0x2e957502f6c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 239
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 423 [select, 170 minutes]:
github.com/cilium/statedb.(*observable[...]).Observe.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/observable.go:46 +0x312
created by github.com/cilium/statedb.(*observable[...]).Observe in goroutine 357
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/observable.go:27 +0xbd

goroutine 301 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/node/sync.(*localNodeSynchronizer).SyncLocalNode(0x2e9573a1af00, {0x4f78938?, 0x2e957370a570?}, 0x2e9572e9b140)
	/go/src/github.com/cilium/cilium/pkg/node/sync/local_node_sync.go:99 +0xab
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1({0x4f78938?, 0x2e957370a570?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:119 +0x33
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573c97680, {0x4f78938, 0x2e957370a570}, {0x4f909a0, 0x2e9573d48180}, {{{0x2e9573709c80, 0x1, 0x1}}, 0x2e9573e7af30, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 303 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5000f80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 1004 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 566
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 418 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 417
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 402 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e996c00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575879400?, 0x88ffe62?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9575879400)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9575879400)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x460d20?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).AcceptUnix(0x2e9573753d10)
	/usr/local/go/src/net/unixsock.go:254 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).run(0x2e9574596fa0, {0x4f78938, 0x2e9573765b00})
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x22b
github.com/cilium/cilium/pkg/envoy.newEnvoyAccessLogServer.func1({0x4f78938?, 0x2e9573765b00?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/envoy/cell.go:208 +0x2a
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574483740, {0x4f78938, 0x2e9573765b00}, {0x4f909a0, 0x2e9574483680}, {{{0x2e95733f9ce0, 0x1, 0x1}}, 0x2e9573e31410, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 341 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e95759e60e0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9577f44640}, {0x4f8fca0, 0x2e95758a0000}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e95759e60e0?}, {0x2e9573ed90e0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9577f44640?}, {0x4f8fca0?, 0x2e95758a0000?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95735b2f00, {0x4f7afd0, 0x2e95759e60e0}, {0x4f5b8e8, 0x2e9577f44640}, 0x2e9572e0e230)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95735b2f00, {0x4f7afd0, 0x2e95759e60e0}, {0x4f5b8e8, 0x2e9574700640})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95735b2f00, {0x4f7afd0, 0x2e95759e60e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e95759e60e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e95759e60e0?}, 0x2e95742b2e78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e95759e60e0}, {0x4f6a460, 0x2e95758a0400}, 0x1, 0x1, 0x2e95759e3f68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95735b2f00, {0x4f7afd0, 0x2e95759e60e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x27dc942?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 354
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 343 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e95759e6310}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e95751b6640}, {0x4f8fca0, 0x2e95758a01a0}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e95759e6310?}, {0x2e9573e90400?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e95751b6640?}, {0x4f8fca0?, 0x2e95758a01a0?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95735b3200, {0x4f7afd0, 0x2e95759e6310}, {0x4f5b8e8, 0x2e95751b6640}, 0x2e9572e0e620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95735b3200, {0x4f7afd0, 0x2e95759e6310}, {0x4f5b8e8, 0x2e9574798960})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95735b3200, {0x4f7afd0, 0x2e95759e6310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e95759e6310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e95759e6310?}, 0x2e95758afe78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e95759e6310}, {0x4f6a460, 0x2e95758a0680}, 0x1, 0x1, 0x2e95759ddf68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95735b3200, {0x4f7afd0, 0x2e95759e6310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/loadbalancer/reflectors.serviceEvents.ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.serviceEvents.ListerWatcherToObservable.func2 in goroutine 356
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 264 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 261
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 265 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e957502f6c0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e95745a73b0}, {0x7bdc8e993e30, 0x2e957421cee0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e957502f6c0?}, {0x2e9573a26b90?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e95745a73b0?}, {0x7bdc8e993e30?, 0x2e957421cee0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95735b2400, {0x4f7afd0, 0x2e957502f6c0}, {0x4f5b8e8, 0x2e95745a73b0}, 0x2e95733af260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95735b2400, {0x4f7afd0, 0x2e957502f6c0}, {0x4f5b8e8, 0x2e95735559f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95735b2400, {0x4f7afd0, 0x2e957502f6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e957502f6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e957502f6c0?}, 0x2e95741fe658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e957502f6c0}, {0x4f6a460, 0x2e95750ba5e0}, 0x1, 0x1, 0x2e95757a3f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95735b2400, {0x4f7afd0, 0x2e957502f6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 261
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 324 [select, 52 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd20c0, {0x4f78938, 0x2e957370b6b0}, {0x4f909a0, 0x2e9573ed58c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573d48960, {0x4f78938, 0x2e957370b6b0}, {0x4f909a0, 0x2e9573d488a0}, {{{0x2e957371b480, 0x1, 0x1}}, 0x2e9573f04cb0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 342 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 354
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 344 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e95759e6310}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e957576f900}, {0x4f8fca0, 0x2e95758a0240}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e95759e6310?}, {0x2e95743c7698?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e957576f900?}, {0x4f8fca0?, 0x2e95758a0240?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95735b3300, {0x4f7afd0, 0x2e95759e6310}, {0x4f5b8e8, 0x2e957576f900}, 0x2e9572e0ee70)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95735b3300, {0x4f7afd0, 0x2e95759e6310}, {0x4f5b8e8, 0x2e9574798b40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95735b3300, {0x4f7afd0, 0x2e95759e6310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e95759e6310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e95759e6310?}, 0x2e95750c0e78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e95759e6310}, {0x4f6a460, 0x2e95758a08c0}, 0x1, 0x1, 0x2e95759dff68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95735b3300, {0x4f7afd0, 0x2e95759e6310})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/loadbalancer/reflectors.endpointsEvents.ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.endpointsEvents.ListerWatcherToObservable.func2 in goroutine 356
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 1026 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/envoy.(*adsServer).startAdsGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpcnew.go:76 +0x35
created by github.com/cilium/cilium/pkg/envoy.(*adsServer).startAdsGRPCServer in goroutine 403
	/go/src/github.com/cilium/cilium/pkg/envoy/grpcnew.go:75 +0x807

goroutine 313 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 298
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 298 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e957502f8f0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9576c8f720}, {0x7bdc8e993e30, 0x2e9574cb9a40}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e957502f8f0?}, {0x2e9573b021a0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9576c8f720?}, {0x7bdc8e993e30?, 0x2e9574cb9a40?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e957371da00, {0x4f7afd0, 0x2e957502f8f0}, {0x4f5b8e8, 0x2e9576c8f720}, 0x2e9572de4d90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e957371da00, {0x4f7afd0, 0x2e957502f8f0}, {0x4f5b8e8, 0x2e957359fa40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e957371da00, {0x4f7afd0, 0x2e957502f8f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e957502f8f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e957502f8f0?}, 0x2e95758ade58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e957502f8f0}, {0x4f6a460, 0x2e9575828160}, 0x1, 0x1, 0x2e95757a7f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e957371da00, {0x4f7afd0, 0x2e957502f8f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 294
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 128477 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9575893c80, 0x2e9574ffd040, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9575893c80, 0x2e9573952850?, 0x2e9573952890?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 432
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 766 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95738b5b00, {0x4f78970, 0x2e9575585630}, 0x2e9572d80a10)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 788
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 304 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8ed2c800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e957582c980?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e957582c980)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e957582c980)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x41cffe?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x2e957370ab40)
	/usr/local/go/src/net/unixsock.go:267 +0x30
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x2e957370aba0, {0x4f78970, 0x2e9573469ae0}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:81 +0xe3
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:67 +0x1a5

goroutine 322 [select, 24 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9573d486c0, {0x4f78938, 0x2e957370afc0}, {0x4f909a0, 0x2e9573d48600}, {{{0x0, 0x0, 0x0}}, 0x2e9573df2e40, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 340 [select, 171 minutes]:
github.com/cilium/cilium/pkg/fqdn/namemanager.New.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xe8
created by github.com/cilium/cilium/pkg/fqdn/namemanager.New.FromChannel[...].func2 in goroutine 359
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 417 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 352
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 118958 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e979a00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9574fb5100?, 0x2e9577bfb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9574fb5100, {0x2e9577bfb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9574fb5100, {0x2e9577bfb000?, 0x50ce20?, 0x2e9574fb5100?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9576e12658, {0x2e9577bfb000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x2e9576cbaa40, {0x2e9577bfb000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x2e95752224e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e95752224e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x2e9576861c20, {0x4f78938, 0x2e95738c52c0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 543
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 268 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 265
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 269 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95735b2400, {0x4f78970, 0x2e9573555a40}, 0x2e95733af260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 265
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 319 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:76 +0x2c
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 304
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:75 +0xa5

goroutine 315 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 301
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 318 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 301
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 316 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x2e95750c7f58?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 301
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 317 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0x2e95758d4410, 0x47)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc34c0, {0x4f78970, 0x2e95745be0f0}, 0x2e95750f69a0, {0x4fa4cb0, 0x2e95750b2b30})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 301
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 325 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd20c0, {0x4f78938, 0x2e957370b8c0}, {0x4f909a0, 0x2e9573ed5980})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573d489c0, {0x4f78938, 0x2e957370b8c0}, {0x4f909a0, 0x2e9573d488a0}, {{{0x2e957371b480, 0x1, 0x1}}, 0x2e9573f04cb0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 403 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8ed2c000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575879800?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9575879800)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9575879800)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x460d20?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x2e9573772060)
	/usr/local/go/src/net/unixsock.go:267 +0x30
google.golang.org/grpc.(*Server).Serve(0x2e9575312008, {0x4f66810, 0x2e9573772060})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:934 +0x45c
github.com/cilium/cilium/pkg/envoy.(*adsServer).startAdsGRPCServer(0x2e9573281040, {0x4f78938, 0x2e9573765e90})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpcnew.go:83 +0x825
github.com/cilium/cilium/pkg/envoy.(*adsServer).run(0x492cce?, {0x4f78938?, 0x2e9573765e90?})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds_server_ads.go:138 +0x1d
github.com/cilium/cilium/pkg/envoy.newEnvoyXDSServer.func1({0x4f78938?, 0x2e9573765e90?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/envoy/cell.go:145 +0x2f
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574483860, {0x4f78938, 0x2e9573765e90}, {0x4f909a0, 0x2e9574483680}, {{{0x2e95733f9ce0, 0x1, 0x1}}, 0x2e9573e31410, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 327 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x2e957491d4a0, 0x2e9575809880, 0x2e9575809960, 0x2e95758099d0, 0x2e9575809a40)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:367 +0x2f1
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x2e957491d4a0, {0x4f78970?, 0x2e9574596460?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:247 +0x596
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x2e957491d4a0, {0x4f78970, 0x2e9574596460})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:179 +0x9c
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:153 +0x125

goroutine 328 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:382 +0x25
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:381 +0x146

goroutine 329 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7bdc8ed2c200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9573c97bc0?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x2e9573c97bc0, 0x2e957595fd28)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x2e957595fd20, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x2e95738c86f0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:398 +0x91
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:395 +0x33f

goroutine 330 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1817 +0x25
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1816 +0x146

goroutine 331 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e996800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9573c97c20?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x2e9573c97c20, 0x2e957593f870)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x2e957593f868, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xd?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1833 +0x91
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1830 +0x33f

goroutine 332 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2617 +0x25
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2616 +0x139

goroutine 333 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e996600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9573c97c80?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x2e9573c97c80, 0x2e957597fe60)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x2e957597fe58, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x2e957597fed8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2633 +0x85
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2630 +0x325

goroutine 334 [chan receive, 171 minutes]:
github.com/vishvananda/netlink.neighSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:431 +0x25
created by github.com/vishvananda/netlink.neighSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:430 +0x1cd

goroutine 335 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e996400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9573c97ce0?, 0x72?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x2e9573c97ce0, 0x2e957599fe10)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
os.(*rawConn).Read(0x2e957599fe08, 0x0?)
	/usr/local/go/src/os/rawconn.go:31 +0x4a
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x2e9573656970?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:937 +0x190
github.com/vishvananda/netlink.neighSubscribeAt.func3()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:444 +0x97
created by github.com/vishvananda/netlink.neighSubscribeAt in goroutine 327
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/neigh_linux.go:441 +0x3f3

goroutine 336 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e957584c640)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 353 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x2e9573d1ab40, {0x4f78938, 0x2e9573745ce0}, {0x4f909a0, 0x2e9573ed5d40})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:389 +0x24b
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574483500, {0x4f78938, 0x2e9573745ce0}, {0x4f909a0, 0x2e9573d48ae0}, {{{0x2e957371bba0, 0x1, 0x1}}, 0x2e9573d5fdc0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 354 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5003ee0, {0x4f78938, 0x2e957374a180}, {0x4f909a0, 0x2e9574b7a720})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573d490e0, {0x4f78938, 0x2e957374a180}, {0x4f909a0, 0x2e9573d49020}, {{{0x2e9573725b40, 0x1, 0x1}}, 0x2e9573f88820, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 355 [select, 2 minutes]:
reflect.rselect({0x2e9575597970, 0x4, 0x230020?})
	/usr/local/go/src/runtime/select.go:616 +0x3cd
reflect.Select({0x2e9574fa8620?, 0x4, 0x2e9575597b10?})
	/usr/local/go/src/reflect/value.go:3018 +0x5a7
github.com/cilium/statedb.(*WatchSet).Wait(0x2e95738c88d0, {0x4f78938, 0x2e957374ac90}, 0x5f5e100)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/watchset.go:123 +0x545
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x2e9572dfed20, {0x4f78938, 0x2e957374ac90}, 0x492cce?, {0x4f909a0, 0x2e9574b7a8a0})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:259 +0x48
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).register.func1.1({0x4f78938?, 0x2e957374ac90?}, {0x4f909a0?, 0x2e9574b7a8a0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:249 +0x45
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95742a8d20, {0x4f78938, 0x2e957374ac90}, {0x4f909a0, 0x2e9573d49140}, {{{0x2e9573728b00, 0x1, 0x1}}, 0x2e9573f88dc0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 356 [chan receive, 170 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runServiceEndpointsReflector({_, _}, {_, _}, {{{}}, 0x2e9573e3b800, 0x2e9573f880c0, {0x4f78c48, 0x2e95737250e0}, {0x4f50fe0, ...}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:442 +0x407
github.com/cilium/cilium/pkg/loadbalancer/reflectors.RegisterK8sReflector.func1({0x4f78938?, 0x2e957374aed0?}, {0x4f909a0?, 0x2e9574b7aa20?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:112 +0x94
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573d49440, {0x4f78938, 0x2e957374aed0}, {0x4f909a0, 0x2e9573d48f60}, {{{0x2e9573725120, 0x1, 0x1}}, 0x2e9573f880c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 357 [chan receive, 170 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runPodReflector({_, _}, {_, _}, {{{}}, 0x2e9573e3b800, 0x2e9573f880c0, {0x4f78c48, 0x2e95737250e0}, {0x4f50fe0, ...}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:198 +0x3ba
github.com/cilium/cilium/pkg/loadbalancer/reflectors.RegisterK8sReflector.func2({0x4f78938?, 0x2e957374b110?}, {0x4f909a0?, 0x2e9574b7ad20?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reflectors/k8s.go:120 +0x94
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573d49500, {0x4f78938, 0x2e957374b110}, {0x4f909a0, 0x2e9573d48f60}, {{{0x2e9573725120, 0x1, 0x1}}, 0x2e9573f880c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1028 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575aea160)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1025
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 359 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9d6c0, {0x4f78938, 0x2e957374b7a0}, {0x4f909a0, 0x2e9574482ae0}, {{{0x2e95733f2160, 0x1, 0x1}}, 0x2e9573b51330, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 360 [select, 2 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd23c0, {0x4f78938, 0x2e957374b980}, {0x4f909a0, 0x2e95742a93e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574483260, {0x4f78938, 0x2e957374b980}, {0x4f909a0, 0x2e95744831a0}, {{{0x2e95733f8120, 0x1, 0x1}}, 0x2e9573b68e20, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 361 [select, 2 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd23c0, {0x4f78938, 0x2e957374bbf0}, {0x4f909a0, 0x2e95742a9620})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95744832c0, {0x4f78938, 0x2e957374bbf0}, {0x4f909a0, 0x2e95744831a0}, {{{0x2e95733f8120, 0x1, 0x1}}, 0x2e9573b68e20, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 362 [select, 171 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e957586c000)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 369 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 341
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 352 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x4f78938, 0x2e95737585d0}, 0x2e9573b681f0, {0x4f909a0, 0x2e9574a120c0}, 0x1, 0x2e9573280d40, 0x2e9575bc7bb8, 0x2e9575bc7ba8, 0x2e9575bc7b98, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:203 +0xa90
github.com/cilium/cilium/pkg/datapath/iptables.newManager.func2({0x4f78938, 0x2e95737585d0}, {0x4f909a0, 0x2e9574a120c0})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:483 +0x1dd
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574483620, {0x4f78938, 0x2e95737585d0}, {0x4f909a0, 0x2e9574483560}, {{{0x2e95733f9440, 0x1, 0x1}}, 0x2e9573b681f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 131185 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e957777ca80, 0x2e95735efa40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e957777ca80, 0x2e9574206440?, 0x2e9574206450?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 703
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 373 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95735b3200, {0x4f78970, 0x2e9574798a50}, 0x2e9572e0e620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 343
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 372 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 343
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 411 [syscall]:
syscall.Syscall6(0xe8, 0x2f, 0x2e9574f34b70, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:96 +0x39
golang.org/x/sys/unix.EpollWait(0x83408e0?, {0x2e9574f34b70?, 0x2?, 0x2?}, 0xffffffffffffffff?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x2e9575ae8c40, {0x2e9574f34b70, 0x2, 0x2}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:181 +0x225
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x2e9574f9efc0, 0x2e9575e2de68)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:364 +0x2df
github.com/cilium/ebpf/perf.(*Reader).Read(0x2e9573cfc830?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:331 +0x3d
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:271 +0x67
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:268 +0x156

goroutine 413 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9f3e0, {0x4f78938, 0x2e957379cff0}, {0x4f909a0, 0x2e9574b7bb00}, {{{0x2e95735b1360, 0x1, 0x1}}, 0x2e9573cfc530, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 405 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd2300, {0x4f78938, 0x2e9573770840}, {0x4f909a0, 0x2e9575b12240})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574b7a1e0, {0x4f78938, 0x2e9573770840}, {0x4f909a0, 0x2e9574483bc0}, {{{0x2e9573449ac0, 0x1, 0x1}}, 0x2e9573bbcbb0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 375 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 344
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 376 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95735b3300, {0x4f78970, 0x2e9574798d70}, 0x2e9572e0ee70)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 344
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 404 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd2300, {0x4f78938, 0x2e95737705d0}, {0x4f909a0, 0x2e9575b122a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574b7a180, {0x4f78938, 0x2e95737705d0}, {0x4f909a0, 0x2e9574483bc0}, {{{0x2e9573449ac0, 0x1, 0x1}}, 0x2e9573bbcbb0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 419 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).run.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:65 +0x2c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).run in goroutine 402
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:64 +0x197

goroutine 410 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/orchestrator.(*orchestrator).reconciler(0x2e9573377808, {0x4f78938, 0x2e957379cb10}, {0x4f909a0, 0x2e9575b134a0})
	/go/src/github.com/cilium/cilium/pkg/datapath/orchestrator/orchestrator.go:271 +0xf5c
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574b7ba40, {0x4f78938, 0x2e957379cb10}, {0x4f909a0, 0x2e9574b7b980}, {{{0x2e95735a9a60, 0x1, 0x1}}, 0x2e9573ce4210, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 409 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9575acc0c0, {0x4f78938, 0x2e9573771d70}, {0x4f909a0, 0x2e9574482fc0}, {{{0x2e95733f2d60, 0x1, 0x1}}, 0x2e9573b51d10, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 406
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 412 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9f3e0, {0x4f78938, 0x2e957379ce40}, {0x4f909a0, 0x2e9574b7bb00}, {{{0x2e95735b1360, 0x1, 0x1}}, 0x2e9573cfc530, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 408 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5000cc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 424 [select]:
github.com/cilium/cilium/pkg/loadbalancer/reflectors.runPodReflector.Buffer[...].func3.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x12b
created by github.com/cilium/cilium/pkg/loadbalancer/reflectors.runPodReflector.Buffer[...].func3 in goroutine 357
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 415 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5004060, {0x4f78938, 0x2e957379d3b0}, {0x4f909a0, 0x2e9575b135c0})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95742a8000, {0x4f78938, 0x2e957379d3b0}, {0x4f909a0, 0x2e9573d49020}, {{{0x2e9573725b40, 0x1, 0x1}}, 0x2e9573f88820, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 416 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x50005e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 433 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5006b80, {0x4f78938, 0x2e957379d6e0}, {0x4f909a0, 0x2e9575b138c0})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95742a8360, {0x4f78938, 0x2e957379d6e0}, {0x4f909a0, 0x2e95742a82a0}, {{{0x2e95736b1900, 0x1, 0x1}}, 0x2e9573d12ef0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1342 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9eba00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95750cb280?, 0x2e95737ba000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e95750cb280, {0x2e95737ba000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e95750cb280, {0x2e95737ba000?, 0x50ce20?, 0x2e95750cb280?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9572eed0d8, {0x2e95737ba000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x2e9573ab5680, {0x2e95737ba000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x2e95773ec720)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e95773ec720, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x2e95749e87e0, {0x4f78938, 0x2e95738c52c0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 543
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 435 [select, 170 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x2e9572ea43f0, {0x4f78938, 0x2e957379dbc0}, {0x2e9575b9dc20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:213 +0xc5
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95742a8840, {0x4f78938, 0x2e957379dbc0}, {0x4f909a0, 0x2e95742a8780}, {{{0x2e95736e2140, 0x1, 0x1}}, 0x2e9573d66250, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 427 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0xeb
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 412
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 428 [chan receive, 171 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0xeb
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 413
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x345

goroutine 429 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575b947e0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9577a04e10}, {0x4f8fca0, 0x2e9575b15680}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575b947e0?}, {0x2e9574418be8?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9577a04e10?}, {0x4f8fca0?, 0x2e9575b15680?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9573be5100, {0x4f7afd0, 0x2e9575b947e0}, {0x4f5b8e8, 0x2e9577a04e10}, 0x2e9572ed6230)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9573be5100, {0x4f7afd0, 0x2e9575b947e0}, {0x4f5b8e8, 0x2e9575bbe5a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9573be5100, {0x4f7afd0, 0x2e9575b947e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575b947e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575b947e0?}, 0x2e9575867678?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575b947e0}, {0x4f6a460, 0x2e9575b15700}, 0x1, 0x1, 0x2e9575b8df68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9573be5100, {0x4f7afd0, 0x2e9575b947e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x90309b?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 415
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 430 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 415
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 432 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575b95b90}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e957530a780}, {0x4f8fca0, 0x2e9575b15ae0}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575b95b90?}, {0x2e9573a85070?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e957530a780?}, {0x4f8fca0?, 0x2e9575b15ae0?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9573be5200, {0x4f7afd0, 0x2e9575b95b90}, {0x4f5b8e8, 0x2e957530a780}, 0x2e95759fccb0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9573be5200, {0x4f7afd0, 0x2e9575b95b90}, {0x4f5b8e8, 0x2e9576a940a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9573be5200, {0x4f7afd0, 0x2e9575b95b90})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575b95b90})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575b95b90?}, 0x2e9575864e78?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575b95b90}, {0x4f6a460, 0x2e9575b15b60}, 0x1, 0x1, 0x2e9575ba1f68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9573be5200, {0x4f7afd0, 0x2e9575b95b90})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x45f690?, 0x2e9575864fd0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 433
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 449 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 433
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 559 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x2e9575d7d540)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:126 +0x97
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:281 +0xab2

goroutine 436 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e95742a89c0, {0x4f78938, 0x2e95737be6c0}, {0x4f909a0, 0x2e95742a8900}, {{{0x2e95736e30e0, 0x1, 0x1}}, 0x2e9573d66c80, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 451 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 410
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 452 [select, 171 minutes]:
github.com/cilium/stream.ToTruncatingChannel[...].func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sinks.go:161 +0x194
created by github.com/cilium/stream.ToTruncatingChannel[...] in goroutine 410
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sinks.go:154 +0xb9

goroutine 453 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 451
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 455 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9b600, {0x4f78938, 0x2e957379f590}, {0x4f909a0, 0x2e9573d48600}, {{{0x2e957371a920, 0x1, 0x1}}, 0x2e9573df2e40, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 456 [select, 171 minutes]:
github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.FromChannel[...].func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb9
created by github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.FromChannel[...].func1 in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 457 [select]:
github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.Buffer[...].func2.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x137
created by github.com/cilium/cilium/pkg/policy/cell.newPolicyImporter.Buffer[...].func2 in goroutine 455
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 437 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x2e95742a8f00, {0x4f78938, 0x2e95737beff0}, {0x4f909a0, 0x2e9575acce40})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:115 +0x365
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95742a8f60, {0x4f78938, 0x2e95737beff0}, {0x4f909a0, 0x2e95742a8e40}, {{{0x2e9573724200, 0x1, 0x1}}, 0x2e9573d988f0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 438 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 439 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 440 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc34c0, {0x4f78970, 0x2e957473ce60}, 0x2e9575af1b20, {0x4fa4cb0, 0x2e95750b2b30})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:591 +0x551
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 441 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 1
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 442 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ec800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575ae7b00?, 0x57d4ec?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9575ae7b00)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9575ae7b00)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x2e9575ae9700)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x2e9575ae9700)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*wrappedTCPListener).Accept(0x2e9573998bd0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:1354 +0x24
github.com/cilium/dns.(*Server).serveTCP(0x2e9573d5c500, {0x4f70c30, 0x2e9573998bd0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0x107
github.com/cilium/dns.(*Server).ActivateAndServe(0x2e9573d5c500)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x22b
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen.func1(0x2e9573d5c500)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:665 +0x29b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen in goroutine 454
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:654 +0x46e

goroutine 443 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e996e00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575ae7b80?, 0x2e9575cc6200?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x2e9575ae7b80, {0x2e9575cc6200, 0x200, 0x200}, {0x2e9573804090, 0x2c, 0x2c}, 0x0, 0x2e95757e0aa8)
	/usr/local/go/src/internal/poll/fd_unix.go:322 +0x32a
net.(*netFD).readMsgInet4(0x2e9575ae7b80, {0x2e9575cc6200?, 0x2e95757e0a80?, 0x476d0c?}, {0x2e9573804090?, 0xa5000a?, 0x2e95757e0a80?}, 0x1bf01c001f80ab0?, 0x2e95757e0a90?)
	/usr/local/go/src/net/fd_posix.go:97 +0x31
net.(*UDPConn).readMsg(0x48dd3b?, {0x2e9575cc6200?, 0x960db15d3c1?, 0x0?}, {0x2e9573804090?, 0x441d680?, 0x7bdc8e996f20?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x175
net.(*UDPConn).ReadMsgUDPAddrPort(0x2e9574b09c78, {0x2e9575cc6200?, 0x4a0edd?, 0x83b0f80?}, {0x2e9573804090?, 0x2e95757e0c08?, 0x4a0ce5?})
	/usr/local/go/src/net/udpsock.go:200 +0x3e
net.(*UDPConn).ReadMsgUDP(0x2e9575ae9a48?, {0x2e9575cc6200?, 0x4381ca0?, 0x2e9575ae7b80?}, {0x2e9573804090?, 0x2e95757e0c68?, 0x425c85?})
	/usr/local/go/src/net/udpsock.go:188 +0x25
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x2e9574b09c78?, 0x2e9574b09c78)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:163 +0x5f
github.com/cilium/dns.(*Server).readUDP(0x2e9573d5c600, 0x2e9574b09c78, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0xe2
github.com/cilium/dns.defaultReader.ReadUDP({0x2e9573d5c600?}, 0x441b1a0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x13
github.com/cilium/dns.(*Server).serveUDP(0x2e9573d5c600, {0x4fa4290, 0x2e9574b09c78})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x242
github.com/cilium/dns.(*Server).ActivateAndServe(0x2e9573d5c600)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x19a
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen.func1(0x2e9573d5c600)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:665 +0x29b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*DNSProxy).Listen in goroutine 454
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:654 +0x46e

goroutine 445 [select, 170 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:188 +0x245
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:159 +0xf2

goroutine 775 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 639
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 1048 [syscall, 171 minutes]:
syscall.Syscall6(0xf7, 0x3, 0x5e, 0x2e95757dedd8, 0x4, 0x2e9572d7bef0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:96 +0x39
internal/syscall/unix.Waitid(0x0?, 0x0?, 0x2e95757dede8?, 0x50d692?, 0x2e95757dedf0?)
	/usr/local/go/src/internal/syscall/unix/waitid_linux.go:18 +0x39
os.(*Process).pidfdWait.func1(...)
	/usr/local/go/src/os/pidfd_linux.go:108
os.ignoringEINTR(...)
	/usr/local/go/src/os/file_posix.go:263
os.(*Process).pidfdWait(0x2e95736f5040)
	/usr/local/go/src/os/pidfd_linux.go:107 +0x1c7
os.(*Process).wait(0x2e9573716490?)
	/usr/local/go/src/os/exec_unix.go:25 +0x1a
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:346
os/exec.(*Cmd).Wait(0x2e95732576c0)
	/usr/local/go/src/os/exec/exec.go:930 +0x45
github.com/cilium/cilium/pkg/health.(*ciliumHealthManager).launchAsEndpoint.func3()
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_endpoint.go:340 +0x31
created by github.com/cilium/cilium/pkg/health.(*ciliumHealthManager).launchAsEndpoint in goroutine 1042
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_endpoint.go:339 +0x10e9

goroutine 448 [chan receive, 24 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:125 +0x10d
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:122 +0x12e

goroutine 804 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9575eb3a00, {0x4f78970, 0x2e9575585810}, 0x2e9572dc2070)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 771
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 466 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:85 +0x119
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:82 +0x12e

goroutine 1003 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x2e9574fb1c70})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e957582f8c0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 566
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 468 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 469 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 468
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 687 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func7()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:371 +0x2c
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:370 +0x1adf

goroutine 558 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 1214 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575bcd340)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1204
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 459 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 410
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 472 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575cbf080)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 532 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:149 +0x18c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:147 +0x3a7

goroutine 1381 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773b4dc0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1227
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 475 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x2e9575aff29c?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 448
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 476 [sync.Cond.Wait, 24 minutes]:
sync.runtime_notifyListWait(0x2e9575ce9290, 0x18)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc3140, {0x4f78970, 0x2e9575cec7d0}, 0x2e9575ce39d0, {0x4fa4a80, 0x2e9575cd95a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 448
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 477 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 448
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 765 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 788
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 479 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 466
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 480 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 466
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 481 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9575ce9390, 0x4)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc3440, {0x4f78970, 0x2e9575cec8c0}, 0x2e9575ce3c70, {0x4fa4c60, 0x2e95757fab40})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 466
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 482 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 466
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 461 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 429
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 462 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9573be5100, {0x4f78970, 0x2e9575bbe690}, 0x2e9572ed6230)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 429
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 483 [sync.Cond.Wait, 24 minutes]:
sync.runtime_notifyListWait(0x2e9574f9f0f0, 0xb)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573649e00?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574f9f0a0, 0x2e9575ce9cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575af80b0, {0x4f7afd0, 0x2e95750f6c40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e95750f6c40?}, 0x2e9573820180?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e95750f6c40}, 0x2e9575cddea0, {0x4f0fa20, 0x2e9573820180}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e95750f6c40}, 0x2e9575aadea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575af80b0, {0x4f7afd0, 0x2e95750f6c40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x4532fe0?, 0x2e9573745cb0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e9575cee980, 0x2e95750f6c40)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 302
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 643 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 486 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 483
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 487 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e95750f6c40}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9576ee0910}, {0x7bdc8e993e30, 0x2e9574f9f0a0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e95750f6c40?}, {0x2e9573961118?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9576ee0910?}, {0x7bdc8e993e30?, 0x2e9574f9f0a0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9573d5d600, {0x4f7afd0, 0x2e95750f6c40}, {0x4f5b8e8, 0x2e9576ee0910}, 0x2e9572ef5c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9573d5d600, {0x4f7afd0, 0x2e95750f6c40}, {0x4f5b8e8, 0x2e9575ceceb0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9573d5d600, {0x4f7afd0, 0x2e95750f6c40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e95750f6c40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e95750f6c40?}, 0x2e95750cee58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e95750f6c40}, {0x4f6a460, 0x2e9575ceeba0}, 0x1, 0x1, 0x2e9575d11f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9573d5d600, {0x4f7afd0, 0x2e95750f6c40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 483
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 642 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func5()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:317 +0x2c
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:316 +0x133f

goroutine 560 [syscall]:
syscall.Syscall6(0xe8, 0x47, 0x2e9576037890, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:96 +0x39
golang.org/x/sys/unix.EpollWait(0x4f085e0?, {0x2e9576037890?, 0x8?, 0x8?}, 0x42f596?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x2e9576315c00, {0x2e9576037890, 0x2, 0x2}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:181 +0x225
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x2e9574f9f420, 0x2e9575bf7e58)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:364 +0x2df
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:331
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x2e9572dcd490, {0x4f78970, 0x2e9575e77360})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:349 +0x488
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:213 +0xd0

goroutine 641 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ec400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575f4e580?, 0x9a85a5?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9575f4e580)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9575f4e580)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x2e95760378a8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x2e9573896030)
	/usr/local/go/src/net/unixsock.go:267 +0x30
google.golang.org/grpc.(*Server).Serve(0x2e957530f688, {0x4f66810, 0x2e9573896030})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:934 +0x45c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:94
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func4()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:309 +0x4a
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:308 +0x12d4

goroutine 126645 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9577586948, 0x8)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9576618b80?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9577586930, {0x2e9575d40601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x8b?}, {0x2e9575d40601?, 0x425234?, 0x2e957639dc98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e9572eddb80)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e9572eddb80)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e9572eddb80, {0x418d900, 0x2e9573a62ed0})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e957370d920, {0x2e9576651c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9577a545f0, 0x0, {0x4f57f10, 0x2e95757ea500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95733f25e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9577a54640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 788
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 1213 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x2e9573b677c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1204
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 1212 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x2e95771ed270})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575bcc160)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1204
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 803 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 771
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 118963 [select]:
net/http.(*persistConn).writeLoop(0x2e957362c000)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 118961
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 1348 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:467 +0xc5
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1362
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:460 +0x4f

goroutine 1041 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:363 +0x165
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:90
github.com/cilium/cilium/pkg/health.(*CiliumHealth).runServer(0x2e9573113c80, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:136 +0x3bd
created by github.com/cilium/cilium/pkg/health.(*ciliumHealthManager).launchCiliumNodeHealth in goroutine 537
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:77 +0x5c5

goroutine 1007 [select, 171 minutes]:
github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe.func1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:157 +0x356
created by github.com/cilium/cilium/pkg/node.(*LocalNodeStore).Observe in goroutine 566
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:137 +0xa8

goroutine 1288 [select, 50 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x2e9574989380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1214 +0x1e5
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1286
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:371 +0x1929

goroutine 1289 [IO wait, 52 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ba400, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x81?, 0x4dcf072?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).RawRead(0x2e95735fb080, 0x2e9575fc3650)
	/usr/local/go/src/internal/poll/fd_unix.go:710 +0x125
net.(*rawConn).Read(0x2e9574cea508, 0x2e9575bffbb8?)
	/usr/local/go/src/net/rawconn.go:44 +0x36
google.golang.org/grpc/internal/transport/readyreader.(*nonBlockingReader).ReadOnReady(0x2e95755505a0, 0x2e9575bffc18?, {0x4f57668, 0x2e9573b046c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/readyreader/ready_reader.go:114 +0xa7
google.golang.org/grpc/internal/transport/readyreader.(*bufReadyReader).Read(0x2e9577387420, {0x2e9574f9e9e4, 0x9, 0x4696740?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/readyreader/ready_reader.go:221 +0x174
io.ReadAtLeast({0x4f0e6e0, 0x2e9577387420}, {0x2e9574f9e9e4, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x8e
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x2e9574f9e9e4, 0x9, 0xaedad2?}, {0x4f0e6e0?, 0x2e9577387420?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:250 +0x65
golang.org/x/net/http2.(*Framer).ReadFrameHeader(0x2e9574f9e9a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:513 +0x6b
google.golang.org/grpc/internal/transport.(*framer).readFrame(0x2e95735fb200)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http_util.go:493 +0x45
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x2e9574989380, {0x4f78938, 0x2e9573b048d0}, 0x2e9573b04900)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:646 +0xff
google.golang.org/grpc.(*Server).serveStreams(0x2e9575312008, {0x4f78778?, 0x88ffe40?}, {0x4f7ae10, 0x2e9574989380}, {0x4faaec0?, 0x2e9574cea500?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1072 +0x368
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1006 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1286
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1005 +0x1cb

goroutine 1476 [sync.WaitGroup.Wait, 170 minutes]:
sync.runtime_SemacquireWaitGroup(0x9095c33e60d2f475?, 0x0?)
	/usr/local/go/src/runtime/sema.go:114 +0x2e
sync.(*WaitGroup).Wait(0x2e9573cd8108)
	/usr/local/go/src/sync/waitgroup.go:206 +0x85
golang.org/x/sync/errgroup.(*Group).Wait(0x2e9573cd8100)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:56 +0x1e
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0x2e957476dc20, 0x41b3c00?, {0x4fa81f0, 0x2e9573d98e90})
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:106 +0x416
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler({0x41b3c00, 0x2e957476dc20}, {0x4f9a8c0, 0x2e95738b5a00})
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:116 +0x110
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.serverVersionStreamInterceptor.func33({0x41b3c00, 0x2e957476dc20}, {0x4f9a8c0, 0x2e95738b5a00}, 0x3cdd8a0?, 0x4ee9ef8)
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:392 +0x58
google.golang.org/grpc.(*Server).processStreamingRPC(0x2e957531f688, {0x4f78938, 0x2e95733fa060}, 0x2e9574ce3180, 0x2e95739ac030, 0x835f660, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1736 +0x1171
google.golang.org/grpc.(*Server).handleStream(0x2e957531f688, {0x4f7ae10, 0x2e95758b4000}, 0x2e9574ce3180)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1862 +0xaa5
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1078 +0x7f
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1475
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1089 +0x11d

goroutine 1350 [IO wait, 16 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e944a00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9574fb4e00?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9574fb4e00)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9574fb4e00)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x2e957569bdf8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x2e9576afabd0)
	/usr/local/go/src/net/unixsock.go:267 +0x30
net/http.(*Server).Serve(0x2e9576aca500, {0x4f66810, 0x2e9576afabd0})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x4f66810?, 0x2e9576afabd0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:365 +0x72
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1362
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:363 +0x485

goroutine 129301 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9574f84300, 0x2e95757f8b40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9574f84300, 0x764b37?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 487
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 130157 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9577586f48, 0x5)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e95756c0780?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9577586f30, {0x2e9573faa790, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e95758efcc8?}, {0x2e9573faa790?, 0x2e95758efcc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9577586f00}, {0x2e9573faa790, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e9576917440, {0x2e9572f3ef00, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e95745a7360, 0x0, {0x4f57f10, 0x2e9574fd1840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e957312e840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e95745a73b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 265
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 555 [select]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x2e9575e766e0)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:165 +0xa5
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 538
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:151 +0x356

goroutine 637 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9574cb9d30, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574cb9ce0, 0x2e9575fbd7c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575efe370, {0x4f7afd0, 0x2e9575e815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e9575e815e0?}, 0x2e957399e5a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e9575e815e0}, 0x2e9575d50ea0, {0x4f0fa20, 0x2e957399e5a0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e9575e815e0}, 0x2e9575d50ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575efe370, {0x4f7afd0, 0x2e9575e815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x2e9575d69a40?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e9575fa3b40, 0x2e9575e815e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 578
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 535 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e9575dcc5a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 536 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x4f8f3a0?, 0x2e9573a2e4e0?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x2e9575cea3c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 1182 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e957586d4a0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1042
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 494 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9573d5d600, {0x4f78970, 0x2e9575ced040}, 0x2e9572ef5c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 487
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 493 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 487
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 686 [IO wait, 170 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9f2600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9576350000?, 0x900000036?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9576350000)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9576350000)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x2e9576315500)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x2e9576315500)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
google.golang.org/grpc.(*Server).Serve(0x2e957531f688, {0x4f690b0, 0x2e9576315500})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:934 +0x45c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:94
github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch.func6()
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:361 +0x4a
created by github.com/cilium/cilium/pkg/hubble/cell.(*hubbleIntegration).launch in goroutine 541
	/go/src/github.com/cilium/cilium/pkg/hubble/cell/hubbleintegration.go:360 +0x1a77

goroutine 539 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9574a13d40, {0x4f78938, 0x2e9573878570}, {0x4f909a0, 0x2e9574a13c80}, {{{0x2e9573775e80, 0x1, 0x1}}, 0x2e9573ccbca0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 540 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9574b7be00, {0x4f78938, 0x2e95738787b0}, {0x4f909a0, 0x2e9574a13860}, {{{0x2e9573774a60, 0x1, 0x1}}, 0x2e9573ccab00, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 688 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 558
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 542 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/status.newStatusCollector.func1({0x4f78938, 0x2e9573878bd0}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/status/cell.go:160 +0x394
github.com/cilium/hive/job.(*jobOneShot).start(0x2e957476a5a0, {0x4f78938, 0x2e9573878bd0}, {0x4f909a0, 0x2e95742a91a0}, {{{0x2e9573728c20, 0x1, 0x1}}, 0x2e9573db3730, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 543 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ebc00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575d83580?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e9575d83580)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e9575d83580)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x2e9575d4cdf8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x2e9573878d80)
	/usr/local/go/src/net/unixsock.go:267 +0x30
net/http.(*Server).Serve(0x2e9573be5a00, {0x4f66810, 0x2e9573878d80})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x4f66810?, 0x2e9573878d80?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:453 +0x72
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:451 +0x4a5

goroutine 544 [select, 2 minutes]:
github.com/cilium/cilium/pkg/metrics.(*sampler).collectLoop(0x2e9573959ce0, {0x4f78938, 0x2e9573878f90}, {0x4f909a0, 0x2e9575f7ede0})
	/go/src/github.com/cilium/cilium/pkg/metrics/sampler.go:305 +0x119
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd2540, {0x4f78938, 0x2e9573878f90}, {0x4f909a0, 0x2e9573373560}, {{{0x2e95736c0fe0, 0x1, 0x1}}, 0x2e9573d7b2c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 561 [select, 52 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9574cd25a0, {0x4f78938, 0x2e95738791a0}, {0x4f909a0, 0x2e9573373560}, {{{0x2e95736c0fe0, 0x1, 0x1}}, 0x2e9573d7b2c0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 562 [chan receive, 171 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x2e9575bdbd40, {0x4f78970, 0x2e9575de8640})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:259 +0x68
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:110 +0x1c5

goroutine 677 [chan receive, 171 minutes]:
github.com/cilium/hive/shell.shell.listener.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/shell/server.go:80 +0x3e
created by github.com/cilium/hive/shell.shell.listener in goroutine 564
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/shell/server.go:79 +0x26c

goroutine 564 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ec000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95761fa500?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e95761fa500)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e95761fa500)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*UnixListener).accept(0x0?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0x2e95739085a0)
	/usr/local/go/src/net/unixsock.go:267 +0x30
github.com/cilium/hive/shell.shell.listener({{0x4f50fe0, 0x2e9574cd2cc0}, 0x2e95731b5070, 0x2e957398e690, {{0x4c2d4ba, 0x1a}}}, {0x4f78938, 0x2e95738799e0}, {0x4f909a0, 0x2e9576050840})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/shell/server.go:90 +0x430
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd2d20, {0x4f78938, 0x2e95738799e0}, {0x4f909a0, 0x2e9574cd2c60}, {{{0x0, 0x0, 0x0}}, 0x2e9573c784b0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 565 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e9ebe00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95761fab80?, 0x900000036?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e95761fab80)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e95761fab80)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x2e95761da9c0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x2e95761da9c0)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
net/http.(*Server).Serve(0x2e9573d5db00, {0x4f690b0, 0x2e95761da9c0})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
github.com/cilium/cilium/daemon/healthz.registerAgentHealthHTTPService.func1({0x4f78938, 0x2e9573879d40}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/daemon/healthz/agenthealth.go:107 +0x4ff
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd2f00, {0x4f78938, 0x2e9573879d40}, {0x4f909a0, 0x2e9574cd2d80}, {{{0x2e95731f29c0, 0x1, 0x1}}, 0x2e957376c520, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1008 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1007
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 1006 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95758586e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 566
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 568 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpointmanager.(*namespaceUpdater).run(0x2e95744cd540, {0x4f78938, 0x2e957387e600}, {0x2e95762cdc20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/endpointmanager/namespace_updater.go:82 +0x20d
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd3320, {0x4f78938, 0x2e957387e600}, {0x4f909a0, 0x2e95736b5c20}, {{{0x2e95736f7040, 0x1, 0x1}}, 0x2e9573e31a30, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1002 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e957582edc0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 321
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1478 [select, 170 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:73 +0xfd
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:93 +0x50
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 1476
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:78 +0x95

goroutine 572 [select, 171 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/writer.(*nodePortAddrReconciler).nodePortAddressReconcilerLoop(0x2e9573f12600, {0x4f78938, 0x2e957387f110}, {0x2e95762ddc20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/writer/node_addr_reconciler.go:83 +0x14d
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd3740, {0x4f78938, 0x2e957387f110}, {0x4f909a0, 0x2e9574cd3680}, {{{0x2e957384bec0, 0x1, 0x1}}, 0x2e9573f88c20, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 573 [select, 171 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/writer.(*wildcardAddressReconciler).wildcardAddressReconcilerLoop(0x2e9573f12b80, {0x4f78938, 0x2e957387f3e0}, {0x2e95762f1c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/writer/wild_addr_reconciler.go:84 +0x14d
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd3800, {0x4f78938, 0x2e957387f3e0}, {0x4f909a0, 0x2e9574cd3680}, {{{0x2e957384bec0, 0x1, 0x1}}, 0x2e9573f88c20, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 574 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e95731aa960, {0x4f78938, 0x2e957387f590}, {0x4f909a0, 0x2e95731aa8a0}, {{{0x2e957417cbc0, 0x1, 0x1}}, 0x2e9573cb8a70, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 575 [select, 170 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/reconciler.socketTerminationLoop({{{}}, {0x4f50fe0, 0x2e95731aaa80}, 0x2e957440c408, {0x4ffc8f8, 0x2e9572dfeee0}, 0x2e957440e590, {{0x3b9aca00, 0xdf8475800, 0x10000, ...}, ...}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reconciler/termination.go:181 +0x406
github.com/cilium/cilium/pkg/loadbalancer/reconciler.registerSocketTermination.func1({0x4f78938, 0x2e957387f740}, {0x4f909a0, 0x2e9576050d20})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/reconciler/termination.go:133 +0x1af
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731aac60, {0x4f78938, 0x2e957387f740}, {0x4f909a0, 0x2e95731aaa20}, {{{0x2e95742526c0, 0x1, 0x1}}, 0x2e957440e590, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 576 [select, 20 minutes]:
github.com/cilium/cilium/pkg/loadbalancer/healthserver.(*healthServer).controlLoop(0x2e957344af00, {0x4f78938, 0x2e957387f8f0}, {0x4f909a0, 0x2e9576051740})
	/go/src/github.com/cilium/cilium/pkg/loadbalancer/healthserver/healthserver.go:234 +0x457
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731ab440, {0x4f78938, 0x2e957387f8f0}, {0x4f909a0, 0x2e95731aaf60}, {{{0x2e95741c8140, 0x1, 0x1}}, 0x2e9573facfd0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 577 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e95731ab4a0, {0x4f78938, 0x2e957387fb00}, {0x4f909a0, 0x2e9574483680}, {{{0x2e95733f9ce0, 0x1, 0x1}}, 0x2e9573e31410, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 579 [chan receive, 171 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4f9af00, {0x4f78938, 0x2e957387fe60}, {0x4f909a0, 0x2e9574483680}, {{{0x2e95733f9ce0, 0x1, 0x1}}, 0x2e9573e31410, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:140 +0x52b
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 580 [select, 171 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd1be0, {0x4f78938, 0x2e9573890270}, {0x4f909a0, 0x2e9575eb0240})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731ab740, {0x4f78938, 0x2e9573890270}, {0x4f909a0, 0x2e95731ab500}, {{{0x2e957461cf80, 0x1, 0x1}}, 0x2e95742bdbf0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 581 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd1be0, {0x4f78938, 0x2e9573890450}, {0x4f909a0, 0x2e9575eb0300})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731ab7a0, {0x4f78938, 0x2e9573890450}, {0x4f909a0, 0x2e95731ab500}, {{{0x2e957461cf80, 0x1, 0x1}}, 0x2e95742bdbf0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 582 [select, 171 minutes]:
github.com/cilium/cilium/pkg/ciliumenvoyconfig.(*nodeLabelController).run(0x2e9572eddcc0, {0x4f78938, 0x2e9573890630}, {0x2e9575ce1c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/ciliumenvoyconfig/node_labels_controller.go:92 +0x23c
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731ab800, {0x4f78938, 0x2e9573890630}, {0x4f909a0, 0x2e95731ab500}, {{{0x2e957461cf80, 0x1, 0x1}}, 0x2e95742bdbf0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 583 [select, 170 minutes]:
github.com/cilium/cilium/pkg/ipcache/cell.registerAPIServerBackendWatcher.func1({0x4f78938, 0x2e9573890840}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/cell/apiserver_watcher.go:79 +0x3d0
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731ab8c0, {0x4f78938, 0x2e9573890840}, {0x4f909a0, 0x2e95733734a0}, {{{0x2e95736c08c0, 0x1, 0x1}}, 0x2e9573d7b050, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1338 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773b5b80)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1004
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 588 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5001660)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 590 [select, 170 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func2()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:171 +0x528
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:132 +0x230

goroutine 592 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x5000e20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:322 +0x85
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:309 +0x88

goroutine 776 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575ee9110}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9577a61310}, {0x7bdc8e993e30, 0x2e9574cb9dc0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575ee9110?}, {0x2e9573c43cf0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9577a61310?}, {0x7bdc8e993e30?, 0x2e9574cb9dc0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95738b5500, {0x4f7afd0, 0x2e9575ee9110}, {0x4f5b8e8, 0x2e9577a61310}, 0x2e9572dc2540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95738b5500, {0x4f7afd0, 0x2e9575ee9110}, {0x4f5b8e8, 0x2e95755858b0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95738b5500, {0x4f7afd0, 0x2e9575ee9110})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575ee9110})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575ee9110?}, 0x2e957638ce58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575ee9110}, {0x4f6a460, 0x2e9576321960}, 0x1, 0x1, 0x2e9575843f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95738b5500, {0x4f7afd0, 0x2e9575ee9110})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 639
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 594 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9575bdbda0, {0x4f78938, 0x2e9573891350}, {0x4f909a0, 0x2e9574cd38c0}, {{{0x2e9574526120, 0x1, 0x1}}, 0x2e9574884c80, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1287 [select, 52 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x2e957483af40, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:420 +0x10a
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x2e9576348aa0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:595 +0x78
google.golang.org/grpc/internal/transport.NewServerTransport.func3()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:350 +0xdc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1286
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:348 +0x18e7

goroutine 596 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...]).run(0x5003920, {0x4f78938, 0x2e9573891560}, {0x4f909a0, 0x2e9575eb0b40})
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:582 +0x6c5
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd3b60, {0x4f78938, 0x2e9573891560}, {0x4f909a0, 0x2e9574cd39e0}, {{{0x2e9574571340, 0x1, 0x1}}, 0x2e95748ecd80, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 597 [select, 52 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd1ca0, {0x4f78938, 0x2e9573891740}, {0x4f909a0, 0x2e9575eb0c00})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd3da0, {0x4f78938, 0x2e9573891740}, {0x4f909a0, 0x2e9574cd3bc0}, {{{0x2e95748caa20, 0x1, 0x1}}, 0x2e95746e8190, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 598 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd1ca0, {0x4f78938, 0x2e9573891920}, {0x4f909a0, 0x2e9575eb0cc0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9574cd3e00, {0x4f78938, 0x2e9573891920}, {0x4f909a0, 0x2e9574cd3bc0}, {{{0x2e95748caa20, 0x1, 0x1}}, 0x2e95746e8190, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 599 [select, 171 minutes]:
github.com/cilium/cilium/pkg/driftchecker.checker.watchTableChanges({0x2e95736599b0, 0x2e95749508e8, {0x4ffabe8, 0x2e9574cb8c40}, 0x2e9574a4a200, {{0x4fc91a8, 0x2e9572f78f00}}, 0x2e95733be3c0}, {0x4f78938, 0x2e9573891b30})
	/go/src/github.com/cilium/cilium/pkg/driftchecker/checker.go:81 +0x23b
github.com/cilium/cilium/pkg/driftchecker.Register.func1({0x4f78938?, 0x2e9573891b30?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/driftchecker/checker.go:61 +0x4c
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573116060, {0x4f78938, 0x2e9573891b30}, {0x4f909a0, 0x2e9574cd3e60}, {{{0x2e95749ae800, 0x1, 0x1}}, 0x2e9574a4a200, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 634 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 602
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 601 [select, 171 minutes]:
github.com/cilium/statedb.derive[...].loop(0x4fa69a0, {0x4f78938, 0x2e9573894030}, {0x2e9575fb3c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/derive.go:118 +0x55e
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573116300, {0x4f78938, 0x2e9573894030}, {0x4f909a0, 0x2e9573116240}, {{{0x2e9574b34540, 0x1, 0x1}}, 0x2e9574b4c510, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 602 [select, 2 minutes]:
github.com/cilium/cilium/pkg/maps/netdev.syncNetDevMap({{{}}, {0x4f50fe0, 0x2e9573c20c00}, 0x2e9574e59e50, 0x2e957440d980, {0x4ffbe90, 0x2e9572dfe460}, {0x4f83548, 0x2e95745ba390}}, {0x4f78938, ...})
	/go/src/github.com/cilium/cilium/pkg/maps/netdev/netdev_sync.go:64 +0x32f
github.com/cilium/cilium/pkg/maps/netdev.registerNetDevMapSync.func1({0x4f78938?, 0x2e9573894210?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/maps/netdev/netdev_sync.go:44 +0x4c
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573c210e0, {0x4f78938, 0x2e9573894210}, {0x4f909a0, 0x2e9573c20780}, {{{0x2e957439fd40, 0x1, 0x1}}, 0x2e9574e59e50, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 128613 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577586780, 0x2e9576b1d680, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577586780, 0xfcedd7?, 0x2e95761f5270?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 604 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9573c21320, {0x4f78938, 0x2e95738945a0}, {0x4f909a0, 0x2e9573c21200}, {{{0x2e9574e6f920, 0x1, 0x1}}, 0x2e9574f5b000, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 1023 [select, 10 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).enableWithConfig.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:347 +0x931
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 414
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 606 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9573c21560, {0x4f78938, 0x2e9573894990}, {0x4f909a0, 0x2e9573c214a0}, {{{0x2e9574ff3820, 0x1, 0x1}}, 0x2e9574fe5d60, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 635 [sync.Cond.Wait, 24 minutes]:
sync.runtime_notifyListWait(0x2e9574fa83d0, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573648cc0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574fa8380, 0x2e9576315d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575efe6e0, {0x4f7afd0, 0x2e957634ed20})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e957634ed20?}, 0x2e957399e240?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e957634ed20}, 0x2e9576377db8, {0x4f0fa20, 0x2e957399e240}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e957634ed20}, 0x2e9575aaddb8, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575efe6e0, {0x4f7afd0, 0x2e957634ed20})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x2e957634ed20?, 0x4cb500?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x2e9576320800, 0x2e957634ed20)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x2e9575d213c0, {0x4f78970, 0x2e9575cedc20}, {0x4f6b170, 0x2e9575cf3558})
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:427 +0x47d
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:271 +0x39
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 533
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 608 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 579
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 609 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 579
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 610 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9575dea610, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc2460, {0x4f78970, 0x2e9575de96d0}, 0x2e9575e81c70, {0x4fa1f90, 0x2e9575fc2b60})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 579
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 611 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 579
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 612 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...].func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0x118
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...].func1 in goroutine 579
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 613 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 614 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x2e9575e8df58?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 590
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 615 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9575deb790, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc33c0, {0x4f78970, 0x2e9575ef4640}, 0x2e9575ee91f0, {0x4fa4c10, 0x2e9575fc2cd0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 616 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 617 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 618 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 590
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 619 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9575debb90, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc32c0, {0x4f78970, 0x2e9575ef4780}, 0x2e9575ee9340, {0x4fa4b70, 0x2e9575fc2e10})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 620 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 621 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 622 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x2e9575da8310?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 590
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 623 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9575f80090, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc3240, {0x4f78970, 0x2e9575ef48c0}, 0x2e9575ee9490, {0x4fa4b20, 0x2e9575fc2e70})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 624 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 625 [select]:
k8s.io/client-go/util/workqueue.(*Typed[...]).updateUnfinishedWorkLoop(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:363 +0xfa
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 626 [select]:
k8s.io/client-go/util/workqueue.(*delayingType[...]).waitingLoop(0x4fbb200, {{0x4f9f650, 0x2e957398e7b0?}, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:320 +0x448
created by k8s.io/client-go/util/workqueue.newDelayingQueue[...] in goroutine 590
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:157 +0x272

goroutine 627 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9575f80490, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/util/workqueue.(*Typed[...]).Get(0x4fc7520)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:269 +0xab
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:611
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x4fc31c0, {0x4f78970, 0x2e9575ef4a00}, 0x2e9575ee95e0, {0x4fa4ad0, 0x2e9575fc2ed0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:536 +0x12a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:465 +0x257
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 628 [select, 171 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:475 +0x9d
sync.(*WaitGroup).Go.func1()
	/usr/local/go/src/sync/waitgroup.go:258 +0x4a
created by sync.(*WaitGroup).Go in goroutine 590
	/usr/local/go/src/sync/waitgroup.go:238 +0x73

goroutine 629 [select, 170 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.startK8sPolicyWatcher.serviceEventStream.func8.1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:152 +0xd0b
created by github.com/cilium/cilium/pkg/policy/k8s.startK8sPolicyWatcher.serviceEventStream.func8 in goroutine 590
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:72 +0x105

goroutine 630 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 644 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 645 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 646 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 647 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 648 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 649 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 650 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 651 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 652 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 653 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 654 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 655 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 656 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 657 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 658 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 659 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 660 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 661 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 662 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 663 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 664 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 665 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 666 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 667 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 668 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 669 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 670 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 671 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:143 +0x10f
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 542
	/go/src/github.com/cilium/cilium/pkg/status/status.go:129 +0xbc

goroutine 121495 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e9ec200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e957362ef00?, 0x2e957692b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e957362ef00, {0x2e957692b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e957362ef00, {0x2e957692b000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9576815490, {0x2e957692b000?, 0x2e9577e262d0?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x2e95768f6c80, {0x2e957692b000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x2e9577c60d20)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e9577c60d20, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x2e95768f6c80)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 121494
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 675 [select, 20 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd2000, {0x4f78938, 0x2e95738ebda0}, {0x4f909a0, 0x2e9576051ce0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95760506c0, {0x4f78938, 0x2e95738ebda0}, {0x4f909a0, 0x2e9574cd2780}, {{{0x2e95732428e0, 0x1, 0x1}}, 0x2e957311d980, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 563
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 632 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e95763815e0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9574f233b0}, {0x4f8fca0, 0x2e9575dffee0}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e95763815e0?}, {0x2e9573eb14f0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9574f233b0?}, {0x4f8fca0?, 0x2e9575dffee0?}, {0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9575eb3100, {0x4f7afd0, 0x2e95763815e0}, {0x4f5b8e8, 0x2e9574f233b0}, 0x2e9576322380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9575eb3100, {0x4f7afd0, 0x2e95763815e0}, {0x4f5b8e8, 0x2e9576317450})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9575eb3100, {0x4f7afd0, 0x2e95763815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e95763815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e95763815e0?}, 0x2e9575e8c678?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e95763815e0}, {0x4f6a460, 0x2e9576388180}, 0x1, 0x1, 0x2e957639bf68)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9575eb3100, {0x4f7afd0, 0x2e95763815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*Reflector).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:417 +0x1d
github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2.5()
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:633 +0x3b
created by github.com/cilium/cilium/pkg/k8s.RegisterReflector[...].ListerWatcherToObservable.func2 in goroutine 596
	/go/src/github.com/cilium/cilium/pkg/k8s/statedb.go:632 +0x225

goroutine 633 [select]:
github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9.3()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:353 +0x126
created by github.com/cilium/cilium/pkg/k8s.(*k8sReflector[...].func9 in goroutine 596
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:342 +0x211

goroutine 676 [select, 20 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd2000, {0x4f78938, 0x2e95738ebdd0}, {0x4f909a0, 0x2e95760507e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9576050720, {0x4f78938, 0x2e95738ebdd0}, {0x4f909a0, 0x2e9574cd2780}, {{{0x2e95732428e0, 0x1, 0x1}}, 0x2e957311d980, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 563
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 678 [chan receive, 171 minutes]:
github.com/cilium/cilium/daemon/healthz.registerAgentHealthHTTPService.func1.1()
	/go/src/github.com/cilium/cilium/daemon/healthz/agenthealth.go:102 +0x2c
created by github.com/cilium/cilium/daemon/healthz.registerAgentHealthHTTPService.func1 in goroutine 565
	/go/src/github.com/cilium/cilium/daemon/healthz/agenthealth.go:101 +0x43f

goroutine 679 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 572
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 680 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 573
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 132513 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e9baa00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575a11300?, 0x2e9574de1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9575a11300, {0x2e9574de1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9575a11300, {0x2e9574de1000?, 0x50ce20?, 0x2e9575a11300?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e95776d8098, {0x2e9574de1000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x2e9573cbdc40, {0x2e9574de1000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x2e9576d83380)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e9576d83380, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x2e95742147e0, {0x4f78938, 0x2e9576b0d470})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 1366
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 639 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9574cb9e10, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574cb9dc0, 0x2e95763822c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575efe420, {0x4f7afd0, 0x2e9575ee9110})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e9575ee9110?}, 0x2e957399fa70?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e9575ee9110}, 0x2e95763a7ea0, {0x4f0fa20, 0x2e957399fa70}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e9575ee9110}, 0x2e95763a7ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575efe420, {0x4f7afd0, 0x2e9575ee9110})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e9575fa3dc0, 0x2e9575ee9110)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 587
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 128918 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577586d80, 0x2e9576413540, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577586d80, 0xfcedd7?, 0x2e9577381770?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 429
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 692 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9574fa8050, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574fa8000, 0x2e9576382440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575efe4d0, {0x4f7afd0, 0x2e9575ee8fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e9575ee8fc0?}, 0x2e9573a02750?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e9575ee8fc0}, 0x2e9575ffcea0, {0x4f0fa20, 0x2e9573a02750}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e9575ee8fc0}, 0x2e9575ffcea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575efe4d0, {0x4f7afd0, 0x2e9575ee8fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e9576388060, 0x2e9575ee8fc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 584
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 131058 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0x2e957587b400)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 131046
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 694 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9574fa8210, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574fa81c0, 0x2e95763824c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575efe580, {0x4f7afd0, 0x2e9575ee9030})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e9575ee9030?}, 0x2e9573a02ab0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e9575ee9030}, 0x2e957638dea0, {0x4f0fa20, 0x2e9573a02ab0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e9575ee9030}, 0x2e957638dea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575efe580, {0x4f7afd0, 0x2e9575ee9030})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e95763880c0, 0x2e9575ee9030)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 585
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 696 [sync.Cond.Wait, 171 minutes]:
sync.runtime_notifyListWait(0x2e9574fa82f0, 0x0)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x2e9574fa82a0, 0x2e9576382540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:574 +0x110
k8s.io/client-go/tools/cache.(*controller).processLoop(0x2e9575efe630, {0x4f7afd0, 0x2e9575ee90a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:252 +0x17d
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext.func1({0x4f7afd0?, 0x2e9575ee90a0?}, 0x2e9573a02e40?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:255 +0x51
k8s.io/apimachinery/pkg/util/wait.BackoffUntilWithContext({0x4f7afd0, 0x2e9575ee90a0}, 0x2e9574b82ea0, {0x4f0fa20, 0x2e9573a02e40}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:256 +0xe5
k8s.io/apimachinery/pkg/util/wait.JitterUntilWithContext({0x4f7afd0, 0x2e9575ee90a0}, 0x2e9574b82ea0, 0x3b9aca00, 0x0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:223 +0x8f
k8s.io/apimachinery/pkg/util/wait.UntilWithContext(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:172
k8s.io/client-go/tools/cache.(*controller).RunWithContext(0x2e9575efe630, {0x4f7afd0, 0x2e9575ee90a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:207 +0x4a5
k8s.io/client-go/tools/cache.(*controller).Run(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:166 +0x1d
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x2e9576388120, 0x2e9575ee90a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:734 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:339 +0x7b
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 586
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:337 +0x1c5

goroutine 2118 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e944600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575cb1100?, 0x2e95770c6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9575cb1100, {0x2e95770c6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9575cb1100, {0x2e95770c6000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e95732a5f08, {0x2e95770c6000?, 0x2e9576afae40?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x2e9575ac5cc0, {0x2e95770c6000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x2e95770917a0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e95770917a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x2e9575ac5cc0)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 2117
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 681 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 576
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 683 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 632
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 684 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9575eb3100, {0x4f78970, 0x2e95763174a0}, 0x2e9576322380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 685 [select, 22 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:148 +0x176
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 556
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:145 +0x226

goroutine 801 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9575eb3900, {0x4f78970, 0x2e9575585720}, 0x2e9572d817a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 703
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 768 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 703
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 885 [select, 2 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1043
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 636
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1039 +0x5a

goroutine 1380 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e95769003c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1227
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 702 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 635
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 127963 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e957777c600, 0x2e9575d9edc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e957777c600, 0x2e957584ab60?, 0x2e9577011f58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 298
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 1374 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e957717dae0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1180
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 1240 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773a46e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1238
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1174 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 432
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 1180 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x2e9575244f90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1042
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 703 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e957634ed20}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9577a60b90}, {0x7bdc8e993e30, 0x2e9574fa8380}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e957634ed20?}, {0x2e957329d0a0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9577a60b90?}, {0x7bdc8e993e30?, 0x2e9574fa8380?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9575eb3900, {0x4f7afd0, 0x2e957634ed20}, {0x4f5b8e8, 0x2e9577a60b90}, 0x2e9572d817a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9575eb3900, {0x4f7afd0, 0x2e957634ed20}, {0x4f5b8e8, 0x2e95755856d0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9575eb3900, {0x4f7afd0, 0x2e957634ed20})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e957634ed20})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e957634ed20?}, 0x2e9575cf7e58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e957634ed20}, {0x4f6a460, 0x2e9576320900}, 0x1, 0x1, 0x2e9576397f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9575eb3900, {0x4f7afd0, 0x2e957634ed20})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 635
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1238 [select, 171 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773a1b80)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1199
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1237 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773a18c0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1199
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1231 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9577382f20)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1229
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1235 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x2e957739aa50})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773a11e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1199
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1236 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1199
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 128478 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9575893cc8, 0x5)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573e89a40?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9575893cb0, {0x2e957726d801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x82?}, {0x2e957726d801?, 0x425234?, 0x2e957561dc98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e9574ffd2c0)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e9574ffd2c0)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e9574ffd2c0, {0x418d900, 0x2e95779dbd10})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e9576e6cae0, {0x2e9575a4a400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e957530a730, 0x0, {0x4f57f10, 0x2e9577ec9c80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e957509f2e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e957530a780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 432
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 1229 [select, 171 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773826e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1222
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1228 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9577382420)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1222
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1227 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x6e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:78 +0xac
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:69
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x2e9575575730?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:231 +0x36
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1222
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:227 +0x6a

goroutine 1226 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x2e95772e1360})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95772ebb80)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1222
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1215 [select, 171 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575bcd600)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1204
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1217 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575dec160)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1215
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1379 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e95773b42c0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1236
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1352 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e9577a6f400)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1213
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 875 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 575
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 859 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 815
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 858 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x95
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 812
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 131636 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9574f84948, 0x1)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9576b8af00?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9574f84930, {0x2e9573dd2f08, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e9578474cc8?}, {0x2e9573dd2f08?, 0x2e9578474cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9574f84900}, {0x2e9573dd2f08, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e95783ef008, {0x2e957525c800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9577f445f0, 0x0, {0x4f57f10, 0x2e9574451940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95750ae6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9577f44640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 341
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 857 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95738b5700, {0x4f78970, 0x2e95746270e0}, 0x2e9572c600e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 784
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 856 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 784
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 1479 [select, 170 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0x2e9573cd8180)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:80 +0x112
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:91 +0x39
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:93 +0x50
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 1476
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:78 +0x95

goroutine 1179 [select, 171 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x4f78970, 0x2e9576bd6500})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:1141 +0x95
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575acb760)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:356 +0x231
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1042
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 851 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9572bd8000, {0x4f78970, 0x2e9574701720}, 0x2e9572dd11f0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 792
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 850 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 792
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 815 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0x2e95745a6d20, {0x4f78938, 0x2e9573aee660}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x332
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0x2e957451d480, {0x4f78938, 0x2e9573aee660}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x10b
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x4f78938, 0x2e9573aee660}, {{{}}, 0x2e9573914138, {0x4ffb678, 0x2e9572ea2c40}, {0x4f50fe0, 0x2e95731171a0}, 0x2e95736d8200}, 0x2e957536a180)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:126 +0x356
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x4f78938?, 0x2e9573aee660?}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:79 +0x39
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573117200, {0x4f78938, 0x2e9573aee660}, {0x4f909a0, 0x2e9573117140}, {{{0x2e9575368d40, 0x1, 0x1}}, 0x2e9573c78fe0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 814 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).refreshLoop(0x4fd2240, {0x4f78938, 0x2e9573aee4b0}, {0x4f909a0, 0x2e95742a9140})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:153 +0x1b6
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573116fc0, {0x4f78938, 0x2e9573aee4b0}, {0x4f909a0, 0x2e9573116de0}, {{{0x2e9575314960, 0x1, 0x1}}, 0x2e9575307240, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 813 [select, 22 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).reconcileLoop(0x4fd2240, {0x4f78938, 0x2e9573aee2d0}, {0x4f909a0, 0x2e95742a90e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:82 +0x607
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573116f60, {0x4f78938, 0x2e9573aee2d0}, {0x4f909a0, 0x2e9573116de0}, {{{0x2e9575314960, 0x1, 0x1}}, 0x2e9575307240, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 812 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/linux/route/reconciler.desiredRouteRefresher.func1({0x4f78938, 0x2e9573ae5e00}, {0x7?, 0x4?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/route/reconciler/refresher.go:98 +0x5b1
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573116cc0, {0x4f78938, 0x2e9573ae5e00}, {0x4f909a0, 0x2e9574483bc0}, {{{0x2e9573449ac0, 0x1, 0x1}}, 0x2e9573bbcbb0, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 811 [select, 171 minutes]:
github.com/cilium/cilium/pkg/mtu.(*endpointUpdater).Updater(0x2e95731c5540, {0x4f78938, 0x2e9573ae5a40}, {0x4f909a0, 0x2e95742a8600})
	/go/src/github.com/cilium/cilium/pkg/mtu/endpoint_updater.go:125 +0x21a
github.com/cilium/hive/job.(*jobOneShot).start(0x2e95731166c0, {0x4f78938, 0x2e9573ae5a40}, {0x4f909a0, 0x2e9574b7b8c0}, {{{0x2e95735a8820, 0x1, 0x1}}, 0x2e9573ce4580, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 810 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x2e95748270e0, {0x4f78938, 0x2e9573ae5860}, {0x4f54778, 0x2e9575377600}, 0x2e9572c60540)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:228 +0x369
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x2e95748270e0, {0x4f78938, 0x2e9573ae5860}, {0x2e9575591c20?, 0x4c7813?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:155 +0x29d
github.com/cilium/hive/job.(*jobOneShot).start(0x2e9573c218c0, {0x4f78938, 0x2e9573ae5860}, {0x4f909a0, 0x2e9573c21740}, {{{0x2e957507a2c0, 0x1, 0x1}}, 0x2e957505ec30, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:139 +0x4a3
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 809 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9573c216e0, {0x4f78938, 0x2e9573ae54a0}, {0x4f909a0, 0x2e9573c21620}, {{{0x0, 0x0, 0x0}}, 0x2e957503a760, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 807 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e95738b5500, {0x4f78970, 0x2e9575585900}, 0x2e9572dc2540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 776
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 806 [select, 171 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:523 +0x9a
created by context.(*cancelCtx).propagateCancel in goroutine 776
	/usr/local/go/src/context/context.go:522 +0x409

goroutine 1021 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x2e9574eb98c0, {0x4f78938, 0x2e9573b38660}, {0x4f909a0, 0x2e9574cd3500}, {{{0x2e9573b3f080, 0x1, 0x1}}, 0x2e9573c5ef30, {0x4f0d760, ...}, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:179 +0x377
github.com/cilium/hive/job.(*queuedJob).Start.func1.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:227 +0x1ae
created by github.com/cilium/hive/job.(*queuedJob).Start.func1 in goroutine 571
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:212 +0x7a

goroutine 770 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 637
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 771 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575e815e0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e95761f54a0}, {0x7bdc8e993e30, 0x2e9574cb9ce0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575e815e0?}, {0x2e957424d8a0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e95761f54a0?}, {0x7bdc8e993e30?, 0x2e9574cb9ce0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9575eb3a00, {0x4f7afd0, 0x2e9575e815e0}, {0x4f5b8e8, 0x2e95761f54a0}, 0x2e9572dc2070)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9575eb3a00, {0x4f7afd0, 0x2e9575e815e0}, {0x4f5b8e8, 0x2e95755857c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9575eb3a00, {0x4f7afd0, 0x2e9575e815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575e815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575e815e0?}, 0x2e9575cf9658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575e815e0}, {0x4f6a460, 0x2e9576320c40}, 0x1, 0x1, 0x2e957636bf48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9575eb3a00, {0x4f7afd0, 0x2e9575e815e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 637
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 131187 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9577586648, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573b0bca0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9577586630, {0x2e95743b6898, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e9575026cc8?}, {0x2e95743b6898?, 0x2e9575026cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9577586600}, {0x2e95743b6898, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e9573a63c38, {0x2e95768e7400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9577a612c0, 0x0, {0x4f57f10, 0x2e95763f3c00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e957300ad40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9577a61310)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 776
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 783 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 692
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 784 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575ee8fc0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9577070a50}, {0x7bdc8e993e30, 0x2e9574fa8000}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575ee8fc0?}, {0x2e95743f4d60?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9577070a50?}, {0x7bdc8e993e30?, 0x2e9574fa8000?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95738b5700, {0x4f7afd0, 0x2e9575ee8fc0}, {0x4f5b8e8, 0x2e9577070a50}, 0x2e9572c600e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95738b5700, {0x4f7afd0, 0x2e9575ee8fc0}, {0x4f5b8e8, 0x2e9574627090})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95738b5700, {0x4f7afd0, 0x2e9575ee8fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575ee8fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575ee8fc0?}, 0x2e95750cd658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575ee8fc0}, {0x4f6a460, 0x2e9573796420}, 0x1, 0x1, 0x2e95758fff48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95738b5700, {0x4f7afd0, 0x2e9575ee8fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 692
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 787 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 694
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 788 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575ee9030}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9577a54640}, {0x7bdc8e993e30, 0x2e9574fa81c0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575ee9030?}, {0x2e957420d0f0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9577a54640?}, {0x7bdc8e993e30?, 0x2e9574fa81c0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e95738b5b00, {0x4f7afd0, 0x2e9575ee9030}, {0x4f5b8e8, 0x2e9577a54640}, 0x2e9572d80a10)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e95738b5b00, {0x4f7afd0, 0x2e9575ee9030}, {0x4f5b8e8, 0x2e95755855e0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e95738b5b00, {0x4f7afd0, 0x2e9575ee9030})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575ee9030})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575ee9030?}, 0x2e9575e8ee58?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575ee9030}, {0x4f6a460, 0x2e9573796880}, 0x1, 0x1, 0x2e9576375f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e95738b5b00, {0x4f7afd0, 0x2e9575ee9030})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 694
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 130421 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e957777cc00, 0x2e9575b6a8c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e957777cc00, 0x2e95746400b0?, 0x2e95746400d0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 792
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 791 [chan receive, 171 minutes]:
k8s.io/client-go/tools/cache.(*controller).RunWithContext.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:173 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).RunWithContext in goroutine 696
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:172 +0xe9

goroutine 792 [select]:
k8s.io/client-go/tools/cache.handleAnyWatch({0x4f7afd0, 0x2e9575ee90a0}, {0x0?, 0x0?, 0x83b0f80?}, {0x4f5b8e8, 0x2e9576fd55e0}, {0x7bdc8e993e30, 0x2e9574fa82a0}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:1001 +0x2b6
k8s.io/client-go/tools/cache.handleWatch({0x4f7afd0?, 0x2e9575ee90a0?}, {0x2e9573a00590?, 0x0?, 0x83b0f80?}, {0x4f5b8e8?, 0x2e9576fd55e0?}, {0x7bdc8e993e30?, 0x2e9574fa82a0?}, {0x5002000, ...}, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:958 +0xea
k8s.io/client-go/tools/cache.(*Reflector).watch(0x2e9572bd8000, {0x4f7afd0, 0x2e9575ee90a0}, {0x4f5b8e8, 0x2e9576fd55e0}, 0x2e9572dd11f0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:620 +0x70f
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync(0x2e9572bd8000, {0x4f7afd0, 0x2e9575ee90a0}, {0x4f5b8e8, 0x2e95747016d0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:553 +0x186
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatchWithContext(0x2e9572bd8000, {0x4f7afd0, 0x2e9575ee90a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:508 +0x472
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext.func1({0x4f7afd0, 0x2e9575ee90a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x2f
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext.func1({0x4f7afd0?, 0x2e9575ee90a0?}, 0x2e9575e8f658?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:53 +0x62
k8s.io/apimachinery/pkg/util/wait.loopConditionUntilContext({0x4f7afd0, 0x2e9575ee90a0}, {0x4f6a460, 0x2e9573796e80}, 0x1, 0x1, 0x2e95763b7f48)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/loop.go:54 +0x115
k8s.io/apimachinery/pkg/util/wait.DelayFunc.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/delay.go:39
k8s.io/client-go/tools/cache.(*Reflector).RunWithContext(0x2e9572bd8000, {0x4f7afd0, 0x2e9575ee90a0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x289
k8s.io/client-go/tools/cache.(*controller).RunWithContext.(*Group).StartWithContext.func3()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:63 +0x1f
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 696
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1175 [select, 171 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x2e9573be5200, {0x4f78970, 0x2e9576a940f0}, 0x2e95759fccb0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:521 +0x12c
k8s.io/client-go/tools/cache.(*Reflector).watchWithResync.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:551 +0x25
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x4c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 432
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 126644 [select, 8 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577586900, 0x2e9572edd7c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577586900, 0x2e9573d45640?, 0x2e9573d45660?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 788
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 1375 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e9575388c60)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1180
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1473 [select, 52 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x2e9573b55d00, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:420 +0x10a
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x2e9575dccdc0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:595 +0x78
google.golang.org/grpc/internal/transport.NewServerTransport.func3()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:350 +0xdc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1456
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:348 +0x18e7

goroutine 1378 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x2e95769fea00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x286
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1236
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:121 +0x1e5

goroutine 1353 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x2e957733c160)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:428 +0x8a5
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1213
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:131 +0x4be

goroutine 1474 [select, 50 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x2e95758b4000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1214 +0x1e5
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1456
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:371 +0x1929

goroutine 1366 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e944800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95750cba00?, 0x900000036?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x2e95750cba00)
	/usr/local/go/src/internal/poll/fd_unix.go:613 +0x28c
net.(*netFD).accept(0x2e95750cba00)
	/usr/local/go/src/net/fd_unix.go:150 +0x29
net.(*TCPListener).accept(0x2e9573eda380)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1b
net.(*TCPListener).Accept(0x2e9573eda380)
	/usr/local/go/src/net/tcpsock.go:387 +0x30
net/http.(*Server).Serve(0x2e957458eb00, {0x4f690b0, 0x2e9573eda380})
	/usr/local/go/src/net/http/server.go:3434 +0x30c
net/http.(*Server).ListenAndServe(0x2e957458eb00)
	/usr/local/go/src/net/http/server.go:3360 +0x72
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x25
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1361
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x51

goroutine 1362 [sync.WaitGroup.Wait, 171 minutes]:
sync.runtime_SemacquireWaitGroup(0x2e9573019090?, 0xa0?)
	/usr/local/go/src/runtime/sema.go:114 +0x2e
sync.(*WaitGroup).Wait(0x2e9575724150)
	/usr/local/go/src/sync/waitgroup.go:206 +0x85
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x2e9575724010)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:318 +0x95
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x2e9575724008)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:361 +0x12c
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:380 +0x25
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:379 +0xd4

goroutine 1341 [select, 171 minutes]:
net/http.(*persistConn).writeLoop(0x2e9573a5ec80)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 1339
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 1340 [IO wait, 171 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ba600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95750cac00?, 0x2e95769e8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e95750cac00, {0x2e95769e8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e95750cac00, {0x2e95769e8000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9572eed0a0, {0x2e95769e8000?, 0x2e95769d7e00?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x2e9573a5ec80, {0x2e95769e8000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x2e9573373380)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e9573373380, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x2e9573a5ec80)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 1339
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 1344 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x2e9575724008)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:385 +0xe9
github.com/cilium/cilium/pkg/health.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:103 +0x65
created by github.com/cilium/cilium/pkg/health.(*CiliumHealth).runServer in goroutine 1041
	/go/src/github.com/cilium/cilium/pkg/health/health_connectivity_node.go:101 +0x19b

goroutine 1361 [chan receive, 171 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x2e957478d500)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xce
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:375 +0x27
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:374 +0x78

goroutine 1477 [select, 170 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:59 +0xbd
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:93 +0x50
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 1476
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:78 +0x95

goroutine 1475 [IO wait, 52 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e9ba000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95772e9400?, 0x2e9574fab000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e95772e9400, {0x2e9574fab000, 0x800, 0x800})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e95772e9400, {0x2e9574fab000?, 0x2e9574fab000?, 0x5?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9577762f60, {0x2e9574fab000?, 0x7bdc8e86ab48?, 0x7bdcd5990108?})
	/usr/local/go/src/net/net.go:196 +0x45
crypto/tls.(*atLeastReader).Read(0x2e957794fb78, {0x2e9574fab000?, 0x2e957502b978?, 0x452688?})
	/usr/local/go/src/crypto/tls/conn.go:815 +0x3b
bytes.(*Buffer).ReadFrom(0x2e957376f0a8, {0x4f0dbc0, 0x2e957794fb78})
	/usr/local/go/src/bytes/buffer.go:229 +0x98
crypto/tls.(*Conn).readFromUntil(0x2e957376ee08, {0x4f0cac0, 0x2e9577762f60}, 0x69e30c?)
	/usr/local/go/src/crypto/tls/conn.go:837 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0x2e957376ee08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x3db
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x2e957376ee08, {0x2e9576302000, 0x8000, 0x7bdcd5990108?})
	/usr/local/go/src/crypto/tls/conn.go:1393 +0x145
bufio.(*Reader).Read(0x2e9575648480, {0x2e9574f9eba4, 0x9, 0x4696740?})
	/usr/local/go/src/bufio/bufio.go:245 +0x197
io.ReadAtLeast({0x4f08a40, 0x2e9575648480}, {0x2e9574f9eba4, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x8e
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x2e9574f9eba4, 0x9, 0xaedad2?}, {0x4f08a40?, 0x2e9575648480?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:250 +0x65
golang.org/x/net/http2.(*Framer).ReadFrameHeader(0x2e9574f9eb60)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:513 +0x6b
google.golang.org/grpc/internal/transport.(*framer).readFrame(0x2e95758e6580)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http_util.go:493 +0x45
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x2e95758b4000, {0x4f78938, 0x2e95733f5b00}, 0x2e95733f5b30)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:646 +0xff
google.golang.org/grpc.(*Server).serveStreams(0x2e957531f688, {0x4f78778?, 0x88ffe40?}, {0x4f7ae10, 0x2e95758b4000}, {0x4faadb8?, 0x2e9577762f60?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1072 +0x368
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1006 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1456
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1005 +0x1cb

goroutine 128919 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9577586dc8, 0x5)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9574b71960?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9577586db0, {0x2e95744be010, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e957502acc8?}, {0x2e95744be010?, 0x2e957502acc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9577586d80}, {0x2e95744be010, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e95781aad68, {0x2e9575b88000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9577a04dc0, 0x0, {0x4f57f10, 0x2e9576619840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95751a2540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9577a04e10)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 429
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 2119 [select]:
net/http.(*persistConn).writeLoop(0x2e9575ac5cc0)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 2117
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 131057 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7bdc8e943c00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e95762fc900?, 0x2e95743c3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e95762fc900, {0x2e95743c3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e95762fc900, {0x2e95743c3000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9574766058, {0x2e95743c3000?, 0x2e9576afae40?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x2e957587b400, {0x2e95743c3000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x2e9577034ea0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e9577034ea0, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x2e957587b400)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 131046
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 130160 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e957777c048, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573cd3900?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e957777c030, {0x2e95772c7201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x80?}, {0x2e95772c7201?, 0x425234?, 0x2e957601fc98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e9575f93040)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e9575f93040)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e9575f93040, {0x418d900, 0x2e957798cc18})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e957734da40, {0x2e95749d8c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9577070a00, 0x0, {0x4f57f10, 0x2e9573cbd500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e957312f640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9577070a50)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 784
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 130422 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e957777cc48, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573dd0340?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e957777cc30, {0x2e9575d40001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x7c?}, {0x2e9575d40001?, 0x425234?, 0x2e9575b3fc98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e9575b6ab40)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e9575b6ab40)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e9575b6ab40, {0x418d900, 0x2e9573a62e28})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e957798acf0, {0x2e95757f7000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9576fd5590, 0x0, {0x4f57f10, 0x2e95757ea1c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e9574b2a0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9576fd55e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 792
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 130045 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577586a80, 0x2e95750f5900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577586a80, 0xfcedd7?, 0x2e9576898e10?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 344
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 130046 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9577586ac8, 0x3)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e95745d8100?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9577586ab0, {0x2e9573fd7d70, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e9575dd8cc8?}, {0x2e9573fd7d70?, 0x2e9575dd8cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9577586a80}, {0x2e9573fd7d70, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e9577789ab8, {0x2e957525dc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e957576f7c0, 0x0, {0x4f57f10, 0x2e9577ad9200})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95750aefc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e957576f900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 344
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 128595 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e95775867c8, 0x5)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9575fe4768?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e95775867b0, {0x2e9573ceb7c0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e95770cecc8?}, {0x2e9573ceb7c0?, 0x2e95770cecc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9577586780}, {0x2e9573ceb7c0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e9577cfa0c0, {0x2e9575a4a800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9574f23180, 0x0, {0x4f57f10, 0x2e957504b100})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e957312fcc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9574f233b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 131693 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9574f84900, 0x2e9576aa3540, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9574f84900, 0xfcedd7?, 0x2e9577960320?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 341
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 121479 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e9ba800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575d82600?, 0x2e95757cb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9575d82600, {0x2e95757cb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9575d82600, {0x2e95757cb000?, 0x50ce20?, 0x2e9575d82600?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9574ceaf88, {0x2e95757cb000?, 0x0?, 0x72?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*connReader).Read(0x2e9573cb7380, {0x2e95757cb000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:812 +0x154
bufio.(*Reader).fill(0x2e9577d036e0)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e9577d036e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*conn).serve(0x2e95765c9a70, {0x4f78938, 0x2e9576afacc0})
	/usr/local/go/src/net/http/server.go:2103 +0x7f3
created by net/http.(*Server).Serve in goroutine 1350
	/usr/local/go/src/net/http/server.go:3464 +0x485

goroutine 118962 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e9ba200, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9575b96d80?, 0x2e95743f8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9575b96d80, {0x2e95743f8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9575b96d80, {0x2e95743f8000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e95732a5628, {0x2e95743f8000?, 0x2e9576b0d260?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x2e957362c000, {0x2e95743f8000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x2e957658d920)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e957658d920, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x2e957362c000)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 118961
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 121496 [select]:
net/http.(*persistConn).writeLoop(0x2e95768f6c80)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 121494
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 128187 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e95758933c8, 0x6)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9576341800?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e95758933b0, {0x2e95744bf5c0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e9578473cc8?}, {0x2e95744bf5c0?, 0x2e9578473cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9575893380}, {0x2e95744bf5c0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e9577b12d68, {0x2e9576db3800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e95761f5450, 0x0, {0x4f57f10, 0x2e95764771c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95735b1640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e95761f54a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 771
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 127964 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e957777c648, 0x6)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e95768f2100?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e957777c630, {0x2e9575561201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x77?}, {0x2e9575561201?, 0x425234?, 0x2e9575841c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e9575d9f040)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e9575d9f040)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e9575d9f040, {0x418d900, 0x2e9573e4ee58})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e9576cb7230, {0x2e95757f7c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9576c8f630, 0x0, {0x4f57f10, 0x2e95769490c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95733d1580)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9576c8f720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 298
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 130168 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e957777c000, 0x2e95732cf540, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e957777c000, 0x2e957396d810?, 0x2e957396d830?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 784
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 131748 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e95775873c8, 0x1)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573a16720?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e95775873b0, {0x2e957517aeb0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x2e9577550cc8?}, {0x2e957517aeb0?, 0x2e9577550cc0?, 0x425c85?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
io.ReadAtLeast({0x7bdc8e993978, 0x2e9577587380}, {0x2e957517aeb0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x8e
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x2e9578226af8, {0x2e957525cc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7f
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e95751b64b0, 0x0, {0x4f57f10, 0x2e95769c2740})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95750afe00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e95751b6640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 343
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 131256 [select]:
net/http.(*persistConn).writeLoop(0x2e957631d040)
	/usr/local/go/src/net/http/transport.go:2652 +0xe6
created by net/http.(*Transport).dialConn in goroutine 131245
	/usr/local/go/src/net/http/transport.go:1995 +0x16fe

goroutine 132464 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e9f2200, 0x77)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x4f789e0?, 0x2e9576cb1110?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitWrite(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:93
internal/poll.(*FD).WaitWrite(...)
	/usr/local/go/src/internal/poll/fd_unix.go:685
net.(*netFD).connect(0x2e9575a11280, {0x4f789e0, 0x2e9576cb1110}, {0x425234?, 0x1?}, {0x4f0ca60?, 0x2e9574f244c0?})
	/usr/local/go/src/net/fd_unix.go:119 +0x656
net.(*netFD).dial(0x2e9575a11280, {0x4f789e0, 0x2e9576cb1110}, {0x4f9bd38?, 0x0?}, {0x4f9bd38, 0x2e957826cea0}, 0x2e95762df218?)
	/usr/local/go/src/net/sock_posix.go:124 +0x3bc
net.socket({0x4f789e0, 0x2e9576cb1110}, {0x4bcc76a, 0x3}, 0x2, 0x1, 0xe0f7f1?, 0x0, {0x4f9bd38, 0x0}, ...)
	/usr/local/go/src/net/sock_posix.go:70 +0x29b
net.internetSocket({0x4f789e0, 0x2e9576cb1110}, {0x4bcc76a, 0x3}, {0x4f9bd38, 0x0}, {0x4f9bd38, 0x2e957826cea0}, 0x1, 0x0, ...)
	/usr/local/go/src/net/ipsock_posix.go:167 +0xf8
net.(*sysDialer).doDialTCPProto(0x2e95751ab200, {0x4f789e0, 0x2e9576cb1110}, 0x0, 0x2e957826cea0, 0x0)
	/usr/local/go/src/net/tcpsock_posix.go:85 +0xe7
net.(*sysDialer).doDialTCP(...)
	/usr/local/go/src/net/tcpsock_posix.go:75
net.(*sysDialer).dialTCP(0x48af39?, {0x4f789e0?, 0x2e9576cb1110?}, 0x3e066e0?, 0x2e95762df470?)
	/usr/local/go/src/net/tcpsock_posix.go:71 +0x69
net.(*sysDialer).dialSingle(0x2e95751ab200, {0x4f789e0, 0x2e9576cb1110}, {0x4f542c8, 0x2e957826cea0})
	/usr/local/go/src/net/dial.go:791 +0x3ae
net.(*sysDialer).dialSerial(0x2e95751ab200, {0x4f789e0, 0x2e9576cb1110}, {0x2e9576353e70?, 0x1, 0x2e9573af41d0?})
	/usr/local/go/src/net/dial.go:756 +0x248
net.(*sysDialer).dialParallel(0x0?, {0x4f789e0?, 0x2e9576cb1110?}, {0x2e9576353e70?, 0x4262100?, 0x4bcd580?}, {0x0?, 0x4bcc76a?, 0x0?})
	/usr/local/go/src/net/dial.go:657 +0x2f9
net.(*Dialer).DialContext(0x2e9572ca5b90, {0x4f78970?, 0x2e9575f987d0?}, {0x4bcc76a, 0x3}, {0x2e9573af41d0, 0x10})
	/usr/local/go/src/net/dial.go:557 +0x485
net/http.(*Transport).dial(0x0?, {0x4f78970?, 0x2e9575f987d0?}, {0x4bcc76a?, 0x0?}, {0x2e9573af41d0?, 0x0?})
	/usr/local/go/src/net/http/transport.go:1307 +0xd2
net/http.(*Transport).dialConn(0x837fd60, {0x4f78970, 0x2e9575f987d0}, {{}, 0x0, {0x2e9574fe7440, 0x4}, {0x2e9573af41d0, 0x10}, 0x0}, ...)
	/usr/local/go/src/net/http/transport.go:1815 +0x847
net/http.(*Transport).dialConnFor(0x837fd60, 0x2e9577a253f0)
	/usr/local/go/src/net/http/transport.go:1648 +0xd2
net/http.(*Transport).startDialConnForLocked.func1()
	/usr/local/go/src/net/http/transport.go:1629 +0x35
created by net/http.(*Transport).startDialConnForLocked in goroutine 132495
	/usr/local/go/src/net/http/transport.go:1628 +0x112

goroutine 131186 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e957777cac8, 0x2)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e95757ea4c0?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e957777cab0, {0x2e957600c001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x7b?}, {0x2e957600c001?, 0x425234?, 0x2e9576373c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e95776a2140)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e95776a2140)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e95776a2140, {0x418d900, 0x2e9573a62a38})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e9577ac6540, {0x2e95768e6c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9577a60af0, 0x0, {0x4f57f10, 0x2e9576577a40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e957300ac00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9577a60b90)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 703
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 131255 [IO wait]:
internal/poll.runtime_pollWait(0x7bdc8e944000, 0x72)
	/usr/local/go/src/runtime/netpoll.go:351 +0x85
internal/poll.(*pollDesc).wait(0x2e9576a96e80?, 0x2e9574f19000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x2e9576a96e80, {0x2e9574f19000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:165 +0x2ae
net.(*netFD).Read(0x2e9576a96e80, {0x2e9574f19000?, 0x0?, 0x1?})
	/usr/local/go/src/net/fd_posix.go:68 +0x25
net.(*conn).Read(0x2e9576e13980, {0x2e9574f19000?, 0x2e9576afae40?, 0x426ff60?})
	/usr/local/go/src/net/net.go:196 +0x45
net/http.(*persistConn).Read(0x2e957631d040, {0x2e9574f19000?, 0x4f085e0?, 0x830b540?})
	/usr/local/go/src/net/http/transport.go:2174 +0x47
bufio.(*Reader).fill(0x2e9576d2a480)
	/usr/local/go/src/bufio/bufio.go:113 +0x103
bufio.(*Reader).Peek(0x2e9576d2a480, 0x1)
	/usr/local/go/src/bufio/bufio.go:152 +0x53
net/http.(*persistConn).readLoop(0x2e957631d040)
	/usr/local/go/src/net/http/transport.go:2330 +0x172
created by net/http.(*Transport).dialConn in goroutine 131245
	/usr/local/go/src/net/http/transport.go:1994 +0x16ac

goroutine 130796 [select, 2 minutes]:
reflect.rselect({0x2e9575dc1440, 0x6, 0x80?})
	/usr/local/go/src/runtime/select.go:616 +0x3cd
reflect.Select({0x2e95759e8580?, 0x6, 0x4ef6e98?})
	/usr/local/go/src/reflect/value.go:3018 +0x5a7
github.com/cilium/cilium/pkg/common.MergeChannels[...].func1()
	/go/src/github.com/cilium/cilium/pkg/common/utils.go:89 +0x65
created by github.com/cilium/cilium/pkg/common.MergeChannels[...] in goroutine 410
	/go/src/github.com/cilium/cilium/pkg/common/utils.go:87 +0x19f

goroutine 131173 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577586600, 0x2e9575d9fcc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577586600, 0xfcedd7?, 0x2e95745f70e0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 776
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 129302 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x2e9574f84348, 0x4)
	/usr/local/go/src/runtime/sema.go:617 +0x1b3
sync.(*Cond).Wait(0x2e9573bdf600?)
	/usr/local/go/src/sync/cond.go:71 +0x73
golang.org/x/net/http2.(*pipe).Read(0x2e9574f84330, {0x2e9575153801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdb
golang.org/x/net/http2.transportResponseBody.Read({0x7b?}, {0x2e9575153801?, 0x425234?, 0x2e9575803c98?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2180 +0x59
encoding/json.(*Decoder).refill(0x2e95757f8dc0)
	/usr/local/go/src/encoding/json/stream.go:167 +0x188
encoding/json.(*Decoder).readValue(0x2e95757f8dc0)
	/usr/local/go/src/encoding/json/stream.go:142 +0x85
encoding/json.(*Decoder).Decode(0x2e95757f8dc0, {0x418d900, 0x2e95779639c8})
	/usr/local/go/src/encoding/json/stream.go:65 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x2e9576d7e750, {0x2e9575b88400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:151 +0x15d
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x2e9576ee08c0, 0x0, {0x4f57f10, 0x2e9577ad8500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x2e95746ed6a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x2e9576ee0910)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:114 +0xf8
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcherWithLogger in goroutine 487
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:85 +0x149

goroutine 131747 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9577587380, 0x2e9575f92640, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9577587380, 0xfcedd7?, 0x2e957739bc70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 343
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470

goroutine 128220 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x2e9575893380, 0x2e9575ceb680, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1199 +0xc88
golang.org/x/net/http2.(*clientStream).doRequest(0x2e9575893380, 0xfcedd7?, 0x2e9574f23270?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1060 +0x18
created by golang.org/x/net/http2.(*ClientConn).internalRoundTrip in goroutine 771
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:966 +0x470
