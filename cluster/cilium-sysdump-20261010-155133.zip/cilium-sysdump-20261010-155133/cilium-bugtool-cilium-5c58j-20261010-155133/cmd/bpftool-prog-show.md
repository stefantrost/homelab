43: cgroup_device  name sd_devices  tag 9f0126175d483e7a  gpl
	loaded_at 2026-10-10T11:00:22+0000  uid 0
	xlated 504B  jited 311B  memlock 4096B
44: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:22+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
45: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:22+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
46: cgroup_device  name sd_devices  tag 99aee04c1c96cc7e  gpl
	loaded_at 2026-10-10T11:00:22+0000  uid 0
	xlated 464B  jited 290B  memlock 4096B
47: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:23+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
48: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:23+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
49: cgroup_device  name sd_devices  tag 9f0126175d483e7a  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 0
	xlated 504B  jited 311B  memlock 4096B
55: cgroup_sysctl  name sysctl_monitor  tag 2953fbb83d3292b5  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 998
	xlated 1240B  jited 781B  memlock 4096B  map_ids 22,25,23
	btf_id 110
57: cgroup_device  name sd_devices  tag 925aa739a35aee81  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 0
	xlated 560B  jited 353B  memlock 4096B
58: cgroup_device  name sd_devices  tag 470479e7b2a42bb5  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 0
	xlated 184B  jited 103B  memlock 4096B
59: cgroup_device  name sd_devices  tag d82bf1294d9d3136  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 0
	xlated 792B  jited 482B  memlock 4096B
60: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
61: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:25+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
65: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
69: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
70: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
74: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
75: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
79: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
80: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
84: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
90: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
94: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
95: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
99: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
100: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
104: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
105: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
109: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
112: cgroup_device  tag b1e4e8bab2078b38
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 64B  jited 42B  memlock 4096B
136: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:56+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
140: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:56+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
176: tracing  name cil_sock_udp_destroy_v4  tag 7352b1c629812875  gpl
	loaded_at 2026-10-10T11:00:58+0000  uid 0
	xlated 328B  jited 199B  memlock 4096B  map_ids 78,64
	btf_id 143
177: tracing  name cil_sock_tcp_destroy_v4  tag 7352b1c629812875  gpl
	loaded_at 2026-10-10T11:00:58+0000  uid 0
	xlated 328B  jited 199B  memlock 4096B  map_ids 78,64
	btf_id 153
278: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:06+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
282: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:06+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
304: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
308: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
332: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
336: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
342: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
346: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
350: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
354: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
362: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
366: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
367: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
371: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:01:07+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
372: cgroup_sock  name cil_sock6_post_bind  tag 87bcd2e567b2fc57  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 1416B  jited 838B  memlock 4096B  map_ids 172,47,59
	btf_id 390
373: cgroup_sock  name cil_sock4_post_bind  tag eb9043708ec7115b  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 984B  jited 571B  memlock 4096B  map_ids 59,172,47
	btf_id 391
374: cgroup_sock_addr  name cil_sock4_recvmsg  tag ab602e317c4b1b12  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 1616B  jited 937B  memlock 4096B  map_ids 64,59,172,47,48
	btf_id 392
375: cgroup_sock_addr  name cil_sock6_getpeername  tag 54a5d2ea66def6a2  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 1848B  jited 1056B  memlock 4096B  map_ids 64,59,172,47,48
	btf_id 393
376: cgroup_sock  name cil_sock_release  tag 2ae0d55b112ace52  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 384B  jited 225B  memlock 4096B  map_ids 64,48
	btf_id 394
377: cgroup_sock_addr  name cil_sock4_getpeername  tag ab602e317c4b1b12  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 1616B  jited 937B  memlock 4096B  map_ids 64,59,172,47,48
	btf_id 395
378: cgroup_sock_addr  name cil_sock6_sendmsg  tag bb755855efb431aa  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 4600B  jited 2586B  memlock 8192B  map_ids 59,172,47,65,57,60,48,64
	btf_id 396
379: cgroup_sock_addr  name cil_sock4_connect  tag 4ff57d2b97742faf  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 6384B  jited 3538B  memlock 8192B  map_ids 59,172,47,49,56,46,65,57,60,48,64
	btf_id 397
380: cgroup_sock_addr  name cil_sock4_sendmsg  tag 5f2cec8aed4dcc77  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 4384B  jited 2489B  memlock 8192B  map_ids 59,172,47,65,57,60,48,64
	btf_id 398
381: cgroup_sock_addr  name cil_sock6_recvmsg  tag 54a5d2ea66def6a2  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 1848B  jited 1056B  memlock 4096B  map_ids 64,59,172,47,48
	btf_id 399
382: cgroup_sock_addr  name cil_sock6_connect  tag 7c373f75761f9334  gpl
	loaded_at 2026-10-10T11:01:08+0000  uid 0
	xlated 6624B  jited 3668B  memlock 8192B  map_ids 59,172,47,49,56,46,65,57,60,48,64
	btf_id 400
383: sched_cls  name cil_to_overlay  tag 2a5cfff9bcc179bc  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 5824B  jited 3361B  memlock 8192B  map_ids 177,73,48,71,72,61,175
	btf_id 405
384: sched_cls  name tail_handle_ipv4  tag 8d8aab9a5d3dff93  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 15008B  jited 8804B  memlock 24576B  map_ids 177,73,59,48,58,71,72,175,178,174,65,57,91,60,50,75,47,52
	btf_id 406
385: sched_cls  name cil_from_overlay  tag 4fa358252a534140  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 1576B  jited 991B  memlock 4096B  map_ids 177,178,174,48,175
	btf_id 407
386: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 48,175
	btf_id 408
387: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 044b138af6457378  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 13040B  jited 7763B  memlock 16384B  map_ids 177,47,73,70,48,76,74,178,174,46,69,175
	btf_id 409
388: sched_cls  name tail_drop_notify  tag 22c5d14c4d7ba9da  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 672B  jited 368B  memlock 4096B  map_ids 177,46
	btf_id 410
389: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 7b2a2942574eeb74  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 12552B  jited 7332B  memlock 16384B  map_ids 177,73,70,48,71,72,175,61,47,178,174,46,69
	btf_id 411
390: sched_cls  name tail_handle_snat_fwd_ipv4  tag 4d66401f44ecab83  gpl
	loaded_at 2026-10-10T11:01:11+0000  uid 0
	xlated 15584B  jited 8828B  memlock 20480B  map_ids 178,174,177,73,48,175,70,71,72,76,74,46
	btf_id 412
391: sched_cls  name cil_from_container  tag b1520d937090b4d6  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1392B  jited 940B  memlock 4096B  map_ids 192,188,191,186,48
	btf_id 426
392: sched_cls  name tail_handle_arp  tag 210da590646efc92  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1616B  jited 928B  memlock 4096B  map_ids 192,48,186
	btf_id 427
393: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 48,186
	btf_id 428
394: sched_cls  name tail_handle_ipv4  tag 02d6eeffe8f139ea  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 10176B  jited 5849B  memlock 16384B  map_ids 182,73,59,71,72,47,48,179,65,57,60,183,185,180
	btf_id 422
396: sched_cls  name tail_ipv4_ct_ingress  tag 96872acfd965f352  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8152B  jited 4708B  memlock 12288B  map_ids 184,182,48,180,71,72,73
	btf_id 431
397: sched_cls  name tail_handle_ipv4  tag 02d6eeffe8f139ea  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 10176B  jited 5849B  memlock 16384B  map_ids 192,73,59,71,72,47,48,190,65,57,60,188,191,186
	btf_id 429
398: sched_cls  name tail_ipv4_policy  tag c41ef863ac6002c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12168B  jited 6881B  memlock 20480B  map_ids 182,184,71,72,94,61,54,47,51,67,68,74,46,183,185,48,180
	btf_id 432
399: sched_cls  name tail_ipv4_to_endpoint  tag 424019b602880193  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12224B  jited 6751B  memlock 16384B  map_ids 47,192,48,189,71,72,133,61,54,51,67,68,74,46,188,191,186
	btf_id 433
400: sched_cls  name tail_drop_notify  tag d35c1d928a577a35  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 696B  jited 383B  memlock 4096B  map_ids 192,46
	btf_id 435
401: sched_cls  name tail_ipv4_ct_egress  tag ed73af9a5bfb3dc0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8448B  jited 4858B  memlock 12288B  map_ids 189,192,48,186,71,72,73
	btf_id 436
402: sched_cls  name tail_ipv4_ct_ingress  tag 96872acfd965f352  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8152B  jited 4708B  memlock 12288B  map_ids 189,192,48,186,71,72,73
	btf_id 437
404: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 03d630a153d5f199  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 7720B  jited 4541B  memlock 12288B  map_ids 192,73,48,186,71,72,61,47,188,191,46,69
	btf_id 439
405: sched_cls  name tail_handle_ipv4_cont  tag 035083e6cc6b8f74  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 15488B  jited 8907B  memlock 28672B  map_ids 179,182,47,184,183,185,94,46,54,51,67,68,74,71,72,48,50,180,52
	btf_id 434
406: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 48,180
	btf_id 441
407: sched_cls  name tail_handle_arp  tag 210da590646efc92  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1616B  jited 928B  memlock 4096B  map_ids 182,48,180
	btf_id 442
408: sched_cls  name cil_lxc_policy_egress  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 443
409: sched_cls  name tail_ipv4_policy  tag c41ef863ac6002c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12168B  jited 6881B  memlock 20480B  map_ids 192,189,71,72,133,61,54,47,51,67,68,74,46,188,191,48,186
	btf_id 440
410: sched_cls  name cil_lxc_policy_egress  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 445
411: sched_cls  name tail_ipv4_ct_egress  tag ed73af9a5bfb3dc0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8448B  jited 4858B  memlock 12288B  map_ids 184,182,48,180,71,72,73
	btf_id 444
412: sched_cls  name tail_drop_notify  tag d35c1d928a577a35  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 696B  jited 383B  memlock 4096B  map_ids 182,46
	btf_id 447
413: sched_cls  name tail_ipv4_to_endpoint  tag 424019b602880193  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12224B  jited 6751B  memlock 16384B  map_ids 47,182,48,184,71,72,94,61,54,51,67,68,74,46,183,185,180
	btf_id 448
414: sched_cls  name cil_lxc_policy  tag 9e007e2259856a49  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8904B  jited 5186B  memlock 12288B  map_ids 182,184,48,180,71,72,73
	btf_id 449
415: sched_cls  name tail_handle_ipv4_cont  tag 035083e6cc6b8f74  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 15488B  jited 8907B  memlock 28672B  map_ids 190,192,47,189,188,191,133,46,54,51,67,68,74,71,72,48,50,186,52
	btf_id 446
416: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 03d630a153d5f199  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 7720B  jited 4541B  memlock 12288B  map_ids 182,73,48,180,71,72,61,47,183,185,46,69
	btf_id 450
417: sched_cls  name cil_from_container  tag b1520d937090b4d6  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1392B  jited 940B  memlock 4096B  map_ids 182,183,185,180,48
	btf_id 452
418: sched_cls  name cil_lxc_policy  tag 9e007e2259856a49  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8904B  jited 5186B  memlock 12288B  map_ids 192,189,48,186,71,72,73
	btf_id 451
419: sched_cls  name cil_lxc_policy_egress  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 462
420: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 48,195
	btf_id 463
421: sched_cls  name tail_ipv4_policy  tag c41ef863ac6002c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12168B  jited 6881B  memlock 20480B  map_ids 206,199,71,72,125,61,54,47,51,67,68,74,46,197,198,48,200
	btf_id 468
422: sched_cls  name tail_handle_ipv4_cont  tag 035083e6cc6b8f74  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 15488B  jited 8907B  memlock 28672B  map_ids 196,201,47,193,194,202,110,46,54,51,67,68,74,71,72,48,50,195,52
	btf_id 464
423: sched_cls  name cil_from_container  tag b1520d937090b4d6  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1392B  jited 940B  memlock 4096B  map_ids 201,194,202,195,48
	btf_id 470
424: sched_cls  name tail_drop_notify  tag d35c1d928a577a35  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 696B  jited 383B  memlock 4096B  map_ids 201,46
	btf_id 471
425: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 03d630a153d5f199  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 7720B  jited 4541B  memlock 12288B  map_ids 201,73,48,195,71,72,61,47,194,202,46,69
	btf_id 472
426: sched_cls  name tail_handle_arp  tag 210da590646efc92  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1616B  jited 928B  memlock 4096B  map_ids 201,48,195
	btf_id 473
427: sched_cls  name tail_ipv4_ct_egress  tag ed73af9a5bfb3dc0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8448B  jited 4858B  memlock 12288B  map_ids 193,201,48,195,71,72,73
	btf_id 474
429: sched_cls  name cil_lxc_policy  tag 9e007e2259856a49  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8904B  jited 5186B  memlock 12288B  map_ids 201,193,48,195,71,72,73
	btf_id 476
430: sched_cls  name tail_handle_ipv4_cont  tag 035083e6cc6b8f74  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 15488B  jited 8907B  memlock 28672B  map_ids 205,206,47,199,197,198,125,46,54,51,67,68,74,71,72,48,50,200,52
	btf_id 469
431: sched_cls  name cil_lxc_policy_egress  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 478
432: sched_cls  name tail_handle_arp  tag 210da590646efc92  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1616B  jited 928B  memlock 4096B  map_ids 206,48,200
	btf_id 479
433: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 03d630a153d5f199  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 7720B  jited 4541B  memlock 12288B  map_ids 206,73,48,200,71,72,61,47,197,198,46,69
	btf_id 480
434: sched_cls  name tail_no_service_ipv4  tag 524138bd9681366f  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 5952B  jited 3236B  memlock 8192B  map_ids 48,200
	btf_id 481
436: sched_cls  name tail_ipv4_to_endpoint  tag 424019b602880193  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12224B  jited 6751B  memlock 16384B  map_ids 47,201,48,193,71,72,110,61,54,51,67,68,74,46,194,202,195
	btf_id 477
437: sched_cls  name tail_handle_ipv4  tag 02d6eeffe8f139ea  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 10176B  jited 5849B  memlock 16384B  map_ids 206,73,59,71,72,47,48,205,65,57,60,197,198,200
	btf_id 483
438: sched_cls  name tail_handle_ipv4  tag 02d6eeffe8f139ea  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 10176B  jited 5849B  memlock 16384B  map_ids 201,73,59,71,72,47,48,196,65,57,60,194,202,195
	btf_id 484
439: sched_cls  name tail_ipv4_ct_egress  tag ed73af9a5bfb3dc0  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8448B  jited 4858B  memlock 12288B  map_ids 199,206,48,200,71,72,73
	btf_id 485
440: sched_cls  name cil_from_container  tag b1520d937090b4d6  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 1392B  jited 940B  memlock 4096B  map_ids 206,197,198,200,48
	btf_id 487
441: sched_cls  name tail_ipv4_ct_ingress  tag 96872acfd965f352  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8152B  jited 4708B  memlock 12288B  map_ids 193,201,48,195,71,72,73
	btf_id 486
442: sched_cls  name tail_ipv4_to_endpoint  tag 424019b602880193  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12224B  jited 6751B  memlock 16384B  map_ids 47,206,48,199,71,72,125,61,54,51,67,68,74,46,197,198,200
	btf_id 488
443: sched_cls  name tail_ipv4_policy  tag c41ef863ac6002c7  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 12168B  jited 6881B  memlock 20480B  map_ids 201,193,71,72,110,61,54,47,51,67,68,74,46,194,202,48,195
	btf_id 489
444: sched_cls  name cil_lxc_policy  tag 9e007e2259856a49  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8904B  jited 5186B  memlock 12288B  map_ids 206,199,48,200,71,72,73
	btf_id 490
445: sched_cls  name tail_drop_notify  tag d35c1d928a577a35  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 696B  jited 383B  memlock 4096B  map_ids 206,46
	btf_id 491
446: sched_cls  name tail_ipv4_ct_ingress  tag 96872acfd965f352  gpl
	loaded_at 2026-10-10T11:01:14+0000  uid 0
	xlated 8152B  jited 4708B  memlock 12288B  map_ids 199,206,48,200,71,72,73
	btf_id 492
447: sched_cls  name tail_handle_ipv4_from_host  tag 225a5d1c8fc087f2  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 4504B  jited 2493B  memlock 8192B  map_ids 208,50,47,209,207,48,46,210,52
	btf_id 497
448: sched_cls  name cil_host_policy  tag 691ef55febf78432  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 16B  jited 17B  memlock 4096B
	btf_id 498
449: sched_cls  name cil_from_host  tag 8f3cbdbfcbadf3c7  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 4752B  jited 2761B  memlock 8192B  map_ids 208,209,207,48,47,210
	btf_id 499
450: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 8d993c64f0c3197f  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 13400B  jited 7999B  memlock 16384B  map_ids 208,47,73,70,48,76,74,209,207,46,69,210
	btf_id 500
451: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 852790b3abb514d8  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 12832B  jited 7642B  memlock 16384B  map_ids 208,73,70,48,71,72,210,61,47,209,207,46,69
	btf_id 501
452: sched_cls  name cil_to_host  tag f50c664f5e67920b  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 1112B  jited 660B  memlock 8192B  map_ids 208,209,207,48,210
	btf_id 502
455: sched_cls  name tail_handle_ipv4_from_netdev  tag 988163d6b4eaaa87  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 13432B  jited 7826B  memlock 24576B  map_ids 208,73,48,59,58,71,72,210,209,207,65,57,91,60,50,75
	btf_id 505
456: sched_cls  name tail_handle_snat_fwd_ipv4  tag 58a967a976e4a8da  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 16320B  jited 9341B  memlock 20480B  map_ids 208,209,207,50,73,48,210,70,71,72,46,76,74
	btf_id 506
457: sched_cls  name tail_drop_notify  tag 21aecbc2f8151ba0  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 1232B  jited 694B  memlock 4096B  map_ids 208,46
	btf_id 507
458: sched_cls  name tail_handle_snat_fwd_ipv4  tag 58a967a976e4a8da  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 16320B  jited 9341B  memlock 20480B  map_ids 213,212,214,50,73,48,215,70,71,72,46,76,74
	btf_id 512
459: sched_cls  name tail_handle_ipv4_from_host  tag 225a5d1c8fc087f2  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 4504B  jited 2493B  memlock 8192B  map_ids 213,50,47,212,214,48,46,215,52
	btf_id 513
460: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 852790b3abb514d8  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 12832B  jited 7642B  memlock 16384B  map_ids 213,73,70,48,71,72,215,61,47,212,214,46,69
	btf_id 514
461: sched_cls  name tail_drop_notify  tag 21aecbc2f8151ba0  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 1232B  jited 694B  memlock 4096B  map_ids 213,46
	btf_id 515
463: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 8d993c64f0c3197f  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 13400B  jited 7999B  memlock 16384B  map_ids 213,47,73,70,48,76,74,212,214,46,69,215
	btf_id 517
465: sched_cls  name cil_to_host  tag f50c664f5e67920b  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 1112B  jited 660B  memlock 8192B  map_ids 213,212,214,48,215
	btf_id 519
466: sched_cls  name tail_handle_ipv4_from_netdev  tag e284f0cfeabf09ef  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 13408B  jited 7846B  memlock 24576B  map_ids 213,73,48,59,58,71,72,215,212,214,65,57,91,60,50,75
	btf_id 520
468: sched_cls  name tail_no_service_ipv4  tag 407d6feccaa41e51  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 5984B  jited 3254B  memlock 8192B  map_ids 213,48,215
	btf_id 522
470: sched_cls  name tail_no_service_ipv4  tag 407d6feccaa41e51  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 5984B  jited 3254B  memlock 8192B  map_ids 221,48,217
	btf_id 528
471: sched_cls  name tail_handle_ipv4_from_host  tag 225a5d1c8fc087f2  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 4504B  jited 2493B  memlock 8192B  map_ids 221,50,47,218,220,48,46,217,52
	btf_id 529
473: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 8d993c64f0c3197f  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 13400B  jited 7999B  memlock 16384B  map_ids 221,47,73,70,48,76,74,218,220,46,69,217
	btf_id 531
474: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 852790b3abb514d8  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 12832B  jited 7642B  memlock 16384B  map_ids 221,73,70,48,71,72,217,61,47,218,220,46,69
	btf_id 532
476: sched_cls  name cil_to_netdev  tag 43afcdec1d06a13e  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 8840B  jited 5250B  memlock 16384B  map_ids 221,73,48,71,72,61,69,218,220,217,46
	btf_id 534
477: sched_cls  name tail_handle_ipv4_from_netdev  tag e284f0cfeabf09ef  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 13408B  jited 7846B  memlock 24576B  map_ids 221,73,48,59,58,71,72,217,218,220,65,57,91,60,50,75
	btf_id 535
479: sched_cls  name tail_handle_snat_fwd_ipv4  tag 58a967a976e4a8da  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 16320B  jited 9341B  memlock 20480B  map_ids 221,218,220,50,73,48,217,70,71,72,46,76,74
	btf_id 537
480: sched_cls  name tail_drop_notify  tag 21aecbc2f8151ba0  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 1232B  jited 694B  memlock 4096B  map_ids 221,46
	btf_id 538
481: sched_cls  name cil_from_netdev  tag 0ebe730923df919a  gpl
	loaded_at 2026-10-10T11:01:17+0000  uid 0
	xlated 3944B  jited 2386B  memlock 8192B  map_ids 221,47,218,220,48,217
	btf_id 539
485: cgroup_device  name sd_devices  tag e5cec4a5a9ebe958  gpl
	loaded_at 2026-10-10T13:51:30+0000  uid 0
	xlated 1712B  jited 1043B  memlock 4096B
