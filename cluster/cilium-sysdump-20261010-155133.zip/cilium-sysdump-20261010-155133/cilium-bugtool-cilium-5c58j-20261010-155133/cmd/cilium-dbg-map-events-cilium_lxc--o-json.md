{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:48:58.728Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:48:58.728Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:48:58.728Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:48:58.728Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:50:58.730Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:50:58.730Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:50:58.731Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:50:58.731Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:52:58.732Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:52:58.732Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:52:58.732Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:52:58.732Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:54:58.734Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:54:58.734Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:54:58.734Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:54:58.735Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:56:58.735Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:56:58.736Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:56:58.736Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:56:58.737Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:58:58.738Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:58:58.738Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:58:58.738Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T12:58:58.738Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:00:58.740Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:00:58.740Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:00:58.740Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:00:58.740Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:02:58.741Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:02:58.742Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:02:58.742Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:02:58.742Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:04:58.744Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:04:58.744Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:04:58.744Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:04:58.745Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:06:58.746Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:06:58.746Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:06:58.746Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:06:58.747Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:08:58.748Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:08:58.748Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:08:58.748Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:08:58.749Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:10:58.750Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:10:58.750Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:10:58.751Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:10:58.751Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:12:58.752Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:12:58.752Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:12:58.753Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:12:58.753Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:14:58.754Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:14:58.754Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:14:58.755Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:14:58.755Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:16:58.757Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:16:58.757Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:16:58.758Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:16:58.758Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:18:58.759Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:18:58.760Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:18:58.760Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:18:58.760Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:20:58.761Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:20:58.762Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:20:58.762Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:20:58.762Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:22:58.764Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:22:58.764Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:22:58.764Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:22:58.764Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:24:58.766Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:24:58.766Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:24:58.766Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:24:58.766Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:26:58.768Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:26:58.768Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:26:58.768Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:26:58.769Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:28:58.769Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:28:58.770Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:28:58.770Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:28:58.770Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:30:58.772Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:30:58.772Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:30:58.772Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:30:58.772Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:32:58.773Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:32:58.773Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:32:58.774Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:32:58.774Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:34:58.775Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:34:58.775Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:34:58.775Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:34:58.775Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:36:58.776Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:36:58.777Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:36:58.777Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:36:58.777Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:38:58.778Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:38:58.779Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:38:58.779Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:38:58.779Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:40:58.780Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:40:58.781Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:40:58.781Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:40:58.781Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:42:58.782Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:42:58.783Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:42:58.783Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:42:58.783Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:44:58.785Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:44:58.785Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:44:58.785Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:44:58.785Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:46:58.786Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:46:58.786Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:46:58.787Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:46:58.787Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:48:58.788Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:48:58.788Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:48:58.789Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:48:58.789Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:50:58.791Z",
  "value": "id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:50:58.791Z",
  "value": "id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:50:58.791Z",
  "value": "id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.2.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2026-10-10T13:50:58.791Z",
  "value": "id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0"
}

