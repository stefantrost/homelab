KVStore:                Disabled   
Kubernetes:             Ok         1.37 (v1.37.1) [linux/amd64]
Kubernetes APIs:        ["cilium/v2::CiliumCIDRGroup", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "core/v1::Pods", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [ens18     192.168.178.115 fda7:7b49:a70a:0:be24:11ff:fe3c:bfbe 2a02:8071:5301:a0a0:be24:11ff:fe3c:bfbe fe80::be24:11ff:fe3c:bfbe (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.20.2 (v1.20.2-e0dc92bd)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.244.2.0/24, 
Allocated addresses:
  10.244.2.11 (kube-system/coredns-559f6c778d-jc27s)
  10.244.2.154 (kube-system/hubble-relay-856fb9b979-qblz5)
  10.244.2.226 (router)
  10.244.2.31 (kube-system/hubble-ui-6dcdfb579c-s4xpb)
  10.244.2.84 (health)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            TCX
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      28/28 healthy
  Name                                                       Last success   Last error   Count   Message
  cilium-health-ep                                           10s ago        never        0       no error   
  ct-map-pressure                                            11s ago        never        0       no error   
  endpoint-1075-regeneration-recovery                        never          never        0       no error   
  endpoint-1508-regeneration-recovery                        never          never        0       no error   
  endpoint-172-regeneration-recovery                         never          never        0       no error   
  endpoint-461-regeneration-recovery                         never          never        0       no error   
  endpoint-462-regeneration-recovery                         never          never        0       no error   
  endpoint-gc                                                1m11s ago      never        0       no error   
  endpoint-periodic-regeneration                             1m11s ago      never        0       no error   
  ipcache-inject-labels                                      11s ago        never        0       no error   
  k8s-heartbeat                                              11s ago        never        0       no error   
  resolve-identity-1075                                      1m10s ago      never        0       no error   
  resolve-identity-1508                                      1m7s ago       never        0       no error   
  resolve-identity-172                                       1m7s ago       never        0       no error   
  resolve-identity-461                                       1m11s ago      never        0       no error   
  resolve-identity-462                                       1m7s ago       never        0       no error   
  resolve-labels-kube-system/coredns-559f6c778d-jc27s        2h51m7s ago    never        0       no error   
  resolve-labels-kube-system/hubble-relay-856fb9b979-qblz5   2h51m7s ago    never        0       no error   
  resolve-labels-kube-system/hubble-ui-6dcdfb579c-s4xpb      2h51m7s ago    never        0       no error   
  sync-policymap-1075                                        6m3s ago       never        0       no error   
  sync-policymap-1508                                        6m3s ago       never        0       no error   
  sync-policymap-172                                         6m3s ago       never        0       no error   
  sync-policymap-461                                         6m3s ago       never        0       no error   
  sync-policymap-462                                         6m3s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1508)                          7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (172)                           7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (462)                           7s ago         never        0       no error   
  write-cni-file                                             2h51m11s ago   never        0       no error   
Proxy Status:            OK, ip 10.244.2.226, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 6.32   Metrics: Disabled
KubeProxyReplacement Details:
  Status:               True
  Socket LB:            Enabled
  Socket LB Tracing:    Enabled
  Socket LB Coverage:   Hostns-only
  Devices:              ens18     192.168.178.115 fda7:7b49:a70a:0:be24:11ff:fe3c:bfbe 2a02:8071:5301:a0a0:be24:11ff:fe3c:bfbe fe80::be24:11ff:fe3c:bfbe (Direct Routing)
  Mode:                 SNAT
  Backend Selection:    Random
  Session Affinity:     Enabled
  NAT46/64 Support:     Disabled
  XDP Acceleration:     Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
  Annotations:
  - service.cilium.io/node
  - service.cilium.io/node-selector
  - service.cilium.io/proxy-delegation
  - service.cilium.io/src-ranges-policy
  - service.cilium.io/type
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoints                     65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  Ratelimit metrics             64
  NAT                           131072
  Neighbor table                131072
  Endpoint policy               16384
  Policy stats                  65536
  Session affinity              65536
  Sock reverse NAT              65536
Encryption:       Disabled        
Cluster health:   2/3 reachable   (2026-10-10T13:50:23Z)   (Probe interval: 1m56.754608943s)
Name              IP              Node                     Endpoints
  workernode02 (localhost):
    Host connectivity to 192.168.178.115:
      ICMP to stack:   OK, RTT=168.011µs   (Last probed: 2026-10-10T13:50:23Z)
      HTTP to agent:   OK, RTT=170.794µs   (Last probed: 2026-10-10T13:50:23Z)
    Endpoint connectivity to 10.244.2.84:
      ICMP to stack:   OK, RTT=120.415µs   (Last probed: 2026-10-10T13:50:43Z)
      HTTP to agent:   OK, RTT=377.281µs   (Last probed: 2026-10-10T13:50:43Z)
  controlplane:
    Host connectivity to 192.168.178.113:
      ICMP to stack:   OK, RTT=272.325µs                                                                                     (Last probed: 2026-10-10T13:52:01Z)
      HTTP to agent:   Get "http://192.168.178.113:4240/hello": dial tcp 192.168.178.113:4240: connect: connection refused   (Last probed: 2026-10-10T13:52:01Z)
    Endpoint connectivity to 10.244.0.27:
      ICMP to stack:   Connection timed out                                                                                              (Last probed: 2026-10-10T13:51:51Z)
      HTTP to agent:   Get "http://10.244.0.27:4240/hello": context deadline exceeded (Client.Timeout exceeded while awaiting headers)   (Last probed: 2026-10-10T13:51:51Z)
  workernode01:
    Host connectivity to 192.168.178.114:
      ICMP to stack:   OK, RTT=308.845µs   (Last probed: 2026-10-10T13:51:02Z)
      HTTP to agent:   OK, RTT=510.862µs   (Last probed: 2026-10-10T13:51:02Z)
    Endpoint connectivity to 10.244.1.197:
      ICMP to stack:   OK, RTT=355.587µs   (Last probed: 2026-10-10T13:51:22Z)
      HTTP to agent:   OK, RTT=906.038µs   (Last probed: 2026-10-10T13:51:22Z)
Modules Health:        Stopped(0) Degraded(0) OK(85)
  agent
  ├── controlplane
  │   ├── cgroup-manager
  │   │   └── job-process-pod-events                              [OK] Running (171m, x1)
  │   ├── cilium-agent-dynamic-config
  │   │   └── job-k8s-reflector-cilium-configs-cm-cilium-config-kube-system      [OK] 161 upserted, 0 deleted, 161 total objects (171m, x1)
  │   ├── ciliumenvoyconfig
  │   │   ├── job-node-labels                                     [OK] Running (171m, x1)
  │   │   ├── job-reconcile                                       [OK] OK, 0 object(s) (171m, x2)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (21m, x6)
  │   ├── config-drift-checker
  │   │   └── job-drift-checker                                   [OK] Running (171m, x1)
  │   ├── daemonconfig
  │   │   └── timer-job-validate-unchanged-daemon-config          [OK] OK (74.131µs) (23s, x1)
  │   ├── dynamic-lifecycle-manager
  │   │   ├── job-reconcile                                       [OK] OK, 0 object(s) (51m, x5)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (21m, x6)
  │   ├── endpoint-manager
  │   │   ├── cilium-endpoint-1075 (/)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (71s, x88)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-1075 (6m3s, x12)
  │   │   ├── cilium-endpoint-1508 (kube-system/coredns-559f6c778d-jc27s)
  │   │   │   ├── cep-k8s-sync                                    [OK] sync-to-k8s-ciliumendpoint (1508) (7s, x1028)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (71s, x87)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-1508 (6m3s, x12)
  │   │   ├── cilium-endpoint-172 (kube-system/hubble-relay-856fb9b979-qblz5)
  │   │   │   ├── cep-k8s-sync                                    [OK] sync-to-k8s-ciliumendpoint (172) (7s, x1028)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (71s, x87)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-172 (6m3s, x12)
  │   │   ├── cilium-endpoint-461 (/)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (71s, x88)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-461 (6m3s, x12)
  │   │   ├── cilium-endpoint-462 (kube-system/hubble-ui-6dcdfb579c-s4xpb)
  │   │   │   ├── cep-k8s-sync                                    [OK] sync-to-k8s-ciliumendpoint (462) (7s, x1028)
  │   │   │   ├── datapath-regenerate                             [OK] Endpoint regeneration successful (71s, x87)
  │   │   │   └── policymap-sync                                  [OK] sync-policymap-462 (6m3s, x12)
  │   │   ├── endpoint-gc                                         [OK] endpoint-gc (71s, x35)
  │   │   └── job-namespace-updater                               [OK] Running (171m, x1)
  │   ├── envoy-proxy
  │   │   ├── job-accesslog-server                                [OK] Running (171m, x1)
  │   │   ├── job-xds-server                                      [OK] Running (171m, x1)
  │   │   ├── observer-job-k8s-secrets-resource-events-cilium-secrets      [OK] Primed (171m, x1)
  │   │   └── timer-job-version-check                             [OK] OK (2.31623ms) (71s, x1)
  │   ├── ep-bpf-prog-watchdog
  │   │   └── timer-job-ep-bpf-prog-watchdog                      [OK] OK (914.365µs) (11s, x1)
  │   ├── fqdn
  │   │   └── namemanager
  │   │       ├── observer-job-preallocate                        [OK] Primed (171m, x1)
  │   │       └── timer-job-dns-garbage-collector-job             [OK] OK (32.202µs) (11s, x1)
  │   ├── hostip-sync
  │   │   └── job-sync-hostips                                    [OK] Synchronized (11s, x174)
  │   ├── hubble
  │   │   └── timer-job-hubble-namespace-cleanup                  [OK] OK (1.134µs) (71s, x1)
  │   ├── identity-policy-computer
  │   │   └── job-policy-computation-loop                         [OK] Running (171m, x1)
  │   ├── ipam
  │   │   └── ipam-podippool-table
  │   │       └── job-k8s-reflector-podippools-daemon-k8s         [OK] 0 upserted, 0 deleted, 0 total objects (171m, x1)
  │   ├── ipcache
  │   │   └── job-api-server-backend-watcher                      [OK] Running (171m, x1)
  │   ├── k8s-tables
  │   │   ├── job-k8s-reflector-k8s-namespaces-daemon-k8s         [OK] 5 upserted, 0 deleted, 5 total objects (171m, x1)
  │   │   └── job-k8s-reflector-k8s-pods-daemon-k8s               [OK] 1 upserted, 0 deleted, 7 total objects (170m, x13)
  │   ├── l7-proxy
  │   │   └── timer-job-proxy-ports-checkpoint                    [OK] OK (265.139µs) (11s, x1)
  │   ├── loadbalancer-healthserver
  │   │   └── job-control-loop                                    [OK] 0 health servers running (20m, x58)
  │   ├── loadbalancer-maps
  │   │   └── timer-job-pressure-metrics-reporter                 [OK] OK (473.918µs) (71s, x1)
  │   ├── loadbalancer-reconciler
  │   │   ├── job-reconcile                                       [OK] OK, 7 object(s) (20m, x119)
  │   │   ├── job-refresh                                         [OK] Next refresh in 29m39.510496648s (20m, x1)
  │   │   └── socket-termination
  │   │       └── job-socket-termination                          [OK] Running (171m, x1)
  │   ├── loadbalancer-reflectors
  │   │   └── k8s-reflector
  │   │       ├── job-reflect-pods                                [OK] Running (171m, x1)
  │   │       └── job-reflect-services-endpoints                  [OK] Running (171m, x1)
  │   ├── loadbalancer-writer
  │   │   ├── job-node-addr-reconciler                            [OK] Running (171m, x1)
  │   │   └── job-wildcard-addr-reconciler                        [OK] Running (171m, x1)
  │   ├── local-node-store
  │   │   └── job-sync-local-node                                 [OK] Running (171m, x1)
  │   ├── nat-stats
  │   │   └── timer-job-nat-stats                                 [OK] OK (326.489µs) (11s, x1)
  │   ├── node-manager
  │   │   ├── job-backgroundSync                                  [OK] Node validation successful (64s, x123)
  │   │   ├── node-checkpoint-writer                              [OK] node checkpoint written (169m, x3)
  │   │   ├── nodes-add                                           [OK] Node adds successful (171m, x3)
  │   │   └── nodes-update                                        [OK] Node updates successful (171m, x1)
  │   ├── policy
  │   │   ├── observer-job-policy-importer                        [OK] Primed (171m, x1)
  │   │   └── timer-job-id-alloc-update-policy-maps               [OK] OK (67.982µs) (23m, x1)
  │   ├── status
  │   │   └── job-probes                                          [OK] Running (171m, x1)
  │   └── ztunnel
  │       └── enrollment-reconciler
  │           └── job-derive-desired-mtls-namespace-enrollments    [OK] Running (171m, x1)
  ├── datapath
  │   ├── agent-liveness-updater
  │   │   └── timer-job-agent-liveness-updater                    [OK] OK (33.505µs) (0s, x1)
  │   ├── device-reconciler
  │   │   ├── job-reconcile                                       [OK] OK, 0 object(s) (21m, x7)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (21m, x6)
  │   ├── iptables
  │   │   ├── ipset
  │   │   │   ├── job-reconcile                                   [OK] OK, 0 object(s) (51m, x4)
  │   │   │   └── job-refresh                                     [OK] Next refresh in 30m0s (21m, x6)
  │   │   └── job-iptables-reconciliation-loop                    [OK] iptables rules full reconciliation completed (21m, x5)
  │   ├── l2-responder
  │   │   └── job-l2-responder-reconciler                         [OK] Running (171m, x1)
  │   ├── link-cache
  │   │   └── timer-job-sync                                      [OK] OK (225.726µs) (11s, x1)
  │   ├── maps
  │   │   ├── ct-nat-map-gc
  │   │   │   ├── observer-job-nat-map-next4                      [OK] OK (685ns) [4089] (10m, x1)
  │   │   │   └── observer-job-nat-map-next6                      [OK] Primed (171m, x1)
  │   │   ├── netdev-map
  │   │   │   └── netdev-map-sync
  │   │   │       └── job-netdev-map-sync                         [OK] Running (171m, x1)
  │   │   └── subnet-map
  │   │       └── timer-job-pressure-metric-subnet_map            [OK] OK (999ns) (11s, x1)
  │   ├── mtu
  │   │   ├── job-endpoint-mtu-updater                            [OK] Endpoint MTU updated (171m, x1)
  │   │   └── job-mtu-updater                                     [OK] MTU updated (1500) (171m, x1)
  │   ├── node-address
  │   │   └── job-node-address-update                             [OK] 10.244.2.226 (primary), fe80::187e:19ff:feea:11c7 (171m, x1)
  │   ├── orchestrator
  │   │   └── job-reinitialize                                    [OK] OK (170m, x2)
  │   ├── route-reconciler
  │   │   ├── job-desired-route-refresher                         [OK] Running (171m, x1)
  │   │   ├── job-reconcile                                       [OK] OK, 1 object(s) (20m, x30)
  │   │   └── job-refresh                                         [OK] Next refresh in 30m0s (20m, x1)
  │   ├── sysctl
  │   │   ├── job-reconcile                                       [OK] OK, 20 object(s) (62s, x336)
  │   │   └── job-refresh                                         [OK] Next refresh in 9m50.60175563s (62s, x1)
  │   └── utime
  │       └── timer-job-sync-userspace-and-datapath               [OK] OK (90.884µs) (11s, x1)
  └── infra
      ├── agent-healthz
      │   └── job-agent-healthz-server-ipv4                       [OK] Running (171m, x1)
      ├── metrics
      │   ├── job-collect                                         [OK] Sampled 24 metrics in 2.771857ms, next collection at 2026-10-10 13:55:58.347061174 +0000 UTC m=+10501.316193157 (71s, x1)
      │   └── timer-job-cleanup                                   [OK] OK (88.787µs) (51m, x1)
      └── shell
          └── job-listener                                        [OK] Listening on /var/run/cilium/shell.sock (171m, x1)
  health
  └── job-module-status-metrics                   [OK] Running (171m, x1)
  

