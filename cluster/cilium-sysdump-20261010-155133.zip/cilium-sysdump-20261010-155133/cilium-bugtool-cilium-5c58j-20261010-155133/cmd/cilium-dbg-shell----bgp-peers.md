<stdin>:0: bgp/peers: bgp router manager is not running
error: <stdin>:0: bgp/peers: bgp router manager is not running
> Error while running 'cilium-dbg shell -- bgp/peers':  exit status 1

