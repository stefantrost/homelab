<stdin>:0: bgp/route-policies: bgp router manager is not running
error: <stdin>:0: bgp/route-policies: bgp router manager is not running
> Error while running 'cilium-dbg shell -- bgp/route-policies':  exit status 1

