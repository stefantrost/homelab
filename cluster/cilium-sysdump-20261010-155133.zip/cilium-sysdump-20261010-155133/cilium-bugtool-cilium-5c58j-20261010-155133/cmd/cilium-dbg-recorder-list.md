Error: unknown command "recorder" for "cilium-dbg"
Run 'cilium-dbg --help' for usage.
unknown command "recorder" for "cilium-dbg"
> Error while running 'cilium-dbg recorder list':  exit status 1

