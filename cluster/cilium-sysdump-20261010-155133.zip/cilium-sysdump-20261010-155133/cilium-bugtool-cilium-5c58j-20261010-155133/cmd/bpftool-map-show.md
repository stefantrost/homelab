22: cgroup_array  name cgroup_map  flags 0x0
	key 4B  value 4B  max_entries 1  memlock 320B
23: ringbuf  name written_sysctls  flags 0x0
	key 0B  value 0B  max_entries 262144  memlock 275784B
25: array  name .rodata.str1.1  flags 0x80
	key 4B  value 5B  max_entries 1  memlock 320B
	frozen
46: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 328B
47: lpm_trie  name cilium_ipcache_  flags 0x81
	key 24B  value 24B  max_entries 512000  memlock 1088B
48: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 18840B
49: hash  name cilium_ratelimi  flags 0x1
	key 4B  value 8B  max_entries 64  memlock 1920B
50: hash  name cilium_lxc  flags 0x81
	key 20B  value 48B  max_entries 65535  memlock 1050240B
51: hash  name cilium_node_map  flags 0x81
	key 20B  value 4B  max_entries 16384  memlock 263568B
52: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524592B
	owner_prog_type sched_cls  owner jited
53: prog_array  name cilium_egressca  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524592B
	owner_prog_type sched_cls  owner jited
54: lru_percpu_hash  name cilium_policyst  flags 0x2
	key 12B  value 16B  max_entries 65536  memlock 7865216B
55: percpu_array  name cilium_percpu_t  flags 0x0
	key 4B  value 8B  max_entries 1  memlock 336B
56: lru_hash  name cilium_ratelimi  flags 0x0
	key 8B  value 16B  max_entries 1024  memlock 91008B
57: hash  name cilium_lb_affin  flags 0x81
	key 8B  value 1B  max_entries 65536  memlock 1049472B
58: lpm_trie  name cilium_lb4_sour  flags 0x81
	key 12B  value 1B  max_entries 65536  memlock 0B
59: hash  name cilium_lb4_serv  flags 0x81
	key 12B  value 12B  max_entries 65536  memlock 1051408B
60: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1050272B
61: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 1049976B
63: hash_of_maps  name cilium_lb4_magl  flags 0x81
	key 2B  value 4B  max_entries 65536  memlock 1049472B
64: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 5768064B
65: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6292352B
66: hash  name cilium_skip_lb4  flags 0x81
	key 16B  value 1B  max_entries 100  memlock 2944B
67: hash  name cilium_auth_map  flags 0x81
	key 12B  value 8B  max_entries 524288  memlock 8389504B
	btf_id 139
68: array  name cilium_runtime_  flags 0x80
	key 4B  value 8B  max_entries 256  memlock 2360B
	btf_id 140
69: hash  name cilium_devices  flags 0x1
	key 4B  value 16B  max_entries 512  memlock 9168B
	btf_id 140
70: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 15729536B
	btf_id 140
71: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 17826688B
	btf_id 140
72: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 8913792B
	btf_id 140
73: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 721792B
	btf_id 140
74: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 328B
	btf_id 140
75: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 10486656B
	btf_id 140
76: percpu_array  name cilium_snat_v4_  flags 0x0
	key 4B  value 4B  max_entries 33  memlock 1104B
	btf_id 140
78: array  name .bss  flags 0x400
	key 4B  value 20B  max_entries 1  memlock 8192B
	btf_id 142
80: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 66432B
	btf_id 142
81: hash  name cilium_l2_respo  flags 0x1
	key 24B  value 8B  max_entries 4096  memlock 66432B
	btf_id 142
91: hash_of_maps  name cilium_lb4_magl  flags 0x81
	key 2B  value 4B  max_entries 65536  memlock 1049472B
	btf_id 142
93: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 142
94: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 142
110: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 142
125: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 142
133: lpm_trie  name cilium_policy_v  flags 0x81
	key 12B  value 12B  max_entries 16384  memlock 440B
	btf_id 142
172: array  name .rodata.config  flags 0x480
	key 4B  value 152B  max_entries 1  memlock 8192B
	btf_id 388  frozen
174: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 388
175: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 388
177: array  name .rodata.config  flags 0x480
	key 4B  value 192B  max_entries 1  memlock 8192B
	btf_id 403  frozen
178: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 404  frozen
179: percpu_array  name cilium_nodeport  flags 0x0
	key 4B  value 18B  max_entries 1  memlock 368B
	btf_id 413
180: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 413
182: array  name .rodata.config  flags 0x480
	key 4B  value 249B  max_entries 1  memlock 8192B
	btf_id 415  frozen
183: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 416  frozen
184: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 60B  max_entries 1  memlock 448B
	btf_id 417
185: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 417
186: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 417
188: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 420  frozen
189: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 60B  max_entries 1  memlock 448B
	btf_id 421
190: percpu_array  name cilium_nodeport  flags 0x0
	key 4B  value 18B  max_entries 1  memlock 368B
	btf_id 423
191: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 423
192: array  name .rodata.config  flags 0x480
	key 4B  value 249B  max_entries 1  memlock 8192B
	btf_id 425  frozen
193: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 60B  max_entries 1  memlock 448B
	btf_id 453
194: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 454  frozen
195: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 454
196: percpu_array  name cilium_nodeport  flags 0x0
	key 4B  value 18B  max_entries 1  memlock 368B
	btf_id 455
197: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 456  frozen
198: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 456
199: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 60B  max_entries 1  memlock 448B
	btf_id 458
200: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 458
201: array  name .rodata.config  flags 0x480
	key 4B  value 249B  max_entries 1  memlock 8192B
	btf_id 459  frozen
202: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 459
205: percpu_array  name cilium_nodeport  flags 0x0
	key 4B  value 18B  max_entries 1  memlock 368B
	btf_id 466
206: array  name .rodata.config  flags 0x480
	key 4B  value 249B  max_entries 1  memlock 8192B
	btf_id 467  frozen
207: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 467
208: array  name .rodata.config  flags 0x480
	key 4B  value 221B  max_entries 1  memlock 8192B
	btf_id 494  frozen
209: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 495  frozen
210: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 495
212: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 508  frozen
213: array  name .rodata.config  flags 0x480
	key 4B  value 221B  max_entries 1  memlock 8192B
	btf_id 509  frozen
214: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 509
215: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 509
217: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 712B
	owner_prog_type sched_cls  owner jited
	btf_id 509
218: array  name .rodata.aux  flags 0x480
	key 4B  value 16B  max_entries 1  memlock 8192B
	btf_id 524  frozen
220: array  name .data.aux  flags 0x400
	key 4B  value 768B  max_entries 1  memlock 8192B
	btf_id 524
221: array  name .rodata.config  flags 0x480
	key 4B  value 221B  max_entries 1  memlock 8192B
	btf_id 527  frozen
