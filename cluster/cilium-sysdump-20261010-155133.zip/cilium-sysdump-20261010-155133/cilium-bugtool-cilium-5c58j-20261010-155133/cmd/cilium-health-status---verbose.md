Cluster health:   2/3 reachable   (2026-10-10T13:50:23Z)   (Probe interval: 1m56.754608943s)
Name              IP              Node                     Endpoints
  workernode02 (localhost):
    Host connectivity to 192.168.178.115:
      ICMP to stack:   OK, RTT=168.011µs   (Last probed: 2026-10-10T13:50:23Z)
      HTTP to agent:   OK, RTT=170.794µs   (Last probed: 2026-10-10T13:50:23Z)
    Endpoint connectivity to 10.244.2.84:
      ICMP to stack:   OK, RTT=120.415µs   (Last probed: 2026-10-10T13:50:43Z)
      HTTP to agent:   OK, RTT=377.281µs   (Last probed: 2026-10-10T13:50:43Z)
  controlplane:
    Host connectivity to 192.168.178.113:
      ICMP to stack:   OK, RTT=272.325µs                                                                                     (Last probed: 2026-10-10T13:52:01Z)
      HTTP to agent:   Get "http://192.168.178.113:4240/hello": dial tcp 192.168.178.113:4240: connect: connection refused   (Last probed: 2026-10-10T13:52:01Z)
    Endpoint connectivity to 10.244.0.27:
      ICMP to stack:   Connection timed out                                                                                              (Last probed: 2026-10-10T13:51:51Z)
      HTTP to agent:   Get "http://10.244.0.27:4240/hello": context deadline exceeded (Client.Timeout exceeded while awaiting headers)   (Last probed: 2026-10-10T13:51:51Z)
  workernode01:
    Host connectivity to 192.168.178.114:
      ICMP to stack:   OK, RTT=308.845µs   (Last probed: 2026-10-10T13:51:02Z)
      HTTP to agent:   OK, RTT=510.862µs   (Last probed: 2026-10-10T13:51:02Z)
    Endpoint connectivity to 10.244.1.197:
      ICMP to stack:   OK, RTT=355.587µs   (Last probed: 2026-10-10T13:51:22Z)
      HTTP to agent:   OK, RTT=906.038µs   (Last probed: 2026-10-10T13:51:22Z)
