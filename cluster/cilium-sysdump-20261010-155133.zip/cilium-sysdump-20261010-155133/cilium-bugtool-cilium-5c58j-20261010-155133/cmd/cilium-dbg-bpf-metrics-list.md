REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     105323    24174710   1248   bpf_host.c
Interface                 INGRESS     2005      149324     564    bpf_overlay.c
Interface                 INGRESS     26300     4524259    1282   bpf_host.c
Interface                 INGRESS     621       34208      1268   bpf_host.c
Stale or unroutable IP    INGRESS     1         112        995    bpf_host.c
Success                   EGRESS      3066      225577     34     encap.h
Success                   EGRESS      41378     4476183    1389   bpf_lxc.c
Success                   EGRESS      4421      535300     1655   bpf_host.c
Success                   EGRESS      53890     8431585    470    nodeport_egress.h
Success                   EGRESS      963       70766      1918   bpf_host.c
Success                   INGRESS     50302     4507103    152    local_delivery.h
Success                   INGRESS     51364     4587061    2316   bpf_lxc.c
Unsupported L3 protocol   EGRESS      33        2310       1841   bpf_lxc.c
