key: ac 00 00 00  value: ad 01 00 00
key: cd 01 00 00  value: c0 01 00 00
key: ce 01 00 00  value: bc 01 00 00
key: 33 04 00 00  value: 9e 01 00 00
key: e4 05 00 00  value: a2 01 00 00
Found 5 elements
