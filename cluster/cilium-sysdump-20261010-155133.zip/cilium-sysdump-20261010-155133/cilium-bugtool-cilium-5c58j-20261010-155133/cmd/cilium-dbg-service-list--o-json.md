[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "192.168.178.113",
          "port": 6443,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.1",
        "port": 443,
        "protocol": "TCP",
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "192.168.178.113",
            "port": 6443,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.1",
          "port": 443,
          "protocol": "TCP",
          "scope": "external"
        },
        "id": 1
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.1.214",
          "nodeName": "workernode01",
          "port": 53,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.2.11",
          "nodeName": "workernode02",
          "port": 53,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 53,
        "protocol": "TCP",
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.1.214",
            "nodeName": "workernode01",
            "port": 53,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.2.11",
            "nodeName": "workernode02",
            "port": 53,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 53,
          "protocol": "TCP",
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.1.214",
          "nodeName": "workernode01",
          "port": 53,
          "preferred": true,
          "protocol": "UDP",
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.2.11",
          "nodeName": "workernode02",
          "port": 53,
          "preferred": true,
          "protocol": "UDP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 53,
        "protocol": "UDP",
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.1.214",
            "nodeName": "workernode01",
            "port": 53,
            "preferred": true,
            "protocol": "UDP",
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.2.11",
            "nodeName": "workernode02",
            "port": 53,
            "preferred": true,
            "protocol": "UDP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 53,
          "protocol": "UDP",
          "scope": "external"
        },
        "id": 3
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.1.214",
          "nodeName": "workernode01",
          "port": 9153,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.2.11",
          "nodeName": "workernode02",
          "port": 9153,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 9153,
        "protocol": "TCP",
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.1.214",
            "nodeName": "workernode01",
            "port": 9153,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.2.11",
            "nodeName": "workernode02",
            "port": 9153,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 9153,
          "protocol": "TCP",
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.2.31",
          "nodeName": "workernode02",
          "port": 8081,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-ui",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.97.123.232",
        "port": 80,
        "protocol": "TCP",
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.2.31",
            "nodeName": "workernode02",
            "port": 8081,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-ui",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.97.123.232",
          "port": 80,
          "protocol": "TCP",
          "scope": "external"
        },
        "id": 5
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "192.168.178.115",
          "nodeName": "workernode02",
          "port": 4244,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.101.247.67",
        "port": 443,
        "protocol": "TCP",
        "scope": "external"
      },
      "id": 6
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "192.168.178.115",
            "nodeName": "workernode02",
            "port": 4244,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.101.247.67",
          "port": 443,
          "protocol": "TCP",
          "scope": "external"
        },
        "id": 6
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.2.154",
          "nodeName": "workernode02",
          "port": 4245,
          "preferred": true,
          "protocol": "TCP",
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-relay",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.105.79.192",
        "port": 80,
        "protocol": "TCP",
        "scope": "external"
      },
      "id": 7
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.2.154",
            "nodeName": "workernode02",
            "port": 4245,
            "preferred": true,
            "protocol": "TCP",
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-relay",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.105.79.192",
          "port": 80,
          "protocol": "TCP",
          "scope": "external"
        },
        "id": 7
      }
    }
  }
]

