Metric                                                                   Labels                                                                                Value
cilium_act_processing_time_seconds                                                                                                                             0s / 0s / 0s
cilium_agent_api_process_time_seconds                                    method=DELETE path=/v1/endpoint return_code=404                                       2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/cluster return_code=200                                           2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/config return_code=200                                            2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/debuginfo return_code=200                                         2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/endpoint return_code=200                                          2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=GET path=/v1/healthz return_code=200                                           2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=POST path=/v1/ipam return_code=201                                             2.5ms / 4.5ms / 4.95ms
cilium_agent_api_process_time_seconds                                    method=PUT path=/v1/endpoint return_code=201                                          3.75s / 4.75s / 4.975s
cilium_api_limiter_adjustment_factor                                     api_call=endpoint-create                                                              0.426697
cilium_api_limiter_adjustment_factor                                     api_call=endpoint-list                                                                100.000000
cilium_api_limiter_processed_requests_total                              api_call=endpoint-create outcome=success return_code=200                              3.000000
cilium_api_limiter_processed_requests_total                              api_call=endpoint-list outcome=success return_code=200                                2.000000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-create value=estimated                                              2.000000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-create value=mean                                                   4.687164
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-list value=estimated                                                0.300000
cilium_api_limiter_processing_duration_seconds                           api_call=endpoint-list value=mean                                                     0.000291
cilium_api_limiter_rate_limit                                            api_call=endpoint-create value=burst                                                  3.000000
cilium_api_limiter_rate_limit                                            api_call=endpoint-create value=limit                                                  0.213349
cilium_api_limiter_rate_limit                                            api_call=endpoint-list value=burst                                                    202.000000
cilium_api_limiter_rate_limit                                            api_call=endpoint-list value=limit                                                    100.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-create value=in-flight                                              0.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-create value=limit                                                  2.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-list value=in-flight                                                0.000000
cilium_api_limiter_requests_in_flight                                    api_call=endpoint-list value=limit                                                    101.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-create value=max                                                    60.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-create value=mean                                                   0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-create value=min                                                    0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-list value=max                                                      0.000000
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-list value=mean                                                     0.000031
cilium_api_limiter_wait_duration_seconds                                 api_call=endpoint-list value=min                                                      0.000000
cilium_bpf_map_capacity                                                  map_group=cilium_auth_map                                                             524288.000000
cilium_bpf_map_capacity                                                  map_group=cilium_call_policy                                                          65535.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ct4_global                                                           131072.000000
cilium_bpf_map_capacity                                                  map_group=cilium_devices                                                              512.000000
cilium_bpf_map_capacity                                                  map_group=cilium_egresscall_policy                                                    65535.000000
cilium_bpf_map_capacity                                                  map_group=cilium_events                                                               2.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ipcache_v2                                                           512000.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ipv4_frag_datagrams                                                  8192.000000
cilium_bpf_map_capacity                                                  map_group=cilium_l2_responder_v4                                                      4096.000000
cilium_bpf_map_capacity                                                  map_group=cilium_l2_responder_v6                                                      4096.000000
cilium_bpf_map_capacity                                                  map_group=cilium_lxc                                                                  65535.000000
cilium_bpf_map_capacity                                                  map_group=cilium_metrics                                                              1024.000000
cilium_bpf_map_capacity                                                  map_group=cilium_node_map_v2                                                          16384.000000
cilium_bpf_map_capacity                                                  map_group=cilium_nodeport_neigh4                                                      131072.000000
cilium_bpf_map_capacity                                                  map_group=cilium_percpu_trace_id                                                      1.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ratelimit                                                            1024.000000
cilium_bpf_map_capacity                                                  map_group=cilium_ratelimit_metrics                                                    64.000000
cilium_bpf_map_capacity                                                  map_group=cilium_runtime_config                                                       256.000000
cilium_bpf_map_capacity                                                  map_group=cilium_signals                                                              2.000000
cilium_bpf_map_capacity                                                  map_group=cilium_skip_lb4                                                             100.000000
cilium_bpf_map_capacity                                                  map_group=cilium_snat_v4_alloc_retries                                                33.000000
cilium_bpf_map_capacity                                                  map_group=cilium_snat_v4_external                                                     131072.000000
cilium_bpf_map_capacity                                                  map_group=default                                                                     65536.000000
cilium_bpf_map_capacity                                                  map_group=endpoint_policy                                                             16384.000000
cilium_bpf_map_ops_total                                                 map_name=ct4_global operation=delete outcome=success                                  6047.000000
cilium_bpf_map_ops_total                                                 map_name=ct_any4_global operation=delete outcome=success                              230.000000
cilium_bpf_map_ops_total                                                 map_name=devices operation=update outcome=success                                     88.000000
cilium_bpf_map_ops_total                                                 map_name=ipcache_v2 operation=delete outcome=success                                  5.000000
cilium_bpf_map_ops_total                                                 map_name=ipcache_v2 operation=update outcome=success                                  22.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_backends_v3 operation=delete outcome=success                             8.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_backends_v3 operation=update outcome=success                             19.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_reverse_nat operation=update outcome=success                             48.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_services_v2 operation=delete outcome=success                             1.000000
cilium_bpf_map_ops_total                                                 map_name=lb4_services_v2 operation=update outcome=success                             121.000000
cilium_bpf_map_ops_total                                                 map_name=lxc operation=update outcome=success                                         351.000000
cilium_bpf_map_ops_total                                                 map_name=policy operation=update outcome=success                                      50.000000
cilium_bpf_map_ops_total                                                 map_name=runtime_config operation=update outcome=success                              10270.000000
cilium_bpf_map_ops_total                                                 map_name=snat_v4_external operation=delete outcome=success                            662.000000
cilium_bpf_map_pressure                                                  map_name=ct4_global                                                                   0.003082
cilium_bpf_map_pressure                                                  map_name=ct_any4_global                                                               0.000259
cilium_bpf_map_pressure                                                  map_name=ipcache_v2                                                                   0.000033
cilium_bpf_map_pressure                                                  map_name=lb4_backends_v3                                                              0.000153
cilium_bpf_map_pressure                                                  map_name=lb4_reverse_nat                                                              0.000107
cilium_bpf_map_pressure                                                  map_name=lb4_services_v2                                                              0.000336
cilium_bpf_map_pressure                                                  map_name=lxc                                                                          0.000092
cilium_bpf_maps                                                                                                                                                73.000000
cilium_bpf_maps_virtual_memory_max_bytes                                                                                                                       89432456.000000
cilium_bpf_progs                                                                                                                                               99.000000
cilium_bpf_progs_virtual_memory_max_bytes                                                                                                                      1134592.000000
cilium_clustermesh_remote_clusters                                                                                                                             0.000000
cilium_controllers_failing                                                                                                                                     0.000000
cilium_controllers_runs_duration_seconds                                 status=success                                                                        2.504ms / 4.507ms / 4.957ms
cilium_controllers_runs_total                                            status=success                                                                        4653.000000
cilium_datapath_conntrack_dump_resets_total                              area=conntrack family=ipv4 name=dump_interrupts                                       0.000000
cilium_datapath_conntrack_gc_duration_seconds                            family=ipv4 protocol=TCP status=completed                                             3.25ms / 9.25ms / 23.05ms
cilium_datapath_conntrack_gc_duration_seconds                            family=ipv4 protocol=non-TCP status=completed                                         2.5ms / 4.5ms / 4.95ms
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=TCP status=alive                                                 20.000000
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=TCP status=deleted                                               2124.000000
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=non-TCP status=alive                                             5.000000
cilium_datapath_conntrack_gc_entries                                     family=ipv4 protocol=non-TCP status=deleted                                           65.000000
cilium_datapath_conntrack_gc_interval_seconds                            global=global                                                                         5130.000000
cilium_datapath_conntrack_gc_key_fallbacks_total                         family=ipv4 protocol=TCP                                                              0.000000
cilium_datapath_conntrack_gc_key_fallbacks_total                         family=ipv4 protocol=non-TCP                                                          0.000000
cilium_datapath_conntrack_gc_runs_total                                  family=ipv4 protocol=TCP status=completed                                             13.000000
cilium_datapath_conntrack_gc_runs_total                                  family=ipv4 protocol=non-TCP status=completed                                         13.000000
cilium_drift_checker_config_delta                                                                                                                              0.000000
cilium_drop_bytes_total                                                  direction=EGRESS reason=Unsupported L3 protocol                                       2310.000000
cilium_drop_bytes_total                                                  direction=INGRESS reason=Stale or unroutable IP                                       112.000000
cilium_drop_count_total                                                  direction=EGRESS reason=Unsupported L3 protocol                                       33.000000
cilium_drop_count_total                                                  direction=INGRESS reason=Stale or unroutable IP                                       1.000000
cilium_endpoint                                                                                                                                                5.000000
cilium_endpoint_component_status                                         status=OK type=BPF                                                                    5.000000
cilium_endpoint_component_status                                         status=OK type=Other                                                                  5.000000
cilium_endpoint_component_status                                         status=OK type=Policy                                                                 5.000000
cilium_endpoint_regeneration_time_stats_seconds                          scope=bpfCompilation status=success                                                   5.5s / 9.1s / 9.91s
cilium_endpoint_regeneration_time_stats_seconds                          scope=bpfLoadProg status=success                                                      550ms / 910ms / 991ms
cilium_endpoint_regeneration_time_stats_seconds                          scope=bpfWaitForELF status=success                                                    10ms / 7.84s / 9.784s
cilium_endpoint_regeneration_time_stats_seconds                          scope=buildPermitAcquisition status=success                                           8.992µs / 834.3µs / 3.445s
cilium_endpoint_regeneration_time_stats_seconds                          scope=endpointPolicyCalculation status=success                                        26.96µs / 85.66µs / 98.87µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=mapSync status=success                                                          44.93µs / 90.66µs / 566.7µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=policyCalculation status=success                                                55.42µs / 91.75µs / 99.92µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=prepareBuild status=success                                                     55.84µs / 92.51µs / 508.4µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=proxyConfiguration status=success                                               5.058µs / 9.104µs / 21.34µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=proxyPolicyCalculation status=success                                           87.86µs / 804.9µs / 984.6µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=proxyWaitForAck status=success                                                  5.035µs / 9.062µs / 9.968µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=selectorPolicyCalculation status=success                                        66.25µs / 550µs / 955µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=total status=success                                                            569.3µs / 944.8µs / 2.134s
cilium_endpoint_regeneration_time_stats_seconds                          scope=waitForPolicyCompute status=success                                             5.117µs / 9.211µs / 73.34µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=waitingForCTClean status=success                                                5.07µs / 9.125µs / 241.7µs
cilium_endpoint_regeneration_time_stats_seconds                          scope=waitingForLock status=success                                                   5.035µs / 9.062µs / 9.968µs
cilium_endpoint_regenerations_total                                      error= outcome=success reason=DeviceConfigurationChanged                              7.000000
cilium_endpoint_regenerations_total                                      error= outcome=success reason=LabelsUpdate                                            5.000000
cilium_endpoint_regenerations_total                                      error= outcome=success reason=PeriodicRegeneration                                    425.000000
cilium_endpoint_restoration_duration_seconds                             phase=initial_policy_computation                                                      0.000000
cilium_endpoint_restoration_duration_seconds                             phase=prepare_regeneration                                                            0.253124
cilium_endpoint_restoration_duration_seconds                             phase=read_from_disk                                                                  0.000234
cilium_endpoint_restoration_duration_seconds                             phase=regeneration                                                                    0.000058
cilium_endpoint_restoration_duration_seconds                             phase=restoration                                                                     0.000130
cilium_endpoint_restoration_endpoints                                    outcome=failed phase=read_from_disk                                                   0.000000
cilium_endpoint_restoration_endpoints                                    outcome=failed phase=regeneration                                                     0.000000
cilium_endpoint_restoration_endpoints                                    outcome=failed phase=restoration                                                      0.000000
cilium_endpoint_restoration_endpoints                                    outcome=skipped phase=restoration                                                     0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=initial_policy_computation                                   0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=prepare_regeneration                                         0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=read_from_disk                                               0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=regeneration                                                 0.000000
cilium_endpoint_restoration_endpoints                                    outcome=successful phase=restoration                                                  0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=initial_policy_computation                                        0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=prepare_regeneration                                              0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=read_from_disk                                                    0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=regeneration                                                      0.000000
cilium_endpoint_restoration_endpoints                                    outcome=total phase=restoration                                                       0.000000
cilium_endpoint_state                                                    endpoint_state=ready                                                                  5.000000
cilium_endpoint_state                                                    endpoint_state=regenerating                                                           0.000000
cilium_endpoint_state                                                    endpoint_state=waiting-for-identity                                                   0.000000
cilium_endpoint_state                                                    endpoint_state=waiting-to-regenerate                                                  0.000000
cilium_errors_warnings_total                                             level=ERROR subsystem=init                                                            0.000000
cilium_errors_warnings_total                                             level=WARN subsystem=init                                                             0.000000
cilium_event_ts                                                          action=DELETE scope=/v1/endpoint source=api                                           1791630061.985759
cilium_event_ts                                                          action=GET scope=/v1/cluster source=api                                               1791640326.256761
cilium_event_ts                                                          action=GET scope=/v1/config source=api                                                1791630062.113518
cilium_event_ts                                                          action=GET scope=/v1/debuginfo source=api                                             1791640327.735395
cilium_event_ts                                                          action=GET scope=/v1/endpoint source=api                                              1791640197.535805
cilium_event_ts                                                          action=GET scope=/v1/healthz source=api                                               1791640326.380146
cilium_event_ts                                                          action=POST scope=/v1/ipam source=api                                                 1791630062.120235
cilium_event_ts                                                          action=PUT scope=/v1/endpoint source=api                                              1791630062.149515
cilium_event_ts                                                          action=create scope=CiliumEndpoint source=k8s                                         1791638919.431585
cilium_event_ts                                                          action=delete scope=CiliumEndpoint source=k8s                                         1791638923.815641
cilium_event_ts                                                          action=update scope=CiliumEndpoint source=k8s                                         1791630058.320636
cilium_event_ts                                                          action=update scope=CiliumNode source=k8s                                             1791630058.813188
cilium_event_ts                                                          action=update scope=Node source=k8s                                                   1791640266.795749
cilium_event_ts                                                          action=update scope=Pod source=k8s                                                    1791630078.866858
cilium_feature_adv_connect_and_lb_bandwidth_manager_enabled                                                                                                    0.000000
cilium_feature_adv_connect_and_lb_bgp_enabled                                                                                                                  0.000000
cilium_feature_adv_connect_and_lb_cilium_envoy_config_enabled                                                                                                  0.000000
cilium_feature_adv_connect_and_lb_cilium_node_config_enabled                                                                                                   0.000000
cilium_feature_adv_connect_and_lb_egress_gateway_enabled                                                                                                       0.000000
cilium_feature_adv_connect_and_lb_envoy_proxy_enabled                    mode=standalone                                                                       1.000000
cilium_feature_adv_connect_and_lb_kube_proxy_replacement_enabled                                                                                               1.000000
cilium_feature_adv_connect_and_lb_l2_lb_enabled                                                                                                                0.000000
cilium_feature_adv_connect_and_lb_l2_pod_announcement_enabled                                                                                                  0.000000
cilium_feature_adv_connect_and_lb_node_port_configuration                acceleration=disabled algorithm=random mode=snat                                      1.000000
cilium_feature_adv_connect_and_lb_sctp_enabled                                                                                                                 0.000000
cilium_feature_adv_connect_and_lb_vtep_enabled                                                                                                                 0.000000
cilium_feature_controlplane_cilium_endpoint_slices_enabled                                                                                                     0.000000
cilium_feature_controlplane_identity_allocation                          mode=crd                                                                              1.000000
cilium_feature_controlplane_ipam                                         mode=kubernetes                                                                       1.000000
cilium_feature_datapath_chaining_enabled                                 mode=none                                                                             1.000000
cilium_feature_datapath_config                                           configured_mode=veth operational_mode=veth                                            1.000000
cilium_feature_datapath_endpoint_routes_enabled                                                                                                                0.000000
cilium_feature_datapath_internet_protocol                                address_family=ipv4-only                                                              1.000000
cilium_feature_datapath_kernel_version                                   version=7.0.0                                                                         1.000000
cilium_feature_datapath_network                                          mode=overlay-vxlan                                                                    1.000000
cilium_feature_network_policies_host_firewall_enabled                                                                                                          0.000000
cilium_feature_network_policies_internal_traffic_policy_services_total   action=add                                                                            1.000000
cilium_feature_network_policies_local_redirect_policy_enabled                                                                                                  0.000000
cilium_feature_network_policies_mutual_auth_enabled                                                                                                            0.000000
cilium_feature_network_policies_non_defaultdeny_policies_enabled                                                                                               1.000000
cilium_forward_bytes_total                                               direction=EGRESS                                                                      13737083.000000
cilium_forward_bytes_total                                               direction=INGRESS                                                                     37972720.000000
cilium_forward_count_total                                               direction=EGRESS                                                                      103700.000000
cilium_forward_count_total                                               direction=INGRESS                                                                     235869.000000
cilium_fqdn_gc_deletions_total                                                                                                                                 0.000000
cilium_fqdn_selectors                                                                                                                                          0.000000
cilium_hive_jobs_observer_last_run_duration_seconds                      job_name=k8s-secrets-resource-events-cilium-secrets module_id=envoy-proxy             0.000028
cilium_hive_jobs_observer_last_run_duration_seconds                      job_name=nat-map-next4 module_id=ct-nat-map-gc                                        0.000007
cilium_hive_jobs_observer_run_duration_seconds                           job_name=k8s-secrets-resource-events-cilium-secrets module_id=envoy-proxy             250µs / 450µs / 495µs
cilium_hive_jobs_observer_run_duration_seconds                           job_name=nat-map-next4 module_id=ct-nat-map-gc                                        250µs / 450µs / 495µs
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=certloader-server-tls module_id=hubble                                       0.043612
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=cleanup module_id=map-sweeper                                                0.262938
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=clustermesh-nodemanager-notifier module_id=clustermesh                       0.000001
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=cni-deletion-queue module_id=endpoint-api                                    0.336561
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=enable-gc module_id=ct-nat-map-gc                                            0.343623
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=endpoint-cleanup module_id=stale-endpoint-cleanup                            0.294807
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=finish-endpoint-restore module_id=endpoint-restore                           0.253137
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=hubble module_id=hubble                                                      0.043291
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=init module_id=cilium-health                                                 0.282123
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=init-host-endpoint module_id=agent-infra-endpoints                           0.256543
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=init-periodic-endpoint-controllers module_id=endpoint-manager                0.470000
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=ipset-init-finalizer module_id=ipset                                         0.019043
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=l2-announcer-lease-gc module_id=l2-announcer                                 0.045449
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=per-endpoint-route-initializer module_id=loader                              0.355839
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=pressure-metric-throttle module_id=bwmap                                     0.000045
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=proxy-bootstrapper module_id=dns-proxy                                       0.514489
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=proxy-ports-restore module_id=l7-proxy                                       0.002622
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=registry module_id=registry                                                  0.000014
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=release-local-identities module_id=ipcache                                   30.473461
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=start-reconciler module_id=loadbalancer-reconciler                           0.000720
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=sync-crds module_id=k8s-synced-crdsync                                       0.050711
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=unlock-lockfile module_id=endpoint-api                                       0.253082
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=update-config-metric module_id=enabled-features                              0.000143
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=wait-for-endpoint-restore module_id=ep-bpf-prog-watchdog                     0.256395
cilium_hive_jobs_oneshot_last_run_duration_seconds                       job_name=wait-for-endpoint-restore module_id=namemanager                              0.469976
cilium_hive_jobs_runs_total                                              job_name=certloader-server-tls module_id=hubble                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=cleanup module_id=map-sweeper                                                1.000000
cilium_hive_jobs_runs_total                                              job_name=cleanup module_id=metrics                                                    2.000000
cilium_hive_jobs_runs_total                                              job_name=clustermesh-nodemanager-notifier module_id=clustermesh                       1.000000
cilium_hive_jobs_runs_total                                              job_name=cni-deletion-queue module_id=endpoint-api                                    1.000000
cilium_hive_jobs_runs_total                                              job_name=dns-garbage-collector-job module_id=namemanager                              171.000000
cilium_hive_jobs_runs_total                                              job_name=enable-gc module_id=ct-nat-map-gc                                            1.000000
cilium_hive_jobs_runs_total                                              job_name=endpoint-cleanup module_id=stale-endpoint-cleanup                            1.000000
cilium_hive_jobs_runs_total                                              job_name=ep-bpf-prog-watchdog module_id=ep-bpf-prog-watchdog                          342.000000
cilium_hive_jobs_runs_total                                              job_name=finish-endpoint-restore module_id=endpoint-restore                           1.000000
cilium_hive_jobs_runs_total                                              job_name=hubble module_id=hubble                                                      1.000000
cilium_hive_jobs_runs_total                                              job_name=hubble-namespace-cleanup module_id=hubble                                    34.000000
cilium_hive_jobs_runs_total                                              job_name=init module_id=cilium-health                                                 1.000000
cilium_hive_jobs_runs_total                                              job_name=init-host-endpoint module_id=agent-infra-endpoints                           1.000000
cilium_hive_jobs_runs_total                                              job_name=init-periodic-endpoint-controllers module_id=endpoint-manager                1.000000
cilium_hive_jobs_runs_total                                              job_name=ipset-init-finalizer module_id=ipset                                         1.000000
cilium_hive_jobs_runs_total                                              job_name=k8s-secrets-resource-events-cilium-secrets module_id=envoy-proxy             1.000000
cilium_hive_jobs_runs_total                                              job_name=l2-announcer-lease-gc module_id=l2-announcer                                 1.000000
cilium_hive_jobs_runs_total                                              job_name=nat-map-next4 module_id=ct-nat-map-gc                                        6277.000000
cilium_hive_jobs_runs_total                                              job_name=nat-stats module_id=nat-stats                                                343.000000
cilium_hive_jobs_runs_total                                              job_name=per-endpoint-route-initializer module_id=loader                              1.000000
cilium_hive_jobs_runs_total                                              job_name=pressure-metric-subnet_map module_id=subnet-map                              342.000000
cilium_hive_jobs_runs_total                                              job_name=pressure-metric-throttle module_id=bwmap                                     1.000000
cilium_hive_jobs_runs_total                                              job_name=pressure-metrics-reporter module_id=loadbalancer-maps                        34.000000
cilium_hive_jobs_runs_total                                              job_name=proxy-bootstrapper module_id=dns-proxy                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=proxy-ports-checkpoint module_id=l7-proxy                                    172.000000
cilium_hive_jobs_runs_total                                              job_name=proxy-ports-restore module_id=l7-proxy                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=registry module_id=registry                                                  1.000000
cilium_hive_jobs_runs_total                                              job_name=release-local-identities module_id=ipcache                                   1.000000
cilium_hive_jobs_runs_total                                              job_name=start-reconciler module_id=loadbalancer-reconciler                           1.000000
cilium_hive_jobs_runs_total                                              job_name=sync module_id=link-cache                                                    684.000000
cilium_hive_jobs_runs_total                                              job_name=sync-crds module_id=k8s-synced-crdsync                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=sync-userspace-and-datapath module_id=utime                                  172.000000
cilium_hive_jobs_runs_total                                              job_name=unlock-lockfile module_id=endpoint-api                                       1.000000
cilium_hive_jobs_runs_total                                              job_name=update-config-metric module_id=enabled-features                              1.000000
cilium_hive_jobs_runs_total                                              job_name=validate-unchanged-daemon-config module_id=daemonconfig                      168.000000
cilium_hive_jobs_runs_total                                              job_name=version-check module_id=envoy-proxy                                          85.000000
cilium_hive_jobs_runs_total                                              job_name=wait-for-endpoint-restore module_id=ep-bpf-prog-watchdog                     1.000000
cilium_hive_jobs_runs_total                                              job_name=wait-for-endpoint-restore module_id=namemanager                              1.000000
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=cleanup module_id=metrics                                                    0.000089
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=dns-garbage-collector-job module_id=namemanager                              0.000032
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=ep-bpf-prog-watchdog module_id=ep-bpf-prog-watchdog                          0.000914
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=hubble-namespace-cleanup module_id=hubble                                    0.000001
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=nat-stats module_id=nat-stats                                                0.000326
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=pressure-metric-subnet_map module_id=subnet-map                              0.000001
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=pressure-metrics-reporter module_id=loadbalancer-maps                        0.000474
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=proxy-ports-checkpoint module_id=l7-proxy                                    0.000265
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=sync module_id=link-cache                                                    0.000226
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=sync-userspace-and-datapath module_id=utime                                  0.000091
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=validate-unchanged-daemon-config module_id=daemonconfig                      0.000074
cilium_hive_jobs_timer_last_run_duration_seconds                         job_name=version-check module_id=envoy-proxy                                          0.002316
cilium_hive_jobs_timer_run_duration_seconds                              job_name=cleanup module_id=metrics                                                    250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=dns-garbage-collector-job module_id=namemanager                              250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=ep-bpf-prog-watchdog module_id=ep-bpf-prog-watchdog                          762.3µs / 972.1µs / 2.179ms
cilium_hive_jobs_timer_run_duration_seconds                              job_name=hubble-namespace-cleanup module_id=hubble                                    250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=nat-stats module_id=nat-stats                                                251.5µs / 452.6µs / 497.9µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=pressure-metric-subnet_map module_id=subnet-map                              250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=pressure-metrics-reporter module_id=loadbalancer-maps                        274.2µs / 493.5µs / 943.3µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=proxy-ports-checkpoint module_id=l7-proxy                                    250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=sync module_id=link-cache                                                    250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=sync-userspace-and-datapath module_id=utime                                  250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=validate-unchanged-daemon-config module_id=daemonconfig                      250µs / 450µs / 495µs
cilium_hive_jobs_timer_run_duration_seconds                              job_name=version-check module_id=envoy-proxy                                          1.759ms / 2.366ms / 2.875ms
cilium_hive_populate_duration                                                                                                                                  0.315561
cilium_hive_start_duration                                                                                                                                     0.378147
cilium_hive_status                                                       status=ok                                                                             85.000000
cilium_identity                                                          type=cluster_local                                                                    3.000000
cilium_identity                                                          type=reserved                                                                         14.000000
cilium_identity_label_sources                                            source=gen                                                                            3.000000
cilium_identity_label_sources                                            source=k8s                                                                            3.000000
cilium_identity_label_sources                                            source=reserved                                                                       14.000000
cilium_identity_updater_timer_duration                                   name=id-alloc-update-policy-maps                                                      2.5m / 4.5m / 4.95m
cilium_identity_updater_timer_trigger_folds                              name=id-alloc-update-policy-maps                                                      750m / 950m / 995m
cilium_identity_updater_timer_trigger_latency                            name=id-alloc-update-policy-maps                                                      2.5m / 4.5m / 4.95m
cilium_ip_addresses                                                      family=ipv4                                                                           5.000000
cilium_ip_addresses                                                      family=ipv6                                                                           0.000000
cilium_ipam_capacity                                                     cidr=10.244.2.0/24 family=ipv4                                                        254.000000
cilium_ipam_events_total                                                 action=allocate family=ipv4                                                           5.000000
cilium_ipcache_errors_total                                              error=cannot_overwrite_by_source type=upsert                                          3.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=DELETE return_code=200                      3.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=200                         496.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=403                         1.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=404                         3.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=GET return_code=429                         1.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=POST return_code=201                        3.000000
cilium_k8s_client_api_calls_total                                        host=api.homelab.techscene.de:6443 method=PUT return_code=200                         1.000000
cilium_k8s_client_api_latency_time_seconds                               method=DELETE path=/apis/cilium.io/v2/namespaces/{namespace}/ciliumendpoints/{name}   13.75ms / 22.75ms / 24.77ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/api/v1/namespaces/{name}                                             7.5ms / 9.5ms / 9.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/apiextensions.k8s.io/v1/customresourcedefinitions               2.5ms / 4.5ms / 4.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/cilium.io/v2/ciliumnodes/{name}                                 17.5ms / 23.5ms / 24.85ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/cilium.io/v2/namespaces/{namespace}/ciliumendpoints/{name}      2.5ms / 4.5ms / 4.95ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/apis/coordination.k8s.io/v1/namespaces/{namespace}/leases            37.5ms / 47.5ms / 49.75ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/readyz                                                               2.52ms / 4.536ms / 4.99ms
cilium_k8s_client_api_latency_time_seconds                               method=GET path=/version                                                              2.708ms / 4.875ms / 46.75ms
cilium_k8s_client_api_latency_time_seconds                               method=POST path=/apis/cilium.io/v2/namespaces/{namespace}/ciliumendpoints            13.75ms / 22.75ms / 24.77ms
cilium_k8s_client_api_latency_time_seconds                               method=PUT path=/apis/cilium.io/v2/ciliumnodes/{name}                                 37.5ms / 47.5ms / 49.75ms
cilium_k8s_client_rate_limiter_duration_seconds                                                                                                                2.5ms / 4.5ms / 4.95ms
cilium_k8s_terminating_endpoints_events_total                                                                                                                  0.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumcidrgroup                                                                  1.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumclusterwidenetworkpolicy                                                   1.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumnetworkpolicy                                                              1.000000
cilium_k8s_workqueue_adds_total                                          name=ciliumnode                                                                       9.000000
cilium_k8s_workqueue_adds_total                                          name=networkpolicy                                                                    1.000000
cilium_k8s_workqueue_adds_total                                          name=node                                                                             40.000000
cilium_k8s_workqueue_adds_total                                          name=secret                                                                           1.000000
cilium_k8s_workqueue_depth                                               name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_depth                                               name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_depth                                               name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_depth                                               name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_depth                                               name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_depth                                               name=node                                                                             1.000000
cilium_k8s_workqueue_depth                                               name=secret                                                                           0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_longest_running_processor_seconds                   name=node                                                                             10269.501699
cilium_k8s_workqueue_longest_running_processor_seconds                   name=secret                                                                           0.000000
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumcidrgroup                                                                  55µs / 91µs / 99.1µs
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumclusterwidenetworkpolicy                                                   5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumnetworkpolicy                                                              5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=ciliumnode                                                                       66.25µs / 5.95ms / 9.595ms
cilium_k8s_workqueue_queue_duration_seconds                              name=networkpolicy                                                                    5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_queue_duration_seconds                              name=node                                                                             6.661µs / 56.13µs / 95.61µs
cilium_k8s_workqueue_queue_duration_seconds                              name=secret                                                                           5.5µs / 9.1µs / 9.91µs
cilium_k8s_workqueue_retries_total                                       name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_retries_total                                       name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_retries_total                                       name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_retries_total                                       name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_retries_total                                       name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_retries_total                                       name=node                                                                             0.000000
cilium_k8s_workqueue_retries_total                                       name=secret                                                                           0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumcidrgroup                                                                  0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumclusterwidenetworkpolicy                                                   0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumnetworkpolicy                                                              0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=ciliumnode                                                                       0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=networkpolicy                                                                    0.000000
cilium_k8s_workqueue_unfinished_work_seconds                             name=node                                                                             10269.501699
cilium_k8s_workqueue_unfinished_work_seconds                             name=secret                                                                           0.000000
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumcidrgroup                                                                  55µs / 91µs / 99.1µs
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumclusterwidenetworkpolicy                                                   55µs / 91µs / 99.1µs
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumnetworkpolicy                                                              55µs / 91µs / 99.1µs
cilium_k8s_workqueue_work_duration_seconds                               name=ciliumnode                                                                       250µs / 5.95ms / 9.595ms
cilium_k8s_workqueue_work_duration_seconds                               name=networkpolicy                                                                    55µs / 91µs / 99.1µs
cilium_k8s_workqueue_work_duration_seconds                               name=node                                                                             60.29µs / 145µs / 914.5µs
cilium_k8s_workqueue_work_duration_seconds                               name=secret                                                                           55µs / 91µs / 99.1µs
cilium_kubernetes_events_received_total                                  action=create equal=false scope=CiliumEndpoint valid=true                             5.000000
cilium_kubernetes_events_received_total                                  action=delete equal=false scope=CiliumEndpoint valid=true                             5.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=CiliumEndpoint valid=true                             4.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=CiliumNode valid=true                                 5.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=Node valid=true                                       35.000000
cilium_kubernetes_events_received_total                                  action=update equal=false scope=Pod valid=true                                        14.000000
cilium_kubernetes_events_total                                           action=delete scope=CiliumEndpoint status=success                                     5.000000
cilium_kubernetes_events_total                                           action=update scope=CiliumEndpoint status=success                                     9.000000
cilium_kubernetes_events_total                                           action=update scope=CiliumNode status=success                                         8.000000
cilium_kubernetes_events_total                                           action=update scope=Node status=success                                               37.000000
cilium_kubernetes_resource_sync_duration                                 scope=CiliumCIDRGroup                                                                 0.455339
cilium_kubernetes_resource_sync_duration                                 scope=CiliumClusterwideNetworkPolicy                                                  0.457214
cilium_kubernetes_resource_sync_duration                                 scope=CiliumEndpoint                                                                  0.638577
cilium_kubernetes_resource_sync_duration                                 scope=CiliumNetworkPolicy                                                             0.554595
cilium_kubernetes_resource_sync_duration                                 scope=CiliumNode                                                                      0.525722
cilium_kubernetes_resource_sync_duration                                 scope=NetworkPolicy                                                                   0.453262
cilium_kubernetes_resource_sync_duration                                 scope=Node                                                                            0.408020
cilium_kubernetes_resource_sync_duration                                 scope=Secret                                                                          0.462877
cilium_localredirectpolicy_controller_duration_seconds                                                                                                         0s / 0s / 0s
cilium_nat_endpoint_max_connection                                       family=ipv4                                                                           0.000183
cilium_nat_endpoint_max_connection                                       family=ipv6                                                                           0.000000
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=http type=endpoint                                      747.9µs / 2.047ms / 2.455ms
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=http type=node                                          533.5µs / 960.4µs / 2.261ms
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=icmp type=endpoint                                      502.9µs / 905.2µs / 995.7µs
cilium_node_health_connectivity_latency_seconds                          address_type=primary protocol=icmp type=node                                          501.9µs / 903.4µs / 993.8µs
cilium_node_health_connectivity_status                                   status=reachable type=endpoint                                                        2.000000
cilium_node_health_connectivity_status                                   status=reachable type=node                                                            2.000000
cilium_node_health_connectivity_status                                   status=unknown type=endpoint                                                          0.000000
cilium_node_health_connectivity_status                                   status=unknown type=node                                                              0.000000
cilium_node_health_connectivity_status                                   status=unreachable type=endpoint                                                      1.000000
cilium_node_health_connectivity_status                                   status=unreachable type=node                                                          1.000000
cilium_nodes_all_datapath_validations_total                                                                                                                    369.000000
cilium_nodes_all_events_received_total                                   event_type=add source=custom-resource                                                 2.000000
cilium_nodes_all_events_received_total                                   event_type=add source=local                                                           1.000000
cilium_nodes_all_events_received_total                                   event_type=update source=custom-resource                                              1.000000
cilium_nodes_all_num                                                                                                                                           3.000000
cilium_policy                                                                                                                                                  0.000000
cilium_policy_change_total                                               operation=delete outcome=fail source=custom-resource                                  0.000000
cilium_policy_change_total                                               operation=delete outcome=fail source=directory                                        0.000000
cilium_policy_change_total                                               operation=delete outcome=fail source=k8s                                              0.000000
cilium_policy_change_total                                               operation=delete outcome=success source=custom-resource                               0.000000
cilium_policy_change_total                                               operation=delete outcome=success source=directory                                     0.000000
cilium_policy_change_total                                               operation=delete outcome=success source=k8s                                           0.000000
cilium_policy_change_total                                               operation=update outcome=fail source=custom-resource                                  0.000000
cilium_policy_change_total                                               operation=update outcome=fail source=directory                                        0.000000
cilium_policy_change_total                                               operation=update outcome=fail source=k8s                                              0.000000
cilium_policy_change_total                                               operation=update outcome=success source=custom-resource                               0.000000
cilium_policy_change_total                                               operation=update outcome=success source=directory                                     0.000000
cilium_policy_change_total                                               operation=update outcome=success source=k8s                                           0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=audit-both                                                                0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=audit-egress                                                              0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=audit-ingress                                                             0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=both                                                                      0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=egress                                                                    0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=ingress                                                                   0.000000
cilium_policy_endpoint_enforcement_status                                enforcement=none                                                                      5.000000
cilium_policy_implementation_delay                                       source=api                                                                            0 / 0 / 0
cilium_policy_implementation_delay                                       source=custom-resource                                                                0 / 0 / 0
cilium_policy_implementation_delay                                       source=k8s                                                                            0 / 0 / 0
cilium_policy_incremental_update_duration                                scope=global                                                                          550µ / 910µ / 991µ
cilium_policy_l7_total                                                   proxy_type=envoy rule=denied                                                          0.000000
cilium_policy_l7_total                                                   proxy_type=envoy rule=forwarded                                                       0.000000
cilium_policy_l7_total                                                   proxy_type=envoy rule=parse_errors                                                    0.000000
cilium_policy_l7_total                                                   proxy_type=envoy rule=received                                                        0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=denied                                                           0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=forwarded                                                        0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=parse_errors                                                     0.000000
cilium_policy_l7_total                                                   proxy_type=fqdn rule=received                                                         0.000000
cilium_policy_max_revision                                                                                                                                     0.000000
cilium_policy_missing_proxy_redirects                                                                                                                          0.000000
cilium_policy_selector_cache_identities                                  type=peer                                                                             18.000000
cilium_policy_selector_cache_operation_duration_seconds                  operation=identity_updates scope=lock type=peer                                       250µs / 450µs / 495µs
cilium_policy_selector_cache_operation_duration_seconds                  operation=identity_updates scope=operation type=peer                                  250µs / 450µs / 495µs
cilium_policy_selector_cache_selectors                                   type=peer                                                                             0.000000
cilium_policy_selector_match_count_max                                   class=cluster                                                                         0.000000
cilium_policy_selector_match_count_max                                   class=fqdn                                                                            0.000000
cilium_policy_selector_match_count_max                                   class=other                                                                           0.000000
cilium_policy_selector_match_count_max                                   class=world                                                                           0.000000
cilium_process_cpu_seconds_total                                                                                                                               208.180000
cilium_process_max_fds                                                                                                                                         524287.000000
cilium_process_network_receive_bytes_total                                                                                                                     33091858.000000
cilium_process_network_transmit_bytes_total                                                                                                                    19799249.000000
cilium_process_open_fds                                                                                                                                        105.000000
cilium_process_resident_memory_bytes                                                                                                                           189300736.000000
cilium_process_start_time_seconds                                                                                                                              1791630056.310000
cilium_process_virtual_memory_bytes                                                                                                                            1568030720.000000
cilium_process_virtual_memory_max_bytes                                                                                                                        18446744073709551616.000000
cilium_subprocess_start_total                                            subsystem=cilium-health                                                               1.000000
cilium_unreachable_health_endpoints                                                                                                                            1.000000
cilium_unreachable_nodes                                                                                                                                       1.000000
cilium_version                                                           arch=linux/amd64 revision=e0dc92bd version=1.20.2                                     0.000000
go_gc_duration_seconds                                                                                                                                         p0(43.19µs) p25(47.72µs) p50(49.74µs) p75(58.18µs) p100(2.447ms)
go_gc_gogc_percent                                                                                                                                             100.000000
go_gc_gomemlimit_bytes                                                                                                                                         10248151040.000000
go_goroutines                                                                                                                                                  396.000000
go_info                                                                  version=go1.26.8                                                                      1.000000
go_memstats_alloc_bytes                                                                                                                                        65919848.000000
go_memstats_alloc_bytes_total                                                                                                                                  1728573120.000000
go_memstats_buck_hash_sys_bytes                                                                                                                                1934970.000000
go_memstats_frees_total                                                                                                                                        20236369.000000
go_memstats_gc_sys_bytes                                                                                                                                       5125904.000000
go_memstats_heap_alloc_bytes                                                                                                                                   65919848.000000
go_memstats_heap_idle_bytes                                                                                                                                    20045824.000000
go_memstats_heap_inuse_bytes                                                                                                                                   80355328.000000
go_memstats_heap_objects                                                                                                                                       535467.000000
go_memstats_heap_released_bytes                                                                                                                                14245888.000000
go_memstats_heap_sys_bytes                                                                                                                                     100401152.000000
go_memstats_last_gc_time_seconds                                                                                                                               1791640277.464404
go_memstats_mallocs_total                                                                                                                                      20771836.000000
go_memstats_mcache_inuse_bytes                                                                                                                                 4592.000000
go_memstats_mcache_sys_bytes                                                                                                                                   16072.000000
go_memstats_mspan_inuse_bytes                                                                                                                                  1109600.000000
go_memstats_mspan_sys_bytes                                                                                                                                    1191360.000000
go_memstats_next_gc_bytes                                                                                                                                      106702954.000000
go_memstats_other_sys_bytes                                                                                                                                    665956.000000
go_memstats_stack_inuse_bytes                                                                                                                                  4456448.000000
go_memstats_stack_sys_bytes                                                                                                                                    4456448.000000
go_memstats_sys_bytes                                                                                                                                          113791862.000000
go_sched_gomaxprocs_threads                                                                                                                                    2.000000
go_sched_latencies_seconds                                                                                                                                     4.679µs / 49.23µs / 301µs
go_threads                                                                                                                                                     12.000000

