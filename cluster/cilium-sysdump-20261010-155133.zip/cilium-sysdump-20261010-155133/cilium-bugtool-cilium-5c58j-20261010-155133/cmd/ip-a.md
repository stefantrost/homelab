1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether bc:24:11:3c:bf:be brd ff:ff:ff:ff:ff:ff
    altname enp6s18
    altname enxbc24113cbfbe
    inet 192.168.178.115/24 metric 1024 brd 192.168.178.255 scope global dynamic ens18
       valid_lft 853703sec preferred_lft 853703sec
    inet6 fda7:7b49:a70a:0:be24:11ff:fe3c:bfbe/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7043sec preferred_lft 3443sec
    inet6 2a02:8071:5301:a0a0:be24:11ff:fe3c:bfbe/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7043sec preferred_lft 3443sec
    inet6 fe80::be24:11ff:fe3c:bfbe/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether fa:9f:0f:30:a0:5d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f89f:fff:fe30:a05d/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:7e:19:ea:11:c7 brd ff:ff:ff:ff:ff:ff
    inet 10.244.2.226/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::187e:19ff:feea:11c7/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default 
    link/ether 9a:52:ff:af:7d:98 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9852:ffff:feaf:7d98/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:ef:0c:52:c3:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8ef:cff:fe52:c3e1/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
9: lxcec1c90124299@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 02:f1:64:7b:a2:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f1:64ff:fe7b:a2b6/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
11: lxceafb1dbb20ff@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:49:c7:96:28:f5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7849:c7ff:fe96:28f5/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
13: lxcb94ae39e656d@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:56:8b:c4:ad:7f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1856:8bff:fec4:ad7f/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
