top - 13:52:07 up  2:51,  0 users,  load average: 0.05, 0.15, 0.14
Tasks:   5 total,   2 running,   3 sleeping,   0 stopped,   0 zombie
%Cpu(s): 52.4 us, 42.9 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  4.8 st 
MiB Mem :   9873.4 total,   7967.6 free,    932.8 used,   1245.3 buff/cache     
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   8940.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1531280 185132  94776 S  10.0   1.8   3:28.17 cilium-+
    126 root      20   0 1329748   6632   4732 S   0.0   0.1   0:00.09 cilium-+
   1119 root      20   0 1270588  14584   9556 S   0.0   0.1   0:00.05 cilium-+
   1152 root      20   0    7592   5008   3028 R   0.0   0.0   0:00.00 top
   1185 root      20   0   16376   8116   6640 R   0.0   0.1   0:00.00 ls
