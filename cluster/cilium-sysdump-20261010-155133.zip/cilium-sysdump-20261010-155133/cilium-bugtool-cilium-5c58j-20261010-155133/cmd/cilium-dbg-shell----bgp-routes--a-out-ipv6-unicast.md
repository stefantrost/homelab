<stdin>:0: bgp/routes out ipv6 unicast: BGP router manager is not running
error: <stdin>:0: bgp/routes out ipv6 unicast: BGP router manager is not running
> Error while running 'cilium-dbg shell -- bgp/routes -a out ipv6 unicast':  exit status 1

