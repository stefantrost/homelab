markdown output at /tmp/cilium-bugtool-20261010-135206.888+0000-UTC-2021248563/cmd/cilium-debuginfo-20261010-135207.756+0000-UTC.md
json output at /tmp/cilium-bugtool-20261010-135206.888+0000-UTC-2021248563/cmd/cilium-debuginfo-20261010-135207.756+0000-UTC.json
