2a02:8071:5301:a0a0::/64 dev ens18 proto ra metric 1024 expires 7042sec pref medium
2a02:8071:5301:a0a0::/59 nhid 2296626197 via fe80::36e1:a9ff:fe62:6be6 dev ens18 proto ra metric 1024 expires 1642sec pref medium
fda7:7b49:a70a::/64 dev ens18 proto ra metric 1024 expires 7042sec pref medium
fda7:7b49:a70a::/64 nhid 2296626197 via fe80::36e1:a9ff:fe62:6be6 dev ens18 proto ra metric 1024 expires 1642sec pref medium
fe80::/64 dev ens18 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcec1c90124299 proto kernel metric 256 pref medium
fe80::/64 dev lxceafb1dbb20ff proto kernel metric 256 pref medium
fe80::/64 dev lxcb94ae39e656d proto kernel metric 256 pref medium
default nhid 2296626197 via fe80::36e1:a9ff:fe62:6be6 dev ens18 proto ra metric 1024 expires 1642sec pref medium
