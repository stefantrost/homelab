Node 0, zone      DMA      2      2      2      1      2      2      2      2      3      4      0 
Node 0, zone    DMA32      6      8      7      4      3      6      2      6      5      6    469 
Node 0, zone   Normal    564    395     44     86     44     74     76     22     21     15   1486 
