SERVICE ADDRESS             BACKEND ADDRESS (REVNAT_ID) (SLOT)
10.96.0.10:53/UDP (1)       10.244.1.214:53/UDP (3) (1)                                   
10.96.0.10:9153/TCP (2)     10.244.2.11:9153/TCP (4) (2)                                  
10.97.123.232:0/ANY (0)     0.0.0.0:0 (0) (0) [ClusterIP, non-routable]                   
10.96.0.10:53/UDP (2)       10.244.2.11:53/UDP (3) (2)                                    
10.96.0.10:53/TCP (0)       0.0.0.0:0 (2) (0) [ClusterIP, non-routable]                   
10.96.0.10:53/UDP (0)       0.0.0.0:0 (3) (0) [ClusterIP, non-routable]                   
10.96.0.1:0/ANY (0)         0.0.0.0:0 (0) (0) [ClusterIP, non-routable]                   
10.96.0.10:53/TCP (2)       10.244.2.11:53/TCP (2) (2)                                    
10.96.0.10:9153/TCP (1)     10.244.1.214:9153/TCP (4) (1)                                 
10.101.247.67:443/TCP (1)   192.168.178.115:4244/TCP (6) (1)                              
10.101.247.67:443/TCP (0)   0.0.0.0:0 (6) (0) [ClusterIP, InternalLocal, non-routable]    
10.105.79.192:0/ANY (0)     0.0.0.0:0 (0) (0) [ClusterIP, non-routable]                   
10.96.0.1:443/TCP (0)       0.0.0.0:0 (1) (0) [ClusterIP, non-routable]                   
10.97.123.232:80/TCP (0)    0.0.0.0:0 (5) (0) [ClusterIP, non-routable]                   
10.105.79.192:80/TCP (0)    0.0.0.0:0 (7) (0) [ClusterIP, non-routable]                   
10.97.123.232:80/TCP (1)    10.244.2.31:8081/TCP (5) (1)                                  
10.101.247.67:0/ANY (0)     0.0.0.0:0 (0) (0) [ClusterIP, non-routable]                   
10.96.0.10:0/ANY (0)        0.0.0.0:0 (0) (0) [ClusterIP, non-routable]                   
10.96.0.10:53/TCP (1)       10.244.1.214:53/TCP (2) (1)                                   
10.105.79.192:80/TCP (1)    10.244.2.154:4245/TCP (7) (1)                                 
10.96.0.1:443/TCP (1)       192.168.178.113:6443/TCP (1) (1)                              
10.96.0.10:9153/TCP (0)     0.0.0.0:0 (4) (0) [ClusterIP, non-routable]                   
