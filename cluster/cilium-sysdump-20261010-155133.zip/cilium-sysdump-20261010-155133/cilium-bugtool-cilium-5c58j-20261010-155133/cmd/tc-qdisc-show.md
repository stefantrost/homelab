qdisc noqueue 0: dev lo root refcnt 2 
qdisc pfifo_fast 0: dev ens18 root refcnt 2 bands 3 priomap 1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc noqueue 0: dev lxcec1c90124299 root refcnt 2 
qdisc noqueue 0: dev lxceafb1dbb20ff root refcnt 2 
qdisc noqueue 0: dev lxcb94ae39e656d root refcnt 2 
