[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.244.0.0/24",
    "hostIP": "192.168.178.113",
    "identity": 2
  },
  {
    "cidr": "10.244.1.0/24",
    "hostIP": "192.168.178.114",
    "identity": 2
  },
  {
    "cidr": "10.244.0.27/32",
    "hostIP": "192.168.178.113",
    "identity": 4
  },
  {
    "cidr": "10.244.0.172/32",
    "hostIP": "192.168.178.113",
    "identity": 6
  },
  {
    "cidr": "10.244.1.173/32",
    "hostIP": "192.168.178.114",
    "identity": 6
  },
  {
    "cidr": "10.244.1.197/32",
    "hostIP": "192.168.178.114",
    "identity": 4
  },
  {
    "cidr": "10.244.1.214/32",
    "hostIP": "192.168.178.114",
    "identity": 41104,
    "metadata": {
      "name": "coredns-559f6c778d-khtkb",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.2.11/32",
    "hostIP": "192.168.178.115",
    "identity": 41104,
    "metadata": {
      "name": "coredns-559f6c778d-jc27s",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.2.31/32",
    "hostIP": "192.168.178.115",
    "identity": 10824,
    "metadata": {
      "name": "hubble-ui-6dcdfb579c-s4xpb",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.2.84/32",
    "hostIP": "192.168.178.115",
    "identity": 4
  },
  {
    "cidr": "10.244.2.154/32",
    "hostIP": "192.168.178.115",
    "identity": 25785,
    "metadata": {
      "name": "hubble-relay-856fb9b979-qblz5",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.2.226/32",
    "hostIP": "192.168.178.115",
    "identity": 1
  },
  {
    "cidr": "192.168.178.113/32",
    "identity": 7
  },
  {
    "cidr": "192.168.178.114/32",
    "identity": 6
  },
  {
    "cidr": "192.168.178.115/32",
    "identity": 1
  }
]

