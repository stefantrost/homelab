2026-10-10T11:00:17,627190+00:00 Linux version 7.0.0-38-generic (buildd@lcy02-amd64-070) (x86_64-linux-gnu-gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0, GNU ld (GNU Binutils for Ubuntu) 2.46) #38-Ubuntu SMP PREEMPT_DYNAMIC Fri Sep  4 09:10:14 UTC 2026 (Ubuntu 7.0.0-38.38-generic 7.0.14)
2026-10-10T11:00:17,627190+00:00 Command line: BOOT_IMAGE=/vmlinuz-7.0.0-38-generic root=UUID=747687d9-c20c-41f8-bfb8-7f4a57910c51 ro console=tty1 console=ttyS0
2026-10-10T11:00:17,627190+00:00 KERNEL supported cpus:
2026-10-10T11:00:17,627190+00:00   Intel GenuineIntel
2026-10-10T11:00:17,627190+00:00   AMD AuthenticAMD
2026-10-10T11:00:17,627190+00:00   Hygon HygonGenuine
2026-10-10T11:00:17,627190+00:00   Centaur CentaurHauls
2026-10-10T11:00:17,627190+00:00   zhaoxin   Shanghai  
2026-10-10T11:00:17,627190+00:00 BIOS-provided physical RAM map:
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000002ffff]  System RAM
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000000030000-0x000000000004ffff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000000050000-0x000000000009efff]  System RAM
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000000009f000-0x000000000009ffff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [gap 0x00000000000a0000-0x00000000000fffff]
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000000100000-0x0000000000811fff]  System RAM
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000000812000-0x0000000000812fff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000000813000-0x000000007a1c3fff]  System RAM
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007a1c4000-0x000000007a1c6fff]  ACPI data
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007a1c7000-0x000000007bce5fff]  System RAM
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007bce6000-0x000000007bf65fff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007bf66000-0x000000007bf77fff]  ACPI data
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007bf78000-0x000000007bff7fff]  ACPI NVS
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007bff8000-0x000000007bffffff]  System RAM
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x000000007c000000-0x000000007fffffff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [gap 0x0000000080000000-0x00000000dfffffff]
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x00000000e0000000-0x00000000efffffff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [gap 0x00000000f0000000-0x00000000feffbfff]
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff]  device reserved
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [gap 0x00000000ff000000-0x00000000ffffffff]
2026-10-10T11:00:17,627190+00:00 BIOS-e820: [mem 0x0000000100000000-0x00000002ffffffff]  System RAM
2026-10-10T11:00:17,627190+00:00 NX (Execute Disable) protection: active
2026-10-10T11:00:17,627190+00:00 APIC: Static calls initialized
2026-10-10T11:00:17,627190+00:00 efi: EFI v2.7 by Proxmox distribution of EDK II
2026-10-10T11:00:17,627190+00:00 efi: ACPI=0x7bf77000 ACPI 2.0=0x7bf77014 SMBIOS=0x7bdcb000 MEMATTR=0x7a1cb118 MOKvar=0x7bd78000 INITRD=0x7a1cca18 RNG=0x7bf67018 
2026-10-10T11:00:17,627190+00:00 random: crng init done
2026-10-10T11:00:17,627190+00:00 SMBIOS 2.8 present.
2026-10-10T11:00:17,627190+00:00 DMI: QEMU Standard PC (Q35 + ICH9, 2009), BIOS 4.2026.08-1 08/26/2026
2026-10-10T11:00:17,627190+00:00 DMI: Memory slots populated: 1/1
2026-10-10T11:00:17,627190+00:00 secureboot: Secure boot disabled
2026-10-10T11:00:17,627190+00:00 Hypervisor detected: KVM
2026-10-10T11:00:17,627190+00:00 last_pfn = 0x7c000 max_arch_pfn = 0x400000000
2026-10-10T11:00:17,627190+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2026-10-10T11:00:17,627191+00:00 kvm-clock: using sched offset of 7174180418 cycles
2026-10-10T11:00:17,627194+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2026-10-10T11:00:17,627197+00:00 tsc: Detected 806.400 MHz processor
2026-10-10T11:00:17,627310+00:00 e820: update [mem 0x00000000-0x00000fff] System RAM ==> device reserved
2026-10-10T11:00:17,627314+00:00 e820: remove [mem 0x000a0000-0x000fffff] System RAM
2026-10-10T11:00:17,627323+00:00 last_pfn = 0x300000 max_arch_pfn = 0x400000000
2026-10-10T11:00:17,627359+00:00 MTRR map: 4 entries (2 fixed + 2 variable; max 18), built from 8 variable MTRRs
2026-10-10T11:00:17,627362+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2026-10-10T11:00:17,627408+00:00 last_pfn = 0x7c000 max_arch_pfn = 0x400000000
2026-10-10T11:00:17,636044+00:00 Using GB pages for direct mapping
2026-10-10T11:00:17,636330+00:00 secureboot: Secure boot disabled
2026-10-10T11:00:17,636332+00:00 RAMDISK: [mem 0x7252a000-0x74efcfff]
2026-10-10T11:00:17,636335+00:00 ACPI: Early table checksum verification disabled
2026-10-10T11:00:17,636339+00:00 ACPI: RSDP 0x000000007BF77014 000024 (v02 BOCHS )
2026-10-10T11:00:17,636344+00:00 ACPI: XSDT 0x000000007BF760E8 00005C (v01 BOCHS  BXPC     00000001      01000013)
2026-10-10T11:00:17,636350+00:00 ACPI: FACP 0x000000007BF6D000 0000F4 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:17,636356+00:00 ACPI: DSDT 0x000000007BF6E000 0067CD (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:17,636359+00:00 ACPI: FACS 0x000000007BFD5000 000040
2026-10-10T11:00:17,636362+00:00 ACPI: WSMT 0x000000007BF75000 000028 (v01 INTEL  EDK2     00000002      01000013)
2026-10-10T11:00:17,636365+00:00 ACPI: APIC 0x000000007BF6C000 000080 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:17,636368+00:00 ACPI: SSDT 0x000000007BF6B000 0000CA (v01 BOCHS  VMGENID  00000001 BXPC 00000001)
2026-10-10T11:00:17,636371+00:00 ACPI: MCFG 0x000000007BF6A000 00003C (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:17,636374+00:00 ACPI: WAET 0x000000007BF69000 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:17,636376+00:00 ACPI: BGRT 0x000000007BF68000 000038 (v01 INTEL  EDK2     00000002      01000013)
2026-10-10T11:00:17,636379+00:00 ACPI: Reserving FACP table memory at [mem 0x7bf6d000-0x7bf6d0f3]
2026-10-10T11:00:17,636380+00:00 ACPI: Reserving DSDT table memory at [mem 0x7bf6e000-0x7bf747cc]
2026-10-10T11:00:17,636381+00:00 ACPI: Reserving FACS table memory at [mem 0x7bfd5000-0x7bfd503f]
2026-10-10T11:00:17,636382+00:00 ACPI: Reserving WSMT table memory at [mem 0x7bf75000-0x7bf75027]
2026-10-10T11:00:17,636383+00:00 ACPI: Reserving APIC table memory at [mem 0x7bf6c000-0x7bf6c07f]
2026-10-10T11:00:17,636384+00:00 ACPI: Reserving SSDT table memory at [mem 0x7bf6b000-0x7bf6b0c9]
2026-10-10T11:00:17,636384+00:00 ACPI: Reserving MCFG table memory at [mem 0x7bf6a000-0x7bf6a03b]
2026-10-10T11:00:17,636385+00:00 ACPI: Reserving WAET table memory at [mem 0x7bf69000-0x7bf69027]
2026-10-10T11:00:17,636386+00:00 ACPI: Reserving BGRT table memory at [mem 0x7bf68000-0x7bf68037]
2026-10-10T11:00:17,636980+00:00 No NUMA configuration found
2026-10-10T11:00:17,636984+00:00 Faking a node at [mem 0x0000000000000000-0x00000002ffffffff]
2026-10-10T11:00:17,637000+00:00 NODE_DATA(0) allocated [mem 0x2fffd5280-0x2ffffffff]
2026-10-10T11:00:17,642827+00:00 ACPI: PM-Timer IO Port: 0x608
2026-10-10T11:00:17,642852+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2026-10-10T11:00:17,642898+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2026-10-10T11:00:17,642902+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2026-10-10T11:00:17,642905+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2026-10-10T11:00:17,642906+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2026-10-10T11:00:17,642907+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2026-10-10T11:00:17,642908+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2026-10-10T11:00:17,642912+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2026-10-10T11:00:17,642922+00:00 e820: update [mem 0x79ccd000-0x79cf0fff] System RAM ==> device reserved
2026-10-10T11:00:17,642937+00:00 TSC deadline timer available
2026-10-10T11:00:17,642939+00:00 CPU topo: Max. logical packages:   1
2026-10-10T11:00:17,642941+00:00 CPU topo: Max. logical nodes:      1
2026-10-10T11:00:17,642941+00:00 CPU topo: Num. nodes per package:  1
2026-10-10T11:00:17,642944+00:00 CPU topo: Max. logical dies:       1
2026-10-10T11:00:17,642944+00:00 CPU topo: Max. dies per package:   1
2026-10-10T11:00:17,642948+00:00 CPU topo: Max. threads per core:   1
2026-10-10T11:00:17,642949+00:00 CPU topo: Num. cores per package:     2
2026-10-10T11:00:17,642950+00:00 CPU topo: Num. threads per package:   2
2026-10-10T11:00:17,642950+00:00 CPU topo: Allowing 2 present CPUs plus 0 hotplug CPUs
2026-10-10T11:00:17,642969+00:00 kvm-guest: APIC: eoi() replaced with kvm_guest_apic_eoi_write()
2026-10-10T11:00:17,642985+00:00 kvm-guest: KVM setup pv remote TLB flush
2026-10-10T11:00:17,642989+00:00 kvm-guest: setup PV sched yield
2026-10-10T11:00:17,643001+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2026-10-10T11:00:17,643003+00:00 PM: hibernation: Registered nosave memory: [mem 0x00030000-0x0004ffff]
2026-10-10T11:00:17,643005+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x000fffff]
2026-10-10T11:00:17,643006+00:00 PM: hibernation: Registered nosave memory: [mem 0x00812000-0x00812fff]
2026-10-10T11:00:17,643008+00:00 PM: hibernation: Registered nosave memory: [mem 0x79ccd000-0x79cf0fff]
2026-10-10T11:00:17,643009+00:00 PM: hibernation: Registered nosave memory: [mem 0x7a1c4000-0x7a1c6fff]
2026-10-10T11:00:17,643010+00:00 PM: hibernation: Registered nosave memory: [mem 0x7bce6000-0x7bff7fff]
2026-10-10T11:00:17,643012+00:00 PM: hibernation: Registered nosave memory: [mem 0x7c000000-0xffffffff]
2026-10-10T11:00:17,643013+00:00 [gap 0x80000000-0xdfffffff] available for PCI devices
2026-10-10T11:00:17,643015+00:00 Booting paravirtualized kernel on KVM
2026-10-10T11:00:17,643017+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2026-10-10T11:00:17,643059+00:00 Zone ranges:
2026-10-10T11:00:17,643061+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2026-10-10T11:00:17,643063+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2026-10-10T11:00:17,643065+00:00   Normal   [mem 0x0000000100000000-0x00000002ffffffff]
2026-10-10T11:00:17,643066+00:00   Device   empty
2026-10-10T11:00:17,643067+00:00 Movable zone start for each node
2026-10-10T11:00:17,643069+00:00 Early memory node ranges
2026-10-10T11:00:17,643070+00:00   node   0: [mem 0x0000000000001000-0x000000000002ffff]
2026-10-10T11:00:17,643071+00:00   node   0: [mem 0x0000000000050000-0x000000000009efff]
2026-10-10T11:00:17,643072+00:00   node   0: [mem 0x0000000000100000-0x0000000000811fff]
2026-10-10T11:00:17,643073+00:00   node   0: [mem 0x0000000000813000-0x000000007a1c3fff]
2026-10-10T11:00:17,643074+00:00   node   0: [mem 0x000000007a1c7000-0x000000007bce5fff]
2026-10-10T11:00:17,643075+00:00   node   0: [mem 0x000000007bff8000-0x000000007bffffff]
2026-10-10T11:00:17,643076+00:00   node   0: [mem 0x0000000100000000-0x00000002ffffffff]
2026-10-10T11:00:17,643078+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x00000002ffffffff]
2026-10-10T11:00:17,643278+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2026-10-10T11:00:17,643281+00:00 On node 0, zone DMA: 32 pages in unavailable ranges
2026-10-10T11:00:17,643290+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2026-10-10T11:00:17,643298+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2026-10-10T11:00:17,648284+00:00 On node 0, zone DMA32: 3 pages in unavailable ranges
2026-10-10T11:00:17,648290+00:00 On node 0, zone DMA32: 786 pages in unavailable ranges
2026-10-10T11:00:17,668640+00:00 On node 0, zone Normal: 16384 pages in unavailable ranges
2026-10-10T11:00:17,668658+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:2 nr_cpu_ids:2 nr_node_ids:1
2026-10-10T11:00:17,669052+00:00 percpu: Embedded 85 pages/cpu s225280 r8192 d114688 u1048576
2026-10-10T11:00:17,669061+00:00 pcpu-alloc: s225280 r8192 d114688 u1048576 alloc=1*2097152
2026-10-10T11:00:17,669063+00:00 pcpu-alloc: [0] 0 1 
2026-10-10T11:00:17,669108+00:00 kvm-guest: PV spinlocks enabled
2026-10-10T11:00:17,669112+00:00 PV qspinlock hash table entries: 256 (order: 0, 4096 bytes, linear)
2026-10-10T11:00:17,669116+00:00 Kernel command line: BOOT_IMAGE=/vmlinuz-7.0.0-38-generic root=UUID=747687d9-c20c-41f8-bfb8-7f4a57910c51 ro console=tty1 console=ttyS0
2026-10-10T11:00:17,669173+00:00 printk: log buffer data + meta data: 262144 + 1114112 = 1376256 bytes
2026-10-10T11:00:17,671725+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2026-10-10T11:00:17,673029+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2026-10-10T11:00:17,673105+00:00 software IO TLB: area num 2.
2026-10-10T11:00:17,690226+00:00 Fallback order for Node 0: 0 
2026-10-10T11:00:17,690232+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 2604136
2026-10-10T11:00:17,690234+00:00 Policy zone: Normal
2026-10-10T11:00:17,690244+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2026-10-10T11:00:17,711919+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2026-10-10T11:00:17,717517+00:00 ftrace: allocating 63997 entries in 252 pages
2026-10-10T11:00:17,717521+00:00 ftrace: allocated 252 pages with 6 groups
2026-10-10T11:00:17,718165+00:00 Dynamic Preempt: lazy
2026-10-10T11:00:17,718421+00:00 rcu: Preemptible hierarchical RCU implementation.
2026-10-10T11:00:17,718424+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=2.
2026-10-10T11:00:17,718425+00:00 	Trampoline variant of Tasks RCU enabled.
2026-10-10T11:00:17,718426+00:00 	Rude variant of Tasks RCU enabled.
2026-10-10T11:00:17,718427+00:00 	Tracing variant of Tasks RCU enabled.
2026-10-10T11:00:17,718427+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2026-10-10T11:00:17,718428+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2026-10-10T11:00:17,718440+00:00 RCU Tasks: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1 rcu_task_cpu_ids=2.
2026-10-10T11:00:17,718442+00:00 RCU Tasks Rude: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1 rcu_task_cpu_ids=2.
2026-10-10T11:00:17,723879+00:00 NR_IRQS: 524544, nr_irqs: 440, preallocated irqs: 16
2026-10-10T11:00:17,724104+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2026-10-10T11:00:17,724113+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2026-10-10T11:00:17,724202+00:00 Console: colour dummy device 80x25
2026-10-10T11:00:17,724206+00:00 printk: legacy console [tty1] enabled
2026-10-10T11:00:17,724521+00:00 printk: console [ttyS0] enabled
2026-10-10T11:00:17,920295+00:00 ACPI: Core revision 20251212
2026-10-10T11:00:17,921106+00:00 APIC: Switch to symmetric I/O mode setup
2026-10-10T11:00:17,922370+00:00 x2apic enabled
2026-10-10T11:00:17,923223+00:00 APIC: Switched APIC routing to: physical x2apic
2026-10-10T11:00:17,924307+00:00 kvm-guest: APIC: send_IPI_mask() replaced with kvm_send_ipi_mask()
2026-10-10T11:00:17,925662+00:00 kvm-guest: APIC: send_IPI_mask_allbutself() replaced with kvm_send_ipi_mask_allbutself()
2026-10-10T11:00:17,927366+00:00 kvm-guest: setup PV IPIs
2026-10-10T11:00:17,928885+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0xb9fb05486c, max_idle_ns: 440795231721 ns
2026-10-10T11:00:17,930850+00:00 Calibrating delay loop (skipped) preset value.. 1612.80 BogoMIPS (lpj=806400)
2026-10-10T11:00:17,931845+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2026-10-10T11:00:17,931845+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2026-10-10T11:00:17,931845+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2026-10-10T11:00:17,931845+00:00 mitigations: Enabled attack vectors: user_kernel, user_user, guest_host, guest_guest, SMT mitigations: auto
2026-10-10T11:00:17,931845+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl
2026-10-10T11:00:17,931845+00:00 Spectre V2 : Mitigation: Enhanced / Automatic IBRS
2026-10-10T11:00:17,931845+00:00 Register File Data Sampling: Mitigation: Clear Register File
2026-10-10T11:00:17,931845+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2026-10-10T11:00:17,931845+00:00 Spectre V2 : Enabling IBPB for BPF
2026-10-10T11:00:17,931845+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2026-10-10T11:00:17,931845+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2026-10-10T11:00:17,931845+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2026-10-10T11:00:17,931845+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2026-10-10T11:00:17,931845+00:00 x86/fpu: Supporting XSAVE feature 0x200: 'Protection Keys User registers'
2026-10-10T11:00:17,931845+00:00 x86/fpu: Supporting XSAVE feature 0x800: 'Control-flow User registers'
2026-10-10T11:00:17,931845+00:00 x86/fpu: Supporting XSAVE feature 0x1000: 'Control-flow Kernel registers (KVM only)'
2026-10-10T11:00:17,931845+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2026-10-10T11:00:17,931845+00:00 x86/fpu: xstate_offset[9]:  832, xstate_sizes[9]:    8
2026-10-10T11:00:17,931845+00:00 x86/fpu: xstate_offset[11]:  840, xstate_sizes[11]:   16
2026-10-10T11:00:17,931845+00:00 x86/fpu: xstate_offset[12]:  856, xstate_sizes[12]:   24
2026-10-10T11:00:17,931845+00:00 x86/fpu: Enabled xstate features 0x1a07, context size is 880 bytes, using 'compacted' format.
2026-10-10T11:00:17,931845+00:00 Freeing SMP alternatives memory: 56K
2026-10-10T11:00:17,931845+00:00 pid_max: default: 32768 minimum: 301
2026-10-10T11:00:17,931845+00:00 landlock: Up and running.
2026-10-10T11:00:17,931845+00:00 Yama: becoming mindful.
2026-10-10T11:00:17,931845+00:00 AppArmor: AppArmor initialized
2026-10-10T11:00:17,931845+00:00 AppArmor: AppArmor secmark mediation reserved: ready to be enabled
2026-10-10T11:00:17,931845+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:17,931845+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:17,931845+00:00 VFS: Finished mounting rootfs on nullfs
2026-10-10T11:00:17,931845+00:00 smpboot: CPU0: Intel(R) N100 (family: 0x6, model: 0xbe, stepping: 0x0)
2026-10-10T11:00:17,932055+00:00 Performance Events: Gracemont events, full-width counters, Intel PMU driver.
2026-10-10T11:00:17,932859+00:00 ... version:                   2
2026-10-10T11:00:17,933658+00:00 ... bit width:                 48
2026-10-10T11:00:17,933862+00:00 ... generic counters:          6
2026-10-10T11:00:17,934658+00:00 ... generic bitmap:            000000000000003f
2026-10-10T11:00:17,934852+00:00 ... fixed-purpose counters:    3
2026-10-10T11:00:17,935654+00:00 ... fixed-purpose bitmap:      0000000000000007
2026-10-10T11:00:17,935852+00:00 ... value mask:                0000ffffffffffff
2026-10-10T11:00:17,936852+00:00 ... max period:                00007fffffffffff
2026-10-10T11:00:17,937852+00:00 ... global_ctrl mask:          000000070000003f
2026-10-10T11:00:17,939051+00:00 signal: max sigframe size: 3632
2026-10-10T11:00:17,939919+00:00 rcu: Hierarchical SRCU implementation.
2026-10-10T11:00:17,939923+00:00 rcu: 	Max phase no-delay instances is 400.
2026-10-10T11:00:17,941916+00:00 Timer migration: 1 hierarchy levels; 8 children per group; 1 crossnode level
2026-10-10T11:00:17,943215+00:00 smp: Bringing up secondary CPUs ...
2026-10-10T11:00:17,944186+00:00 smpboot: x86: Booting SMP configuration:
2026-10-10T11:00:17,944196+00:00 .... node  #0, CPUs:      #1
2026-10-10T11:00:17,944892+00:00 smp: Brought up 1 node, 2 CPUs
2026-10-10T11:00:17,944892+00:00 smpboot: Total of 2 processors activated (3225.60 BogoMIPS)
2026-10-10T11:00:17,946911+00:00 Memory: 8747664K/10416544K available (23836K kernel code, 4957K rwdata, 16776K rodata, 5304K init, 5840K bss, 1660488K reserved, 0K cma-reserved)
2026-10-10T11:00:17,947927+00:00 devtmpfs: initialized
2026-10-10T11:00:17,947927+00:00 x86/mm: Memory block size: 128MB
2026-10-10T11:00:17,949910+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x7bf78000-0x7bff7fff] (524288 bytes)
2026-10-10T11:00:17,950877+00:00 posixtimers hash table entries: 1024 (order: 2, 16384 bytes, linear)
2026-10-10T11:00:17,950877+00:00 futex hash table entries: 512 (32768 bytes on 1 NUMA nodes, total 32 KiB, linear).
2026-10-10T11:00:17,951273+00:00 PM: RTC time: 11:00:17, date: 2026-10-10
2026-10-10T11:00:17,951845+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2026-10-10T11:00:17,953216+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2026-10-10T11:00:17,953484+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2026-10-10T11:00:17,953666+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2026-10-10T11:00:17,953693+00:00 audit: initializing netlink subsys (disabled)
2026-10-10T11:00:17,953852+00:00 audit: type=2000 audit(1791630017.772:1): state=initialized audit_enabled=0 res=1
2026-10-10T11:00:17,953949+00:00 thermal_sys: Registered thermal governor 'fair_share'
2026-10-10T11:00:17,953950+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2026-10-10T11:00:17,953953+00:00 thermal_sys: Registered thermal governor 'step_wise'
2026-10-10T11:00:17,953955+00:00 thermal_sys: Registered thermal governor 'user_space'
2026-10-10T11:00:17,953957+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2026-10-10T11:00:17,954854+00:00 cpuidle: using governor ladder
2026-10-10T11:00:17,955853+00:00 cpuidle: using governor menu
2026-10-10T11:00:17,959500+00:00 efi: Freeing EFI boot services memory: 48376K
2026-10-10T11:00:17,959507+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2026-10-10T11:00:17,959754+00:00 PCI: ECAM [mem 0xe0000000-0xefffffff] (base 0xe0000000) for domain 0000 [bus 00-ff]
2026-10-10T11:00:17,959771+00:00 PCI: Using configuration type 1 for base access
2026-10-10T11:00:17,959912+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2026-10-10T11:00:17,967849+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2026-10-10T11:00:17,967855+00:00 HugeTLB: 16380 KiB vmemmap can be freed for a 1.00 GiB page
2026-10-10T11:00:17,967857+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2026-10-10T11:00:17,967859+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2026-10-10T11:00:17,979870+00:00 fbcon: Taking over console
2026-10-10T11:00:17,979894+00:00 ACPI: Added _OSI(Module Device)
2026-10-10T11:00:17,979897+00:00 ACPI: Added _OSI(Processor Device)
2026-10-10T11:00:17,979899+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2026-10-10T11:00:17,982628+00:00 ACPI: 2 ACPI AML tables successfully acquired and loaded
2026-10-10T11:00:17,987862+00:00 ACPI: \_SB_: platform _OSC: OS support mask [006e7eff]
2026-10-10T11:00:17,988232+00:00 ACPI: Interpreter enabled
2026-10-10T11:00:17,988243+00:00 ACPI: PM: (supports S0 S5)
2026-10-10T11:00:17,988246+00:00 ACPI: Using IOAPIC for interrupt routing
2026-10-10T11:00:17,988634+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2026-10-10T11:00:17,988638+00:00 PCI: Ignoring E820 reservations for host bridge windows
2026-10-10T11:00:17,988851+00:00 ACPI: Enabled 3 GPEs in block 00 to 3F
2026-10-10T11:00:17,993143+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2026-10-10T11:00:17,993152+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI EDR HPX-Type3]
2026-10-10T11:00:17,993198+00:00 acpi PNP0A08:00: _OSC: platform does not support [PCIeHotplug LTR DPC]
2026-10-10T11:00:17,993257+00:00 acpi PNP0A08:00: _OSC: OS now controls [SHPCHotplug PME AER PCIeCapability]
2026-10-10T11:00:17,993845+00:00 PCI host bridge to bus 0000:00
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:17,993845+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2026-10-10T11:00:17,993845+00:00 pci 0000:00:00.0: [8086:29c0] type 00 class 0x060000 conventional PCI endpoint
2026-10-10T11:00:17,994308+00:00 pci 0000:00:01.0: [1234:1111] type 00 class 0x030000 conventional PCI endpoint
2026-10-10T11:00:17,994845+00:00 pci 0000:00:01.0: BAR 0 [mem 0x80000000-0x80ffffff pref]
2026-10-10T11:00:17,994845+00:00 pci 0000:00:01.0: BAR 2 [mem 0x8224b000-0x8224bfff]
2026-10-10T11:00:17,994845+00:00 pci 0000:00:01.0: ROM [mem 0xffff0000-0xffffffff pref]
2026-10-10T11:00:17,994845+00:00 pci 0000:00:01.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2026-10-10T11:00:18,000870+00:00 pci 0000:00:1a.0: [8086:2937] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:18,001845+00:00 pci 0000:00:1a.0: BAR 4 [io  0x8100-0x811f]
2026-10-10T11:00:18,002089+00:00 pci 0000:00:1a.1: [8086:2938] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:18,002089+00:00 pci 0000:00:1a.1: BAR 4 [io  0x80e0-0x80ff]
2026-10-10T11:00:18,002370+00:00 pci 0000:00:1a.2: [8086:2939] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:18,002845+00:00 pci 0000:00:1a.2: BAR 4 [io  0x80c0-0x80df]
2026-10-10T11:00:18,002845+00:00 pci 0000:00:1a.7: [8086:293c] type 00 class 0x0c0320 conventional PCI endpoint
2026-10-10T11:00:18,003845+00:00 pci 0000:00:1a.7: BAR 0 [mem 0x8224a000-0x8224afff]
2026-10-10T11:00:18,003845+00:00 pci 0000:00:1b.0: [8086:293e] type 00 class 0x040300 conventional PCI endpoint
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1b.0: BAR 0 [mem 0x82240000-0x82243fff]
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1c.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1c.0: BAR 0 [mem 0x82249000-0x82249fff]
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1c.0:   bridge window [mem 0x82000000-0x821fffff]
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1c.0:   bridge window [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:18,005845+00:00 pci 0000:00:1c.0: enabling Extended Tags
2026-10-10T11:00:18,006845+00:00 pci 0000:00:1c.1: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:18,007845+00:00 pci 0000:00:1c.1: BAR 0 [mem 0x82248000-0x82248fff]
2026-10-10T11:00:18,007845+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:18,007845+00:00 pci 0000:00:1c.1:   bridge window [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:18,007845+00:00 pci 0000:00:1c.1:   bridge window [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:18,007845+00:00 pci 0000:00:1c.1: enabling Extended Tags
2026-10-10T11:00:18,008845+00:00 pci 0000:00:1c.2: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:18,009877+00:00 pci 0000:00:1c.2: BAR 0 [mem 0x82247000-0x82247fff]
2026-10-10T11:00:18,009945+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:18,010057+00:00 pci 0000:00:1c.2:   bridge window [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:18,010845+00:00 pci 0000:00:1c.2:   bridge window [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:18,010845+00:00 pci 0000:00:1c.2: enabling Extended Tags
2026-10-10T11:00:18,010845+00:00 pci 0000:00:1c.3: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:18,011845+00:00 pci 0000:00:1c.3: BAR 0 [mem 0x82246000-0x82246fff]
2026-10-10T11:00:18,011845+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:18,011845+00:00 pci 0000:00:1c.3:   bridge window [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:18,011845+00:00 pci 0000:00:1c.3:   bridge window [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:18,011845+00:00 pci 0000:00:1c.3: enabling Extended Tags
2026-10-10T11:00:18,012845+00:00 pci 0000:00:1d.0: [8086:2934] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:18,012845+00:00 pci 0000:00:1d.0: BAR 4 [io  0x80a0-0x80bf]
2026-10-10T11:00:18,013918+00:00 pci 0000:00:1d.1: [8086:2935] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:18,014852+00:00 pci 0000:00:1d.1: BAR 4 [io  0x8080-0x809f]
2026-10-10T11:00:18,015335+00:00 pci 0000:00:1d.2: [8086:2936] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:18,015845+00:00 pci 0000:00:1d.2: BAR 4 [io  0x8060-0x807f]
2026-10-10T11:00:18,015845+00:00 pci 0000:00:1d.7: [8086:293a] type 00 class 0x0c0320 conventional PCI endpoint
2026-10-10T11:00:18,016845+00:00 pci 0000:00:1d.7: BAR 0 [mem 0x82245000-0x82245fff]
2026-10-10T11:00:18,016845+00:00 pci 0000:00:1e.0: [8086:244e] type 01 class 0x060401 conventional PCI bridge
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09] (subtractive decode)
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1e.0:   bridge window [io  0x6000-0x7fff]
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1e.0:   bridge window [mem 0x81000000-0x818fffff]
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1f.0: [8086:2918] type 00 class 0x060100 conventional PCI endpoint
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1f.0: quirk: [io  0x0600-0x067f] claimed by ICH6 ACPI/GPIO/TCO
2026-10-10T11:00:18,017845+00:00 pci 0000:00:1f.2: [8086:2922] type 00 class 0x010601 conventional PCI endpoint
2026-10-10T11:00:18,019845+00:00 pci 0000:00:1f.2: BAR 4 [io  0x8040-0x805f]
2026-10-10T11:00:18,019845+00:00 pci 0000:00:1f.2: BAR 5 [mem 0x82244000-0x82244fff]
2026-10-10T11:00:18,019845+00:00 pci 0000:00:1f.3: [8086:2930] type 00 class 0x0c0500 conventional PCI endpoint
2026-10-10T11:00:18,020845+00:00 pci 0000:00:1f.3: BAR 4 [io  0x8000-0x803f]
2026-10-10T11:00:18,020845+00:00 acpiphp: Slot [0] registered
2026-10-10T11:00:18,020845+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:18,021845+00:00 acpiphp: Slot [0-2] registered
2026-10-10T11:00:18,021845+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:18,022845+00:00 acpiphp: Slot [0-3] registered
2026-10-10T11:00:18,022845+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:18,023845+00:00 acpiphp: Slot [0-4] registered
2026-10-10T11:00:18,023845+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:18,023852+00:00 pci_bus 0000:05: extended config space not accessible
2026-10-10T11:00:18,024167+00:00 acpiphp: Slot [0-5] registered
2026-10-10T11:00:18,024211+00:00 acpiphp: Slot [5] registered
2026-10-10T11:00:18,024245+00:00 acpiphp: Slot [6] registered
2026-10-10T11:00:18,024288+00:00 acpiphp: Slot [7] registered
2026-10-10T11:00:18,024322+00:00 acpiphp: Slot [8] registered
2026-10-10T11:00:18,024364+00:00 acpiphp: Slot [9] registered
2026-10-10T11:00:18,024397+00:00 acpiphp: Slot [10] registered
2026-10-10T11:00:18,024434+00:00 acpiphp: Slot [11] registered
2026-10-10T11:00:18,024479+00:00 acpiphp: Slot [12] registered
2026-10-10T11:00:18,024513+00:00 acpiphp: Slot [13] registered
2026-10-10T11:00:18,024546+00:00 acpiphp: Slot [14] registered
2026-10-10T11:00:18,024580+00:00 acpiphp: Slot [15] registered
2026-10-10T11:00:18,024635+00:00 acpiphp: Slot [16] registered
2026-10-10T11:00:18,024668+00:00 acpiphp: Slot [17] registered
2026-10-10T11:00:18,024710+00:00 acpiphp: Slot [18] registered
2026-10-10T11:00:18,024747+00:00 acpiphp: Slot [19] registered
2026-10-10T11:00:18,024782+00:00 acpiphp: Slot [20] registered
2026-10-10T11:00:18,024815+00:00 acpiphp: Slot [21] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [22] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [23] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [24] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [25] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [26] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [27] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [28] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [29] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [30] registered
2026-10-10T11:00:18,024845+00:00 acpiphp: Slot [31] registered
2026-10-10T11:00:18,024845+00:00 pci 0000:05:01.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:18,025845+00:00 pci 0000:05:01.0: BAR 0 [mem 0x81800000-0x818000ff 64bit]
2026-10-10T11:00:18,025845+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:18,025845+00:00 pci 0000:05:01.0:   bridge window [io  0x7000-0x7fff]
2026-10-10T11:00:18,025845+00:00 pci 0000:05:01.0:   bridge window [mem 0x81600000-0x817fffff]
2026-10-10T11:00:18,026450+00:00 pci 0000:05:01.0:   bridge window [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:18,026450+00:00 pci 0000:05:02.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:18,026845+00:00 pci 0000:05:02.0: BAR 0 [mem 0x81801000-0x818010ff 64bit]
2026-10-10T11:00:18,026845+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:18,026935+00:00 pci 0000:05:02.0:   bridge window [mem 0x81400000-0x815fffff]
2026-10-10T11:00:18,027845+00:00 pci 0000:05:02.0:   bridge window [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:18,027845+00:00 pci 0000:05:03.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:18,028845+00:00 pci 0000:05:03.0: BAR 0 [mem 0x81802000-0x818020ff 64bit]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:03.0:   bridge window [mem 0x81200000-0x813fffff]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:03.0:   bridge window [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:04.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:18,028845+00:00 pci 0000:05:04.0: BAR 0 [mem 0x81803000-0x818030ff 64bit]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:04.0:   bridge window [io  0x6000-0x6fff]
2026-10-10T11:00:18,028845+00:00 pci 0000:05:04.0:   bridge window [mem 0x81000000-0x811fffff]
2026-10-10T11:00:18,029854+00:00 pci 0000:05:04.0:   bridge window [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:18,038854+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09] (subtractive decode)
2026-10-10T11:00:18,039051+00:00 pci 0000:00:1e.0:   bridge window [io  0x0000-0x0cf7 window] (subtractive decode)
2026-10-10T11:00:18,039061+00:00 pci 0000:00:1e.0:   bridge window [io  0x0d00-0xffff window] (subtractive decode)
2026-10-10T11:00:18,039065+00:00 pci 0000:00:1e.0:   bridge window [mem 0x000a0000-0x000bffff window] (subtractive decode)
2026-10-10T11:00:18,039068+00:00 pci 0000:00:1e.0:   bridge window [mem 0x80000000-0xdfffffff window] (subtractive decode)
2026-10-10T11:00:18,039072+00:00 pci 0000:00:1e.0:   bridge window [mem 0xf0000000-0xfebfffff window] (subtractive decode)
2026-10-10T11:00:18,039075+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7000000000-0x77ffffffff window] (subtractive decode)
2026-10-10T11:00:18,039845+00:00 pci_bus 0000:06: extended config space not accessible
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [8-2] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [18-2] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [0-6] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [1] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [2] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [3] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [4] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [5-2] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [6-2] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [7-2] registered
2026-10-10T11:00:18,039845+00:00 acpiphp: Slot [9-2] registered
2026-10-10T11:00:18,039858+00:00 acpiphp: Slot [10-2] registered
2026-10-10T11:00:18,039897+00:00 acpiphp: Slot [11-2] registered
2026-10-10T11:00:18,039935+00:00 acpiphp: Slot [12-2] registered
2026-10-10T11:00:18,039986+00:00 acpiphp: Slot [13-2] registered
2026-10-10T11:00:18,040031+00:00 acpiphp: Slot [14-2] registered
2026-10-10T11:00:18,040073+00:00 acpiphp: Slot [15-2] registered
2026-10-10T11:00:18,040115+00:00 acpiphp: Slot [16-2] registered
2026-10-10T11:00:18,040165+00:00 acpiphp: Slot [17-2] registered
2026-10-10T11:00:18,040228+00:00 acpiphp: Slot [19-2] registered
2026-10-10T11:00:18,040277+00:00 acpiphp: Slot [20-2] registered
2026-10-10T11:00:18,040328+00:00 acpiphp: Slot [21-2] registered
2026-10-10T11:00:18,040377+00:00 acpiphp: Slot [22-2] registered
2026-10-10T11:00:18,040417+00:00 acpiphp: Slot [23-2] registered
2026-10-10T11:00:18,040455+00:00 acpiphp: Slot [24-2] registered
2026-10-10T11:00:18,040497+00:00 acpiphp: Slot [25-2] registered
2026-10-10T11:00:18,040535+00:00 acpiphp: Slot [26-2] registered
2026-10-10T11:00:18,040583+00:00 acpiphp: Slot [27-2] registered
2026-10-10T11:00:18,040622+00:00 acpiphp: Slot [28-2] registered
2026-10-10T11:00:18,040666+00:00 acpiphp: Slot [29-2] registered
2026-10-10T11:00:18,040707+00:00 acpiphp: Slot [30-2] registered
2026-10-10T11:00:18,040766+00:00 acpiphp: Slot [31-2] registered
2026-10-10T11:00:18,043694+00:00 pci 0000:06:08.0: [1af4:1003] type 00 class 0x078000 conventional PCI endpoint
2026-10-10T11:00:18,043854+00:00 pci 0000:06:08.0: BAR 0 [io  0x7040-0x707f]
2026-10-10T11:00:18,043880+00:00 pci 0000:06:08.0: BAR 1 [mem 0x81601000-0x81601fff]
2026-10-10T11:00:18,043957+00:00 pci 0000:06:08.0: BAR 4 [mem 0x7070004000-0x7070007fff 64bit pref]
2026-10-10T11:00:18,047845+00:00 pci 0000:06:12.0: [1af4:1000] type 00 class 0x020000 conventional PCI endpoint
2026-10-10T11:00:18,048878+00:00 pci 0000:06:12.0: BAR 0 [io  0x7000-0x703f]
2026-10-10T11:00:18,048909+00:00 pci 0000:06:12.0: BAR 1 [mem 0x81600000-0x81600fff]
2026-10-10T11:00:18,049004+00:00 pci 0000:06:12.0: BAR 4 [mem 0x7070000000-0x7070003fff 64bit pref]
2026-10-10T11:00:18,049029+00:00 pci 0000:06:12.0: ROM [mem 0xfffc0000-0xffffffff pref]
2026-10-10T11:00:18,053902+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:18,057142+00:00 pci_bus 0000:07: extended config space not accessible
2026-10-10T11:00:18,057430+00:00 acpiphp: Slot [0-7] registered
2026-10-10T11:00:18,057473+00:00 acpiphp: Slot [1-2] registered
2026-10-10T11:00:18,057512+00:00 acpiphp: Slot [2-2] registered
2026-10-10T11:00:18,057561+00:00 acpiphp: Slot [3-2] registered
2026-10-10T11:00:18,057609+00:00 acpiphp: Slot [4-2] registered
2026-10-10T11:00:18,057652+00:00 acpiphp: Slot [5-3] registered
2026-10-10T11:00:18,057690+00:00 acpiphp: Slot [6-3] registered
2026-10-10T11:00:18,057728+00:00 acpiphp: Slot [7-3] registered
2026-10-10T11:00:18,057766+00:00 acpiphp: Slot [8-3] registered
2026-10-10T11:00:18,057804+00:00 acpiphp: Slot [9-3] registered
2026-10-10T11:00:18,057842+00:00 acpiphp: Slot [10-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [11-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [12-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [13-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [14-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [15-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [16-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [17-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [18-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [19-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [20-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [21-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [22-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [23-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [24-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [25-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [26-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [27-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [28-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [29-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [30-3] registered
2026-10-10T11:00:18,057845+00:00 acpiphp: Slot [31-3] registered
2026-10-10T11:00:18,073507+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:18,074218+00:00 pci_bus 0000:08: extended config space not accessible
2026-10-10T11:00:18,074521+00:00 acpiphp: Slot [0-8] registered
2026-10-10T11:00:18,074585+00:00 acpiphp: Slot [1-3] registered
2026-10-10T11:00:18,074641+00:00 acpiphp: Slot [2-3] registered
2026-10-10T11:00:18,074682+00:00 acpiphp: Slot [3-3] registered
2026-10-10T11:00:18,074731+00:00 acpiphp: Slot [4-3] registered
2026-10-10T11:00:18,074769+00:00 acpiphp: Slot [5-4] registered
2026-10-10T11:00:18,074808+00:00 acpiphp: Slot [6-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [7-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [8-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [9-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [10-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [11-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [12-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [13-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [14-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [15-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [16-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [17-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [18-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [19-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [20-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [21-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [22-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [23-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [24-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [25-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [26-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [27-4] registered
2026-10-10T11:00:18,074845+00:00 acpiphp: Slot [28-4] registered
2026-10-10T11:00:18,074868+00:00 acpiphp: Slot [29-4] registered
2026-10-10T11:00:18,074909+00:00 acpiphp: Slot [30-4] registered
2026-10-10T11:00:18,074949+00:00 acpiphp: Slot [31-4] registered
2026-10-10T11:00:18,083746+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:18,084122+00:00 pci_bus 0000:09: extended config space not accessible
2026-10-10T11:00:18,084403+00:00 acpiphp: Slot [1-4] registered
2026-10-10T11:00:18,084453+00:00 acpiphp: Slot [0-9] registered
2026-10-10T11:00:18,084491+00:00 acpiphp: Slot [2-4] registered
2026-10-10T11:00:18,084540+00:00 acpiphp: Slot [3-4] registered
2026-10-10T11:00:18,084580+00:00 acpiphp: Slot [4-4] registered
2026-10-10T11:00:18,084622+00:00 acpiphp: Slot [5-5] registered
2026-10-10T11:00:18,084662+00:00 acpiphp: Slot [6-5] registered
2026-10-10T11:00:18,084709+00:00 acpiphp: Slot [7-5] registered
2026-10-10T11:00:18,084756+00:00 acpiphp: Slot [8-5] registered
2026-10-10T11:00:18,084808+00:00 acpiphp: Slot [9-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [10-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [11-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [12-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [13-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [14-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [15-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [16-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [17-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [18-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [19-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [20-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [21-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [22-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [23-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [24-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [25-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [26-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [27-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [28-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [29-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [30-5] registered
2026-10-10T11:00:18,084845+00:00 acpiphp: Slot [31-5] registered
2026-10-10T11:00:18,085523+00:00 pci 0000:09:01.0: [1af4:1004] type 00 class 0x010000 conventional PCI endpoint
2026-10-10T11:00:18,086905+00:00 pci 0000:09:01.0: BAR 0 [io  0x6000-0x603f]
2026-10-10T11:00:18,086936+00:00 pci 0000:09:01.0: BAR 1 [mem 0x81000000-0x81000fff]
2026-10-10T11:00:18,087017+00:00 pci 0000:09:01.0: BAR 4 [mem 0x7040000000-0x7040003fff 64bit pref]
2026-10-10T11:00:18,096758+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:18,104351+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2026-10-10T11:00:18,104524+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2026-10-10T11:00:18,104695+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 10
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 10
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 11
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 11
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIA configured for IRQ 16
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIB configured for IRQ 17
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIC configured for IRQ 18
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSID configured for IRQ 19
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIE configured for IRQ 20
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIF configured for IRQ 21
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIG configured for IRQ 22
2026-10-10T11:00:18,104845+00:00 ACPI: PCI: Interrupt link GSIH configured for IRQ 23
2026-10-10T11:00:18,106101+00:00 iommu: Default domain type: Translated
2026-10-10T11:00:18,106106+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2026-10-10T11:00:18,107041+00:00 SCSI subsystem initialized
2026-10-10T11:00:18,107084+00:00 libata version 3.00 loaded.
2026-10-10T11:00:18,107109+00:00 ACPI: bus type USB registered
2026-10-10T11:00:18,107124+00:00 usbcore: registered new interface driver usbfs
2026-10-10T11:00:18,107132+00:00 usbcore: registered new interface driver hub
2026-10-10T11:00:18,107139+00:00 usbcore: registered new device driver usb
2026-10-10T11:00:18,107159+00:00 pps_core: LinuxPPS API ver. 1 registered
2026-10-10T11:00:18,107162+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2026-10-10T11:00:18,107166+00:00 PTP clock support registered
2026-10-10T11:00:18,108902+00:00 EDAC MC: Ver: 3.0.0
2026-10-10T11:00:18,110221+00:00 efivars: Registered efivars operations
2026-10-10T11:00:18,111538+00:00 NetLabel: Initializing
2026-10-10T11:00:18,111545+00:00 NetLabel:  domain hash size = 128
2026-10-10T11:00:18,111548+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2026-10-10T11:00:18,111570+00:00 NetLabel:  unlabeled traffic allowed by default
2026-10-10T11:00:18,111656+00:00 mctp: management component transport protocol core
2026-10-10T11:00:18,111660+00:00 NET: Registered PF_MCTP protocol family
2026-10-10T11:00:18,111673+00:00 PCI: Using ACPI for IRQ routing
2026-10-10T11:00:18,289288+00:00 PCI: pci_cache_line_size set to 64 bytes
2026-10-10T11:00:18,290101+00:00 e820: register RAM buffer resource [mem 0x0009f000-0x0009ffff]
2026-10-10T11:00:18,290119+00:00 e820: register RAM buffer resource [mem 0x00812000-0x008fffff]
2026-10-10T11:00:18,290123+00:00 e820: register RAM buffer resource [mem 0x79ccd000-0x7bffffff]
2026-10-10T11:00:18,290126+00:00 e820: register RAM buffer resource [mem 0x7a1c4000-0x7bffffff]
2026-10-10T11:00:18,290128+00:00 e820: register RAM buffer resource [mem 0x7bce6000-0x7bffffff]
2026-10-10T11:00:18,290247+00:00 pci 0000:00:01.0: vgaarb: setting as boot VGA device
2026-10-10T11:00:18,290253+00:00 pci 0000:00:01.0: vgaarb: bridge control possible
2026-10-10T11:00:18,290256+00:00 pci 0000:00:01.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2026-10-10T11:00:18,290265+00:00 vgaarb: loaded
2026-10-10T11:00:18,291215+00:00 clocksource: Switched to clocksource kvm-clock
2026-10-10T11:00:18,291431+00:00 VFS: Disk quotas dquot_6.6.0
2026-10-10T11:00:18,291444+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2026-10-10T11:00:18,295022+00:00 AppArmor: AppArmor Filesystem Enabled
2026-10-10T11:00:18,295055+00:00 acpi PNP0C01:00: Reserved [mem 0xe0000000-0xefffffff]
2026-10-10T11:00:18,295082+00:00 pnp: PnP ACPI init
2026-10-10T11:00:18,295770+00:00 pnp: PnP ACPI: found 4 devices
2026-10-10T11:00:18,301761+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2026-10-10T11:00:18,301854+00:00 NET: Registered PF_INET protocol family
2026-10-10T11:00:18,302207+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2026-10-10T11:00:18,321255+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2026-10-10T11:00:18,321305+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:18,321551+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2026-10-10T11:00:18,321825+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2026-10-10T11:00:18,321969+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2026-10-10T11:00:18,322093+00:00 MPTCP token hash table entries: 16384 (order: 7, 393216 bytes, linear)
2026-10-10T11:00:18,322166+00:00 UDP hash table entries: 8192 (order: 7, 524288 bytes, linear)
2026-10-10T11:00:18,322243+00:00 UDP-Lite hash table entries: 8192 (order: 7, 524288 bytes, linear)
2026-10-10T11:00:18,322336+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2026-10-10T11:00:18,322354+00:00 NET: Registered PF_XDP protocol family
2026-10-10T11:00:18,322364+00:00 pci 0000:06:12.0: ROM [mem 0xfffc0000-0xffffffff pref]: can't claim; no compatible bridge window
2026-10-10T11:00:18,322375+00:00 pci 0000:00:1c.0: bridge window [io  0x1000-0x0fff] to [bus 01] add_size 1000
2026-10-10T11:00:18,322380+00:00 pci 0000:00:1c.1: bridge window [io  0x1000-0x0fff] to [bus 02] add_size 1000
2026-10-10T11:00:18,322384+00:00 pci 0000:00:1c.2: bridge window [io  0x1000-0x0fff] to [bus 03] add_size 1000
2026-10-10T11:00:18,322387+00:00 pci 0000:00:1c.3: bridge window [io  0x1000-0x0fff] to [bus 04] add_size 1000
2026-10-10T11:00:18,322399+00:00 pci 0000:00:1c.0: bridge window [io  0x1000-0x1fff]: assigned
2026-10-10T11:00:18,322403+00:00 pci 0000:00:1c.1: bridge window [io  0x2000-0x2fff]: assigned
2026-10-10T11:00:18,322406+00:00 pci 0000:00:1c.2: bridge window [io  0x3000-0x3fff]: assigned
2026-10-10T11:00:18,322409+00:00 pci 0000:00:1c.3: bridge window [io  0x4000-0x4fff]: assigned
2026-10-10T11:00:18,322414+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:18,322463+00:00 pci 0000:00:1c.0:   bridge window [io  0x1000-0x1fff]
2026-10-10T11:00:18,324258+00:00 pci 0000:00:1c.0:   bridge window [mem 0x82000000-0x821fffff]
2026-10-10T11:00:18,325409+00:00 pci 0000:00:1c.0:   bridge window [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:18,327819+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:18,327869+00:00 pci 0000:00:1c.1:   bridge window [io  0x2000-0x2fff]
2026-10-10T11:00:18,329657+00:00 pci 0000:00:1c.1:   bridge window [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:18,330799+00:00 pci 0000:00:1c.1:   bridge window [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:18,333330+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:18,333374+00:00 pci 0000:00:1c.2:   bridge window [io  0x3000-0x3fff]
2026-10-10T11:00:18,335369+00:00 pci 0000:00:1c.2:   bridge window [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:18,338259+00:00 pci 0000:00:1c.2:   bridge window [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:18,341864+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:18,342260+00:00 pci 0000:00:1c.3:   bridge window [io  0x4000-0x4fff]
2026-10-10T11:00:18,343228+00:00 pci 0000:00:1c.3:   bridge window [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:18,343948+00:00 pci 0000:00:1c.3:   bridge window [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:18,345301+00:00 pci 0000:06:12.0: ROM [mem 0x81640000-0x8167ffff pref]: assigned
2026-10-10T11:00:18,345312+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:18,345365+00:00 pci 0000:05:01.0:   bridge window [io  0x7000-0x7fff]
2026-10-10T11:00:18,346619+00:00 pci 0000:05:01.0:   bridge window [mem 0x81600000-0x817fffff]
2026-10-10T11:00:18,347494+00:00 pci 0000:05:01.0:   bridge window [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:18,349285+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:18,350631+00:00 pci 0000:05:02.0:   bridge window [mem 0x81400000-0x815fffff]
2026-10-10T11:00:18,351481+00:00 pci 0000:05:02.0:   bridge window [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:18,353892+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:18,356527+00:00 pci 0000:05:03.0:   bridge window [mem 0x81200000-0x813fffff]
2026-10-10T11:00:18,357200+00:00 pci 0000:05:03.0:   bridge window [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:18,358431+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:18,358460+00:00 pci 0000:05:04.0:   bridge window [io  0x6000-0x6fff]
2026-10-10T11:00:18,359428+00:00 pci 0000:05:04.0:   bridge window [mem 0x81000000-0x811fffff]
2026-10-10T11:00:18,360207+00:00 pci 0000:05:04.0:   bridge window [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:18,361542+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09]
2026-10-10T11:00:18,361578+00:00 pci 0000:00:1e.0:   bridge window [io  0x6000-0x7fff]
2026-10-10T11:00:18,362735+00:00 pci 0000:00:1e.0:   bridge window [mem 0x81000000-0x818fffff]
2026-10-10T11:00:18,363542+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:18,365297+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2026-10-10T11:00:18,365307+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2026-10-10T11:00:18,365311+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:18,365314+00:00 pci_bus 0000:00: resource 7 [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:18,365317+00:00 pci_bus 0000:00: resource 8 [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:18,365320+00:00 pci_bus 0000:00: resource 9 [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:18,365324+00:00 pci_bus 0000:01: resource 0 [io  0x1000-0x1fff]
2026-10-10T11:00:18,365327+00:00 pci_bus 0000:01: resource 1 [mem 0x82000000-0x821fffff]
2026-10-10T11:00:18,365329+00:00 pci_bus 0000:01: resource 2 [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:18,365333+00:00 pci_bus 0000:02: resource 0 [io  0x2000-0x2fff]
2026-10-10T11:00:18,365335+00:00 pci_bus 0000:02: resource 1 [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:18,365338+00:00 pci_bus 0000:02: resource 2 [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:18,365341+00:00 pci_bus 0000:03: resource 0 [io  0x3000-0x3fff]
2026-10-10T11:00:18,365344+00:00 pci_bus 0000:03: resource 1 [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:18,365346+00:00 pci_bus 0000:03: resource 2 [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:18,365350+00:00 pci_bus 0000:04: resource 0 [io  0x4000-0x4fff]
2026-10-10T11:00:18,365352+00:00 pci_bus 0000:04: resource 1 [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:18,365355+00:00 pci_bus 0000:04: resource 2 [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:18,365359+00:00 pci_bus 0000:05: resource 0 [io  0x6000-0x7fff]
2026-10-10T11:00:18,365361+00:00 pci_bus 0000:05: resource 1 [mem 0x81000000-0x818fffff]
2026-10-10T11:00:18,365364+00:00 pci_bus 0000:05: resource 2 [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:18,365367+00:00 pci_bus 0000:05: resource 4 [io  0x0000-0x0cf7 window]
2026-10-10T11:00:18,365370+00:00 pci_bus 0000:05: resource 5 [io  0x0d00-0xffff window]
2026-10-10T11:00:18,365372+00:00 pci_bus 0000:05: resource 6 [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:18,365375+00:00 pci_bus 0000:05: resource 7 [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:18,365378+00:00 pci_bus 0000:05: resource 8 [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:18,365381+00:00 pci_bus 0000:05: resource 9 [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:18,365384+00:00 pci_bus 0000:06: resource 0 [io  0x7000-0x7fff]
2026-10-10T11:00:18,365386+00:00 pci_bus 0000:06: resource 1 [mem 0x81600000-0x817fffff]
2026-10-10T11:00:18,365389+00:00 pci_bus 0000:06: resource 2 [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:18,365393+00:00 pci_bus 0000:07: resource 1 [mem 0x81400000-0x815fffff]
2026-10-10T11:00:18,365395+00:00 pci_bus 0000:07: resource 2 [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:18,365398+00:00 pci_bus 0000:08: resource 1 [mem 0x81200000-0x813fffff]
2026-10-10T11:00:18,365401+00:00 pci_bus 0000:08: resource 2 [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:18,365404+00:00 pci_bus 0000:09: resource 0 [io  0x6000-0x6fff]
2026-10-10T11:00:18,365407+00:00 pci_bus 0000:09: resource 1 [mem 0x81000000-0x811fffff]
2026-10-10T11:00:18,365409+00:00 pci_bus 0000:09: resource 2 [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:18,368847+00:00 ACPI: \_SB_.GSIA: Enabled at IRQ 16
2026-10-10T11:00:18,371186+00:00 ACPI: \_SB_.GSIB: Enabled at IRQ 17
2026-10-10T11:00:18,372476+00:00 ACPI: \_SB_.GSIC: Enabled at IRQ 18
2026-10-10T11:00:18,373791+00:00 ACPI: \_SB_.GSID: Enabled at IRQ 19
2026-10-10T11:00:18,379916+00:00 PCI: CLS 0 bytes, default 64
2026-10-10T11:00:18,380088+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2026-10-10T11:00:18,380094+00:00 software IO TLB: mapped [mem 0x000000006e52a000-0x000000007252a000] (64MB)
2026-10-10T11:00:18,380146+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0xb9fb05486c, max_idle_ns: 440795231721 ns
2026-10-10T11:00:18,380219+00:00 Trying to unpack rootfs image as initramfs...
2026-10-10T11:00:18,383523+00:00 Initialise system trusted keyrings
2026-10-10T11:00:18,383540+00:00 Key type blacklist registered
2026-10-10T11:00:18,386976+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2026-10-10T11:00:18,387517+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2026-10-10T11:00:18,391026+00:00 fuse: init (API version 7.45)
2026-10-10T11:00:18,407953+00:00 integrity: Platform Keyring initialized
2026-10-10T11:00:18,407965+00:00 integrity: Machine keyring initialized
2026-10-10T11:00:18,429714+00:00 Key type asymmetric registered
2026-10-10T11:00:18,429722+00:00 Asymmetric key parser 'x509' registered
2026-10-10T11:00:18,429760+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 242)
2026-10-10T11:00:18,433963+00:00 io scheduler mq-deadline registered
2026-10-10T11:00:18,436955+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2026-10-10T11:00:18,438794+00:00 pcieport 0000:00:1c.0: PME: Signaling with IRQ 24
2026-10-10T11:00:18,441162+00:00 pcieport 0000:00:1c.0: AER: enabled with IRQ 24
2026-10-10T11:00:18,443869+00:00 pcieport 0000:00:1c.1: PME: Signaling with IRQ 25
2026-10-10T11:00:18,451215+00:00 pcieport 0000:00:1c.1: AER: enabled with IRQ 25
2026-10-10T11:00:18,456977+00:00 pcieport 0000:00:1c.2: PME: Signaling with IRQ 26
2026-10-10T11:00:18,461715+00:00 pcieport 0000:00:1c.2: AER: enabled with IRQ 26
2026-10-10T11:00:18,464353+00:00 pcieport 0000:00:1c.3: PME: Signaling with IRQ 27
2026-10-10T11:00:18,469300+00:00 pcieport 0000:00:1c.3: AER: enabled with IRQ 27
2026-10-10T11:00:18,472280+00:00 shpchp 0000:05:01.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:18,472650+00:00 ACPI: \_SB_.GSIF: Enabled at IRQ 21
2026-10-10T11:00:18,478313+00:00 shpchp 0000:05:01.0: pci_hp_register failed with error -16
2026-10-10T11:00:18,478330+00:00 shpchp 0000:05:01.0: Slot initialization failed
2026-10-10T11:00:18,485640+00:00 shpchp 0000:05:02.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:18,485881+00:00 ACPI: \_SB_.GSIG: Enabled at IRQ 22
2026-10-10T11:00:18,493511+00:00 shpchp 0000:05:02.0: pci_hp_register failed with error -16
2026-10-10T11:00:18,493526+00:00 shpchp 0000:05:02.0: Slot initialization failed
2026-10-10T11:00:18,498916+00:00 shpchp 0000:05:03.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:18,499193+00:00 ACPI: \_SB_.GSIH: Enabled at IRQ 23
2026-10-10T11:00:18,506242+00:00 shpchp 0000:05:03.0: pci_hp_register failed with error -16
2026-10-10T11:00:18,506256+00:00 shpchp 0000:05:03.0: Slot initialization failed
2026-10-10T11:00:18,513589+00:00 shpchp 0000:05:04.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:18,513832+00:00 ACPI: \_SB_.GSIE: Enabled at IRQ 20
2026-10-10T11:00:18,518824+00:00 shpchp 0000:05:04.0: pci_hp_register failed with error -16
2026-10-10T11:00:18,518838+00:00 shpchp 0000:05:04.0: Slot initialization failed
2026-10-10T11:00:18,522571+00:00 input: Power Button as /devices/platform/LNXPWRBN:00/input/input0
2026-10-10T11:00:18,522650+00:00 ACPI: button: Power Button [PWRF]
2026-10-10T11:00:18,537665+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2026-10-10T11:00:18,568884+00:00 00:00: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2026-10-10T11:00:18,609208+00:00 Linux agpgart interface v0.103
2026-10-10T11:00:18,612157+00:00 loop: module loaded
2026-10-10T11:00:18,613358+00:00 virtio_scsi virtio2: 2/0/0 default/read/poll queues
2026-10-10T11:00:18,616644+00:00 scsi host0: Virtio SCSI HBA
2026-10-10T11:00:18,622129+00:00 ACPI: bus type drm_connector registered
2026-10-10T11:00:18,622439+00:00 tun: Universal TUN/TAP device driver, 1.6
2026-10-10T11:00:18,624964+00:00 scsi 0:0:0:0: Direct-Access     QEMU     QEMU HARDDISK    2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:18,629319+00:00 PPP generic driver version 2.4.2
2026-10-10T11:00:18,631541+00:00 uhci_hcd 0000:00:1a.0: UHCI Host Controller
2026-10-10T11:00:18,631561+00:00 uhci_hcd 0000:00:1a.0: new USB bus registered, assigned bus number 1
2026-10-10T11:00:18,631593+00:00 uhci_hcd 0000:00:1a.0: detected 2 ports
2026-10-10T11:00:18,631760+00:00 uhci_hcd 0000:00:1a.0: irq 16, io port 0x00008100
2026-10-10T11:00:18,637595+00:00 Freeing initrd memory: 42828K
2026-10-10T11:00:18,638016+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:18,638023+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,638027+00:00 usb usb1: Product: UHCI Host Controller
2026-10-10T11:00:18,638030+00:00 usb usb1: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:18,638033+00:00 usb usb1: SerialNumber: 0000:00:1a.0
2026-10-10T11:00:18,638161+00:00 hub 1-0:1.0: USB hub found
2026-10-10T11:00:18,638169+00:00 hub 1-0:1.0: 2 ports detected
2026-10-10T11:00:18,639343+00:00 ehci-pci 0000:00:1d.7: EHCI Host Controller
2026-10-10T11:00:18,639355+00:00 ehci-pci 0000:00:1d.7: new USB bus registered, assigned bus number 2
2026-10-10T11:00:18,639830+00:00 ehci-pci 0000:00:1d.7: irq 19, io mem 0x82245000
2026-10-10T11:00:18,646021+00:00 ehci-pci 0000:00:1d.7: USB 2.0 started, EHCI 1.00
2026-10-10T11:00:18,646091+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 7.00
2026-10-10T11:00:18,646098+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,646102+00:00 usb usb2: Product: EHCI Host Controller
2026-10-10T11:00:18,646105+00:00 usb usb2: Manufacturer: Linux 7.0.0-38-generic ehci_hcd
2026-10-10T11:00:18,646107+00:00 usb usb2: SerialNumber: 0000:00:1d.7
2026-10-10T11:00:18,646207+00:00 hub 2-0:1.0: USB hub found
2026-10-10T11:00:18,646216+00:00 hub 2-0:1.0: 6 ports detected
2026-10-10T11:00:18,647461+00:00 sd 0:0:0:0: Power-on or device reset occurred
2026-10-10T11:00:18,647470+00:00 sd 0:0:0:0: Attached scsi generic sg0 type 0
2026-10-10T11:00:18,647548+00:00 sd 0:0:0:0: [sda] 68157440 512-byte logical blocks: (34.9 GB/32.5 GiB)
2026-10-10T11:00:18,647577+00:00 sd 0:0:0:0: [sda] Write Protect is off
2026-10-10T11:00:18,647581+00:00 sd 0:0:0:0: [sda] Mode Sense: 63 00 10 08
2026-10-10T11:00:18,647618+00:00 sd 0:0:0:0: [sda] Write cache: enabled, read cache: enabled, supports DPO and FUA
2026-10-10T11:00:18,655212+00:00  sda: sda1 sda13 sda14 sda15
2026-10-10T11:00:18,655350+00:00 sd 0:0:0:0: [sda] Attached SCSI disk
2026-10-10T11:00:18,667474+00:00 ehci-pci 0000:00:1a.7: EHCI Host Controller
2026-10-10T11:00:18,667484+00:00 ehci-pci 0000:00:1a.7: new USB bus registered, assigned bus number 3
2026-10-10T11:00:18,667852+00:00 ehci-pci 0000:00:1a.7: irq 19, io mem 0x8224a000
2026-10-10T11:00:18,674023+00:00 ehci-pci 0000:00:1a.7: USB 2.0 started, EHCI 1.00
2026-10-10T11:00:18,674089+00:00 usb usb3: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 7.00
2026-10-10T11:00:18,674094+00:00 usb usb3: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,674098+00:00 usb usb3: Product: EHCI Host Controller
2026-10-10T11:00:18,674100+00:00 usb usb3: Manufacturer: Linux 7.0.0-38-generic ehci_hcd
2026-10-10T11:00:18,674102+00:00 usb usb3: SerialNumber: 0000:00:1a.7
2026-10-10T11:00:18,674178+00:00 hub 3-0:1.0: USB hub found
2026-10-10T11:00:18,674185+00:00 hub 3-0:1.0: 6 ports detected
2026-10-10T11:00:18,695371+00:00 hub 1-0:1.0: USB hub found
2026-10-10T11:00:18,695442+00:00 hub 1-0:1.0: 2 ports detected
2026-10-10T11:00:18,696222+00:00 uhci_hcd 0000:00:1a.1: UHCI Host Controller
2026-10-10T11:00:18,696231+00:00 uhci_hcd 0000:00:1a.1: new USB bus registered, assigned bus number 4
2026-10-10T11:00:18,696327+00:00 uhci_hcd 0000:00:1a.1: detected 2 ports
2026-10-10T11:00:18,696480+00:00 uhci_hcd 0000:00:1a.1: irq 17, io port 0x000080e0
2026-10-10T11:00:18,696609+00:00 usb usb4: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:18,696614+00:00 usb usb4: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,696617+00:00 usb usb4: Product: UHCI Host Controller
2026-10-10T11:00:18,696620+00:00 usb usb4: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:18,696622+00:00 usb usb4: SerialNumber: 0000:00:1a.1
2026-10-10T11:00:18,696702+00:00 hub 4-0:1.0: USB hub found
2026-10-10T11:00:18,696709+00:00 hub 4-0:1.0: 2 ports detected
2026-10-10T11:00:18,697800+00:00 uhci_hcd 0000:00:1a.2: UHCI Host Controller
2026-10-10T11:00:18,697811+00:00 uhci_hcd 0000:00:1a.2: new USB bus registered, assigned bus number 5
2026-10-10T11:00:18,697848+00:00 uhci_hcd 0000:00:1a.2: detected 2 ports
2026-10-10T11:00:18,698117+00:00 uhci_hcd 0000:00:1a.2: irq 18, io port 0x000080c0
2026-10-10T11:00:18,698266+00:00 usb usb5: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:18,698272+00:00 usb usb5: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,698275+00:00 usb usb5: Product: UHCI Host Controller
2026-10-10T11:00:18,698278+00:00 usb usb5: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:18,698280+00:00 usb usb5: SerialNumber: 0000:00:1a.2
2026-10-10T11:00:18,698362+00:00 hub 5-0:1.0: USB hub found
2026-10-10T11:00:18,698370+00:00 hub 5-0:1.0: 2 ports detected
2026-10-10T11:00:18,699365+00:00 uhci_hcd 0000:00:1d.0: UHCI Host Controller
2026-10-10T11:00:18,699375+00:00 uhci_hcd 0000:00:1d.0: new USB bus registered, assigned bus number 6
2026-10-10T11:00:18,699469+00:00 uhci_hcd 0000:00:1d.0: detected 2 ports
2026-10-10T11:00:18,699582+00:00 uhci_hcd 0000:00:1d.0: irq 16, io port 0x000080a0
2026-10-10T11:00:18,700123+00:00 usb usb6: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:18,700128+00:00 usb usb6: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,700131+00:00 usb usb6: Product: UHCI Host Controller
2026-10-10T11:00:18,700134+00:00 usb usb6: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:18,700136+00:00 usb usb6: SerialNumber: 0000:00:1d.0
2026-10-10T11:00:18,700216+00:00 hub 6-0:1.0: USB hub found
2026-10-10T11:00:18,700226+00:00 hub 6-0:1.0: 2 ports detected
2026-10-10T11:00:18,701275+00:00 uhci_hcd 0000:00:1d.1: UHCI Host Controller
2026-10-10T11:00:18,701285+00:00 uhci_hcd 0000:00:1d.1: new USB bus registered, assigned bus number 7
2026-10-10T11:00:18,701323+00:00 uhci_hcd 0000:00:1d.1: detected 2 ports
2026-10-10T11:00:18,701447+00:00 uhci_hcd 0000:00:1d.1: irq 17, io port 0x00008080
2026-10-10T11:00:18,701792+00:00 usb usb7: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:18,701798+00:00 usb usb7: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,701801+00:00 usb usb7: Product: UHCI Host Controller
2026-10-10T11:00:18,701803+00:00 usb usb7: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:18,701805+00:00 usb usb7: SerialNumber: 0000:00:1d.1
2026-10-10T11:00:18,701887+00:00 hub 7-0:1.0: USB hub found
2026-10-10T11:00:18,701894+00:00 hub 7-0:1.0: 2 ports detected
2026-10-10T11:00:18,702833+00:00 uhci_hcd 0000:00:1d.2: UHCI Host Controller
2026-10-10T11:00:18,702846+00:00 uhci_hcd 0000:00:1d.2: new USB bus registered, assigned bus number 8
2026-10-10T11:00:18,702874+00:00 uhci_hcd 0000:00:1d.2: detected 2 ports
2026-10-10T11:00:18,703016+00:00 uhci_hcd 0000:00:1d.2: irq 18, io port 0x00008060
2026-10-10T11:00:18,703373+00:00 usb usb8: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:18,703379+00:00 usb usb8: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:18,703382+00:00 usb usb8: Product: UHCI Host Controller
2026-10-10T11:00:18,703384+00:00 usb usb8: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:18,703387+00:00 usb usb8: SerialNumber: 0000:00:1d.2
2026-10-10T11:00:18,703468+00:00 hub 8-0:1.0: USB hub found
2026-10-10T11:00:18,703476+00:00 hub 8-0:1.0: 2 ports detected
2026-10-10T11:00:18,703695+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2026-10-10T11:00:18,704890+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2026-10-10T11:00:18,704900+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2026-10-10T11:00:18,705246+00:00 mousedev: PS/2 mouse device common for all mice
2026-10-10T11:00:18,705349+00:00 rtc_cmos 00:03: RTC can wake from S4
2026-10-10T11:00:18,706524+00:00 rtc_cmos 00:03: registered as rtc0
2026-10-10T11:00:18,706736+00:00 rtc_cmos 00:03: setting system clock to 2026-10-10T11:00:18 UTC (1791630018)
2026-10-10T11:00:18,706844+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram
2026-10-10T11:00:18,706859+00:00 i2c_dev: i2c /dev entries driver
2026-10-10T11:00:18,706879+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2026-10-10T11:00:18,706899+00:00 device-mapper: uevent: version 1.0.3
2026-10-10T11:00:18,706957+00:00 device-mapper: ioctl: 4.50.0-ioctl (2025-04-28) initialised: dm-devel@lists.linux.dev
2026-10-10T11:00:18,706964+00:00 intel_pstate: CPU model not supported
2026-10-10T11:00:18,707171+00:00 simple-framebuffer simple-framebuffer.0: [drm] Registered 1 planes with drm panic
2026-10-10T11:00:18,707842+00:00 [drm] Initialized simpledrm 1.0.0 for simple-framebuffer.0 on minor 0
2026-10-10T11:00:18,712032+00:00 Console: switching to colour frame buffer device 160x50
2026-10-10T11:00:18,713472+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2026-10-10T11:00:18,713873+00:00 simple-framebuffer simple-framebuffer.0: [drm] fb0: simpledrmdrmfb frame buffer device
2026-10-10T11:00:18,714173+00:00 drop_monitor: Initializing network drop monitor service
2026-10-10T11:00:18,714297+00:00 NET: Registered PF_INET6 protocol family
2026-10-10T11:00:18,715157+00:00 Segment Routing with IPv6
2026-10-10T11:00:18,715175+00:00 In-situ OAM (IOAM) with IPv6
2026-10-10T11:00:18,715196+00:00 NET: Registered PF_PACKET protocol family
2026-10-10T11:00:18,715261+00:00 Key type dns_resolver registered
2026-10-10T11:00:18,716165+00:00 IPI shorthand broadcast: enabled
2026-10-10T11:00:18,717668+00:00 sched_clock: Marking stable (883004195, 206733196)->(1424738476, -335001085)
2026-10-10T11:00:18,722212+00:00 registered taskstats version 1
2026-10-10T11:00:18,724423+00:00 Loading compiled-in X.509 certificates
2026-10-10T11:00:18,725470+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 6b2b0d62fc3a1216c49fda2b061b13d4dbf474bd'
2026-10-10T11:00:18,725997+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing 2025 Kmod: d541cef61dc7e793b7eb7e899970a2eef0b5dc8c'
2026-10-10T11:00:18,726479+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2026-10-10T11:00:18,726989+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing 2025 Kmod: 4627603d2357a2a3f81006370894c221175893e9'
2026-10-10T11:00:18,727463+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2026-10-10T11:00:18,727472+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2026-10-10T11:00:18,727490+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2026-10-10T11:00:18,727513+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2026-10-10T11:00:18,727531+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2026-10-10T11:00:18,727551+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2026-10-10T11:00:18,727568+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2026-10-10T11:00:18,727590+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2026-10-10T11:00:18,727609+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2026-10-10T11:00:18,727838+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2026-10-10T11:00:18,733146+00:00 Demotion targets for Node 0: null
2026-10-10T11:00:18,734198+00:00 Key type .fscrypt registered
2026-10-10T11:00:18,734411+00:00 Key type fscrypt-provisioning registered
2026-10-10T11:00:18,734679+00:00 Key type big_key registered
2026-10-10T11:00:18,798354+00:00 Key type encrypted registered
2026-10-10T11:00:18,798591+00:00 AppArmor: AppArmor sha256 policy hashing enabled
2026-10-10T11:00:18,798798+00:00 ima: No TPM chip found, activating TPM-bypass!
2026-10-10T11:00:18,799419+00:00 Loading compiled-in module X.509 certificates
2026-10-10T11:00:18,800581+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 6b2b0d62fc3a1216c49fda2b061b13d4dbf474bd'
2026-10-10T11:00:18,800804+00:00 ima: Allocated hash algorithm: sha256
2026-10-10T11:00:18,801450+00:00 ima: No architecture policies found
2026-10-10T11:00:18,801682+00:00 evm: Initialising EVM extended attributes:
2026-10-10T11:00:18,801883+00:00 evm: security.selinux
2026-10-10T11:00:18,802495+00:00 evm: security.SMACK64
2026-10-10T11:00:18,802700+00:00 evm: security.SMACK64EXEC
2026-10-10T11:00:18,802893+00:00 evm: security.SMACK64TRANSMUTE
2026-10-10T11:00:18,803498+00:00 evm: security.SMACK64MMAP
2026-10-10T11:00:18,803694+00:00 evm: security.apparmor
2026-10-10T11:00:18,803879+00:00 evm: security.ima
2026-10-10T11:00:18,804494+00:00 evm: security.capability
2026-10-10T11:00:18,804707+00:00 evm: HMAC attrs: 0x1
2026-10-10T11:00:18,806293+00:00 PM:   Magic number: 14:901:23
2026-10-10T11:00:18,806596+00:00 memory memory63: hash matches
2026-10-10T11:00:18,807487+00:00 RAS: Correctable Errors collector initialized.
2026-10-10T11:00:18,808461+00:00 clk: Disabling unused clocks
2026-10-10T11:00:18,808665+00:00 PM: genpd: Disabling unused power domains
2026-10-10T11:00:18,825450+00:00 Freeing unused decrypted memory: 2028K
2026-10-10T11:00:18,827505+00:00 Freeing unused kernel image (initmem) memory: 5304K
2026-10-10T11:00:18,827727+00:00 Write protecting the kernel read-only data: 43008k
2026-10-10T11:00:18,831364+00:00 Freeing unused kernel image (text/rodata gap) memory: 736K
2026-10-10T11:00:18,833022+00:00 Freeing unused kernel image (rodata/data gap) memory: 1656K
2026-10-10T11:00:18,869330+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2026-10-10T11:00:18,869553+00:00 Run /init as init process
2026-10-10T11:00:18,869736+00:00   with arguments:
2026-10-10T11:00:18,869738+00:00     /init
2026-10-10T11:00:18,869739+00:00   with environment:
2026-10-10T11:00:18,869740+00:00     HOME=/
2026-10-10T11:00:18,869741+00:00     TERM=linux
2026-10-10T11:00:18,889154+00:00 usb 2-1: new high-speed USB device number 2 using ehci-pci
2026-10-10T11:00:19,019162+00:00 usb 2-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2026-10-10T11:00:19,019396+00:00 usb 2-1: New USB device strings: Mfr=1, Product=3, SerialNumber=10
2026-10-10T11:00:19,019591+00:00 usb 2-1: Product: QEMU USB Tablet
2026-10-10T11:00:19,019780+00:00 usb 2-1: Manufacturer: QEMU
2026-10-10T11:00:19,019998+00:00 usb 2-1: SerialNumber: 28754-0000:00:1d.7-1
2026-10-10T11:00:19,209602+00:00 systemd[1]: Inserted module 'autofs4'
2026-10-10T11:00:19,244302+00:00 systemd[1]: Successfully made /usr/ read-only.
2026-10-10T11:00:19,579556+00:00 systemd[1]: systemd 259.5-0ubuntu3.4 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +IPE +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +KMOD +LIBCRYPTSETUP +LIBCRYPTSETUP_PLUGINS +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK +BTF -XKBCOMMON -UTMP +SYSVINIT +LIBARCHIVE)
2026-10-10T11:00:19,580233+00:00 systemd[1]: Detected virtualization kvm.
2026-10-10T11:00:19,580453+00:00 systemd[1]: Detected architecture x86-64.
2026-10-10T11:00:19,580659+00:00 systemd[1]: Running in initrd.
2026-10-10T11:00:19,587962+00:00 systemd[1]: Hostname set to <ubuntu-2604>.
2026-10-10T11:00:19,638832+00:00 systemd[1]: bpf-restrict-fs: BPF LSM hook not enabled in the kernel, BPF LSM not supported.
2026-10-10T11:00:19,716659+00:00 systemd[1]: Queued start job for default target initrd.target.
2026-10-10T11:00:19,722686+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2026-10-10T11:00:19,727001+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-41A1\x2dDD67.device - /dev/disk/by-uuid/41A1-DD67...
2026-10-10T11:00:19,730650+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-618f4c04\x2d0edd\x2d49b3\x2d8ad5\x2d00a29af1f556.device - /dev/disk/by-uuid/618f4c04-0edd-49b3-8ad5-00a29af1f556...
2026-10-10T11:00:19,734776+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-747687d9\x2dc20c\x2d41f8\x2dbfb8\x2d7f4a57910c51.device - /dev/disk/by-uuid/747687d9-c20c-41f8-bfb8-7f4a57910c51...
2026-10-10T11:00:19,739104+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2026-10-10T11:00:19,742859+00:00 systemd[1]: Reached target paths.target - Path Units.
2026-10-10T11:00:19,746003+00:00 systemd[1]: Reached target slices.target - Slice Units.
2026-10-10T11:00:19,749480+00:00 systemd[1]: Reached target swap.target - Swaps.
2026-10-10T11:00:19,753028+00:00 systemd[1]: Reached target timers.target - Timer Units.
2026-10-10T11:00:19,755554+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2026-10-10T11:00:19,759717+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Sockets.
2026-10-10T11:00:19,762972+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Management Netlink Socket.
2026-10-10T11:00:19,766678+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2026-10-10T11:00:19,769683+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2026-10-10T11:00:19,772454+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2026-10-10T11:00:19,775977+00:00 systemd[1]: Starting dracut-cmdline-ask.service - dracut ask for additional cmdline parameters...
2026-10-10T11:00:19,781011+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2026-10-10T11:00:19,784230+00:00 systemd[1]: systemd-battery-check.service - Early Battery Level Check skipped, unmet condition check ConditionDirectoryNotEmpty=/sys/class/power_supply
2026-10-10T11:00:19,790053+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2026-10-10T11:00:19,796036+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2026-10-10T11:00:19,800728+00:00 systemd[1]: Starting systemd-network-generator.service - Generate Network Units from Kernel Command Line...
2026-10-10T11:00:19,808555+00:00 systemd[1]: systemd-pcrphase-initrd.service - TPM PCR Barrier (initrd) skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:19,813477+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2026-10-10T11:00:19,817242+00:00 systemd[1]: Finished dracut-cmdline-ask.service - dracut ask for additional cmdline parameters.
2026-10-10T11:00:19,829234+00:00 systemd-journald[123]: Collecting audit messages is disabled.
2026-10-10T11:00:19,833586+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2026-10-10T11:00:19,840975+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully...
2026-10-10T11:00:19,849095+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2026-10-10T11:00:19,859704+00:00 systemd[1]: Finished systemd-network-generator.service - Generate Network Units from Kernel Command Line.
2026-10-10T11:00:19,868253+00:00 systemd[1]: Reached target network-pre.target - Preparation for Network.
2026-10-10T11:00:19,875313+00:00 systemd[1]: Listening on systemd-networkd-resolve-hook.socket - Network Management Resolve Hook Socket.
2026-10-10T11:00:19,883866+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2026-10-10T11:00:19,893149+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully.
2026-10-10T11:00:19,905841+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2026-10-10T11:00:19,924641+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2026-10-10T11:00:19,932519+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2026-10-10T11:00:19,937275+00:00 systemd[1]: Reached target local-fs-pre.target - Preparation for Local File Systems.
2026-10-10T11:00:19,944191+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2026-10-10T11:00:19,951823+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2026-10-10T11:00:20,368739+00:00 virtio_net virtio1 ens18: renamed from eth0
2026-10-10T11:00:20,526544+00:00 hid: raw HID events driver (C) Jiri Kosina
2026-10-10T11:00:20,530781+00:00 ahci 0000:00:1f.2: AHCI vers 0001.0000, 32 command slots, 1.5 Gbps, SATA mode
2026-10-10T11:00:20,530797+00:00 ahci 0000:00:1f.2: 6/6 ports implemented (port mask 0x3f)
2026-10-10T11:00:20,530805+00:00 ahci 0000:00:1f.2: flags: 64bit ncq only 
2026-10-10T11:00:20,533115+00:00 scsi host1: ahci
2026-10-10T11:00:20,546341+00:00 usbcore: registered new interface driver usbhid
2026-10-10T11:00:20,546351+00:00 usbhid: USB HID core driver
2026-10-10T11:00:20,568289+00:00 scsi host2: ahci
2026-10-10T11:00:20,569581+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2026-10-10T11:00:20,573329+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2026-10-10T11:00:20,596555+00:00 scsi host3: ahci
2026-10-10T11:00:20,596883+00:00 scsi host4: ahci
2026-10-10T11:00:20,597246+00:00 scsi host5: ahci
2026-10-10T11:00:20,597407+00:00 scsi host6: ahci
2026-10-10T11:00:20,597511+00:00 ata1: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244100 irq 38 lpm-pol 1
2026-10-10T11:00:20,597537+00:00 ata2: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244180 irq 38 lpm-pol 1
2026-10-10T11:00:20,597557+00:00 ata3: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244200 irq 38 lpm-pol 1
2026-10-10T11:00:20,597578+00:00 ata4: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244280 irq 38 lpm-pol 1
2026-10-10T11:00:20,597598+00:00 ata5: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244300 irq 38 lpm-pol 1
2026-10-10T11:00:20,597619+00:00 ata6: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244380 irq 38 lpm-pol 1
2026-10-10T11:00:20,654545+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:1d.7/usb2/2-1/2-1:1.0/0003:0627:0001.0001/input/input5
2026-10-10T11:00:20,660095+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:1d.7-1/input0
2026-10-10T11:00:20,906224+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:20,906607+00:00 ata1: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2026-10-10T11:00:20,906764+00:00 ata1.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2026-10-10T11:00:20,906780+00:00 ata1.00: applying bridge limits
2026-10-10T11:00:20,907096+00:00 ata4: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:20,907443+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:20,907786+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:20,908270+00:00 ata2: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2026-10-10T11:00:20,908435+00:00 ata1.00: configured for UDMA/100
2026-10-10T11:00:20,908674+00:00 ata2.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2026-10-10T11:00:20,908685+00:00 ata2.00: applying bridge limits
2026-10-10T11:00:20,908905+00:00 ata2.00: configured for UDMA/100
2026-10-10T11:00:20,909617+00:00 scsi 1:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:20,925578+00:00 sr 1:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2026-10-10T11:00:20,948166+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2026-10-10T11:00:20,963114+00:00 sr 1:0:0:0: Attached scsi CD-ROM sr0
2026-10-10T11:00:20,963291+00:00 sr 1:0:0:0: Attached scsi generic sg1 type 5
2026-10-10T11:00:20,964058+00:00 scsi 2:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:20,988307+00:00 sr 2:0:0:0: [sr1] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2026-10-10T11:00:21,026091+00:00 sr 2:0:0:0: Attached scsi CD-ROM sr1
2026-10-10T11:00:21,026669+00:00 sr 2:0:0:0: Attached scsi generic sg2 type 5
2026-10-10T11:00:21,320147+00:00 EXT4-fs (sda1): orphan cleanup on readonly fs
2026-10-10T11:00:21,320442+00:00 EXT4-fs (sda1): mounted filesystem 747687d9-c20c-41f8-bfb8-7f4a57910c51 ro with ordered data mode. Quota mode: none.
2026-10-10T11:00:21,584572+00:00 systemd-journald[123]: Received SIGTERM from PID 1 (systemd).
2026-10-10T11:00:22,315375+00:00 systemd[1]: systemd 259.5-0ubuntu3.4 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +IPE +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +KMOD +LIBCRYPTSETUP +LIBCRYPTSETUP_PLUGINS +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK +BTF -XKBCOMMON -UTMP +SYSVINIT +LIBARCHIVE)
2026-10-10T11:00:22,315394+00:00 systemd[1]: Detected virtualization kvm.
2026-10-10T11:00:22,315411+00:00 systemd[1]: Detected architecture x86-64.
2026-10-10T11:00:22,321800+00:00 systemd[1]: Hostname set to <workernode02>.
2026-10-10T11:00:22,383092+00:00 systemd[1]: bpf-restrict-fs: BPF LSM hook not enabled in the kernel, BPF LSM not supported.
2026-10-10T11:00:22,449307+00:00 Guest personality initialized and is inactive
2026-10-10T11:00:22,449407+00:00 VMCI host device registered (name=vmci, major=10, minor=262)
2026-10-10T11:00:22,449413+00:00 Initialized host personality
2026-10-10T11:00:22,452448+00:00 NET: Registered PF_VSOCK protocol family
2026-10-10T11:00:22,703454+00:00 systemd[1]: /usr/lib/systemd/system/xfs_scrub_all.service:26: Support for option CPUAccounting= has been removed and it is ignored
2026-10-10T11:00:22,704179+00:00 systemd[1]: /usr/lib/systemd/system/system-xfs_scrub.slice:15: Support for option CPUAccounting= has been removed and it is ignored
2026-10-10T11:00:22,817619+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2026-10-10T11:00:22,817829+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2026-10-10T11:00:22,820975+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2026-10-10T11:00:22,821783+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2026-10-10T11:00:22,824776+00:00 systemd[1]: Created slice system-systemd\x2dfsck.slice - Slice /system/systemd-fsck.
2026-10-10T11:00:22,828299+00:00 systemd[1]: Created slice system-xfs_scrub.slice - xfs_scrub background service slice.
2026-10-10T11:00:22,830640+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2026-10-10T11:00:22,832152+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2026-10-10T11:00:22,835066+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2026-10-10T11:00:22,837193+00:00 systemd[1]: Expecting device dev-disk-by\x2dlabel-BOOT.device - /dev/disk/by-label/BOOT...
2026-10-10T11:00:22,839033+00:00 systemd[1]: Expecting device dev-disk-by\x2dlabel-UEFI.device - /dev/disk/by-label/UEFI...
2026-10-10T11:00:22,840733+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2026-10-10T11:00:22,842202+00:00 systemd[1]: Reached target imports.target - Image Downloads.
2026-10-10T11:00:22,843639+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2026-10-10T11:00:22,845240+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2026-10-10T11:00:22,847762+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2026-10-10T11:00:22,849610+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2026-10-10T11:00:22,851741+00:00 systemd[1]: Reached target slices.target - Slice Units.
2026-10-10T11:00:22,853222+00:00 systemd[1]: Reached target snapd.mounts-pre.target - Mounting snaps.
2026-10-10T11:00:22,854735+00:00 systemd[1]: Reached target snapd.mounts.target - Mounted snaps.
2026-10-10T11:00:22,856293+00:00 systemd[1]: Reached target swap.target - Swaps.
2026-10-10T11:00:22,857510+00:00 systemd[1]: Reached target time-set.target - System Time Set.
2026-10-10T11:00:22,859215+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2026-10-10T11:00:22,861594+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2026-10-10T11:00:22,863383+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2026-10-10T11:00:22,875008+00:00 systemd[1]: Listening on rpcbind.socket - RPCbind Server Activation Socket.
2026-10-10T11:00:22,876897+00:00 systemd[1]: Listening on syslog.socket - Syslog Socket.
2026-10-10T11:00:22,879806+00:00 systemd[1]: Listening on systemd-ask-password.socket - Query the User Interactively for a Password.
2026-10-10T11:00:22,883145+00:00 systemd[1]: Listening on systemd-creds.socket - Credential Encryption/Decryption.
2026-10-10T11:00:22,886592+00:00 systemd[1]: Listening on systemd-factory-reset.socket - Factory Reset Management.
2026-10-10T11:00:22,890133+00:00 systemd[1]: Listening on systemd-mute-console.socket - Console Output Muting Service Socket.
2026-10-10T11:00:22,892253+00:00 systemd[1]: Listening on systemd-networkd-varlink.socket - Network Management Varlink Socket.
2026-10-10T11:00:22,894170+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Management Netlink Socket.
2026-10-10T11:00:22,895972+00:00 systemd[1]: systemd-pcrextend.socket - TPM PCR Measurements skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:22,896008+00:00 systemd[1]: systemd-pcrlock.socket - Make TPM PCR Policy skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:22,896147+00:00 systemd[1]: Listening on systemd-resolved-monitor.socket - Resolve Monitor Varlink Socket.
2026-10-10T11:00:22,898137+00:00 systemd[1]: Listening on systemd-resolved-varlink.socket - Resolve Service Varlink Socket.
2026-10-10T11:00:22,900027+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2026-10-10T11:00:22,901943+00:00 systemd[1]: Listening on systemd-udevd-varlink.socket - udev Varlink Socket.
2026-10-10T11:00:22,905328+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2026-10-10T11:00:22,910134+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2026-10-10T11:00:22,914031+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2026-10-10T11:00:22,918536+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2026-10-10T11:00:22,923615+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2026-10-10T11:00:22,930138+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2026-10-10T11:00:22,931705+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS skipped, unmet condition check ConditionPathExists=/etc/krb5.keytab
2026-10-10T11:00:22,935757+00:00 systemd[1]: Starting keyboard-setup.service - Set the console keyboard layout...
2026-10-10T11:00:22,946644+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2026-10-10T11:00:22,950233+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2026-10-10T11:00:22,952027+00:00 systemd[1]: modprobe@configfs.service - Load Kernel Module configfs skipped, unmet condition check ConditionKernelModuleLoaded=!configfs
2026-10-10T11:00:22,955100+00:00 systemd[1]: Starting modprobe@dm_multipath.service - Load Kernel Module dm_multipath...
2026-10-10T11:00:22,957335+00:00 systemd[1]: modprobe@drm.service - Load Kernel Module drm skipped, unmet condition check ConditionKernelModuleLoaded=!drm
2026-10-10T11:00:22,960793+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2026-10-10T11:00:22,962536+00:00 systemd[1]: modprobe@fuse.service - Load Kernel Module fuse skipped, unmet condition check ConditionKernelModuleLoaded=!fuse
2026-10-10T11:00:22,965811+00:00 systemd[1]: Mounting sys-fs-fuse-connections.mount - FUSE Control File System...
2026-10-10T11:00:22,967708+00:00 systemd[1]: netplan-ovs-cleanup.service - OpenVSwitch configuration for cleanup skipped, unmet condition check ConditionFileIsExecutable=/usr/bin/ovs-vsctl
2026-10-10T11:00:22,967995+00:00 systemd[1]: systemd-hibernate-clear.service - Clear Stale Hibernate Storage Info skipped, unmet condition check ConditionPathExists=/sys/firmware/efi/efivars/HibernateLocation-8cf2644b-4b0b-428f-9387-6d876050dc67
2026-10-10T11:00:22,974104+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2026-10-10T11:00:22,976312+00:00 systemd[1]: systemd-pcrmachine.service - TPM PCR Machine ID Measurement skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:22,976405+00:00 systemd[1]: systemd-pcrproduct.service - TPM NvPCR Product ID Measurement skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:22,983808+00:00 systemd[1]: Starting systemd-remount-fs.service - Remount Root and Kernel File Systems...
2026-10-10T11:00:22,988038+00:00 systemd[1]: systemd-tpm2-setup-early.service - Early TPM SRK Setup skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:22,994035+00:00 systemd[1]: Starting systemd-udev-load-credentials.service - Load udev Rules from Credentials...
2026-10-10T11:00:23,000031+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2026-10-10T11:00:23,005494+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2026-10-10T11:00:23,007766+00:00 pstore: Using crash dump compression: deflate
2026-10-10T11:00:23,007863+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2026-10-10T11:00:23,010590+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2026-10-10T11:00:23,013208+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2026-10-10T11:00:23,017414+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2026-10-10T11:00:23,020310+00:00 systemd[1]: Mounted sys-fs-fuse-connections.mount - FUSE Control File System.
2026-10-10T11:00:23,023771+00:00 systemd[1]: modprobe@dm_multipath.service: Deactivated successfully.
2026-10-10T11:00:23,024068+00:00 systemd[1]: Finished modprobe@dm_multipath.service - Load Kernel Module dm_multipath.
2026-10-10T11:00:23,032435+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2026-10-10T11:00:23,034957+00:00 pstore: Registered efi_pstore as persistent store backend
2026-10-10T11:00:23,036479+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2026-10-10T11:00:23,039775+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2026-10-10T11:00:23,047116+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully...
2026-10-10T11:00:23,070629+00:00 systemd-journald[490]: Collecting audit messages is disabled.
2026-10-10T11:00:23,078887+00:00 systemd[1]: Finished systemd-udev-load-credentials.service - Load udev Rules from Credentials.
2026-10-10T11:00:23,087165+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2026-10-10T11:00:23,091310+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2026-10-10T11:00:23,098016+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2026-10-10T11:00:23,102962+00:00 EXT4-fs (sda1): re-mounted 747687d9-c20c-41f8-bfb8-7f4a57910c51 r/w.
2026-10-10T11:00:23,202110+00:00 systemd-journald[490]: Received client request to flush runtime journal.
2026-10-10T11:00:24,353957+00:00 Console: switching to colour dummy device 80x25
2026-10-10T11:00:24,354629+00:00 bochs-drm 0000:00:01.0: vgaarb: deactivate vga console
2026-10-10T11:00:24,354773+00:00 [drm] Found bochs VGA, ID 0xb0c5.
2026-10-10T11:00:24,354780+00:00 [drm] Framebuffer size 16384 kB @ 0x80000000, mmio @ 0x8224b000.
2026-10-10T11:00:24,355334+00:00 bochs-drm 0000:00:01.0: [drm] Registered 1 planes with drm panic
2026-10-10T11:00:24,361038+00:00 [drm] Initialized bochs-drm 1.0.0 for 0000:00:01.0 on minor 0
2026-10-10T11:00:24,416117+00:00 fbcon: bochs-drmdrmfb (fb0) is primary device
2026-10-10T11:00:24,452139+00:00 Console: switching to colour frame buffer device 160x50
2026-10-10T11:00:24,460646+00:00 bochs-drm 0000:00:01.0: [drm] fb0: bochs-drmdrmfb frame buffer device
2026-10-10T11:00:24,531342+00:00 EXT4-fs (sda13): mounted filesystem 618f4c04-0edd-49b3-8ad5-00a29af1f556 r/w with ordered data mode. Quota mode: none.
2026-10-10T11:00:24,585517+00:00 snd_hda_intel 0000:00:1b.0: no codecs found!
2026-10-10T11:00:24,597993+00:00 lpc_ich 0000:00:1f.0: I/O space for GPIO uninitialized
2026-10-10T11:00:24,659263+00:00 i801_smbus 0000:00:1f.3: Enabling SMBus device
2026-10-10T11:00:24,659315+00:00 i801_smbus 0000:00:1f.3: SMBus using PCI interrupt
2026-10-10T11:00:24,664978+00:00 RAPL PMU: API unit is 2^-32 Joules, 0 fixed counters, 10737418240 ms ovfl timer
2026-10-10T11:00:24,677669+00:00 i2c i2c-0: Memory type 0x07 not supported yet, not instantiating SPD
2026-10-10T11:00:24,911772+00:00 intel_rapl_msr: PL4 support detected.
2026-10-10T11:00:25,058000+00:00 audit: type=1400 audit(1791630024.851:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Discord" pid=715 comm="apparmor_parser"
2026-10-10T11:00:25,058199+00:00 audit: type=1400 audit(1791630024.851:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="1password" pid=714 comm="apparmor_parser"
2026-10-10T11:00:25,061498+00:00 audit: type=1400 audit(1791630024.854:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name=4D6F6E676F444220436F6D70617373 pid=717 comm="apparmor_parser"
2026-10-10T11:00:25,063902+00:00 audit: type=1400 audit(1791630024.856:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="QtWebEngineProcess" pid=719 comm="apparmor_parser"
2026-10-10T11:00:25,073162+00:00 audit: type=1400 audit(1791630024.866:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="alsamixer" pid=722 comm="apparmor_parser"
2026-10-10T11:00:25,078919+00:00 audit: type=1400 audit(1791630024.871:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="babeld" pid=726 comm="apparmor_parser"
2026-10-10T11:00:25,087945+00:00 audit: type=1400 audit(1791630024.878:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="balena-etcher" pid=727 comm="apparmor_parser"
2026-10-10T11:00:25,087955+00:00 audit: type=1400 audit(1791630024.878:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Xorg" pid=721 comm="apparmor_parser"
2026-10-10T11:00:25,087963+00:00 audit: type=1400 audit(1791630024.878:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Xorg_wrap" pid=721 comm="apparmor_parser"
2026-10-10T11:00:25,095580+00:00 audit: type=1400 audit(1791630024.883:11): apparmor="STATUS" operation="profile_load" profile="unconfined" name="bfdd" pid=729 comm="apparmor_parser"
2026-10-10T11:00:25,145552+00:00 RPC: Registered named UNIX socket transport module.
2026-10-10T11:00:25,145561+00:00 RPC: Registered udp transport module.
2026-10-10T11:00:25,145562+00:00 RPC: Registered tcp transport module.
2026-10-10T11:00:25,145563+00:00 RPC: Registered tcp-with-tls transport module.
2026-10-10T11:00:25,145572+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2026-10-10T11:00:25,560906+00:00 ISO 9660 Extensions: Microsoft Joliet Level 3
2026-10-10T11:00:25,561480+00:00 ISO 9660 Extensions: RRIP_1991A
2026-10-10T11:00:25,717720+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2026-10-10T11:00:25,718032+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2026-10-10T11:00:25,718200+00:00 Loaded X.509 cert 'wens: 61c038651aabdcf94bd0ac7ff06c7248db18c600'
2026-10-10T11:00:26,447782+00:00 NET: Registered PF_QIPCRTR protocol family
2026-10-10T11:00:26,704448+00:00 loop0: detected capacity change from 0 to 8
2026-10-10T11:00:28,874987+00:00 Loading iSCSI transport class v2.0-870.
2026-10-10T11:00:49,398532+00:00 kauditd_printk_skb: 174 callbacks suppressed
2026-10-10T11:00:49,398551+00:00 audit: type=1400 audit(1791630049.384:186): apparmor="STATUS" operation="profile_load" profile="unconfined" name="cri-containerd.apparmor.d" pid=1524 comm="apparmor_parser"
2026-10-10T11:00:57,663096+00:00 evm: overlay not supported
2026-10-10T11:00:57,876971+00:00 Initializing XFRM netlink socket
2026-10-10T11:01:02,016250+00:00 eth0: renamed from tmp56534
2026-10-10T11:01:02,102479+00:00 eth0: renamed from tmp035dd
2026-10-10T11:01:02,148324+00:00 eth0: renamed from tmpb7179
2026-10-10T11:45:15,145490+00:00 clocksource: Long readout interval, skipping watchdog check: cs_nsec: 2616180503 wd_nsec: 496027799
