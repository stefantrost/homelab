CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
376      cgroup_inet_sock_release multi           cil_sock_release                
373      cgroup_inet4_post_bind multi           cil_sock4_post_bind                
372      cgroup_inet6_post_bind multi           cil_sock6_post_bind                
379      cgroup_inet4_connect multi           cil_sock4_connect                
382      cgroup_inet6_connect multi           cil_sock6_connect                
377      cgroup_inet4_getpeername multi           cil_sock4_getpeername                
375      cgroup_inet6_getpeername multi           cil_sock6_getpeername                
380      cgroup_udp4_sendmsg multi           cil_sock4_sendmsg                
378      cgroup_udp6_sendmsg multi           cil_sock6_sendmsg                
374      cgroup_udp4_recvmsg multi           cil_sock4_recvmsg                
381      cgroup_udp6_recvmsg multi           cil_sock6_recvmsg                
55       cgroup_sysctl   multi           sysctl_monitor                 
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    49       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    48       cgroup_inet_ingress multi           sd_fw_ingress                  
    47       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/polkit.service
    58       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    45       cgroup_inet_ingress multi           sd_fw_ingress                  
    44       cgroup_inet_egress multi           sd_fw_egress                   
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/fwupd.service
    485      cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chrony.service
    57       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    61       cgroup_inet_ingress multi           sd_fw_ingress                  
    60       cgroup_inet_egress multi           sd_fw_egress                   
    59       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67580aa4_c28a_47f4_b86e_f28e86ff7e7b.slice/cri-containerd-b8366a44f5247c919f1b0184291780453919693a0ee06a32f682233f67df8e37.scope
    136      cgroup_device   multi           sd_devices                     
    140      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67580aa4_c28a_47f4_b86e_f28e86ff7e7b.slice/cri-containerd-e6db8a07df576a1bf4ac7d125bf5181d0c3060e2e871240c4f7cbc5cdc409b2a.scope
    75       cgroup_device   multi           sd_devices                     
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31830aeb_7b60_4688_bff3_ee77ca2d3f3a.slice/cri-containerd-b4f5e7222e07ff6bde4f5929dafb6abf4348221441d0fc460fbdd54e845da6ad.scope
    342      cgroup_device   multi           sd_devices                     
    346      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31830aeb_7b60_4688_bff3_ee77ca2d3f3a.slice/cri-containerd-b71797b2c79bd3f43dd1c2e3d85fcd3332fb6fc5d519ed837fbae109a3a14def.scope
    304      cgroup_device   multi           sd_devices                     
    308      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode90d583e_ced8_4b21_af47_2068d9b9bd7e.slice/cri-containerd-f26b8675498746b3cac5b774c1b3f27173f9b05aa1cc60f9f4451d0cf5433522.scope
    90       cgroup_device   multi           sd_devices                     
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode90d583e_ced8_4b21_af47_2068d9b9bd7e.slice/cri-containerd-f7b27ac2c52c56dd4ecb78a8a9371f48d7ff2324e6b6f80c1a3a65a007a91641.scope
    112      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode90d583e_ced8_4b21_af47_2068d9b9bd7e.slice/cri-containerd-6480541cf1e71e5d36c550c015944d003b9fb49d6ca16875a30a1ff19f66e446.scope
    65       cgroup_device   multi           sd_devices                     
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode90d583e_ced8_4b21_af47_2068d9b9bd7e.slice/cri-containerd-9ffb94c764c0f3029f25932ecff50575b2d6c7e7efaa107be43d59f4fe981362.scope
    105      cgroup_device   multi           sd_devices                     
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf26fb350_abcb_4bb2_8fb5_b0faa0070778.slice/cri-containerd-aac9369a1e8cade98f299735d5394354a705a3348beb45a4bd2a69644a08bbc3.scope
    100      cgroup_device   multi           sd_devices                     
    104      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf26fb350_abcb_4bb2_8fb5_b0faa0070778.slice/cri-containerd-36438aba0c63b5e9dbeed809d8c9807b534ec8e78d9381e44d855a900bbe0262.scope
    70       cgroup_device   multi           sd_devices                     
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0da351c_3c98_4f8b_9399_2d469b80f02e.slice/cri-containerd-565349be29079020cb906a880e8f4142c2a62efd67fd715c29fea2c7cf913dfb.scope
    278      cgroup_device   multi           sd_devices                     
    282      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0da351c_3c98_4f8b_9399_2d469b80f02e.slice/cri-containerd-80f1ad8d4caa1391f8f94478d2979751248966640f9a9eb12d2f24f05962a6a2.scope
    362      cgroup_device   multi           sd_devices                     
    366      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10a825c3_cf3b_4b1b_9b29_ad72a65d9533.slice/cri-containerd-5f57af3b7b10328d7bb984a362aa2a83659156b753ff8499611dc9b3d69aee7c.scope
    350      cgroup_device   multi           sd_devices                     
    354      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10a825c3_cf3b_4b1b_9b29_ad72a65d9533.slice/cri-containerd-035dd9220c5da0e3ea2ebd6e57a8ac42b7d2089aeef1e199d7b2179fe19fa006.scope
    332      cgroup_device   multi           sd_devices                     
    336      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10a825c3_cf3b_4b1b_9b29_ad72a65d9533.slice/cri-containerd-3e96ba554058d73f650a98b72dd62e5f6c58be98308f088f1546c6deb7125c7c.scope
    367      cgroup_device   multi           sd_devices                     
    371      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd96c096a_7e2d_4b72_afea_26068c1e9f00.slice/cri-containerd-8d42a76fc258479dd8987a1ff06d5c9cc4c04de78656b16c3bde087e2ba1211a.scope
    80       cgroup_device   multi           sd_devices                     
    84       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd96c096a_7e2d_4b72_afea_26068c1e9f00.slice/cri-containerd-f2628858d8b9ca62ae6befb89b6ed8c7b24b827edc8ebcf5dcafb59881e050d7.scope
    95       cgroup_device   multi           sd_devices                     
    99       cgroup_device   multi                                          
