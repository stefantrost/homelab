Endpoint ID: 172
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_00172

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    2147286   23665     0        0
Allow    Ingress     11         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -         -         0        0
Allow    Egress      0          ANY          NONE         disabled    48136     681       0        0
Allow    Egress      11         ANY          NONE         disabled    349       3         0        0
Allow    Egress      12         ANY          NONE         disabled    -         -         0        0
Allow    Egress      13         ANY          NONE         disabled    -         -         0        0
Allow    Egress      14         ANY          NONE         disabled    -         -         0        0


Endpoint ID: 461
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_00461

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        0
Allow    Ingress     11         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -       -         0        0
Allow    Egress      0          ANY          NONE         disabled    -       -         0        0
Allow    Egress      11         ANY          NONE         disabled    -       -         0        0
Allow    Egress      12         ANY          NONE         disabled    -       -         0        0
Allow    Egress      13         ANY          NONE         disabled    -       -         0        0
Allow    Egress      14         ANY          NONE         disabled    -       -         0        0


Endpoint ID: 462
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_00462

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    1056289   12441     0        0
Allow    Ingress     11         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -         -         0        0
Allow    Egress      0          ANY          NONE         disabled    -         -         0        0
Allow    Egress      11         ANY          NONE         disabled    -         -         0        0
Allow    Egress      12         ANY          NONE         disabled    -         -         0        0
Allow    Egress      13         ANY          NONE         disabled    -         -         0        0
Allow    Egress      14         ANY          NONE         disabled    -         -         0        0


Endpoint ID: 1075
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_01075

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    190470   2342      0        0
Allow    Ingress     11         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    -        -         0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0


Endpoint ID: 1508
Path: /sys/fs/bpf/tc/globals/cilium_policy_v3_01508

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    990535   11393     0        0
Allow    Ingress     11         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    96732    1061      0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0


