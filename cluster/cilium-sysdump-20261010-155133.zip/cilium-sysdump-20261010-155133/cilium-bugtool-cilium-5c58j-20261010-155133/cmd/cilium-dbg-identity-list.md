ID      LABELS
1       reserved:host
2       reserved:world
3       reserved:unmanaged
4       reserved:health
5       reserved:init
6       reserved:remote-node
7       reserved:kube-apiserver
        reserved:remote-node
8       reserved:ingress
9       reserved:world-ipv4
10      reserved:world-ipv6
11      reserved:aggregate-cluster
12      reserved:aggregate-cluster-mesh
13      reserved:aggregate-world
14      reserved:aggregate-remote-node
10824   gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081
        k8s:app.kubernetes.io/name=hubble-ui
        k8s:app.kubernetes.io/part-of=cilium
        k8s:helm.sh/chart=cilium-1.20.2
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-ui
19386   k8s:batch.kubernetes.io/job-name=hubble-generate-certs-687da7eec1
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-generate-certs
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:job-name=hubble-generate-certs-687da7eec1
        k8s:k8s-app=hubble-generate-certs
25785   gen:io.cilium.k8s.named-ports=grpc.TCP.4245
        k8s:app.kubernetes.io/name=hubble-relay
        k8s:app.kubernetes.io/part-of=cilium
        k8s:helm.sh/chart=cilium-1.20.2
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-relay
41104   gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181
        gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=coredns
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns
