{
  "local": {
    "name": "workernode02"
  },
  "nodes": [
    {
      "endpoint": {
        "http": {
          "lastProbed": "2026-10-10T13:51:51Z",
          "status": "Get \"http://10.244.0.27:4240/hello\": context deadline exceeded (Client.Timeout exceeded while awaiting headers)"
        },
        "icmp": {
          "lastProbed": "2026-10-10T13:51:51Z",
          "status": "Connection timed out"
        },
        "ip": "10.244.0.27"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:51:51Z",
            "status": "Get \"http://10.244.0.27:4240/hello\": context deadline exceeded (Client.Timeout exceeded while awaiting headers)"
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:51:51Z",
            "status": "Connection timed out"
          },
          "ip": "10.244.0.27"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:52:01Z",
            "status": "Get \"http://192.168.178.113:4240/hello\": dial tcp 192.168.178.113:4240: connect: connection refused"
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:52:01Z",
            "latency": 272325
          },
          "ip": "192.168.178.113"
        },
        "secondary-addresses": []
      },
      "name": "controlplane"
    },
    {
      "endpoint": {
        "http": {
          "lastProbed": "2026-10-10T13:50:43Z",
          "latency": 377281
        },
        "icmp": {
          "lastProbed": "2026-10-10T13:50:43Z",
          "latency": 120415
        },
        "ip": "10.244.2.84"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:50:43Z",
            "latency": 377281
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:50:43Z",
            "latency": 120415
          },
          "ip": "10.244.2.84"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:50:23Z",
            "latency": 170794
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:50:23Z",
            "latency": 168011
          },
          "ip": "192.168.178.115"
        },
        "secondary-addresses": []
      },
      "name": "workernode02"
    },
    {
      "endpoint": {
        "http": {
          "lastProbed": "2026-10-10T13:51:22Z",
          "latency": 906038
        },
        "icmp": {
          "lastProbed": "2026-10-10T13:51:22Z",
          "latency": 355587
        },
        "ip": "10.244.1.197"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:51:22Z",
            "latency": 906038
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:51:22Z",
            "latency": 355587
          },
          "ip": "10.244.1.197"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "lastProbed": "2026-10-10T13:51:02Z",
            "latency": 510862
          },
          "icmp": {
            "lastProbed": "2026-10-10T13:51:02Z",
            "latency": 308845
          },
          "ip": "192.168.178.114"
        },
        "secondary-addresses": []
      },
      "name": "workernode01"
    }
  ],
  "probeInterval": "1m56.754608943s",
  "timestamp": "2026-10-10T13:50:23Z"
}

