Total: 353
TCP:   168 (estab 26, closed 118, orphaned 0, timewait 103)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  11        7         4        
TCP	  50        36        14       
INET	  63        44        19       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                     Local Address:Port  Peer Address:PortProcess                                                                                     
UNCONN 0      0                              127.0.0.1:38809      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=54)) ino:18171 sk:104c fwmark:0xb00 cgroup:/ <->           
UNCONN 0      0                             127.0.0.54:53         0.0.0.0:*                                         uid:989 ino:7545 sk:2 cgroup:unreachable:c24 <->      
UNCONN 0      0                          127.0.0.53%lo:53         0.0.0.0:*                                         uid:989 ino:7543 sk:3 cgroup:unreachable:c24 <->      
UNCONN 0      0                  192.168.178.115%ens18:68         0.0.0.0:*                                         uid:998 ino:15419 sk:4 cgroup:unreachable:10eb <->    
UNCONN 0      0                                0.0.0.0:111        0.0.0.0:*                                         ino:7184 sk:5 cgroup:unreachable:678 <->              
UNCONN 0      0                                0.0.0.0:8472       0.0.0.0:*                                         ino:18386 sk:104a cgroup:/ <->                        
UNCONN 0      0                              127.0.0.1:323        0.0.0.0:*                                         ino:14628 sk:6 cgroup:unreachable:125f <->            
UNCONN 0      0                                   [::]:111           [::]:*                                         ino:7186 sk:1049 cgroup:unreachable:678 v6only:1 <->  
UNCONN 0      0                                   [::]:8472          [::]:*                                         ino:18385 sk:104b cgroup:/ v6only:1 <->               
UNCONN 0      0                                  [::1]:323           [::]:*                                         ino:14629 sk:104d cgroup:unreachable:125f v6only:1 <->
UNCONN 0      0      [fe80::be24:11ff:fe3c:bfbe]%ens18:546           [::]:*                                         uid:998 ino:14974 sk:104e cgroup:unreachable:10eb v6only:1 <->
