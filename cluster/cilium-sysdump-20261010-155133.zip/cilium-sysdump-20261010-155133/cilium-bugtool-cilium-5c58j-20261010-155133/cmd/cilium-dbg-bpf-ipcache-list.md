IP PREFIX/ADDRESS    IDENTITY
10.244.1.173/32      identity=6 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel       
10.244.1.197/32      identity=4 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel       
192.168.178.113/32   identity=7 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  
0.0.0.0/0            identity=2 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  
10.244.0.27/32       identity=4 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       
10.244.1.214/32      identity=41104 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel   
10.244.2.154/32      identity=25785 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              
10.244.2.226/32      identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  
10.244.0.0/24        identity=2 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       
10.244.1.0/24        identity=2 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel       
10.244.2.11/32       identity=41104 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              
10.244.0.172/32      identity=6 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       
10.244.2.31/32       identity=10824 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              
10.244.2.84/32       identity=4 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  
192.168.178.114/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  
192.168.178.115/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  
