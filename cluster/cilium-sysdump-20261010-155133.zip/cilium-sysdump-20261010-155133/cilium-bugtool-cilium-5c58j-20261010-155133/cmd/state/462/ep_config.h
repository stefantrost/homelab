/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: 035dd9220c5da0e3ea2ebd6e57a8ac42b7d2089aeef1e199d7b2179fe19fa006
 * Container Interface: eth0
 * IPv4 address: 10.244.2.31
 * Identity: 10824
 * PolicyMap: cilium_policy_v3_00462
 * NodeMAC: 7a:49:c7:96:28:f5
 */

/*
 * Labels:
 * - k8s:io.cilium.k8s.policy.cluster=default
 * - k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
 * - k8s:helm.sh/chart=cilium-1.20.2
 * - k8s:app.kubernetes.io/name=hubble-ui
 * - k8s:k8s-app=hubble-ui
 * - gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081
 * - k8s:app.kubernetes.io/part-of=cilium
 * - k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
 * - k8s:io.kubernetes.pod.namespace=kube-system
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
