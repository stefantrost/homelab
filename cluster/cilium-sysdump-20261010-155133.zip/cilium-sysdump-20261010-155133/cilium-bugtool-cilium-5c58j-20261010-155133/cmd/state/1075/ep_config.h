/*
 * This file is not using during compilation of endpoint programs.
 * IPv4 address: 10.244.2.84
 * Identity: 4
 * PolicyMap: cilium_policy_v3_01075
 * NodeMAC: 0a:ef:0c:52:c3:e1
 */

/*
 * Labels:
 * - reserved:health
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
