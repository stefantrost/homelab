/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: 565349be29079020cb906a880e8f4142c2a62efd67fd715c29fea2c7cf913dfb
 * Container Interface: eth0
 * IPv4 address: 10.244.2.154
 * Identity: 25785
 * PolicyMap: cilium_policy_v3_00172
 * NodeMAC: 02:f1:64:7b:a2:b6
 */

/*
 * Labels:
 * - k8s:k8s-app=hubble-relay
 * - k8s:app.kubernetes.io/part-of=cilium
 * - k8s:app.kubernetes.io/name=hubble-relay
 * - k8s:helm.sh/chart=cilium-1.20.2
 * - k8s:io.kubernetes.pod.namespace=kube-system
 * - k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
 * - k8s:io.cilium.k8s.policy.cluster=default
 * - gen:io.cilium.k8s.named-ports=grpc.TCP.4245
 * - k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
