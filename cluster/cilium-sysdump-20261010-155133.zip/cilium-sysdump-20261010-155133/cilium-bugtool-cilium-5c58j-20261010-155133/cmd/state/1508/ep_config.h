/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: b71797b2c79bd3f43dd1c2e3d85fcd3332fb6fc5d519ed837fbae109a3a14def
 * Container Interface: eth0
 * IPv4 address: 10.244.2.11
 * Identity: 41104
 * PolicyMap: cilium_policy_v3_01508
 * NodeMAC: 1a:56:8b:c4:ad:7f
 */

/*
 * Labels:
 * - gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080
 * - gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181
 * - k8s:io.cilium.k8s.policy.serviceaccount=coredns
 * - k8s:io.cilium.k8s.policy.cluster=default
 * - k8s:k8s-app=kube-dns
 * - k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
 * - k8s:io.kubernetes.pod.namespace=kube-system
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#define MONITOR_AGGREGATION 3
#undef POLICY_AUDIT_MODE
#define POLICY_VERDICT_NOTIFY 1
#define ENABLE_SIP_VERIFICATION 1
#define TRACE_NOTIFY 1
