search fritz.box
nameserver 192.168.178.1
nameserver fda7:7b49:a70a:0:36e1:a9ff:fe62:6be6
nameserver 2a02:8071:5301:a0a0:36e1:a9ff:fe62:6be6
