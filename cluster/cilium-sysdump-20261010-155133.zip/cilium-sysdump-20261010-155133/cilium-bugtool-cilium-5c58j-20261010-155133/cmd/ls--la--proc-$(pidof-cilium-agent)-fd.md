total 0
dr-x------ 2 root root 103 Oct 10 11:00 .
dr-xr-xr-x 9 root root   0 Oct 10 11:00 ..
lrwx------ 1 root root  64 Oct 10 13:52 0 -> /dev/null
l-wx------ 1 root root  64 Oct 10 13:52 1 -> pipe:[17968]
lrwx------+1 root root  64 Oct 10 13:52 10 -> socket:[18089]
lrwx------ 1 root root  64 Oct 10 11:01 109 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 11 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 115 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 116 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 11:01 118 -> socket:[21277]
lrwx------+1 root root  64 Oct 10 13:52 12 -> socket:[18091]
lrwx------+1 root root  64 Oct 10 13:52 129 -> socket:[20305]
lr-x------ 1 root root  64 Oct 10 13:52 13 -> net:[4026531833]
lrwx------ 1 root root  64 Oct 10 13:52 14 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 15 -> socket:[18092]
lrwx------ 1 root root  64 Oct 10 13:52 16 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 17 -> socket:[18121]
lrwx------+1 root root  64 Oct 10 13:52 18 -> socket:[18122]
lrwx------+1 root root  64 Oct 10 13:52 19 -> socket:[18123]
l-wx------ 1 root root  64 Oct 10 13:52 2 -> pipe:[17969]
l-wx------ 1 root root  64 Oct 10 13:52 20 -> /run/cilium/state/route-reconciler.wal
lrwx------+1 root root  64 Oct 10 13:52 21 -> socket:[18570]
lrwx------ 1 root root  64 Oct 10 13:52 22 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 23 -> socket:[18572]
lrwx------ 1 root root  64 Oct 10 13:52 24 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 248 -> socket:[20707]
lrwx------+1 root root  64 Oct 10 13:52 249 -> socket:[20708]
lrwx------+1 root root  64 Oct 10 13:52 25 -> socket:[18525]
lrwx------ 1 root root  64 Oct 10 13:52 250 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 26 -> socket:[18526]
lrwx------+1 root root  64 Oct 10 13:52 267 -> socket:[20713]
lrwx------+1 root root  64 Oct 10 13:52 268 -> socket:[20714]
lrwx------+1 root root  64 Oct 10 13:52 27 -> socket:[18527]
lrwx------ 1 root root  64 Oct 10 13:52 28 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 29 -> anon_inode:bpf-map
lr-x------ 1 root root  64 Oct 10 13:52 3 -> /sys/fs/cgroup/cpu.max
lrwx------ 1 root root  64 Oct 10 13:52 30 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 31 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 11:01 313 -> socket:[22996]
lrwx------ 1 root root  64 Oct 10 13:52 32 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 33 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 34 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 35 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 36 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 37 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 38 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 39 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 4 -> socket:[18080]
lrwx------ 1 root root  64 Oct 10 13:52 40 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 41 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 42 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 43 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 44 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 45 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 11:00 46 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 47 -> anon_inode:[eventpoll]
lrwx------ 1 root root  64 Oct 10 13:52 48 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 49 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 5 -> anon_inode:[eventpoll]
lrwx------ 1 root root  64 Oct 10 13:52 50 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 51 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 52 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 53 -> socket:[18170]
lrwx------+1 root root  64 Oct 10 13:52 54 -> socket:[18171]
lrwx------+1 root root  64 Oct 10 13:52 55 -> socket:[18172]
lrwx------+1 root root  64 Oct 10 11:01 56 -> socket:[153245]
lrwx------ 1 root root  64 Oct 10 13:52 57 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 58 -> socket:[18707]
lrwx------+1 root root  64 Oct 10 13:52 59 -> socket:[18292]
lrwx------ 1 root root  64 Oct 10 13:52 6 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 11:00 60 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 61 -> socket:[18294]
lrwx------ 1 root root  64 Oct 10 11:00 62 -> anon_inode:bpf-map
lrwx------ 1 root root  64 Oct 10 13:52 63 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 64 -> socket:[18701]
lr-x------ 1 root root  64 Oct 10 13:52 65 -> anon_inode:btf
lrwx------ 1 root root  64 Oct 10 13:52 66 -> anon_inode:bpf-map
l-wx------ 1 root root  64 Oct 10 13:52 67 -> /run/cilium/state/device-reconciler.wal
lrwx------ 1 root root  64 Oct 10 13:52 68 -> anon_inode:bpf-prog
lrwx------+1 root root  64 Oct 10 13:52 69 -> socket:[18376]
l-wx------ 1 root root  64 Oct 10 13:52 7 -> /run/cilium/state/cilium-agent-health-history.log
lrwx------+1 root root  64 Oct 10 13:52 70 -> socket:[18739]
lrwx------ 1 root root  64 Oct 10 13:52 71 -> anon_inode:[eventpoll]
lrwx------ 1 root root  64 Oct 10 13:52 72 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 73 -> anon_inode:[eventfd]
lrwx------ 1 root root  64 Oct 10 13:52 74 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 75 -> anon_inode:[perf_event]
lrwx------ 1 root root  64 Oct 10 13:52 76 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 13:52 77 -> socket:[18377]
lrwx------+1 root root  64 Oct 10 13:52 78 -> socket:[18378]
lrwx------+1 root root  64 Oct 10 11:00 79 -> socket:[152424]
lrwx------+1 root root  64 Oct 10 13:52 8 -> socket:[18085]
lrwx------+1 root root  64 Oct 10 13:52 80 -> socket:[18379]
lrwx------+1 root root  64 Oct 10 13:52 81 -> socket:[18380]
lrwx------+1 root root  64 Oct 10 13:52 82 -> socket:[18381]
lr-x------ 1 root root  64 Oct 10 13:52 83 -> anon_inode:btf
lrwx------+1 root root  64 Oct 10 11:00 84 -> socket:[155806]
lrwx------+1 root root  64 Oct 10 11:00 85 -> socket:[155807]
lrwx------ 1 root root  64 Oct 10 13:52 86 -> anon_inode:bpf-prog
lrwx------+1 root root  64 Oct 10 11:00 88 -> socket:[165871]
lrwx------ 1 root root  64 Oct 10 11:00 9 -> anon_inode:bpf-map
lrwx------+1 root root  64 Oct 10 11:00 91 -> socket:[166284]
lrwx------+1 root root  64 Oct 10 11:01 92 -> socket:[169092]
lrwx------ 1 root root  64 Oct 10 13:52 94 -> anon_inode:[pidfd]
lrwx------+1 root root  64 Oct 10 13:52 95 -> socket:[168206]
