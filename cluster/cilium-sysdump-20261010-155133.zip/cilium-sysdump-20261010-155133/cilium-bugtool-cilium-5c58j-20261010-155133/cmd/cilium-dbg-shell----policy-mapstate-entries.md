ID: 172	Namespace: kube-system	Name: hubble-relay-856fb9b979-qblz5	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Egress      11         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress
Egress      0          *            0          254            allow     0           0        allow-any-egress
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      13         *            0          254            allow     0           0        allow-any-egress

ID: 461	Namespace: 	Name: 	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      13         *            0          254            allow     0           0        allow-any-egress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Egress      12         *            0          254            allow     0           0        allow-any-egress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress

ID: 462	Namespace: kube-system	Name: hubble-ui-6dcdfb579c-s4xpb	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      13         *            0          254            allow     0           0        allow-any-egress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress
Ingress     0          *            0          254            allow     0           0        allow-any-ingress

ID: 1075	Namespace: 	Name: 	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Ingress     12         *            0          254            allow     0           0        allow-any-ingress
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      13         *            0          254            allow     0           0        allow-any-egress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress

ID: 1508	Namespace: kube-system	Name: coredns-559f6c778d-jc27s	Entries:10
Direction   Identity   Proto+Port   Priority   ListenerPrio   Verdict   ProxyPort   Cookie   Origins
Egress      0          *            0          254            allow     0           0        allow-any-egress
Egress      14         *            0          254            allow     0           0        allow-any-egress
Egress      13         *            0          254            allow     0           0        allow-any-egress
Egress      11         *            0          254            allow     0           0        allow-any-egress
Egress      12         *            0          254            allow     0           0        allow-any-egress
Ingress     0          *            0          254            allow     0           0        allow-any-ingress
Ingress     14         *            0          254            allow     0           0        allow-any-ingress
Ingress     13         *            0          254            allow     0           0        allow-any-ingress
Ingress     11         *            0          254            allow     0           0        allow-any-ingress
Ingress     12         *            0          254            allow     0           0        allow-any-ingress


