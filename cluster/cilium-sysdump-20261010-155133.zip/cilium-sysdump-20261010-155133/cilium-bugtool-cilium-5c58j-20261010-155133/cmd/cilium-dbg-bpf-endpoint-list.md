IP ADDRESS          LOCAL ENDPOINT INFO
10.244.2.11:0       id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0   
10.244.2.31:0       id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0   
192.168.178.115:0   (localhost)                                                                                                                   
10.244.2.84:0       id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0   
10.244.2.226:0      (localhost)                                                                                                                   
10.244.2.154:0      id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0   
