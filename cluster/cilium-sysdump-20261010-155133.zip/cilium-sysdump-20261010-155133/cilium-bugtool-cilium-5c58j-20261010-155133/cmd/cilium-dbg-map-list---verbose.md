## Map: cilium_ratelimit
Cache is empty


## Map: cilium_lb4_backends_v3
Key   Value                   State   Error
13    TCP://10.244.1.214              
14    TCP://10.244.2.11               
18    TCP://10.244.2.11               
12    TCP://10.244.2.154              
1     TCP://192.168.178.113           
17    TCP://10.244.1.214              
16    UDP://10.244.2.11               
9     TCP://192.168.178.115           
15    UDP://10.244.1.214              
11    TCP://10.244.2.31               

## Map: cilium_policy_v3_00172
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_policy_v3_01508
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_lb4_affinity
Cache is empty


## Map: cilium_ratelimit_metrics
Cache is empty


## Map: cilium_lxc
Key                 Value                                                                                                                         State   Error
10.244.2.226:0      (localhost)                                                                                                                   sync    
10.244.2.84:0       id=1075  sec_id=4     flags=0x0000 ifindex=7   mac=92:26:B9:95:01:DC nodemac=0A:EF:0C:52:C3:E1 parent_ifindex=0   rt_info:0   sync    
10.244.2.154:0      id=172   sec_id=25785 flags=0x0000 ifindex=9   mac=E6:51:02:69:E4:73 nodemac=02:F1:64:7B:A2:B6 parent_ifindex=0   rt_info:0   sync    
10.244.2.11:0       id=1508  sec_id=41104 flags=0x0000 ifindex=13  mac=66:F9:11:7E:7B:00 nodemac=1A:56:8B:C4:AD:7F parent_ifindex=0   rt_info:0   sync    
10.244.2.31:0       id=462   sec_id=10824 flags=0x0000 ifindex=11  mac=26:4A:27:0A:51:A7 nodemac=7A:49:C7:96:28:F5 parent_ifindex=0   rt_info:0   sync    
192.168.178.115:0   (localhost)                                                                                                                   sync    

## Map: cilium_percpu_trace_id
Cache is empty


## Map: cilium_lb4_reverse_nat
Key   Value               State   Error
7     10.105.79.192:80            
2     10.96.0.10:53               
5     10.97.123.232:80            
3     10.96.0.10:53               
6     10.101.247.67:443           
4     10.96.0.10:9153             
1     10.96.0.1:443               

## Map: cilium_lb4_maglev
Cache is empty


## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3499277376953125           
AgentLiveness   10311840657932             
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_ct4_global
Key                                                     Value   State   Error
10.244.2.31:30853 --> 10.244.2.226:37151, 6, 1          expires=9930 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9920 TxFlagsSeen=0x1b LastTxReport=9920 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:11409 --> 10.244.2.226:32272, 6, 1         expires=10091 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10081 TxFlagsSeen=0x1b LastTxReport=10081 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:33508 --> 10.244.2.226:37151, 6, 1          expires=10091 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10081 TxFlagsSeen=0x1b LastTxReport=10081 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:54427 --> 10.244.2.226:62751, 6, 1          expires=10210 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10200 TxFlagsSeen=0x1b LastTxReport=10200 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:41654 --> 10.244.2.226:32272, 6, 1         expires=10111 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10101 TxFlagsSeen=0x1b LastTxReport=10101 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:14020 --> 10.244.2.226:32272, 6, 1         expires=10141 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10131 TxFlagsSeen=0x1b LastTxReport=10131 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:48357 --> 10.244.2.226:32272, 6, 1         expires=9921 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9911 TxFlagsSeen=0x1b LastTxReport=9911 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:45723 --> 10.244.2.226:32272, 6, 1         expires=10241 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10231 TxFlagsSeen=0x1b LastTxReport=10231 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:64653 --> 10.244.2.226:37151, 6, 1          expires=10290 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10280 TxFlagsSeen=0x1b LastTxReport=10280 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:26788 --> 10.244.2.226:32272, 6, 1         expires=9961 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9951 TxFlagsSeen=0x1b LastTxReport=9951 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:32920 --> 10.244.2.226:36895, 6, 1          expires=9751 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9741 TxFlagsSeen=0x1b LastTxReport=9741 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:10890 --> 10.244.2.226:37151, 6, 1          expires=9941 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9931 TxFlagsSeen=0x1b LastTxReport=9931 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:21632 --> 10.244.2.226:32272, 6, 1         expires=10211 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10201 TxFlagsSeen=0x1a LastTxReport=10201 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:40101 --> 10.244.2.226:32272, 6, 1         expires=10081 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10071 TxFlagsSeen=0x1b LastTxReport=10071 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:51900 --> 10.244.2.226:36895, 6, 1          expires=9971 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9961 TxFlagsSeen=0x1b LastTxReport=9961 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:2753 --> 10.244.2.226:36895, 6, 1           expires=9861 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9851 TxFlagsSeen=0x1b LastTxReport=9851 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:42684 --> 10.244.2.226:37151, 6, 1          expires=9951 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9941 TxFlagsSeen=0x1b LastTxReport=9941 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:33920 --> 10.244.2.226:36895, 6, 1          expires=10201 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10191 TxFlagsSeen=0x1b LastTxReport=10191 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:44698 --> 10.244.2.226:32272, 6, 1         expires=10191 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10181 TxFlagsSeen=0x1b LastTxReport=10181 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:10405 --> 10.244.2.226:37151, 6, 1          expires=9911 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9901 TxFlagsSeen=0x1b LastTxReport=9901 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:20176 --> 10.244.2.226:36880, 6, 0          expires=9740 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=9680 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:63708 --> 10.244.2.226:37151, 6, 1          expires=10070 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10060 TxFlagsSeen=0x1b LastTxReport=10060 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:10404 --> 10.244.2.226:37151, 6, 1          expires=10160 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10150 TxFlagsSeen=0x1b LastTxReport=10150 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:50831 --> 10.244.2.226:37151, 6, 1          expires=9880 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9870 TxFlagsSeen=0x1b LastTxReport=9870 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:9866 --> 10.244.2.226:37151, 6, 1           expires=9940 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9930 TxFlagsSeen=0x1b LastTxReport=9930 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:17053 --> 10.244.2.226:32272, 6, 1         expires=10041 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10031 TxFlagsSeen=0x1a LastTxReport=10031 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:19166 --> 10.244.2.226:32272, 6, 1         expires=10291 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10281 TxFlagsSeen=0x1b LastTxReport=10281 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:38104 --> 10.244.2.226:37151, 6, 1          expires=9831 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9821 TxFlagsSeen=0x1b LastTxReport=9821 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:53992 --> 10.244.2.226:62751, 6, 1          expires=10140 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10130 TxFlagsSeen=0x1b LastTxReport=10130 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:56973 --> 10.244.2.226:37151, 6, 1          expires=10101 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10091 TxFlagsSeen=0x1b LastTxReport=10091 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:53383 --> 10.244.2.226:36895, 6, 1          expires=10051 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10041 TxFlagsSeen=0x1b LastTxReport=10041 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:50916 --> 10.244.2.226:37151, 6, 1          expires=9721 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9711 TxFlagsSeen=0x1b LastTxReport=9711 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:50919 --> 10.244.2.226:62751, 6, 1          expires=9740 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9730 TxFlagsSeen=0x1b LastTxReport=9730 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:38115 --> 10.244.2.226:37151, 6, 1          expires=9761 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9751 TxFlagsSeen=0x1b LastTxReport=9751 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:42663 --> 10.244.2.226:37151, 6, 1          expires=9740 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9730 TxFlagsSeen=0x1b LastTxReport=9730 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:57529 --> 10.244.2.226:36880, 6, 0          expires=10188 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=10128 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:43669 --> 10.244.2.226:32272, 6, 1         expires=9841 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9831 TxFlagsSeen=0x1a LastTxReport=9831 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:56493 --> 10.244.2.226:37151, 6, 1          expires=9861 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9851 TxFlagsSeen=0x1b LastTxReport=9851 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:40104 --> 10.244.2.226:36895, 6, 1          expires=9781 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9771 TxFlagsSeen=0x1b LastTxReport=9771 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:29337 --> 10.244.2.226:62751, 6, 1          expires=10260 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10250 TxFlagsSeen=0x1b LastTxReport=10250 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:57575 --> 10.244.2.226:32272, 6, 1         expires=9881 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9871 TxFlagsSeen=0x1b LastTxReport=9871 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:35022 --> 10.244.2.226:32272, 6, 1         expires=9951 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9941 TxFlagsSeen=0x1b LastTxReport=9941 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.115:20710 --> 10.244.2.154:37904, 6, 0      expires=18296 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10296 TxFlagsSeen=0x1a LastTxReport=10296 Flags=0x0010 [ SeenNonSyn ] RevNAT=6 SourceSecurityID=25785 BackendID=0 NatPort=0 
                                                             
10.244.2.11:22663 --> 10.244.2.226:62751, 6, 1          expires=9830 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9820 TxFlagsSeen=0x1b LastTxReport=9820 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:34968 --> 10.244.2.226:36895, 6, 1          expires=10151 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10141 TxFlagsSeen=0x1b LastTxReport=10141 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:19150 --> 10.244.2.226:37151, 6, 1          expires=10250 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10240 TxFlagsSeen=0x1b LastTxReport=10240 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:28299 --> 10.244.2.226:36895, 6, 1          expires=9941 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9931 TxFlagsSeen=0x1b LastTxReport=9931 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:53430 --> 10.244.2.226:37151, 6, 1          expires=9890 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9880 TxFlagsSeen=0x1b LastTxReport=9880 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:46235 --> 10.244.2.226:32272, 6, 1         expires=10241 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10231 TxFlagsSeen=0x1b LastTxReport=10231 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:11954 --> 10.244.2.226:36895, 6, 1          expires=10091 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10081 TxFlagsSeen=0x1b LastTxReport=10081 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:63651 --> 10.244.2.226:37151, 6, 1          expires=9811 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9801 TxFlagsSeen=0x1b LastTxReport=9801 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:57024 --> 10.244.2.226:32272, 6, 1         expires=9821 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9811 TxFlagsSeen=0x1a LastTxReport=9811 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:44777 --> 192.168.178.115:36880, 6, 0   expires=10313 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=10303 TxFlagsSeen=0x02 LastTxReport=10303 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:50316 --> 10.244.2.226:37151, 6, 1          expires=10320 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10310 TxFlagsSeen=0x1b LastTxReport=10310 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:64715 --> 10.244.2.226:32272, 6, 1         expires=10231 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10221 TxFlagsSeen=0x1a LastTxReport=10221 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:1721 --> 10.244.2.226:37151, 6, 1           expires=10060 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10050 TxFlagsSeen=0x1b LastTxReport=10050 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:63654 --> 10.244.2.226:32272, 6, 1         expires=9861 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9851 TxFlagsSeen=0x1b LastTxReport=9851 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:4285 --> 10.244.2.226:36895, 6, 1           expires=9701 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9691 TxFlagsSeen=0x1b LastTxReport=9691 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:8838 --> 10.244.2.226:37151, 6, 1           expires=10191 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10181 TxFlagsSeen=0x1b LastTxReport=10181 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:32448 --> 10.244.2.226:32272, 6, 1         expires=9741 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9731 TxFlagsSeen=0x1a LastTxReport=9731 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:5845 --> 10.244.2.226:32272, 6, 1          expires=9791 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9781 TxFlagsSeen=0x1b LastTxReport=9781 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:14465 --> 10.244.2.226:32272, 6, 1         expires=10221 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10211 TxFlagsSeen=0x1b LastTxReport=10211 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:63665 --> 10.244.2.226:62751, 6, 1          expires=10010 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10000 TxFlagsSeen=0x1b LastTxReport=10000 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:12953 --> 10.244.2.226:37151, 6, 1          expires=9991 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9981 TxFlagsSeen=0x1b LastTxReport=9981 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:12996 --> 10.244.2.226:37151, 6, 1          expires=10230 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10220 TxFlagsSeen=0x1b LastTxReport=10220 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38057 --> 10.244.2.226:62751, 6, 1          expires=10250 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10240 TxFlagsSeen=0x1b LastTxReport=10240 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:62090 --> 10.244.2.226:62751, 6, 1          expires=10240 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10230 TxFlagsSeen=0x1b LastTxReport=10230 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:9919 --> 10.244.2.226:32272, 6, 1          expires=10261 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10251 TxFlagsSeen=0x1b LastTxReport=10251 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:59598 --> 10.244.2.226:62751, 6, 1          expires=10310 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10300 TxFlagsSeen=0x1b LastTxReport=10300 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:40126 --> 192.168.178.115:36880, 6, 0   expires=9827 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=9817 TxFlagsSeen=0x02 LastTxReport=9817 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:31365 --> 10.244.2.226:37151, 6, 1          expires=9931 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9921 TxFlagsSeen=0x1b LastTxReport=9921 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:15026 --> 10.244.2.226:37151, 6, 1          expires=9781 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9771 TxFlagsSeen=0x1b LastTxReport=9771 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:1757 --> 10.244.2.226:37151, 6, 1           expires=10071 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10061 TxFlagsSeen=0x1b LastTxReport=10061 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:49303 --> 10.244.2.226:36895, 6, 1          expires=10031 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10021 TxFlagsSeen=0x1b LastTxReport=10021 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:38049 --> 10.244.2.226:32272, 6, 1         expires=10031 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10021 TxFlagsSeen=0x1b LastTxReport=10021 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:32908 --> 192.168.178.115:11033, 6, 0   expires=18311 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10307 TxFlagsSeen=0x1a LastTxReport=10307 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:51331 --> 10.244.2.226:37151, 6, 1          expires=10281 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10271 TxFlagsSeen=0x1b LastTxReport=10271 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.114:39568 --> 192.168.178.115:36880, 6, 0   expires=9741 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9731 TxFlagsSeen=0x1b LastTxReport=9731 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39110 --> 10.244.2.226:37151, 6, 1          expires=9770 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9760 TxFlagsSeen=0x1b LastTxReport=9760 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:26301 --> 10.244.2.226:37151, 6, 1          expires=10020 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10010 TxFlagsSeen=0x1b LastTxReport=10010 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:64182 --> 10.244.2.226:62751, 6, 1          expires=10020 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10010 TxFlagsSeen=0x1b LastTxReport=10010 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:48871 --> 10.244.2.226:36895, 6, 1          expires=9801 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9791 TxFlagsSeen=0x1b LastTxReport=9791 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:24281 --> 10.244.2.226:37151, 6, 1          expires=9970 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9960 TxFlagsSeen=0x1b LastTxReport=9960 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:61671 --> 10.244.2.226:32272, 6, 1         expires=9881 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9871 TxFlagsSeen=0x1b LastTxReport=9871 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:47776 --> 10.244.2.226:32272, 6, 1         expires=10321 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10311 TxFlagsSeen=0x1b LastTxReport=10311 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:51856 --> 10.244.2.226:37151, 6, 1          expires=10210 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10200 TxFlagsSeen=0x1b LastTxReport=10200 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:44162 --> 10.244.1.173:36880, 6, 1          expires=10131 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10121 TxFlagsSeen=0x1b LastTxReport=10121 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.2.11:62655 --> 10.244.2.226:62751, 6, 1          expires=10080 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10070 TxFlagsSeen=0x1b LastTxReport=10070 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:49795 --> 10.244.2.226:37151, 6, 1          expires=10280 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10270 TxFlagsSeen=0x1b LastTxReport=10270 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:39054 --> 10.244.2.226:36895, 6, 1          expires=10141 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10131 TxFlagsSeen=0x1b LastTxReport=10131 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:22247 --> 10.244.2.226:36895, 6, 1          expires=9911 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9901 TxFlagsSeen=0x1b LastTxReport=9901 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:35492 --> 10.244.2.226:36895, 6, 1          expires=10181 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10171 TxFlagsSeen=0x1b LastTxReport=10171 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:40625 --> 10.244.2.226:37151, 6, 1          expires=9980 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9970 TxFlagsSeen=0x1b LastTxReport=9970 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:45288 --> 10.244.2.226:37151, 6, 1          expires=10121 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10111 TxFlagsSeen=0x1b LastTxReport=10111 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:14002 --> 10.244.2.226:37151, 6, 1          expires=9780 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9770 TxFlagsSeen=0x1b LastTxReport=9770 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:34523 --> 10.244.2.226:62751, 6, 1          expires=9890 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9880 TxFlagsSeen=0x1b LastTxReport=9880 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:1171 --> 10.244.2.226:36895, 6, 1           expires=10311 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10301 TxFlagsSeen=0x1b LastTxReport=10301 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:63622 --> 10.244.2.226:37151, 6, 1          expires=9791 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9781 TxFlagsSeen=0x1b LastTxReport=9781 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:12979 --> 10.244.2.11:11033, 6, 0       expires=18294 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10294 TxFlagsSeen=0x1a LastTxReport=10294 Flags=0x0010 [ SeenNonSyn ] RevNAT=1 SourceSecurityID=41104 BackendID=0 NatPort=0 
                                                             
10.244.2.154:52433 --> 10.244.2.226:32272, 6, 1         expires=9721 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9711 TxFlagsSeen=0x1b LastTxReport=9711 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:64129 --> 10.244.2.226:36895, 6, 1          expires=9761 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9751 TxFlagsSeen=0x1b LastTxReport=9751 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38048 --> 10.244.2.226:62751, 6, 1          expires=10000 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9990 TxFlagsSeen=0x1b LastTxReport=9990 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:35520 --> 10.244.2.226:32272, 6, 1         expires=9741 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9731 TxFlagsSeen=0x1b LastTxReport=9731 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.114:39149 --> 192.168.178.115:36880, 6, 0   expires=10072 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10062 TxFlagsSeen=0x1b LastTxReport=10062 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:62655 --> 10.244.2.226:37151, 6, 1          expires=9730 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9720 TxFlagsSeen=0x1b LastTxReport=9720 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:30387 --> 10.244.2.226:62751, 6, 1          expires=9750 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9740 TxFlagsSeen=0x1b LastTxReport=9740 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:34454 --> 10.244.2.226:62751, 6, 1          expires=10150 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10140 TxFlagsSeen=0x1b LastTxReport=10140 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:16110 --> 10.244.2.226:37151, 6, 1          expires=9960 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9950 TxFlagsSeen=0x1b LastTxReport=9950 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:3201 --> 10.244.2.226:32272, 6, 1          expires=10021 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10011 TxFlagsSeen=0x1b LastTxReport=10011 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:53931 --> 10.244.2.226:32272, 6, 1         expires=10061 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10051 TxFlagsSeen=0x1b LastTxReport=10051 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:48846 --> 10.244.2.226:62751, 6, 1          expires=9870 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9860 TxFlagsSeen=0x1b LastTxReport=9860 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38574 --> 10.244.2.226:62751, 6, 1          expires=9780 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9770 TxFlagsSeen=0x1b LastTxReport=9770 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:47873 --> 10.96.0.1:12979, 6, 4             expires=18294 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x1a LastTxReport=10294 Flags=0x0010 [ SeenNonSyn ] RevNAT=1 SourceSecurityID=0 BackendID=1 NatPort=0 
                                                             
192.168.178.114:3790 --> 192.168.178.115:36880, 6, 0    expires=9878 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9868 TxFlagsSeen=0x1b LastTxReport=9868 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:27835 --> 10.244.2.226:37151, 6, 1          expires=10310 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10300 TxFlagsSeen=0x1b LastTxReport=10300 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:1702 --> 10.244.2.226:32272, 6, 1          expires=10251 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10241 TxFlagsSeen=0x1b LastTxReport=10241 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:50886 --> 10.244.2.226:32272, 6, 1         expires=9781 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9771 TxFlagsSeen=0x1b LastTxReport=9771 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:62152 --> 10.244.2.226:62751, 6, 1          expires=10270 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10260 TxFlagsSeen=0x1b LastTxReport=10260 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:25280 --> 10.244.2.226:32272, 6, 1         expires=10071 Packets=0 Bytes=0 RxFlagsSeen=0x1e LastRxReport=10061 TxFlagsSeen=0x1a LastTxReport=10061 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:9429 --> 10.244.2.226:32272, 6, 1          expires=9791 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9781 TxFlagsSeen=0x1b LastTxReport=9781 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:45742 --> 10.244.2.226:36895, 6, 1          expires=10221 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10211 TxFlagsSeen=0x1b LastTxReport=10211 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:36509 --> 10.244.2.226:36895, 6, 1          expires=10001 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9991 TxFlagsSeen=0x1b LastTxReport=9991 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:7813 --> 10.244.2.226:32272, 6, 1          expires=10171 Packets=0 Bytes=0 RxFlagsSeen=0x1e LastRxReport=10161 TxFlagsSeen=0x1a LastTxReport=10161 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:45260 --> 10.244.2.226:36895, 6, 1          expires=10171 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10161 TxFlagsSeen=0x1b LastTxReport=10161 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:9944 --> 10.244.2.226:62751, 6, 1           expires=9800 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9790 TxFlagsSeen=0x1b LastTxReport=9790 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:52937 --> 10.244.2.226:36895, 6, 1          expires=10281 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10271 TxFlagsSeen=0x1b LastTxReport=10271 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:42635 --> 10.244.1.173:36880, 6, 1          expires=9995 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9985 TxFlagsSeen=0x1b LastTxReport=9985 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.2.154:14563 --> 10.244.2.226:32272, 6, 1         expires=9871 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9861 TxFlagsSeen=0x1b LastTxReport=9861 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:44726 --> 10.244.2.226:32272, 6, 1         expires=10111 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10101 TxFlagsSeen=0x1b LastTxReport=10101 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:12979 --> 192.168.178.115:11033, 6, 0   expires=18294 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10294 TxFlagsSeen=0x1a LastTxReport=10294 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:49794 --> 10.244.2.226:32272, 6, 1         expires=9801 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9791 TxFlagsSeen=0x1b LastTxReport=9791 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:54470 --> 10.244.2.226:32272, 6, 1         expires=9781 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9771 TxFlagsSeen=0x1b LastTxReport=9771 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:58022 --> 10.244.2.226:32272, 6, 1         expires=9981 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9971 TxFlagsSeen=0x1b LastTxReport=9971 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:35025 --> 10.244.2.226:32272, 6, 1         expires=9771 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9761 TxFlagsSeen=0x1b LastTxReport=9761 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:49343 --> 10.244.2.226:36895, 6, 1          expires=9901 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9891 TxFlagsSeen=0x1b LastTxReport=9891 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:2190 --> 10.244.2.226:37151, 6, 1           expires=10291 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10281 TxFlagsSeen=0x1b LastTxReport=10281 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:21671 --> 10.244.2.226:62751, 6, 1          expires=9940 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9930 TxFlagsSeen=0x1b LastTxReport=9930 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:9907 --> 10.244.2.226:36895, 6, 1           expires=9981 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9971 TxFlagsSeen=0x1b LastTxReport=9971 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:11406 --> 10.244.2.226:36895, 6, 1          expires=10261 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10251 TxFlagsSeen=0x1b LastTxReport=10251 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:28320 --> 10.244.2.226:37151, 6, 1          expires=10051 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10041 TxFlagsSeen=0x1b LastTxReport=10041 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:36001 --> 10.244.2.226:32272, 6, 1         expires=10031 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10021 TxFlagsSeen=0x1b LastTxReport=10021 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:64220 --> 10.244.2.226:62751, 6, 1          expires=9980 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9970 TxFlagsSeen=0x1b LastTxReport=9970 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:689 --> 10.244.2.226:36895, 6, 1            expires=10011 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10001 TxFlagsSeen=0x1b LastTxReport=10001 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:40155 --> 10.244.2.226:62751, 6, 1          expires=10200 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10190 TxFlagsSeen=0x1b LastTxReport=10190 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:25760 --> 10.244.2.226:37151, 6, 1          expires=10050 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10040 TxFlagsSeen=0x1b LastTxReport=10040 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:4837 --> 10.244.2.226:62751, 6, 1           expires=10300 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10290 TxFlagsSeen=0x1b LastTxReport=10290 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:16535 --> 10.244.2.226:62751, 6, 1          expires=9960 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9950 TxFlagsSeen=0x1b LastTxReport=9950 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:5317 --> 10.244.2.226:62751, 6, 1           expires=10060 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10050 TxFlagsSeen=0x1b LastTxReport=10050 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:55441 --> 10.244.2.226:32272, 6, 1         expires=10301 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10291 TxFlagsSeen=0x1b LastTxReport=10291 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:26309 --> 10.244.2.226:62751, 6, 1          expires=9900 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9890 TxFlagsSeen=0x1b LastTxReport=9890 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39622 --> 10.244.2.226:37151, 6, 1          expires=9771 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9761 TxFlagsSeen=0x1b LastTxReport=9761 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:11967 --> 10.244.2.226:32272, 6, 1         expires=10261 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10251 TxFlagsSeen=0x1b LastTxReport=10251 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:48793 --> 10.244.2.226:37151, 6, 1          expires=9710 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9700 TxFlagsSeen=0x1b LastTxReport=9700 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:55949 --> 10.244.2.226:37151, 6, 1          expires=10100 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10090 TxFlagsSeen=0x1b LastTxReport=10090 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:43173 --> 10.244.2.226:32272, 6, 1         expires=10081 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10071 TxFlagsSeen=0x1b LastTxReport=10071 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:46248 --> 10.244.2.226:32272, 6, 1         expires=10181 Packets=0 Bytes=0 RxFlagsSeen=0x1e LastRxReport=10171 TxFlagsSeen=0x1a LastTxReport=10171 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:43230 --> 10.244.2.226:32272, 6, 1         expires=9851 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9841 TxFlagsSeen=0x1b LastTxReport=9841 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:45216 --> 10.244.2.226:32272, 6, 1         expires=10321 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10311 TxFlagsSeen=0x1b LastTxReport=10311 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:23204 --> 10.244.2.226:32272, 6, 1         expires=9961 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9951 TxFlagsSeen=0x1b LastTxReport=9951 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:46758 --> 10.244.2.226:37151, 6, 1          expires=9820 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9810 TxFlagsSeen=0x1b LastTxReport=9810 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:35975 --> 10.244.2.226:37151, 6, 1          expires=9750 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9740 TxFlagsSeen=0x1b LastTxReport=9740 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:20153 --> 10.244.2.226:36895, 6, 1          expires=9721 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9711 TxFlagsSeen=0x1b LastTxReport=9711 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:21207 --> 10.244.2.226:62751, 6, 1          expires=10040 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10030 TxFlagsSeen=0x1b LastTxReport=10030 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:34434 --> 10.244.2.226:37151, 6, 1          expires=10140 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10130 TxFlagsSeen=0x1b LastTxReport=10130 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:18083 --> 10.244.2.226:32272, 6, 1         expires=10151 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10141 TxFlagsSeen=0x1b LastTxReport=10141 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:49848 --> 10.244.2.226:62751, 6, 1          expires=9920 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9910 TxFlagsSeen=0x1b LastTxReport=9910 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:44711 --> 10.244.2.226:37151, 6, 1          expires=9741 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9731 TxFlagsSeen=0x1b LastTxReport=9731 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:36561 --> 10.244.2.226:32272, 6, 1         expires=9771 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9761 TxFlagsSeen=0x1b LastTxReport=9761 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:50818 --> 10.244.2.226:32272, 6, 1         expires=9801 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9791 TxFlagsSeen=0x1b LastTxReport=9791 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:3749 --> 10.244.2.226:32272, 6, 1          expires=10161 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10151 TxFlagsSeen=0x1b LastTxReport=10151 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:20686 --> 10.244.2.226:37151, 6, 1          expires=10251 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10241 TxFlagsSeen=0x1b LastTxReport=10241 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39143 --> 10.244.2.226:37151, 6, 1          expires=10151 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10141 TxFlagsSeen=0x1b LastTxReport=10141 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:12995 --> 10.244.2.226:37151, 6, 1          expires=10000 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9990 TxFlagsSeen=0x1b LastTxReport=9990 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38552 --> 10.244.2.226:36895, 6, 1          expires=10241 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10231 TxFlagsSeen=0x1b LastTxReport=10231 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:16521 --> 10.244.2.226:62751, 6, 1          expires=10220 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10210 TxFlagsSeen=0x1b LastTxReport=10210 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:13447 --> 10.244.2.226:36895, 6, 1          expires=9811 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9801 TxFlagsSeen=0x1b LastTxReport=9801 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:4281 --> 10.244.2.226:37151, 6, 1           expires=10061 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10051 TxFlagsSeen=0x1b LastTxReport=10051 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:15072 --> 10.244.2.226:37151, 6, 1          expires=10110 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10100 TxFlagsSeen=0x1b LastTxReport=10100 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:28860 --> 10.244.2.226:37151, 6, 1          expires=10201 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10191 TxFlagsSeen=0x1b LastTxReport=10191 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:24714 --> 10.244.2.226:32272, 6, 1         expires=9831 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9821 TxFlagsSeen=0x1a LastTxReport=9821 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:30860 --> 192.168.178.115:11033, 6, 0   expires=18311 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10308 TxFlagsSeen=0x1a LastTxReport=10308 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.11:53992 --> 10.244.2.226:36895, 6, 1          expires=9731 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9721 TxFlagsSeen=0x1b LastTxReport=9721 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:42650 --> 10.244.2.226:36895, 6, 1          expires=10101 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10091 TxFlagsSeen=0x1b LastTxReport=10091 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:58011 --> 10.244.2.226:36895, 6, 1          expires=9921 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9911 TxFlagsSeen=0x1b LastTxReport=9911 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:59526 --> 10.244.2.226:37151, 6, 1          expires=9790 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9780 TxFlagsSeen=0x1b LastTxReport=9780 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:46281 --> 10.244.2.226:32272, 6, 1         expires=9701 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9691 TxFlagsSeen=0x1b LastTxReport=9691 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:54445 --> 10.244.2.226:37151, 6, 1          expires=9860 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9850 TxFlagsSeen=0x1b LastTxReport=9850 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:7890 --> 10.244.2.226:37151, 6, 1           expires=10031 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10021 TxFlagsSeen=0x1b LastTxReport=10021 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:23692 --> 10.244.2.226:37151, 6, 1          expires=9921 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9911 TxFlagsSeen=0x1b LastTxReport=9911 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:53965 --> 10.244.2.226:62751, 6, 1          expires=10030 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10020 TxFlagsSeen=0x1b LastTxReport=10020 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:46246 --> 10.244.2.226:37151, 6, 1          expires=10011 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10001 TxFlagsSeen=0x1b LastTxReport=10001 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:31432 --> 10.244.2.226:32272, 6, 1         expires=10201 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10191 TxFlagsSeen=0x1b LastTxReport=10191 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:20651 --> 10.244.2.226:37151, 6, 1          expires=9870 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9860 TxFlagsSeen=0x1b LastTxReport=9860 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:35466 --> 10.244.2.226:62751, 6, 1          expires=9850 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9840 TxFlagsSeen=0x1b LastTxReport=9840 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:53905 --> 10.244.2.226:32272, 6, 1         expires=10301 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10291 TxFlagsSeen=0x1b LastTxReport=10291 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:15519 --> 10.244.2.226:37151, 6, 1          expires=10271 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10261 TxFlagsSeen=0x1b LastTxReport=10261 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:20618 --> 10.244.2.226:32272, 6, 1         expires=9831 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9821 TxFlagsSeen=0x1b LastTxReport=9821 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:9867 --> 10.244.2.226:36895, 6, 1           expires=10191 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10181 TxFlagsSeen=0x1b LastTxReport=10181 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:36994 --> 10.244.2.226:37151, 6, 1          expires=10141 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10131 TxFlagsSeen=0x1b LastTxReport=10131 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:11938 --> 10.244.2.226:37151, 6, 1          expires=9840 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9830 TxFlagsSeen=0x1b LastTxReport=9830 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:45257 --> 10.244.2.226:32272, 6, 1         expires=9701 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9691 TxFlagsSeen=0x1b LastTxReport=9691 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:9431 --> 10.244.2.226:36895, 6, 1           expires=9851 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9841 TxFlagsSeen=0x1b LastTxReport=9841 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:39118 --> 10.244.2.226:32272, 6, 1         expires=9951 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9941 TxFlagsSeen=0x1b LastTxReport=9941 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:43203 --> 10.244.2.226:36895, 6, 1          expires=9831 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9821 TxFlagsSeen=0x1b LastTxReport=9821 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:5761 --> 10.244.2.226:32272, 6, 1          expires=10021 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10011 TxFlagsSeen=0x1b LastTxReport=10011 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:32479 --> 10.244.2.226:32272, 6, 1         expires=9911 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9901 TxFlagsSeen=0x1b LastTxReport=9901 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:59570 --> 10.244.2.226:62751, 6, 1          expires=10180 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10170 TxFlagsSeen=0x1b LastTxReport=10170 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:2178 --> 10.244.2.226:36895, 6, 1           expires=10121 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10111 TxFlagsSeen=0x1b LastTxReport=10111 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:16035 --> 10.244.2.226:32272, 6, 1         expires=10151 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10141 TxFlagsSeen=0x1b LastTxReport=10141 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:19141 --> 10.244.2.226:32272, 6, 1         expires=10271 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10261 TxFlagsSeen=0x1b LastTxReport=10261 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:165 --> 10.244.2.226:32272, 6, 1           expires=10161 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10151 TxFlagsSeen=0x1b LastTxReport=10151 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:48856 --> 10.244.2.226:36895, 6, 1          expires=9821 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9811 TxFlagsSeen=0x1b LastTxReport=9811 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:51340 --> 10.244.2.226:62751, 6, 1          expires=9700 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9690 TxFlagsSeen=0x1b LastTxReport=9690 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.197:64185 --> 10.244.2.226:36880, 6, 0         expires=9897 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9887 TxFlagsSeen=0x1b LastTxReport=9887 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39559 --> 10.244.2.226:37151, 6, 1          expires=9751 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9741 TxFlagsSeen=0x1b LastTxReport=9741 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:62630 --> 10.244.2.226:32272, 6, 1         expires=9861 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9851 TxFlagsSeen=0x1b LastTxReport=9851 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:64165 --> 10.244.2.226:32272, 6, 1         expires=10251 Packets=0 Bytes=0 RxFlagsSeen=0x1e LastRxReport=10241 TxFlagsSeen=0x1a LastTxReport=10241 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:10369 --> 10.244.2.226:32272, 6, 1         expires=10221 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10211 TxFlagsSeen=0x1b LastTxReport=10211 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:7333 --> 10.244.2.226:37151, 6, 1           expires=9910 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9900 TxFlagsSeen=0x1b LastTxReport=9900 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:43679 --> 10.244.2.226:37151, 6, 1          expires=10221 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10211 TxFlagsSeen=0x1b LastTxReport=10211 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:3734 --> 10.244.2.226:62751, 6, 1           expires=10070 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10060 TxFlagsSeen=0x1b LastTxReport=10060 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:19157 --> 10.244.2.226:62751, 6, 1          expires=10290 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10280 TxFlagsSeen=0x1b LastTxReport=10280 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38090 --> 10.244.2.226:62751, 6, 1          expires=9790 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9780 TxFlagsSeen=0x1b LastTxReport=9780 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:1752 --> 10.244.2.226:36895, 6, 1           expires=10081 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10071 TxFlagsSeen=0x1b LastTxReport=10071 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:17092 --> 10.244.2.226:37151, 6, 1          expires=10231 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10221 TxFlagsSeen=0x1b LastTxReport=10221 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:697 --> 10.244.2.226:36895, 6, 1            expires=9771 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9761 TxFlagsSeen=0x1b LastTxReport=9761 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:49318 --> 10.244.2.226:37151, 6, 1          expires=9821 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9811 TxFlagsSeen=0x1b LastTxReport=9811 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:14019 --> 10.244.2.226:37151, 6, 1          expires=10001 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9991 TxFlagsSeen=0x1b LastTxReport=9991 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:11405 --> 10.244.2.226:62751, 6, 1          expires=10190 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10180 TxFlagsSeen=0x1b LastTxReport=10180 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:23168 --> 10.244.2.226:32272, 6, 1         expires=10211 Packets=0 Bytes=0 RxFlagsSeen=0x1e LastRxReport=10201 TxFlagsSeen=0x1a LastTxReport=10201 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:53905 --> 192.168.178.115:11033, 6, 0   expires=18311 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10308 TxFlagsSeen=0x1a LastTxReport=10308 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.11:18618 --> 10.244.2.226:62751, 6, 1          expires=10280 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10270 TxFlagsSeen=0x1b LastTxReport=10270 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:44172 --> 10.244.2.226:32272, 6, 1         expires=10131 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10121 TxFlagsSeen=0x1b LastTxReport=10121 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:52945 --> 10.244.2.226:32272, 6, 1         expires=9721 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9711 TxFlagsSeen=0x1b LastTxReport=9711 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:49817 --> 10.244.2.226:37151, 6, 1          expires=9711 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9701 TxFlagsSeen=0x1b LastTxReport=9701 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:27339 --> 10.244.2.226:36895, 6, 1          expires=10271 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10261 TxFlagsSeen=0x1b LastTxReport=10261 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39100 --> 10.244.2.226:37151, 6, 1          expires=9950 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9940 TxFlagsSeen=0x1b LastTxReport=9940 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:7396 --> 10.244.2.226:62751, 6, 1           expires=9990 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9980 TxFlagsSeen=0x1b LastTxReport=9980 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:18058 --> 10.244.2.226:37151, 6, 1          expires=10080 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10070 TxFlagsSeen=0x1b LastTxReport=10070 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:32391 --> 10.244.2.226:62751, 6, 1          expires=9840 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9830 TxFlagsSeen=0x1b LastTxReport=9830 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:45233 --> 10.244.2.226:37151, 6, 1          expires=9801 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9791 TxFlagsSeen=0x1b LastTxReport=9791 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:51429 --> 10.244.2.226:32272, 6, 1         expires=9921 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9911 TxFlagsSeen=0x1a LastTxReport=9911 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:13986 --> 10.244.2.226:37151, 6, 1          expires=9841 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9831 TxFlagsSeen=0x1b LastTxReport=9831 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:49886 --> 10.244.2.226:32272, 6, 1         expires=10121 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10111 TxFlagsSeen=0x1b LastTxReport=10111 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:40088 --> 10.244.2.226:62751, 6, 1          expires=10100 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10090 TxFlagsSeen=0x1b LastTxReport=10090 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:54498 --> 10.244.2.226:32272, 6, 1         expires=10311 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10301 TxFlagsSeen=0x1b LastTxReport=10301 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:130 --> 10.244.2.226:36895, 6, 1            expires=9951 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9941 TxFlagsSeen=0x1b LastTxReport=9941 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:41620 --> 10.244.2.226:32272, 6, 1         expires=10281 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10271 TxFlagsSeen=0x1a LastTxReport=10271 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:4789 --> 10.244.2.226:37151, 6, 1           expires=10260 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10250 TxFlagsSeen=0x1b LastTxReport=10250 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38546 --> 10.244.2.226:62751, 6, 1          expires=9770 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9760 TxFlagsSeen=0x1b LastTxReport=9760 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:47873 --> 10.101.247.67:20710, 6, 4        expires=18296 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x1a LastTxReport=10296 Flags=0x0010 [ SeenNonSyn ] RevNAT=6 SourceSecurityID=0 BackendID=9 NatPort=0 
                                                             
10.244.2.154:18117 --> 10.244.2.226:32272, 6, 1         expires=10271 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10261 TxFlagsSeen=0x1b LastTxReport=10261 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:20668 --> 10.244.2.226:36895, 6, 1          expires=10131 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10121 TxFlagsSeen=0x1b LastTxReport=10121 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:24220 --> 10.244.2.226:32272, 6, 1         expires=9901 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9891 TxFlagsSeen=0x1a LastTxReport=9891 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:29885 --> 10.244.2.226:37151, 6, 1          expires=10021 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10011 TxFlagsSeen=0x1b LastTxReport=10011 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:31460 --> 10.244.2.226:37151, 6, 1          expires=10090 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10080 TxFlagsSeen=0x1b LastTxReport=10080 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:50830 --> 10.244.2.226:62751, 6, 1          expires=9860 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9850 TxFlagsSeen=0x1b LastTxReport=9850 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:43668 --> 10.244.2.226:32272, 6, 1         expires=10281 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10271 TxFlagsSeen=0x1b LastTxReport=10271 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:17630 --> 10.244.2.226:32272, 6, 1         expires=10291 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10281 TxFlagsSeen=0x1b LastTxReport=10281 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:53982 --> 10.244.2.226:32272, 6, 1         expires=10121 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10111 TxFlagsSeen=0x1a LastTxReport=10111 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:58517 --> 10.244.2.226:36895, 6, 1          expires=10021 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10011 TxFlagsSeen=0x1b LastTxReport=10011 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:41099 --> 10.244.2.226:62751, 6, 1          expires=10230 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10220 TxFlagsSeen=0x1b LastTxReport=10220 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:28898 --> 10.244.2.226:36895, 6, 1          expires=10231 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10221 TxFlagsSeen=0x1b LastTxReport=10221 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:54991 --> 10.244.2.226:62751, 6, 1          expires=10050 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10040 TxFlagsSeen=0x1b LastTxReport=10040 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:12515 --> 10.244.2.226:32272, 6, 1         expires=9871 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9861 TxFlagsSeen=0x1b LastTxReport=9861 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:12996 --> 10.244.2.226:32272, 6, 1         expires=10141 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10131 TxFlagsSeen=0x1b LastTxReport=10131 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:36056 --> 10.244.2.226:37151, 6, 1          expires=9830 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9820 TxFlagsSeen=0x1b LastTxReport=9820 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:62113 --> 10.244.2.226:62751, 6, 1          expires=10320 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10310 TxFlagsSeen=0x1b LastTxReport=10310 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:8329 --> 10.244.2.226:62751, 6, 1           expires=9820 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9810 TxFlagsSeen=0x1b LastTxReport=9810 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:36067 --> 10.244.2.226:37151, 6, 1          expires=9760 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9750 TxFlagsSeen=0x1b LastTxReport=9750 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.197:48777 --> 10.244.2.226:36880, 6, 0         expires=10092 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10082 TxFlagsSeen=0x1b LastTxReport=10082 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.11:59081 --> 10.244.2.226:36895, 6, 1          expires=10041 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10031 TxFlagsSeen=0x1b LastTxReport=10031 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:61095 --> 10.244.2.226:37151, 6, 1          expires=9701 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9691 TxFlagsSeen=0x1b LastTxReport=9691 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:12433 --> 10.244.2.226:32272, 6, 1         expires=10091 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10081 TxFlagsSeen=0x1b LastTxReport=10081 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:32957 --> 10.244.2.226:36895, 6, 1          expires=10071 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10061 TxFlagsSeen=0x1b LastTxReport=10061 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:27799 --> 10.244.2.226:37151, 6, 1          expires=9851 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9841 TxFlagsSeen=0x1b LastTxReport=9841 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:3289 --> 10.244.2.226:36895, 6, 1           expires=10061 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10051 TxFlagsSeen=0x1b LastTxReport=10051 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:24770 --> 10.244.1.173:36880, 6, 1          expires=9879 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9869 TxFlagsSeen=0x1b LastTxReport=9869 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.2.31:192 --> 10.244.2.226:37151, 6, 1            expires=9731 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9721 TxFlagsSeen=0x1b LastTxReport=9721 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:41704 --> 10.244.2.226:37151, 6, 1          expires=10120 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10110 TxFlagsSeen=0x1b LastTxReport=10110 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:19168 --> 10.244.2.226:37151, 6, 1          expires=10111 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10101 TxFlagsSeen=0x1b LastTxReport=10101 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:13008 --> 10.244.2.226:32272, 6, 1         expires=9991 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9981 TxFlagsSeen=0x1b LastTxReport=9981 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:22682 --> 10.244.2.226:32272, 6, 1         expires=9811 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9801 TxFlagsSeen=0x1b LastTxReport=9801 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:41649 --> 10.244.2.226:37151, 6, 1          expires=9981 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9971 TxFlagsSeen=0x1b LastTxReport=9971 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:20111 --> 10.244.2.226:62751, 6, 1          expires=9810 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9800 TxFlagsSeen=0x1b LastTxReport=9800 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:47236 --> 10.244.2.226:36895, 6, 1          expires=10291 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10281 TxFlagsSeen=0x1b LastTxReport=10281 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:10407 --> 10.244.2.226:32272, 6, 1         expires=9761 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9751 TxFlagsSeen=0x1a LastTxReport=9751 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:6278 --> 10.244.2.226:37151, 6, 1           expires=10190 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10180 TxFlagsSeen=0x1b LastTxReport=10180 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:36039 --> 10.244.2.226:36880, 6, 0          expires=9916 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=9856 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:12967 --> 10.244.2.226:32272, 6, 1         expires=9761 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9751 TxFlagsSeen=0x1b LastTxReport=9751 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:61091 --> 10.244.2.226:37151, 6, 1          expires=9810 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9800 TxFlagsSeen=0x1b LastTxReport=9800 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:40156 --> 192.168.178.115:36880, 6, 0   expires=10099 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=10089 TxFlagsSeen=0x02 LastTxReport=10089 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.11:55976 --> 10.244.2.226:36895, 6, 1          expires=9791 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9781 TxFlagsSeen=0x1b LastTxReport=9781 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:56999 --> 10.244.2.226:37151, 6, 1          expires=9700 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9690 TxFlagsSeen=0x1b LastTxReport=9690 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:5813 --> 10.244.2.226:37151, 6, 1           expires=10261 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10251 TxFlagsSeen=0x1b LastTxReport=10251 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:27782 --> 10.244.2.226:32272, 6, 1         expires=10001 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9991 TxFlagsSeen=0x1a LastTxReport=9991 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:64657 --> 10.244.2.226:32272, 6, 1         expires=10011 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10001 TxFlagsSeen=0x1b LastTxReport=10001 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:10953 --> 10.244.2.226:32272, 6, 1         expires=9751 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9741 TxFlagsSeen=0x1b LastTxReport=9741 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:27817 --> 10.244.2.226:62751, 6, 1          expires=9970 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9960 TxFlagsSeen=0x1b LastTxReport=9960 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:23709 --> 10.244.2.226:32272, 6, 1         expires=9731 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9721 TxFlagsSeen=0x1b LastTxReport=9721 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:44209 --> 10.244.2.226:37151, 6, 1          expires=9800 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9790 TxFlagsSeen=0x1b LastTxReport=9790 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:55010 --> 10.244.2.226:32272, 6, 1         expires=10311 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10301 TxFlagsSeen=0x1b LastTxReport=10301 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:25734 --> 10.244.2.226:32272, 6, 1         expires=10001 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9991 TxFlagsSeen=0x1b LastTxReport=9991 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:27331 --> 10.244.2.226:37151, 6, 1          expires=10240 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10230 TxFlagsSeen=0x1b LastTxReport=10230 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:16572 --> 10.244.2.226:62751, 6, 1          expires=10120 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10110 TxFlagsSeen=0x1b LastTxReport=10110 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:27804 --> 10.244.2.226:32272, 6, 1         expires=9901 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9891 TxFlagsSeen=0x1b LastTxReport=9891 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:42132 --> 10.244.2.226:37151, 6, 1          expires=10131 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10121 TxFlagsSeen=0x1b LastTxReport=10121 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:9417 --> 10.244.2.226:32272, 6, 1          expires=9751 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9741 TxFlagsSeen=0x1b LastTxReport=9741 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:57487 --> 10.244.2.226:36895, 6, 1          expires=10211 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10201 TxFlagsSeen=0x1b LastTxReport=10201 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:2721 --> 10.244.2.226:32272, 6, 1          expires=10101 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10091 TxFlagsSeen=0x1b LastTxReport=10091 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:35045 --> 10.244.2.226:62751, 6, 1          expires=9730 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9720 TxFlagsSeen=0x1b LastTxReport=9720 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:19098 --> 10.244.2.226:32272, 6, 1         expires=9811 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9801 TxFlagsSeen=0x1b LastTxReport=9801 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.0.27:42636 --> 10.244.2.226:36880, 6, 0          expires=9954 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=9894 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:37053 --> 10.244.2.226:32272, 6, 1         expires=9891 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9881 TxFlagsSeen=0x1b LastTxReport=9881 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:52928 --> 10.244.2.226:32272, 6, 1         expires=9821 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9811 TxFlagsSeen=0x1b LastTxReport=9811 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:128 --> 10.244.2.226:37151, 6, 1            expires=9961 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9951 TxFlagsSeen=0x1b LastTxReport=9951 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39127 --> 10.244.2.226:37151, 6, 1          expires=10171 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10161 TxFlagsSeen=0x1b LastTxReport=10161 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:44186 --> 10.244.2.226:32272, 6, 1         expires=10191 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10181 TxFlagsSeen=0x1b LastTxReport=10181 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:20618 --> 10.244.2.226:37151, 6, 1          expires=10081 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10071 TxFlagsSeen=0x1b LastTxReport=10071 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:55952 --> 10.244.2.226:37151, 6, 1          expires=10211 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10201 TxFlagsSeen=0x1b LastTxReport=10201 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:31976 --> 10.244.2.226:62751, 6, 1          expires=10130 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10120 TxFlagsSeen=0x1b LastTxReport=10120 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:10391 --> 10.244.2.226:36895, 6, 1          expires=10161 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10151 TxFlagsSeen=0x1b LastTxReport=10151 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:30403 --> 10.244.2.226:37151, 6, 1          expires=10241 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10231 TxFlagsSeen=0x1b LastTxReport=10231 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:30907 --> 10.244.2.226:37151, 6, 1          expires=10311 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10301 TxFlagsSeen=0x1b LastTxReport=10301 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:27344 --> 10.244.2.226:36895, 6, 1          expires=9931 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9921 TxFlagsSeen=0x1b LastTxReport=9921 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:52367 --> 10.244.2.226:37151, 6, 1          expires=9881 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9871 TxFlagsSeen=0x1b LastTxReport=9871 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:39583 --> 10.244.2.226:37151, 6, 1          expires=10220 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10210 TxFlagsSeen=0x1b LastTxReport=10210 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:62632 --> 10.244.2.226:32272, 6, 1         expires=10051 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10041 TxFlagsSeen=0x1a LastTxReport=10041 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:6822 --> 10.244.2.226:36895, 6, 1           expires=9961 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9951 TxFlagsSeen=0x1b LastTxReport=9951 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:10905 --> 10.244.2.226:37151, 6, 1          expires=9990 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9980 TxFlagsSeen=0x1b LastTxReport=9980 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:43158 --> 10.244.2.226:36895, 6, 1          expires=10301 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10291 TxFlagsSeen=0x1b LastTxReport=10291 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:35551 --> 10.244.2.226:32272, 6, 1         expires=9911 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9901 TxFlagsSeen=0x1b LastTxReport=9901 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:60605 --> 10.244.2.226:37151, 6, 1          expires=10040 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10030 TxFlagsSeen=0x1b LastTxReport=10030 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:43228 --> 10.244.2.226:36895, 6, 1          expires=9711 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9701 TxFlagsSeen=0x1b LastTxReport=9701 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:16005 --> 10.244.1.173:36880, 6, 1          expires=9762 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9752 TxFlagsSeen=0x1b LastTxReport=9752 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.1.197:33980 --> 10.244.2.226:36880, 6, 0         expires=9722 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9712 TxFlagsSeen=0x1b LastTxReport=9712 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:64147 --> 10.244.2.226:32272, 6, 1         expires=9931 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9921 TxFlagsSeen=0x1b LastTxReport=9921 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:33480 --> 10.244.2.226:32272, 6, 1         expires=10201 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10191 TxFlagsSeen=0x1b LastTxReport=10191 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:44710 --> 10.244.2.226:37151, 6, 1          expires=10010 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10000 TxFlagsSeen=0x1b LastTxReport=10000 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:56998 --> 10.244.2.226:32272, 6, 1         expires=9981 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9971 TxFlagsSeen=0x1b LastTxReport=9971 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:23213 --> 10.244.1.173:36880, 6, 1          expires=10287 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10277 TxFlagsSeen=0x1b LastTxReport=10277 Flags=0x0413 [ RxClosing TxClosing SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.2.154:56491 --> 10.244.2.226:32272, 6, 1         expires=10061 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10051 TxFlagsSeen=0x1b LastTxReport=10051 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:27353 --> 10.244.2.226:37151, 6, 1          expires=9971 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9961 TxFlagsSeen=0x1b LastTxReport=9961 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:26775 --> 10.244.2.226:37151, 6, 1          expires=9850 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9840 TxFlagsSeen=0x1b LastTxReport=9840 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:25792 --> 10.244.2.226:32272, 6, 1         expires=10071 Packets=0 Bytes=0 RxFlagsSeen=0x1e LastRxReport=10061 TxFlagsSeen=0x1a LastTxReport=10061 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:48282 --> 10.244.2.226:32272, 6, 1         expires=9711 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9701 TxFlagsSeen=0x1b LastTxReport=9701 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:46245 --> 10.244.2.226:36895, 6, 1          expires=9991 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9981 TxFlagsSeen=0x1b LastTxReport=9981 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:34493 --> 10.244.2.226:32272, 6, 1         expires=9891 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9881 TxFlagsSeen=0x1b LastTxReport=9881 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:60121 --> 10.244.2.226:32272, 6, 1         expires=9941 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9931 TxFlagsSeen=0x1b LastTxReport=9931 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:28317 --> 10.244.2.226:32272, 6, 1         expires=9971 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9961 TxFlagsSeen=0x1a LastTxReport=9961 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:58512 --> 10.244.2.226:62751, 6, 1          expires=9930 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9920 TxFlagsSeen=0x1b LastTxReport=9920 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:34482 --> 10.244.2.226:62751, 6, 1          expires=10110 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10100 TxFlagsSeen=0x1b LastTxReport=10100 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:35468 --> 192.168.178.115:11033, 6, 0   expires=18311 Packets=0 Bytes=0 RxFlagsSeen=0x18 LastRxReport=10311 TxFlagsSeen=0x1a LastTxReport=10311 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.11:50862 --> 10.244.2.226:62751, 6, 1          expires=9760 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9750 TxFlagsSeen=0x1b LastTxReport=9750 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:23234 --> 10.244.2.226:37151, 6, 1          expires=9901 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9891 TxFlagsSeen=0x1b LastTxReport=9891 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.114:1259 --> 192.168.178.115:36880, 6, 0    expires=18306 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10305 TxFlagsSeen=0x1a LastTxReport=10305 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.31:22210 --> 10.244.2.226:37151, 6, 1          expires=9900 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9890 TxFlagsSeen=0x1b LastTxReport=9890 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:21661 --> 10.244.2.226:32272, 6, 1         expires=9731 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9721 TxFlagsSeen=0x1b LastTxReport=9721 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:32966 --> 10.244.1.173:36880, 6, 1          expires=18304 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10304 TxFlagsSeen=0x1a LastTxReport=10304 Flags=0x0410 [ SeenNonSyn FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                             
10.244.2.11:34453 --> 10.244.2.226:62751, 6, 1          expires=9720 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9710 TxFlagsSeen=0x1b LastTxReport=9710 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:57526 --> 10.244.2.226:37151, 6, 1          expires=9891 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9881 TxFlagsSeen=0x1b LastTxReport=9881 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:54998 --> 10.244.2.226:37151, 6, 1          expires=10180 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10170 TxFlagsSeen=0x1b LastTxReport=10170 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:61117 --> 10.244.2.226:37151, 6, 1          expires=10041 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10031 TxFlagsSeen=0x1b LastTxReport=10031 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:19089 --> 10.244.2.226:36895, 6, 1          expires=9741 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9731 TxFlagsSeen=0x1b LastTxReport=9731 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:24761 --> 10.244.2.226:62751, 6, 1          expires=9910 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9900 TxFlagsSeen=0x1b LastTxReport=9900 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:64168 --> 10.244.2.226:32272, 6, 1         expires=10051 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=10041 TxFlagsSeen=0x1a LastTxReport=10041 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:38631 --> 10.244.2.226:37151, 6, 1          expires=10150 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10140 TxFlagsSeen=0x1b LastTxReport=10140 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:59560 --> 10.244.2.226:62751, 6, 1          expires=10160 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10150 TxFlagsSeen=0x1b LastTxReport=10150 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:51340 --> 10.244.2.226:37151, 6, 1          expires=10321 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10311 TxFlagsSeen=0x1b LastTxReport=10311 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:38603 --> 10.244.2.226:36895, 6, 1          expires=10251 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10241 TxFlagsSeen=0x1b LastTxReport=10241 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:14495 --> 10.244.2.226:37151, 6, 1          expires=10270 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10260 TxFlagsSeen=0x1b LastTxReport=10260 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.84:59610 --> 10.244.2.226:36880, 6, 1          expires=18302 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10302 TxFlagsSeen=0x1a LastTxReport=10302 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.1.197:4743 --> 10.244.2.226:36880, 6, 0          expires=18310 Packets=0 Bytes=0 RxFlagsSeen=0x1a LastRxReport=10310 TxFlagsSeen=0x1a LastTxReport=10310 Flags=0x0010 [ SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.0.27:43211 --> 10.244.2.226:36880, 6, 0          expires=10363 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=10303 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:32413 --> 10.244.2.226:32272, 6, 1         expires=9971 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9961 TxFlagsSeen=0x1b LastTxReport=9961 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:45195 --> 10.244.2.226:62751, 6, 1          expires=9710 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9700 TxFlagsSeen=0x1b LastTxReport=9700 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:48868 --> 10.244.2.226:37151, 6, 1          expires=9720 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9710 TxFlagsSeen=0x1b LastTxReport=9710 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:64178 --> 10.244.2.226:37151, 6, 1          expires=10300 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10290 TxFlagsSeen=0x1b LastTxReport=10290 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:57049 --> 10.244.2.226:32272, 6, 1         expires=9941 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9931 TxFlagsSeen=0x1b LastTxReport=9931 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:56022 --> 10.244.2.226:37151, 6, 1          expires=10181 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10171 TxFlagsSeen=0x1b LastTxReport=10171 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:53907 --> 10.244.2.226:36895, 6, 1          expires=9841 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9831 TxFlagsSeen=0x1b LastTxReport=9831 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:43199 --> 10.244.2.226:36895, 6, 1          expires=10111 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10101 TxFlagsSeen=0x1b LastTxReport=10101 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:3717 --> 10.244.2.226:32272, 6, 1          expires=10171 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10161 TxFlagsSeen=0x1b LastTxReport=10161 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:30397 --> 192.168.178.115:36880, 6, 0   expires=10021 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=10011 TxFlagsSeen=0x02 LastTxReport=10011 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.154:42133 --> 10.244.2.226:32272, 6, 1         expires=9841 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9831 TxFlagsSeen=0x1b LastTxReport=9831 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:3218 --> 10.244.2.226:32272, 6, 1          expires=10011 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10001 TxFlagsSeen=0x1b LastTxReport=10001 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:43660 --> 10.244.2.226:32272, 6, 1         expires=10131 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10121 TxFlagsSeen=0x1b LastTxReport=10121 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:41108 --> 10.244.2.226:37151, 6, 1          expires=10130 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10120 TxFlagsSeen=0x1b LastTxReport=10120 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:24764 --> 10.244.2.226:37151, 6, 1          expires=10200 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10190 TxFlagsSeen=0x1b LastTxReport=10190 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:673 --> 10.244.2.226:32272, 6, 1           expires=10101 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10091 TxFlagsSeen=0x1b LastTxReport=10091 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:6866 --> 10.244.2.226:37151, 6, 1           expires=10030 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10020 TxFlagsSeen=0x1b LastTxReport=10020 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:61131 --> 10.244.2.226:32272, 6, 1         expires=10231 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10221 TxFlagsSeen=0x1b LastTxReport=10221 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:13516 --> 10.244.2.226:36895, 6, 1          expires=10321 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10311 TxFlagsSeen=0x1b LastTxReport=10311 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:47326 --> 10.244.2.226:32272, 6, 1         expires=9851 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9841 TxFlagsSeen=0x1b LastTxReport=9841 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:42125 --> 10.244.2.226:62751, 6, 1          expires=10170 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10160 TxFlagsSeen=0x1b LastTxReport=10160 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:61075 --> 10.244.2.226:32272, 6, 1         expires=9931 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9921 TxFlagsSeen=0x1b LastTxReport=9921 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:59577 --> 10.244.2.226:36895, 6, 1          expires=9871 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9861 TxFlagsSeen=0x1b LastTxReport=9861 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:37556 --> 10.244.2.226:36895, 6, 1          expires=9881 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9871 TxFlagsSeen=0x1b LastTxReport=9871 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:46256 --> 10.244.2.226:62751, 6, 1          expires=9880 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9870 TxFlagsSeen=0x1b LastTxReport=9870 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:16541 --> 10.244.2.226:32272, 6, 1         expires=10041 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10031 TxFlagsSeen=0x1b LastTxReport=10031 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
192.168.178.113:21636 --> 192.168.178.115:36880, 6, 0   expires=9866 Packets=0 Bytes=0 RxFlagsSeen=0x14 LastRxReport=9856 TxFlagsSeen=0x02 LastTxReport=9856 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.0.27:16050 --> 10.244.2.226:36880, 6, 0          expires=10110 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=0 TxFlagsSeen=0x02 LastTxReport=10050 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                             
10.244.2.11:16043 --> 10.244.2.226:62751, 6, 1          expires=10090 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10080 TxFlagsSeen=0x1b LastTxReport=10080 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:47272 --> 10.244.2.226:32272, 6, 1         expires=10181 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10171 TxFlagsSeen=0x1b LastTxReport=10171 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:38615 --> 10.244.2.226:37151, 6, 1          expires=10170 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10160 TxFlagsSeen=0x1b LastTxReport=10160 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:20161 --> 10.244.2.226:36895, 6, 1          expires=9891 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9881 TxFlagsSeen=0x1b LastTxReport=9881 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.11:12930 --> 10.244.2.226:62751, 6, 1          expires=9950 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9940 TxFlagsSeen=0x1b LastTxReport=9940 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:10916 --> 10.244.2.226:37151, 6, 1          expires=10161 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10151 TxFlagsSeen=0x1b LastTxReport=10151 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:23180 --> 10.244.2.226:37151, 6, 1          expires=9920 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9910 TxFlagsSeen=0x1b LastTxReport=9910 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:21675 --> 10.244.2.226:37151, 6, 1          expires=9871 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=9861 TxFlagsSeen=0x1b LastTxReport=9861 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.31:179 --> 10.244.2.226:37151, 6, 1            expires=10301 Packets=0 Bytes=0 RxFlagsSeen=0x1b LastRxReport=10291 TxFlagsSeen=0x1b LastTxReport=10291 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             
10.244.2.154:15568 --> 10.244.2.226:32272, 6, 1         expires=9991 Packets=0 Bytes=0 RxFlagsSeen=0x1f LastRxReport=9981 TxFlagsSeen=0x1a LastTxReport=9981 Flags=0x0013 [ RxClosing TxClosing SeenNonSyn ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                             

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_devices
Key   Value                 State   Error
2     bc:24:11:3c:bf:be 0           

## Map: cilium_ct_any4_global
Key                                                    Value   State   Error
10.244.2.84:0 --> 10.244.2.226:0, 1, 3                 expires=10285 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10225 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:10051 --> 10.244.2.226:0, 1, 1             expires=10285 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10225 TxFlagsSeen=0x00 LastTxReport=10225 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:54185 --> 10.244.2.226:0, 1, 1             expires=10130 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10070 TxFlagsSeen=0x00 LastTxReport=10070 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:48383 --> 10.244.2.226:0, 1, 1             expires=9779 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9719 TxFlagsSeen=0x00 LastTxReport=9719 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.31:0 --> 10.244.2.226:0, 1, 3                 expires=10371 Packets=0 Bytes=0 RxFlagsSeen=0x02 LastRxReport=10311 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:38358 --> 10.244.1.173:0, 1, 1             expires=9955 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9895 TxFlagsSeen=0x00 LastTxReport=9895 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            
10.244.2.11:0 --> 10.244.2.226:0, 1, 3                 expires=10371 Packets=0 Bytes=0 RxFlagsSeen=0x02 LastRxReport=10311 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:42919 --> 10.244.1.173:0, 1, 1             expires=9839 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9779 TxFlagsSeen=0x00 LastTxReport=9779 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            
10.244.2.84:51320 --> 10.244.2.226:0, 1, 1             expires=9818 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9758 TxFlagsSeen=0x00 LastTxReport=9758 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:22069 --> 10.244.1.173:0, 1, 1             expires=9722 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9662 TxFlagsSeen=0x00 LastTxReport=9662 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            
10.244.2.84:33967 --> 10.244.1.173:0, 1, 1             expires=10364 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10304 TxFlagsSeen=0x00 LastTxReport=10304 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            
10.244.2.154:0 --> 10.244.2.226:0, 1, 3                expires=10371 Packets=0 Bytes=0 RxFlagsSeen=0x02 LastRxReport=10311 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:0 --> 10.244.1.173:0, 1, 3                 expires=10364 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10304 TxFlagsSeen=0x00 LastTxReport=0 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            
10.244.2.84:13858 --> 10.244.2.226:0, 1, 1             expires=10207 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10147 TxFlagsSeen=0x00 LastTxReport=10147 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:5580 --> 10.244.1.173:0, 1, 1              expires=10091 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10031 TxFlagsSeen=0x00 LastTxReport=10031 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            
91.189.91.112:40923 --> 192.168.178.115:31488, 17, 0   expires=9899 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9839 TxFlagsSeen=0x00 LastTxReport=9838 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=0 BackendID=0 NatPort=0 
                                                            
10.244.2.84:52802 --> 10.244.2.226:0, 1, 1             expires=9974 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=9914 TxFlagsSeen=0x00 LastTxReport=9914 Flags=0x0000 [ ] RevNAT=0 SourceSecurityID=1 BackendID=0 NatPort=0 
                                                            
10.244.2.84:46276 --> 10.244.1.173:0, 1, 1             expires=10247 Packets=0 Bytes=0 RxFlagsSeen=0x00 LastRxReport=10187 TxFlagsSeen=0x00 LastTxReport=10187 Flags=0x0400 [ FromTunnel ] RevNAT=0 SourceSecurityID=6 BackendID=0 NatPort=0 
                                                            

## Map: cilium_auth_map
Cache is empty


## Map: cilium_lb_affinity_match
Cache is empty


## Map: cilium_lb4_services_v2
Key                         Value                   State   Error
10.96.0.10:53/UDP (0)       0 2[0] (3) [0x0 0x0]            
10.96.0.1:0/ANY (0)         0 0[0] (0) [0x0 0x0]            
10.96.0.10:53/TCP (2)       14 0[0] (2) [0x0 0x0]           
10.97.123.232:80/TCP (0)    0 1[0] (5) [0x0 0x0]            
10.96.0.10:9153/TCP (0)     0 2[0] (4) [0x0 0x0]            
10.96.0.10:9153/TCP (1)     17 0[0] (4) [0x0 0x0]           
10.105.79.192:80/TCP (0)    0 1[0] (7) [0x0 0x0]            
10.101.247.67:443/TCP (1)   9 0[0] (6) [0x0 0x10]           
10.101.247.67:443/TCP (0)   0 1[0] (6) [0x0 0x10]           
10.96.0.10:53/UDP (1)       15 0[0] (3) [0x0 0x0]           
10.96.0.10:53/UDP (2)       16 0[0] (3) [0x0 0x0]           
10.105.79.192:0/ANY (0)     0 0[0] (0) [0x0 0x0]            
10.97.123.232:80/TCP (1)    11 0[0] (5) [0x0 0x0]           
10.96.0.1:443/TCP (0)       0 1[0] (1) [0x0 0x0]            
10.96.0.10:53/TCP (0)       0 2[0] (2) [0x0 0x0]            
10.101.247.67:0/ANY (0)     0 0[0] (0) [0x0 0x0]            
10.96.0.10:0/ANY (0)        0 0[0] (0) [0x0 0x0]            
10.96.0.10:9153/TCP (2)     18 0[0] (4) [0x0 0x0]           
10.97.123.232:0/ANY (0)     0 0[0] (0) [0x0 0x0]            
10.96.0.10:53/TCP (1)       13 0[0] (2) [0x0 0x0]           
10.105.79.192:80/TCP (1)    12 0[0] (7) [0x0 0x0]           
10.96.0.1:443/TCP (1)       1 0[0] (1) [0x0 0x0]            

## Map: cilium_lb4_reverse_sk
Cache is empty


## Map: cilium_snat_v4_external
Cache is empty


## Map: cilium_policy_v3_00461
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_policy_v3_01075
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_policy_v3_00462
Key               Value   State   Error
Ingress: 0 ANY    0 0             
Egress: 0 ANY     0 0             
Ingress: 11 ANY   0 0             
Egress: 11 ANY    0 0             
Ingress: 12 ANY   0 0             
Egress: 12 ANY    0 0             
Ingress: 13 ANY   0 0             
Egress: 13 ANY    0 0             
Ingress: 14 ANY   0 0             
Egress: 14 ANY    0 0             

## Map: cilium_ipcache_v2
Key                  Value                                                                        State   Error
192.168.178.113/32   identity=7 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
192.168.178.115/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
0.0.0.0/0            identity=2 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.1.197/32      identity=4 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel       sync    
10.244.2.31/32       identity=10824 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              sync    
10.244.1.214/32      identity=41104 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel   sync    
10.244.0.172/32      identity=6 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       sync    
10.244.2.11/32       identity=41104 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              sync    
10.244.0.0/24        identity=2 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       sync    
10.244.2.154/32      identity=25785 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>              sync    
10.244.2.226/32      identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.2.84/32       identity=4 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.0.27/32       identity=4 encryptkey=0 tunnelendpoint=192.168.178.113 flags=hastunnel       sync    
192.168.178.114/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                  sync    
10.244.1.173/32      identity=6 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel       sync    
10.244.1.0/24        identity=2 encryptkey=0 tunnelendpoint=192.168.178.114 flags=hastunnel       sync    

## Map: cilium_metrics
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_policystats
Cache is disabled


## Map: cilium_skip_lb4
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_l2_responder_v6
Cache is disabled


