key: 01 00 00 00  value: 84 01 00 00
key: 07 00 00 00  value: 80 01 00 00
key: 0f 00 00 00  value: 83 01 00 00
key: 24 00 00 00  value: 85 01 00 00
key: 26 00 00 00  value: 86 01 00 00
key: 2d 00 00 00  value: 82 01 00 00
Found 6 elements
