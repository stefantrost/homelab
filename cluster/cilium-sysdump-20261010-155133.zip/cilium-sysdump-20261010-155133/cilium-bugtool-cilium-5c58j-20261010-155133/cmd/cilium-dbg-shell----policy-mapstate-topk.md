ID: 461	Namespace: 	Name: 	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-egress    5
allow-any-ingress   5

ID: 1075	Namespace: 	Name: 	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-ingress   5
allow-any-egress    5

ID: 172	Namespace: kube-system	Name: hubble-relay-856fb9b979-qblz5	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-egress    5
allow-any-ingress   5

ID: 462	Namespace: kube-system	Name: hubble-ui-6dcdfb579c-s4xpb	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-ingress   5
allow-any-egress    5

ID: 1508	Namespace: kube-system	Name: coredns-559f6c778d-jc27s	Entries: 10 (may not sum)	Policies: 2
Policy              Entries
allow-any-egress    5
allow-any-ingress   5


