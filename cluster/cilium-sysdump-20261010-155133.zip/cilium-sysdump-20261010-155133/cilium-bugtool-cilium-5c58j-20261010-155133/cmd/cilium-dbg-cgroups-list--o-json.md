[
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10a825c3_cf3b_4b1b_9b29_ad72a65d9533.slice/cri-containerd-5f57af3b7b10328d7bb984a362aa2a83659156b753ff8499611dc9b3d69aee7c.scope"
      },
      {
        "cgroup-id": 10148,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10a825c3_cf3b_4b1b_9b29_ad72a65d9533.slice/cri-containerd-3e96ba554058d73f650a98b72dd62e5f6c58be98308f088f1546c6deb7125c7c.scope"
      }
    ],
    "ips": [
      "10.244.2.31"
    ],
    "name": "hubble-ui-6dcdfb579c-s4xpb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9539,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67580aa4_c28a_47f4_b86e_f28e86ff7e7b.slice/cri-containerd-b8366a44f5247c919f1b0184291780453919693a0ee06a32f682233f67df8e37.scope"
      }
    ],
    "ips": [
      "192.168.178.115"
    ],
    "name": "cilium-5c58j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8756,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf26fb350_abcb_4bb2_8fb5_b0faa0070778.slice/cri-containerd-aac9369a1e8cade98f299735d5394354a705a3348beb45a4bd2a69644a08bbc3.scope"
      }
    ],
    "ips": [
      "192.168.178.115"
    ],
    "name": "cilium-envoy-bvbbb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9887,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31830aeb_7b60_4688_bff3_ee77ca2d3f3a.slice/cri-containerd-b4f5e7222e07ff6bde4f5929dafb6abf4348221441d0fc460fbdd54e845da6ad.scope"
      }
    ],
    "ips": [
      "10.244.2.11"
    ],
    "name": "coredns-559f6c778d-jc27s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9974,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0da351c_3c98_4f8b_9399_2d469b80f02e.slice/cri-containerd-80f1ad8d4caa1391f8f94478d2979751248966640f9a9eb12d2f24f05962a6a2.scope"
      }
    ],
    "ips": [
      "10.244.2.154"
    ],
    "name": "hubble-relay-856fb9b979-qblz5",
    "namespace": "kube-system"
  }
]

