Name           IPv4 Address      Endpoint CIDR   IPv6 Address   Endpoint CIDR   Source
controlplane   192.168.178.113   10.244.0.0/24                                  custom-resource
workernode01   192.168.178.114   10.244.1.0/24                                  custom-resource
workernode02   192.168.178.115   10.244.2.0/24                                  local
