 13:52:07 up  2:51,  0 users,  load average: 0.05, 0.15, 0.14
