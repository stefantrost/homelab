# Cilium debug information

#### Cilium status

```
KVStore:                Disabled   
Kubernetes:             Ok         1.37 (v1.37.1) [linux/amd64]
Kubernetes APIs:        ["cilium/v2::CiliumCIDRGroup", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "core/v1::Pods", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [ens18     192.168.178.115 fda7:7b49:a70a:0:be24:11ff:fe3c:bfbe 2a02:8071:5301:a0a0:be24:11ff:fe3c:bfbe fe80::be24:11ff:fe3c:bfbe (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.20.2 (v1.20.2-e0dc92bd)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.244.2.0/24, 
Allocated addresses:
  10.244.2.11 (kube-system/coredns-559f6c778d-jc27s)
  10.244.2.154 (kube-system/hubble-relay-856fb9b979-qblz5)
  10.244.2.226 (router)
  10.244.2.31 (kube-system/hubble-ui-6dcdfb579c-s4xpb)
  10.244.2.84 (health)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            TCX
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      28/28 healthy
  Name                                                       Last success   Last error   Count   Message
  cilium-health-ep                                           7s ago         never        0       no error   
  ct-map-pressure                                            8s ago         never        0       no error   
  endpoint-1075-regeneration-recovery                        never          never        0       no error   
  endpoint-1508-regeneration-recovery                        never          never        0       no error   
  endpoint-172-regeneration-recovery                         never          never        0       no error   
  endpoint-461-regeneration-recovery                         never          never        0       no error   
  endpoint-462-regeneration-recovery                         never          never        0       no error   
  endpoint-gc                                                1m9s ago       never        0       no error   
  endpoint-periodic-regeneration                             1m8s ago       never        0       no error   
  ipcache-inject-labels                                      9s ago         never        0       no error   
  k8s-heartbeat                                              9s ago         never        0       no error   
  resolve-identity-1075                                      1m8s ago       never        0       no error   
  resolve-identity-1508                                      1m5s ago       never        0       no error   
  resolve-identity-172                                       1m5s ago       never        0       no error   
  resolve-identity-461                                       1m9s ago       never        0       no error   
  resolve-identity-462                                       1m5s ago       never        0       no error   
  resolve-labels-kube-system/coredns-559f6c778d-jc27s        2h51m5s ago    never        0       no error   
  resolve-labels-kube-system/hubble-relay-856fb9b979-qblz5   2h51m5s ago    never        0       no error   
  resolve-labels-kube-system/hubble-ui-6dcdfb579c-s4xpb      2h51m5s ago    never        0       no error   
  sync-policymap-1075                                        6m1s ago       never        0       no error   
  sync-policymap-1508                                        6m0s ago       never        0       no error   
  sync-policymap-172                                         6m1s ago       never        0       no error   
  sync-policymap-461                                         6m1s ago       never        0       no error   
  sync-policymap-462                                         6m0s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1508)                          4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (172)                           5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (462)                           4s ago         never        0       no error   
  write-cni-file                                             2h51m9s ago    never        0       no error   
Proxy Status:            OK, ip 10.244.2.226, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 6.31   Metrics: Disabled
KubeProxyReplacement Details:
  Status:               True
  Socket LB:            Enabled
  Socket LB Tracing:    Enabled
  Socket LB Coverage:   Hostns-only
  Devices:              ens18     192.168.178.115 fda7:7b49:a70a:0:be24:11ff:fe3c:bfbe 2a02:8071:5301:a0a0:be24:11ff:fe3c:bfbe fe80::be24:11ff:fe3c:bfbe (Direct Routing)
  Mode:                 SNAT
  Backend Selection:    Random
  Session Affinity:     Enabled
  NAT46/64 Support:     Disabled
  XDP Acceleration:     Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
  Annotations:
  - service.cilium.io/node
  - service.cilium.io/node-selector
  - service.cilium.io/proxy-delegation
  - service.cilium.io/src-ranges-policy
  - service.cilium.io/type
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoints                     65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  Ratelimit metrics             64
  NAT                           131072
  Neighbor table                131072
  Endpoint policy               16384
  Policy stats                  65536
  Session affinity              65536
  Sock reverse NAT              65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
k8s-client-connection-keep-alive:30s
bpf-lb-algorithm-annotation:false
procfs:/host/proc
dnsproxy-lock-count:131
proxy-initial-fetch-timeout:30
cni-chaining-target:
enable-cilium-health-api-server-access:
envoy-policy-restore-timeout:3m0s
kube-proxy-replacement:true
proxy-prometheus-port:0
eni-subnet-ids:
bpf-lb-dsr-dispatch:opt
identity-heartbeat-timeout:30m0s
external-envoy-proxy:true
identity-allocation-sync-interval:5m0s
enable-encryption-strict-mode-egress:false
identity-allocation-timeout:2m0s
bpf-lb-algorithm:random
eni-exclude-interface-tags:
tofqdns-idle-connection-grace-period:0s
alibabacloud-vswitches:
enable-host-legacy-routing:false
l2-pod-announcements-interface-pattern:
proxy-max-connection-duration-seconds:0
bpf-ct-timeout-regular-tcp:2h13m20s
derive-masq-ip-addr-from-device:
lb-state-file:
eni-use-primary-address:false
vtep-sync-interval:1m0s
enable-hubble-open-metrics:false
bpf-root:/sys/fs/bpf
enable-cilium-api-server-access:
policy-cidr-match-mode:
http-retry-timeout:0
hubble-event-buffer-capacity:4095
auto-direct-node-routes:false
ipv6-pod-subnets:
ipv4-range:auto
ipv4-service-loopback-address:169.254.42.1
pprof-block-profile-rate:0
http-retry-count:3
enable-bbr-hostns-only:false
hubble-redact-http-headers-deny:
dnsproxy-socket-linger-timeout:10
enable-sctp:false
enable-no-service-endpoints-routable:true
install-iptables-rules:true
cni-chaining-mode:none
disable-iptables-feeder-rules:
install-no-conntrack-iptables-rules:false
hubble-redact-http-userinfo:true
bpf-events-policy-verdict-enabled:true
enable-xdp-prefilter:false
enable-nat46x64-gateway:false
envoy-access-log-enabled:true
bpf-fragments-map-max:8192
enable-ciliumnode-crd:true
hubble-drop-events-reasons:
ignore-flags-drift-checker:
lb-state-file-interval:1s
agent-labels:
label-prefix-file:
socket-path:/var/run/cilium/cilium.sock
bpf-nat-global-max:524288
envoy-xds-mode:ads
exclude-local-address:
bpf-lb-ipip-sock-mark:false
enable-k8s-cluster-network-policy:false
enable-node-selector-labels:false
enable-unreachable-routes:false
ipam-multi-pool-pre-allocation:
mesh-auth-mutual-listener-port:0
config-dir:/tmp/cilium/config-map
hive-log-threshold:100ms
vtep-mask:
k8s-client-connection-timeout:30s
mesh-auth-spire-admin-socket:
config:
proxy-max-active-downstream-connections:50000
enable-stale-cilium-endpoint-cleanup:true
k8s-heartbeat-timeout:30s
enable-ipv4:true
agent-health-port:9879
bpf-lb-enable-wildcard-entries:true
hubble-socket-path:/var/run/cilium/hubble.sock
trace-payloadlen-overlay:192
fixed-identity-mapping:
enable-ipv4-big-tcp:false
monitor-aggregation-flags:all
policy-secrets-namespace:cilium-secrets
cluster-health-port:4240
multicast-enabled:false
enable-identity-mark:true
enable-k8s-networkpolicy:true
enable-node-ipam:false
envoy-secrets-namespace:
envoy-http-upstream-linger-timeout:-1
ip-tracing-option-type:0
encryption-strict-egress-cidr:
proxy-admin-port:0
exclude-node-label-patterns:
set-cilium-is-up-condition:true
identity-management-mode:agent
enable-bpf-tproxy:false
endpoint-regen-interval:2m0s
enable-gateway-api:false
local-router-ipv4:
enable-drift-checker:true
enable-non-default-deny-policies:true
fqdn-regex-compile-lru-size:1024
direct-routing-device:
tunnel-port:0
tofqdns-proxy-port:0
http-idle-timeout:0
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
srv6-encap-mode:reduced
proxy-max-concurrent-retries:128
agent-liveness-update-interval:1s
hubble-redact-http-urlquery:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
vtep-cidr:
k8s-namespace:kube-system
ipv6-cluster-alloc-cidr:f00d::/64
proxy-portrange-max:20000
tunnel-source-port-range:0-0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-envoy-config:false
hubble-metrics-server-tls-cert-file:
enable-standalone-dns-proxy:false
metrics:
hubble-export-denylist:
proxy-idle-timeout-seconds:60
proxy-xff-num-trusted-hops-ingress:0
enable-endpoint-lockdown-on-policy-overflow:false
enable-route-mtu-for-cni-chaining:false
enable-ipv4-fragment-tracking:true
envoy-config-retry-interval:15s
policy-accounting:true
egress-gateway-reconciliation-trigger-interval:1s
clustermesh-cache-ttl:0s
mesh-auth-rotated-identities-queue-size:1024
cni-log-file:/var/run/cilium/cilium-cni.log
eni-subnet-tags:
proxy-gid:1337
enable-tracing:false
hubble-event-queue-size:0
kvstore-max-consecutive-quorum-errors:2
bpf-sock-rev-map-max:0
hubble-export-file-compress:false
hubble-export-file-path:
enable-gops:true
enable-ipsec:false
proxy-connect-timeout:2
allow-localhost:auto
monitor-queue-size:0
egress-masquerade-interfaces:
eni-disable-prefix-delegation:false
bpf-lb-source-range-all-types:false
k8s-require-ipv6-pod-cidr:false
route-metric:0
custom-cni-conf:false
k8s-client-burst:20
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
max-controller-interval:0
bpf-policy-stats-map-max:65536
enable-ipsec-key-watcher:true
k8s-kubeconfig-path:
ipv6-node:auto
bpf-map-event-buffers:
controller-group-metrics:
hubble-export-file-max-backups:5
eni-first-interface-index:0
shell-sock-path:/var/run/cilium/shell.sock
enable-hubble:true
enable-policy-secrets-sync:true
ipam-default-ip-pool:default
debug-verbose:
bpf-neigh-global-max:524288
wireguard-track-all-ips-fallback:false
ipv4-node:auto
policy-secrets-only-from-secrets-namespace:true
bpf-lb-mode-annotation:false
enable-active-connection-tracking:false
ztunnel-endpoint-event-channel-buffer-size:1
bpf-ct-timeout-regular-tcp-syn:1m0s
gops-port:9890
operator-api-serve-addr:127.0.0.1:9234
bpf-lb-sock:false
kvstore-lease-ttl:15m0s
clustermesh-mcs-api-install-crds:true
ipam:kubernetes
install-uplink-routes-for-delegated-ipam:false
use-cilium-internal-ip-for-ipsec:false
policy-trigger-interval:1s
read-cni-conf:
kvstore-opt:
enable-ip-masq-agent:false
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-lb-rss-ipv6-src-cidr:
tunnel-protocol:vxlan
enable-auto-protect-node-port-range:true
alibabacloud-security-group-tags:
enable-dynamic-source-lookup-nodeport:false
cni-exclusive:false
ipv6-mcast-device:
bpf-lb-service-map-max:0
monitor-aggregation-interval:5s
version:false
eni-security-groups:
enable-l2-announcements:false
bpf-lb-rss-ipv4-src-cidr:
hubble-export-aggregation-interval:0s
preallocate-bpf-maps:false
kvstore:
dnsproxy-lock-timeout:500ms
proxy-portrange-min:10000
allow-unsafe-policy-skb-usage:false
synchronize-k8s-nodes:true
azure-interface-name:
bpf-ct-timeout-service-tcp:2h13m20s
operator-prometheus-serve-addr::9963
annotate-k8s-node:false
tofqdns-pre-cache:
lrp-address-matcher-cidrs:
hubble-lost-event-send-interval:1s
enable-tcx:true
http-request-timeout:3600
trace-payloadlen:128
disable-endpoint-crd:false
endpoint-gc-interval:5m0s
http-stream-idle-timeout:300
pprof-address:localhost
prepend-iptables-chains:true
pprof:false
enable-extended-ip-protocols:false
log-system-load:false
bpf-lb-sock-hostns-only:true
nat-map-stats-entries:32
restore:true
node-port-range:
hubble-dynamic-metrics-config-path:
identity-restore-grace-period:30s
cluster-name:default
hubble-redact-http-headers-allow:
enable-xt-socket-fallback:true
cluster-id:0
enable-metrics:true
hubble-drop-events:false
enable-remote-node-masquerade:false
node-labels:
config-sources-overrides:{"allowConfigKeys":[],"denyConfigKeys":[]}
hubble-export-fieldmask:
ipsec-key-rotation-duration:5m0s
bpf-lb-acceleration:disabled
enable-source-ip-verification:true
hubble-redact-enabled:false
crd-wait-timeout:5m0s
remove-cilium-node-taints:true
auto-create-cilium-node-resource:true
routing-mode:tunnel
vtep-mac:
proxy-cluster-max-connections:1024
hubble-export-allowlist:
proxy-xff-num-trusted-hops-egress:0
bpf-policy-map-pressure-metrics-threshold:0.1
mesh-auth-queue-size:1024
enable-masquerade-to-route-source:false
kube-proxy-replacement-healthz-bind-address:
hubble-drop-events-extended:false
hubble-metrics-server-tls-key-file:
encryption-strict-egress-allow-remote-node-identities:false
enable-ipv6-fragment-tracking:true
endpoint-queue-size:25
enable-endpoint-routes:false
enable-host-firewall:false
keep-config:false
ipam-pre-allocate:0
identity-gc-interval:15m0s
bpf-lb-source-range-map-max:0
bpf-distributed-lru:false
tofqdns-enable-dns-compression:true
enable-egress-gateway:false
bpf-events-default-rate-limit:0
ipam-min-allocate:0
hubble-metrics-server-enable-tls:false
ipam-static-ip-tags:
enable-local-redirect-policy:false
enable-health-check-nodeport:true
hubble-skip-unknown-cgroup-ids:true
enable-ipv4-masquerade:true
alibabacloud-vswitch-tags:
lb-sock-terminate-all-protos:false
enable-icmp-rules:true
mtu:0
encrypt-node:false
boot-id-file:/proc/sys/kernel/random/boot_id
allocator-list-timeout:3m0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-ipv6-big-tcp:false
bpf-ct-timeout-service-any:1m0s
enable-encryption-strict-mode-ingress:false
enable-k8s:true
l2-announcements-renew-deadline:5s
vtep-endpoint:
datapath-plugins-state-dir:/var/run/cilium/plugins
fib-table-id-annotation:false
enable-bpf-masquerade:false
endpoint-policy-update-timeout:10s
mesh-auth-mutual-connect-timeout:5s
static-cnp-path:
conntrack-gc-interval:0s
container-ip-local-reserved-ports:auto
tofqdns-preallocate-identities:true
datapath-mode:veth
enable-ztunnel:false
bpf-ct-global-tcp-max:524288
cilium-endpoint-gc-interval:5m0s
mesh-auth-enabled:false
standalone-dns-proxy-server-port:10095
envoy-log:
http-max-grpc-timeout:0
bpf-events-drop-enabled:true
proxy-cluster-max-pending-requests:1024
wireguard-persistent-keepalive:0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
cmdref:
ipv4-pod-subnets:
mesh-auth-gc-interval:5m0s
enable-l2-pod-announcements:false
hubble-listen-address::4244
config-sources:[{"kind":"config-map","namespace":"kube-system","name":"cilium-config"}]
connectivity-probe-frequency-ratio:0.5
default-lb-service-ipam:lbipam
dnsproxy-enable-transparent-mode:true
bypass-ip-availability-upon-restore:false
envoy-keep-cap-netbindservice:false
hive-start-timeout:5m0s
mke-cgroup-mount:
enable-ipv6-masquerade:true
max-connected-clusters:255
hubble-flowlogs-config-path:
bpf-lb-map-max:65536
monitor-aggregation:medium
hubble-disable-tls:false
debug:false
bpf-lb-nat46x64:false
hubble-network-policy-correlation-enabled:true
ingress-secrets-namespace:
conntrack-gc-max-interval:0s
cgroup-root:/run/cilium/cgroupv2
ipam-cilium-node-update-rate:15s
bpf-node-map-max:16384
nodes-gc-interval:5m0s
enable-ipv6:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
tofqdns-min-ttl:0
cni-external-routing:false
iptables-random-fully:false
bgp-router-id-allocation-ip-pool:
vlan-bpf-bypass:
ipv4-service-range:auto
lb-init-wait-timeout:1m0s
bpf-ct-global-any-max:262144
bpf-lb-rev-nat-map-max:0
enable-bgp-legacy-origin-attribute:false
clustermesh-service-v2:prefer-legacy
subnet-topology:
endpoint-bpf-prog-watchdog-interval:30s
hubble-monitor-events:
lb-retry-backoff-max:1m0s
status-collector-warning-threshold:15s
enable-bpf-clock-probe:false
bpf-ct-timeout-service-tcp-grace:1m0s
eni-security-group-tags:
clustermesh-enable-mcs-api:false
identity-allocation-mode:crd
mesh-auth-signal-backoff-duration:1s
ipam-max-allocate:0
eni-delete-on-termination:true
k8s-sync-timeout:3m0s
direct-routing-skip-unreachable:false
enable-bgp-control-plane-status-report:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
pprof-port:6060
clustermesh-default-global-namespace:true
hubble-drop-events-rate-limit:1
proxy-cluster-max-requests:1024
hubble-export-file-max-size-mb:10
envoy-base-id:0
alibabacloud-security-groups:
enable-cilium-endpoint-slice:false
metrics-sampling-interval:5m
envoy-node-locality-enabled:false
enable-dynamic-lifecycle-manager:false
enable-ipv6-ndp:false
egress-gateway-policy-map-max:16384
bpf-events-trace-enabled:true
enable-ipip-termination:false
policy-deny-response:none
enable-well-known-identities:false
gateway-api-secrets-namespace:
http-normalize-path:true
lb-retry-backoff-min:1s
unmanaged-pod-watcher-interval:15s
tofqdns-proxy-response-max-delay:100ms
envoy-access-log-buffer-size:4096
api-rate-limit:
only-masquerade-default-pool:false
enable-dynamic-config:true
tofqdns-endpoint-max-ip-per-hostname:1000
pprof-mutex-profile-fraction:0
set-cilium-node-taints:true
bpf-auth-map-max:524288
enable-wireguard:false
identity-max-jitter:30s
tofqdns-max-deferred-connection-deletes:10000
prometheus-serve-addr:
node-port-acceleration:disabled
trace-sock:true
enable-k8s-host-firewall-bypass:true
l2-announcements-lease-duration:15s
policy-audit-mode:false
force-device-detection:false
labels:
enable-local-node-route:true
lb-pressure-metrics-interval:5m0s
envoy-config-timeout:2m0s
enable-endpoint-health-checking:true
packetization-layer-pmtud-mode:blackhole
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-conntrack-accounting:false
lb-reflector-wait-time:500ms
disable-external-ip-mitigation:false
l2-announcements-retry-period:2s
dnsproxy-concurrency-processing-grace-period:0s
bgp-router-id-allocation-mode:default
identity-change-grace-period:5s
k8s-require-ipv4-pod-cidr:false
tofqdns-dns-reject-response-code:refused
log-driver:
hubble-metrics-server-tls-client-ca-files:
status-collector-probe-check-timeout:5m0s
status-collector-stackdump-path:/run/cilium/state/agent.stack.gz
bpf-lb-mode:snat
enable-health-check-loadbalancer-ip:false
enable-health-checking:true
envoy-default-log-level:
enable-monitor:true
proxy-max-requests-per-connection:0
lib-dir:/var/lib/cilium
health-check-icmp-failure-threshold:3
hubble-drop-events-interval:2m0s
agent-health-require-k8s-connectivity:true
clustermesh-sync-timeout:1m0s
ipv6-service-range:auto
dynamic-lifecycle-config:[]
enable-mke:false
use-full-tls-context:false
policy-default-local-cluster:true
dns-policy-unload-on-shutdown:false
enable-pmtu-discovery:false
clustermesh-enable-endpoint-sync:false
bpf-lb-maglev-table-size:16381
bpf-lb-external-clusterip:false
node-port-bind-protection:true
restored-proxy-ports-age-limit:15
enable-vtep:false
service-no-backend-response:reject
disable-envoy-version-check:false
enable-bbr:false
allow-icmp-frag-needed:true
enable-ipsec-xfrm-state-caching:true
hubble-export-fieldaggregate:
enable-l7-proxy:true
enable-policy:default
enable-service-topology:false
proxy-use-original-source-address:true
k8s-api-server-urls:
enable-cilium-network-policy:true
certificates-directory:/var/run/cilium/certs
ipv6-native-routing-cidr:
enable-l2-neigh-discovery:false
devices:
bpf-ct-timeout-regular-any:1m0s
bpf-lb-maglev-map-max:0
policy-queue-size:100
ipv4-native-routing-cidr:
hive-stop-timeout:1m0s
local-router-ipv6:
bpf-lb-affinity-map-max:0
hubble-prefer-ipv6:false
ipsec-key-file:
log-opt:
k8s-client-qps:10
ipv6-range:auto
bpf-ct-timeout-regular-tcp-fin:10s
nat-map-stats-interval:30s
prefer-ipv6:false
hubble-metrics:
state-dir:/var/run/cilium
dns-max-ips-per-restored-rule:1000
enable-ingress-controller:false
bpf-policy-map-max:16384
enable-lb-ipam:true
dnsproxy-concurrency-limit:0
iptables-lock-timeout:5s
enable-bandwidth-manager:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
nodeport-addresses:
bpf-policy-map-full-reconciliation-interval:15m0s
enable-cilium-clusterwide-network-policy:true
bpf-filter-priority:1
status-collector-interval:5s
hubble-metrics-server:
bpf-lb-sock-terminate-pod-connections:true
bpf-events-default-burst-limit:0
enable-srv6:false
local-max-addr-scope:254
ipv6-service-loopback-address:fe80::1
bpf-lb-service-backend-map-max:0
bpf-map-dynamic-size-ratio:0.0025
max-internal-timer-delay:0s
underlay-protocol:auto
enable-bgp-control-plane:false
status-collector-failure-threshold:1m0s
enable-datapath-plugins:false
enable-k8s-api-discovery:false
k8s-service-proxy-name:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                       IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                          
172        Disabled           Disabled          25785      gen:io.cilium.k8s.named-ports=grpc.TCP.4245                                              10.244.2.154   ready   
                                                           k8s:app.kubernetes.io/name=hubble-relay                                                                         
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                            
                                                           k8s:helm.sh/chart=cilium-1.20.2                                                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=hubble-relay                                                                                        
461        Disabled           Disabled          1          reserved:host                                                                                           ready   
462        Disabled           Disabled          10824      gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081                                10.244.2.31    ready   
                                                           k8s:app.kubernetes.io/name=hubble-ui                                                                            
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                            
                                                           k8s:helm.sh/chart=cilium-1.20.2                                                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=hubble-ui                                                                                           
1075       Disabled           Disabled          4          reserved:health                                                                          10.244.2.84    ready   
1508       Disabled           Disabled          41104      gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181                10.244.2.11    ready   
                                                           gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                                 
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=kube-dns                                                                                            
```

#### BPF Policy Get 172

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    2145260   23643     0        0
Allow    Ingress     11         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -         -         0        0
Allow    Egress      0          ANY          NONE         disabled    48136     681       0        0
Allow    Egress      11         ANY          NONE         disabled    349       3         0        0
Allow    Egress      12         ANY          NONE         disabled    -         -         0        0
Allow    Egress      13         ANY          NONE         disabled    -         -         0        0
Allow    Egress      14         ANY          NONE         disabled    -         -         0        0

```


#### BPF CT List 172

```
Invalid argument: unknown type 172
```


#### Endpoint Get 172

```
[
  {
    "id": 172,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-172-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "eddd2473-7b9f-4048-9cf8-8a18af6af010"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-172",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:51:02.038Z",
            "success-count": 35
          },
          "uuid": "a4b6f3ec-98bb-4247-8829-ecc0705ffe61"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/hubble-relay-856fb9b979-qblz5",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T11:01:02.011Z",
            "success-count": 1
          },
          "uuid": "6f3e1f70-4dae-45f4-b01b-ea69608f16b7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-172",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.656Z",
            "success-count": 12
          },
          "uuid": "9cb51464-cbe9-45f6-ae31-fa56c81e3d0e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (172)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:52:02.729Z",
            "success-count": 1028
          },
          "uuid": "26964f48-0811-428a-8731-4dc2063bfca8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "565349be29079020cb906a880e8f4142c2a62efd67fd715c29fea2c7cf913dfb:eth0"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 25785,
        "labels": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:helm.sh/chart=cilium-1.20.2",
          "gen:io.cilium.k8s.named-ports=grpc.TCP.4245",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=856fb9b979"
        ],
        "realized": {},
        "security-relevant": [
          "gen:io.cilium.k8s.named-ports=grpc.TCP.4245",
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:helm.sh/chart=cilium-1.20.2",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:50:58Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 4245,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.2.154",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "02:f1:64:7b:a2:b6",
        "interface-index": 9,
        "interface-name": "lxcec1c90124299",
        "mac": "e6:51:02:69:e4:73"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 25785,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 25785,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 172

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 172

```
Timestamp              Status   State                   Message
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:08:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:08:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:06:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:06:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:04:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:04:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:02:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:02:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:00:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:00:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:58:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:58:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:56:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:56:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:54:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:54:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:52:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:52:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 25785

```
ID      LABELS
25785   gen:io.cilium.k8s.named-ports=grpc.TCP.4245
        k8s:app.kubernetes.io/name=hubble-relay
        k8s:app.kubernetes.io/part-of=cilium
        k8s:helm.sh/chart=cilium-1.20.2
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-relay

```


#### BPF Policy Get 461

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        0
Allow    Ingress     11         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -       -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -       -         0        0
Allow    Egress      0          ANY          NONE         disabled    -       -         0        0
Allow    Egress      11         ANY          NONE         disabled    -       -         0        0
Allow    Egress      12         ANY          NONE         disabled    -       -         0        0
Allow    Egress      13         ANY          NONE         disabled    -       -         0        0
Allow    Egress      14         ANY          NONE         disabled    -       -         0        0

```


#### BPF CT List 461

```
Invalid argument: unknown type 461
```


#### Endpoint Get 461

```
[
  {
    "id": 461,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-461-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "825345c1-7bf6-4642-8323-6f7a13409afd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-461",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:50:58.643Z",
            "success-count": 35
          },
          "uuid": "db865ab5-d295-483f-92f9-d3f98f8e8c4f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-461",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.259Z",
            "success-count": 12
          },
          "uuid": "095152ba-94cf-49a3-8ed7-c6132847a3f3"
        }
      ],
      "external-identifiers": {},
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host"
        ]
      },
      "labels": {
        "derived": [
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:50:58Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1a:7e:19:ea:11:c7",
        "interface-index": 4,
        "interface-name": "cilium_host",
        "mac": "1a:7e:19:ea:11:c7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 461

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 461

```
Timestamp              Status   State                   Message
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:08:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:08:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:06:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:06:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:04:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:04:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:02:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:02:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:00:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:00:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:58:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:58:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:56:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:56:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:54:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:54:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:52:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:52:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 462

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    1055775   12435     0        0
Allow    Ingress     11         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -         -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -         -         0        0
Allow    Egress      0          ANY          NONE         disabled    -         -         0        0
Allow    Egress      11         ANY          NONE         disabled    -         -         0        0
Allow    Egress      12         ANY          NONE         disabled    -         -         0        0
Allow    Egress      13         ANY          NONE         disabled    -         -         0        0
Allow    Egress      14         ANY          NONE         disabled    -         -         0        0

```


#### BPF CT List 462

```
Invalid argument: unknown type 462
```


#### Endpoint Get 462

```
[
  {
    "id": 462,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-462-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b2b91819-f232-4509-bb63-cd689d464a50"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-462",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:51:02.126Z",
            "success-count": 35
          },
          "uuid": "03c86125-dc32-4320-8574-98bf8c470b4f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/hubble-ui-6dcdfb579c-s4xpb",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T11:01:02.104Z",
            "success-count": 1
          },
          "uuid": "9fb2acfe-d616-4ad2-859d-cd613bfb4298"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-462",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.861Z",
            "success-count": 12
          },
          "uuid": "f71c2d73-67e9-4d33-bb89-28087de0b1e9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (462)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:52:02.843Z",
            "success-count": 1028
          },
          "uuid": "d568c0df-f15a-4c73-b018-f2bf0f3763f6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "035dd9220c5da0e3ea2ebd6e57a8ac42b7d2089aeef1e199d7b2179fe19fa006:eth0"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 10824,
        "labels": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:helm.sh/chart=cilium-1.20.2",
          "gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6dcdfb579c"
        ],
        "realized": {},
        "security-relevant": [
          "gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081",
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:helm.sh/chart=cilium-1.20.2",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:50:58Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 8090,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 8081,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.2.31",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7a:49:c7:96:28:f5",
        "interface-index": 11,
        "interface-name": "lxceafb1dbb20ff",
        "mac": "26:4a:27:0a:51:a7"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10824,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10824,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 462

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 462

```
Timestamp              Status   State                   Message
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:08:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:08:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:06:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:06:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:04:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:04:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:02:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:02:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:00:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:00:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:58:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:58:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:56:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:56:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:54:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:54:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:52:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:52:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 10824

```
ID      LABELS
10824   gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081
        k8s:app.kubernetes.io/name=hubble-ui
        k8s:app.kubernetes.io/part-of=cilium
        k8s:helm.sh/chart=cilium-1.20.2
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-ui

```


#### BPF Policy Get 1075

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    190470   2342      0        0
Allow    Ingress     11         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    -        -         0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0

```


#### BPF CT List 1075

```
Invalid argument: unknown type 1075
```


#### Endpoint Get 1075

```
[
  {
    "id": 1075,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-1075-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "dfeb19d7-daf8-4dab-b331-d59e6ce3738b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1075",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:50:59.692Z",
            "success-count": 35
          },
          "uuid": "d8f80b19-8f2d-4ffa-acd0-b8a4ca84fa2b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1075",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.632Z",
            "success-count": 12
          },
          "uuid": "fa6e46e7-957a-49a5-bba4-6888ca8de0c2"
        }
      ],
      "external-identifiers": {},
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:50:58Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.2.84",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0a:ef:0c:52:c3:e1",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "92:26:b9:95:01:dc"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1075

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1075

```
Timestamp              Status   State                   Message
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:08:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:08:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:06:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:06:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:04:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:04:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:02:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:02:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:00:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:00:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:58:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:58:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:56:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:56:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:54:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:54:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:52:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:52:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1508

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   COOKIE
Allow    Ingress     0          ANY          NONE         disabled    990535   11393     0        0
Allow    Ingress     11         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     12         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     13         ANY          NONE         disabled    -        -         0        0
Allow    Ingress     14         ANY          NONE         disabled    -        -         0        0
Allow    Egress      0          ANY          NONE         disabled    96732    1061      0        0
Allow    Egress      11         ANY          NONE         disabled    -        -         0        0
Allow    Egress      12         ANY          NONE         disabled    -        -         0        0
Allow    Egress      13         ANY          NONE         disabled    -        -         0        0
Allow    Egress      14         ANY          NONE         disabled    -        -         0        0

```


#### BPF CT List 1508

```
Invalid argument: unknown type 1508
```


#### Endpoint Get 1508

```
[
  {
    "id": 1508,
    "spec": {
      "label-configuration": {},
      "options": {
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s",
            "interval": "1s"
          },
          "name": "endpoint-1508-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "875fc54f-abfc-469c-bdbb-6f8bda75f34f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1508",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:51:02.173Z",
            "success-count": 35
          },
          "uuid": "a33f11f6-6800-46c6-9f96-87d7b5f81b4a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-559f6c778d-jc27s",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T11:01:02.150Z",
            "success-count": 1
          },
          "uuid": "253f0576-c063-4eab-b843-2195a8fac626"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1508",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:46:06.818Z",
            "success-count": 12
          },
          "uuid": "1629d056-1918-48a2-bc32-e2bd004bad41"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1508)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2026-10-10T13:52:02.878Z",
            "success-count": 1028
          },
          "uuid": "ce5a89a4-6cc1-4d5c-9ce1-237d0a82b70d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b71797b2c79bd3f43dd1c2e3d85fcd3332fb6fc5d519ed837fbae109a3a14def:eth0"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 41104,
        "labels": [
          "gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080",
          "gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=559f6c778d"
        ],
        "realized": {},
        "security-relevant": [
          "gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181",
          "gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: PeriodicRegeneration)",
          "state": "ready",
          "timestamp": "2026-10-10T13:50:58Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "liveness-probe",
          "port": 8080,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        },
        {
          "name": "readiness-probe",
          "port": 8181,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.2.11",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1a:56:8b:c4:ad:7f",
        "interface-index": 13,
        "interface-name": "lxcb94ae39e656d",
        "mac": "66:f9:11:7e:7b:00"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 41104,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "allowed-ingress-identities": [
            0,
            11,
            12,
            13,
            14
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 41104,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1508

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1508

```
Timestamp              Status   State                   Message
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:28:39Z   OK       ready                   Policy Map changes applied
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:08:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:08:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:08:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:06:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:06:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:06:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:04:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:04:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:04:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:02:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:02:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:02:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T13:00:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T13:00:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T13:00:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:58:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:58:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:58:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:56:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:56:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:56:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:54:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:54:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:54:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:52:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:52:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:52:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:50:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:48:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:46:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:46:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:46:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:44:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:44:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:44:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:42:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:42:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:42:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:40:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:40:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:40:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:38:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:36:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:36:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:36:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:34:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:34:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:34:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:32:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:32:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:32:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:30:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:28:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:28:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:28:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:26:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:26:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:26:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:24:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:24:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:24:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:22:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:20:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:20:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:20:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:18:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:16:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:14:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:12:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:12:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:12:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: PeriodicRegeneration)
2026-10-10T12:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2026-10-10T12:10:58Z   OK       regenerating            Regenerating endpoint: PeriodicRegeneration
2026-10-10T12:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to PeriodicRegeneration: periodic endpoint regeneration

```


#### Identity get 41104

```
ID      LABELS
41104   gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181
        gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=coredns
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend                Service Type   Backend                                  
1    10.96.0.1:443/TCP       ClusterIP      1 => 192.168.178.113:6443/TCP (active)   
2    10.96.0.10:53/TCP       ClusterIP      1 => 10.244.1.214:53/TCP (active)        
                                            2 => 10.244.2.11:53/TCP (active)         
3    10.96.0.10:53/UDP       ClusterIP      1 => 10.244.1.214:53/UDP (active)        
                                            2 => 10.244.2.11:53/UDP (active)         
4    10.96.0.10:9153/TCP     ClusterIP      1 => 10.244.1.214:9153/TCP (active)      
                                            2 => 10.244.2.11:9153/TCP (active)       
5    10.97.123.232:80/TCP    ClusterIP      1 => 10.244.2.31:8081/TCP (active)       
6    10.101.247.67:443/TCP   ClusterIP      1 => 192.168.178.115:4244/TCP (active)   
7    10.105.79.192:80/TCP    ClusterIP      1 => 10.244.2.154:4245/TCP (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00400000-03adb000 r-xp 00000000 00:37 510805                             /usr/bin/cilium-agent
03adb000-08271000 r--p 036db000 00:37 510805                             /usr/bin/cilium-agent
08271000-08397000 rw-p 07e71000 00:37 510805                             /usr/bin/cilium-agent
08397000-0a92f000 rw-p 00000000 00:00 0 
2e9570000000-2e9572800000 ---p 00000000 00:00 0                          [anon: Go: heap reservation]
2e9572800000-2e9578c00000 rw-p 00000000 00:00 0                          [anon: Go: heap]
2e9578c00000-2e957c000000 ---p 00000000 00:00 0                          [anon: Go: heap reservation]
7bdc8db4e000-7bdc8db8e000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8e24c000-7bdc8e28d000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
7bdc8e28d000-7bdc8e2ce000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
7bdc8e86a000-7bdc8e8aa000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8e8aa000-7bdc8e8ca000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdc8e8ca000-7bdc8e90a000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8e90e000-7bdc8e920000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8e92c000-7bdc8e93c000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdc8e940000-7bdc8e980000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8e984000-7bdc8e98c000 rw-p 00000000 00:00 0                          [anon: Go: GC span queue]
7bdc8e98c000-7bdc8e98e000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
7bdc8e98e000-7bdc8ea0e000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8ea0e000-7bdc8ea1e000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdc8ea1e000-7bdc8ea5e000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8ea5e000-7bdc8ea6e000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdc8ea6e000-7bdc8eaae000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8eaae000-7bdc8eabe000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdc8eabe000-7bdc8ead0000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8ead0000-7bdc8eae0000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdc8eae0000-7bdc8eda0000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdc8eda0000-7bdc8ef00000 rw-p 00000000 00:00 0                          [anon: Go: profiler hash buckets]
7bdc8ef00000-7bdc8f000000 rw-p 00000000 00:00 0                          [anon: Go: page alloc index]
7bdc8f000000-7bdc91000000 rw-p 00000000 00:00 0                          [anon: Go: heap index]
7bdc91000000-7bdca6d2a000 ---p 00000000 00:00 0                          [anon: Go: scavenge index]
7bdca6d2a000-7bdca6d2b000 rw-p 00000000 00:00 0                          [anon: Go: scavenge index]
7bdca6d2b000-7bdcb1000000 ---p 00000000 00:00 0                          [anon: Go: scavenge index]
7bdcb1000000-7bdcc6d2a000 ---p 00000000 00:00 0                          [anon: Go: page summary]
7bdcc6d2a000-7bdcc6d2b000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
7bdcc6d2b000-7bdcd3ba5000 ---p 00000000 00:00 0                          [anon: Go: page summary]
7bdcd3ba5000-7bdcd3ba6000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
7bdcd3ba6000-7bdcd5574000 ---p 00000000 00:00 0                          [anon: Go: page summary]
7bdcd5574000-7bdcd5575000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
7bdcd5575000-7bdcd5800000 ---p 00000000 00:00 0                          [anon: Go: page summary]
7bdcd5800000-7bdcd5801000 rw-s 00000000 00:11 1099                       anon_inode:bpf-map
7bdcd5801000-7bdcd5803000 rw-s 00000000 00:11 1099                       anon_inode:[perf_event]
7bdcd5803000-7bdcd5804000 rw-p 00000000 00:00 0                          [anon: Go: getrandom states]
7bdcd5804000-7bdcd5824000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdcd5828000-7bdcd583e000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdcd583e000-7bdcd584e000 rw-p 00000000 00:00 0                          [anon: Go: gc bits]
7bdcd584e000-7bdcd585e000 rw-p 00000000 00:00 0                          [anon: Go: allspans array]
7bdcd585e000-7bdcd5870000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdcd5870000-7bdcd591e000 ---p 00000000 00:00 0                          [anon: Go: page summary]
7bdcd591e000-7bdcd591f000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
7bdcd591f000-7bdcd5970000 ---p 00000000 00:00 0                          [anon: Go: page summary]
7bdcd5970000-7bdcd5990000 rw-p 00000000 00:00 0                          [anon: Go: page alloc]
7bdcd5990000-7bdcd59d0000 rw-p 00000000 00:00 0                          [anon: Go: immortal metadata]
7bdcd59d0000-7bdcd59d4000 r--p 00000000 00:00 0                          [vvar]
7bdcd59d4000-7bdcd59d6000 r--p 00000000 00:00 0                          [vvar_vclock]
7bdcd59d6000-7bdcd59d8000 r-xp 00000000 00:00 0                          [vdso]
7ffd55b54000-7ffd55b75000 rw-p 00000000 00:00 0                          [stack]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### Cilium encryption



#### Cilium version

```
1.20.2 e0dc92bd 2026-09-15T15:51:54Z go version go1.26.8 linux/amd64
```


#### Kernel version

```
7.0.0
```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=12) "10.244.2.226": (string) (len=6) "router",
  (string) (len=11) "10.244.2.84": (string) (len=6) "health",
  (string) (len=12) "10.244.2.154": (string) (len=41) "kube-system/hubble-relay-856fb9b979-qblz5",
  (string) (len=11) "10.244.2.31": (string) (len=38) "kube-system/hubble-ui-6dcdfb579c-s4xpb",
  (string) (len=11) "10.244.2.11": (string) (len=36) "kube-system/coredns-559f6c778d-jc27s"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=23) "default:192.168.178.115": (string) (len=7) "node-ip"
}

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

