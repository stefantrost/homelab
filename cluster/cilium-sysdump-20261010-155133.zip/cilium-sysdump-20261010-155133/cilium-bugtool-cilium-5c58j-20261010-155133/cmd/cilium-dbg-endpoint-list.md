ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                       IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                          
172        Disabled           Disabled          25785      gen:io.cilium.k8s.named-ports=grpc.TCP.4245                                              10.244.2.154   ready   
                                                           k8s:app.kubernetes.io/name=hubble-relay                                                                         
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                            
                                                           k8s:helm.sh/chart=cilium-1.20.2                                                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=hubble-relay                                                                                        
461        Disabled           Disabled          1          reserved:host                                                                                           ready   
462        Disabled           Disabled          10824      gen:io.cilium.k8s.named-ports=grpc.TCP.8090_http.TCP.8081                                10.244.2.31    ready   
                                                           k8s:app.kubernetes.io/name=hubble-ui                                                                            
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                            
                                                           k8s:helm.sh/chart=cilium-1.20.2                                                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=hubble-ui                                                                                           
1075       Disabled           Disabled          4          reserved:health                                                                          10.244.2.84    ready   
1508       Disabled           Disabled          41104      gen:io.cilium.k8s.named-ports-1=metrics.TCP.9153_readiness-probe.TCP.8181                10.244.2.11    ready   
                                                           gen:io.cilium.k8s.named-ports=dns.UDP.53_dns-tcp.TCP.53_liveness-probe.TCP.8080                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                      
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                        
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                                 
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                     
                                                           k8s:k8s-app=kube-dns                                                                                            
