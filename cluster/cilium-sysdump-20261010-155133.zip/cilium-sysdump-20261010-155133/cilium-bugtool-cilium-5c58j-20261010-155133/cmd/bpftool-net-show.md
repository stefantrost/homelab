xdp:

tc:
ens18(2) tcx/ingress cil_from_netdev prog_id 481 link_id 20 
ens18(2) tcx/egress cil_to_netdev prog_id 476 link_id 21 
cilium_net(3) tcx/ingress cil_to_host prog_id 465 link_id 19 
cilium_host(4) tcx/ingress cil_to_host prog_id 452 link_id 17 
cilium_host(4) tcx/egress cil_from_host prog_id 449 link_id 18 
cilium_vxlan(5) tcx/ingress cil_from_overlay prog_id 385 link_id 15 
cilium_vxlan(5) tcx/egress cil_to_overlay prog_id 383 link_id 16 
lxc_health(7) tcx/ingress cil_from_container prog_id 417 link_id 22 
lxcec1c90124299(9) tcx/ingress cil_from_container prog_id 423 link_id 23 
lxceafb1dbb20ff(11) tcx/ingress cil_from_container prog_id 440 link_id 25 
lxcb94ae39e656d(13) tcx/ingress cil_from_container prog_id 391 link_id 24 

flow_dissector:

netfilter:

