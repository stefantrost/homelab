bandwidth manager not enabled> Error while running 'cilium-dbg bpf bandwidth list':  exit status 1

