alloc: 61.56MB (64547696 bytes)
total-alloc: 1.61GB (1727200968 bytes)
sys: 108.52MB (113791862 bytes)
lookups: 0
mallocs: 20766611
frees: 20236166
heap-alloc: 61.56MB (64547696 bytes)
heap-sys: 95.75MB (100401152 bytes)
heap-idle: 20.23MB (21217280 bytes)
heap-in-use: 75.52MB (79183872 bytes)
heap-released: 14.59MB (15294464 bytes)
heap-objects: 530445
stack-in-use: 4.25MB (4456448 bytes)
stack-sys: 4.25MB (4456448 bytes)
stack-mspan-inuse: 1.06MB (1109600 bytes)
stack-mspan-sys: 1.14MB (1191360 bytes)
stack-mcache-inuse: 4.48KB (4592 bytes)
stack-mcache-sys: 15.70KB (16072 bytes)
other-sys: 651.07KB (666692 bytes)
gc-sys: 4.89MB (5125904 bytes)
next-gc: when heap-alloc >= 101.76MB (106702954 bytes)
last-gc: 2026-10-10 13:51:17.464404091 +0000 UTC
gc-pause-total: 11.651261ms
gc-pause: 60986
gc-pause-end: 1791640277464404091
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 6.58391059388563e-05
enable-gc: true
debug-gc: false
