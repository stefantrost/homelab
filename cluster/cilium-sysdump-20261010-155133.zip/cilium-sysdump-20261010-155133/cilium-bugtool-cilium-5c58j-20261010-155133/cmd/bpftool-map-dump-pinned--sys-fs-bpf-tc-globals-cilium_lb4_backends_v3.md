key: 0d 00 00 00  value: 0a f4 01 d6 00 35 06 00  00 00 00 00
key: 0e 00 00 00  value: 0a f4 02 0b 00 35 06 00  00 00 00 00
key: 12 00 00 00  value: 0a f4 02 0b 23 c1 06 00  00 00 00 00
key: 0c 00 00 00  value: 0a f4 02 9a 10 95 06 00  00 00 00 00
key: 01 00 00 00  value: c0 a8 b2 71 19 2b 06 00  00 00 00 00
key: 11 00 00 00  value: 0a f4 01 d6 23 c1 06 00  00 00 00 00
key: 10 00 00 00  value: 0a f4 02 0b 00 35 11 00  00 00 00 00
key: 09 00 00 00  value: c0 a8 b2 73 10 94 06 00  00 00 00 00
key: 0f 00 00 00  value: 0a f4 01 d6 00 35 11 00  00 00 00 00
key: 0b 00 00 00  value: 0a f4 02 1f 1f 91 06 00  00 00 00 00
Found 10 elements
