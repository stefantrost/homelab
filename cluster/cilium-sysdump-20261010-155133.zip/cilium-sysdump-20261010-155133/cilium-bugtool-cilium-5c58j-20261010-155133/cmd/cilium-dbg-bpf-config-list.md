KEY             VALUE
AgentLiveness   10310840987196
UTimeOffset     3499277376953125
