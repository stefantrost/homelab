Get "http://localhost/v1/debuginfo": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium-dbg debuginfo --output=markdown,json -f --output-directory=/tmp/cilium-bugtool-20261010-135248.848+0000-UTC-888230969/cmd':  exit status 1

