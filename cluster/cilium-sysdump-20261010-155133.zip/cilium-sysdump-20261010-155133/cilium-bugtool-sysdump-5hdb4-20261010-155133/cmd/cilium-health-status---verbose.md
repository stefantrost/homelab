Error: Cannot get status: Get "http://localhost/v1beta/status": dial unix /var/run/cilium/health.sock: connect: no such file or directory

> Error while running 'cilium-health status --verbose':  exit status 1

