Cannot find auth bpf map
