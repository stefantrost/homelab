2026/10/10 13:52:49 missing PID or address
> Error while running 'gops stats $(pidof cilium-agent)':  exit status 1

