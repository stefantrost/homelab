cp: cannot stat '/var/run/cilium/state': No such file or directory
> Error while running 'cp -r /var/run/cilium/state /tmp/cilium-bugtool-20261010-135248.848+0000-UTC-888230969/cmd/state':  exit status 1

