Error: Unable to open /sys/fs/bpf/tc/globals/cilium_ct4_global: loading pinned map /sys/fs/bpf/tc/globals/cilium_ct4_global: no such file or directory
> Error while running 'cilium-dbg bpf ct list --time-diff':  exit status 1

