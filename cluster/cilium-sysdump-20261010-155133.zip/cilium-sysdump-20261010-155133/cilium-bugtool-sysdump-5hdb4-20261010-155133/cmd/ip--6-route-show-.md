2a02:8071:5301:a0a0::/64 dev ens18 proto ra metric 1024 expires 6999sec pref medium
2a02:8071:5301:a0a0::/59 nhid 1190202035 via fe80::36e1:a9ff:fe62:6be6 dev ens18 proto ra metric 1024 expires 1599sec pref medium
fda7:7b49:a70a::/64 dev ens18 proto ra metric 1024 expires 6999sec pref medium
fda7:7b49:a70a::/64 nhid 1190202035 via fe80::36e1:a9ff:fe62:6be6 dev ens18 proto ra metric 1024 expires 1599sec pref medium
fe80::/64 dev ens18 proto kernel metric 256 pref medium
default nhid 1190202035 via fe80::36e1:a9ff:fe62:6be6 dev ens18 proto ra metric 1024 expires 1599sec pref medium
