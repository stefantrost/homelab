USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root           7 18.1  0.3 1269740 13276 ?       Ssl  13:52   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root          28  0.0  0.0   6760  3828 ?        R    13:52   0:00  \_ ps auxfw
root          30  0.0  0.0   4512  2968 ?        R    13:52   0:00  \_ bash -c ip a
root           1  0.1  0.1  16112  6828 ?        Ss   13:52   0:00 /bin/sleep 1d
