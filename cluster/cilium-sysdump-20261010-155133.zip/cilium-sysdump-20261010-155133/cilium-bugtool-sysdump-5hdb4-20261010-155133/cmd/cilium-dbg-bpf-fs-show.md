MountID:          1242
ParentID:         1232
Mounted State:    true
MountPoint:       /sys/fs/bpf
MountOptions:     rw,relatime
OptionFields:     [master:10]
FilesystemType:   bpf
MountSource:      bpf
SuperOptions:     rw,mode=700
