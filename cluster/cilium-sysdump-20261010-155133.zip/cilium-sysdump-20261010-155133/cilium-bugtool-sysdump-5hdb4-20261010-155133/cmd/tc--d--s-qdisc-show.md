qdisc noqueue 0: dev lo root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc pfifo_fast 0: dev ens18 root refcnt 2 bands 3 priomap 1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
 Sent 81137600 bytes 155876 pkt (dropped 0, overlimits 0 requeues 8) 
 backlog 0b 0p requeues 8
