 13:52:48 up  2:52,  0 users,  load average: 0.05, 0.13, 0.16
