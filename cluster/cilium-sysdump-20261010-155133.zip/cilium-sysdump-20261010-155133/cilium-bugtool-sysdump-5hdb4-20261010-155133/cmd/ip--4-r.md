default via 192.168.178.1 dev ens18 proto dhcp src 192.168.178.113 metric 1024 
192.168.178.0/24 dev ens18 proto kernel scope link src 192.168.178.113 metric 1024 
192.168.178.1 dev ens18 proto dhcp scope link src 192.168.178.113 metric 1024 
