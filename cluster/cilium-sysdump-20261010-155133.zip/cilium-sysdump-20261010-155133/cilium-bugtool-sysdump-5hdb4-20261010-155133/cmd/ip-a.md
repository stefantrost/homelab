1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether bc:24:11:48:8f:e6 brd ff:ff:ff:ff:ff:ff
    altname enp6s18
    altname enxbc2411488fe6
    inet 192.168.178.113/24 metric 1024 brd 192.168.178.255 scope global dynamic ens18
       valid_lft 853663sec preferred_lft 853663sec
    inet6 fda7:7b49:a70a:0:be24:11ff:fe48:8fe6/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7001sec preferred_lft 3401sec
    inet6 2a02:8071:5301:a0a0:be24:11ff:fe48:8fe6/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7001sec preferred_lft 3401sec
    inet6 fe80::be24:11ff:fe48:8fe6/64 scope link proto kernel_ll 
       valid_lft forever preferred_lft forever
