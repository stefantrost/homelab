top - 13:52:49 up  2:52,  0 users,  load average: 0.05, 0.13, 0.16
Tasks:   4 total,   2 running,   2 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.8 us, 33.3 sy,  0.0 ni, 38.1 id,  4.8 wa,  0.0 hi,  0.0 si,  0.0 st 
MiB Mem :   3843.4 total,   1833.8 free,   1110.2 used,   1141.2 buff/cache     
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2733.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      7 root      20   0 1270580  14416   9440 S   9.1   0.4   0:00.04 cilium-+
      1 root      20   0   16112   6828   5608 S   0.0   0.2   0:00.01 sleep
     39 root      20   0    7592   4984   3008 R   0.0   0.1   0:00.00 top
     86 root      20   0   16244   6720   5412 R   0.0   0.2   0:00.00 cat
