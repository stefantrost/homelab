Error: Cannot get ipcache entries. err: Get "http://localhost/v1/ip": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium-dbg ip list -n -o json':  exit status 1

