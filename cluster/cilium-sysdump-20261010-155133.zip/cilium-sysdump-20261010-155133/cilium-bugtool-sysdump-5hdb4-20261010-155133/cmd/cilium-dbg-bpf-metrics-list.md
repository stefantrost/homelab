error loading BPF metrics map: failed to load bpf map: no such file or directory
> Error while running 'cilium-dbg bpf metrics list':  exit status 1

