Get "http://localhost/v1/cluster/nodes": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium-dbg node list':  exit status 1

