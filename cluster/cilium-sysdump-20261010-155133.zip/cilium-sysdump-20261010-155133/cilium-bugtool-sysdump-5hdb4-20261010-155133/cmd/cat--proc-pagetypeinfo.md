Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable      0      0      0      0      0      0      0      1      0      0      0 
Node    0, zone      DMA, type      Movable      2      2      2      2      1      2      2      2      2      3      1 
Node    0, zone      DMA, type  Reclaimable      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type    Unmovable      0      0      1      0      1      6      3      0      0      1      0 
Node    0, zone    DMA32, type      Movable    819    569    243    183    159     79     40     23      9      5    339 
Node    0, zone    DMA32, type  Reclaimable      1      0      0      1      0      1      0      1      1      1      0 
Node    0, zone    DMA32, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone    DMA32, type          CMA      0      0      0      0      0      0      0      0      0      1     82 
Node    0, zone    DMA32, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable      1     15      7      2      7      1      0      1      5      4      0 
Node    0, zone   Normal, type      Movable      0      0      1      1      1      2      8      4      1      0      0 
Node    0, zone   Normal, type  Reclaimable      1      1      0      1      0      1      0      1      0      0      0 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      1      0      1      1      1      1      1      0      0      0      5 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA            1            7            0            0            0            0 
Node 0, zone    DMA32           11          804            4            0          165            0 
Node 0, zone   Normal           76          695           16            0          237            0 
