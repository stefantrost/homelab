2026-10-10T11:00:06,578919+00:00 Linux version 7.0.0-38-generic (buildd@lcy02-amd64-070) (x86_64-linux-gnu-gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0, GNU ld (GNU Binutils for Ubuntu) 2.46) #38-Ubuntu SMP PREEMPT_DYNAMIC Fri Sep  4 09:10:14 UTC 2026 (Ubuntu 7.0.0-38.38-generic 7.0.14)
2026-10-10T11:00:06,578919+00:00 Command line: BOOT_IMAGE=/vmlinuz-7.0.0-38-generic root=UUID=747687d9-c20c-41f8-bfb8-7f4a57910c51 ro console=tty1 console=ttyS0
2026-10-10T11:00:06,578919+00:00 KERNEL supported cpus:
2026-10-10T11:00:06,578919+00:00   Intel GenuineIntel
2026-10-10T11:00:06,578919+00:00   AMD AuthenticAMD
2026-10-10T11:00:06,578919+00:00   Hygon HygonGenuine
2026-10-10T11:00:06,578919+00:00   Centaur CentaurHauls
2026-10-10T11:00:06,578919+00:00   zhaoxin   Shanghai  
2026-10-10T11:00:06,578919+00:00 BIOS-provided physical RAM map:
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000002ffff]  System RAM
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000000030000-0x000000000004ffff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000000050000-0x000000000009efff]  System RAM
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000000009f000-0x000000000009ffff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [gap 0x00000000000a0000-0x00000000000fffff]
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000000100000-0x0000000000811fff]  System RAM
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000000812000-0x0000000000812fff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000000813000-0x000000007a1c3fff]  System RAM
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007a1c4000-0x000000007a1c6fff]  ACPI data
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007a1c7000-0x000000007bce5fff]  System RAM
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007bce6000-0x000000007bf65fff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007bf66000-0x000000007bf77fff]  ACPI data
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007bf78000-0x000000007bff7fff]  ACPI NVS
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007bff8000-0x000000007bffffff]  System RAM
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x000000007c000000-0x000000007fffffff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [gap 0x0000000080000000-0x00000000dfffffff]
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x00000000e0000000-0x00000000efffffff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [gap 0x00000000f0000000-0x00000000feffbfff]
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff]  device reserved
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [gap 0x00000000ff000000-0x00000000ffffffff]
2026-10-10T11:00:06,578919+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000017fffffff]  System RAM
2026-10-10T11:00:06,578919+00:00 NX (Execute Disable) protection: active
2026-10-10T11:00:06,578919+00:00 APIC: Static calls initialized
2026-10-10T11:00:06,578919+00:00 efi: EFI v2.7 by Proxmox distribution of EDK II
2026-10-10T11:00:06,578919+00:00 efi: ACPI=0x7bf77000 ACPI 2.0=0x7bf77014 SMBIOS=0x7bdcb000 MEMATTR=0x7a1cb118 MOKvar=0x7bd78000 INITRD=0x7a1cca18 RNG=0x7bf67018 
2026-10-10T11:00:06,578919+00:00 random: crng init done
2026-10-10T11:00:06,578919+00:00 SMBIOS 2.8 present.
2026-10-10T11:00:06,578919+00:00 DMI: QEMU Standard PC (Q35 + ICH9, 2009), BIOS 4.2026.08-1 08/26/2026
2026-10-10T11:00:06,578919+00:00 DMI: Memory slots populated: 1/1
2026-10-10T11:00:06,578919+00:00 secureboot: Secure boot disabled
2026-10-10T11:00:06,578919+00:00 Hypervisor detected: KVM
2026-10-10T11:00:06,578919+00:00 last_pfn = 0x7c000 max_arch_pfn = 0x400000000
2026-10-10T11:00:06,578919+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2026-10-10T11:00:06,578920+00:00 kvm-clock: using sched offset of 5956372384 cycles
2026-10-10T11:00:06,578921+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2026-10-10T11:00:06,578925+00:00 tsc: Detected 806.400 MHz processor
2026-10-10T11:00:06,579033+00:00 e820: update [mem 0x00000000-0x00000fff] System RAM ==> device reserved
2026-10-10T11:00:06,579037+00:00 e820: remove [mem 0x000a0000-0x000fffff] System RAM
2026-10-10T11:00:06,579046+00:00 last_pfn = 0x180000 max_arch_pfn = 0x400000000
2026-10-10T11:00:06,579081+00:00 MTRR map: 4 entries (2 fixed + 2 variable; max 18), built from 8 variable MTRRs
2026-10-10T11:00:06,579085+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2026-10-10T11:00:06,579130+00:00 last_pfn = 0x7c000 max_arch_pfn = 0x400000000
2026-10-10T11:00:06,586506+00:00 Using GB pages for direct mapping
2026-10-10T11:00:06,587016+00:00 secureboot: Secure boot disabled
2026-10-10T11:00:06,587018+00:00 RAMDISK: [mem 0x7252a000-0x74efcfff]
2026-10-10T11:00:06,587021+00:00 ACPI: Early table checksum verification disabled
2026-10-10T11:00:06,587024+00:00 ACPI: RSDP 0x000000007BF77014 000024 (v02 BOCHS )
2026-10-10T11:00:06,587028+00:00 ACPI: XSDT 0x000000007BF760E8 00005C (v01 BOCHS  BXPC     00000001      01000013)
2026-10-10T11:00:06,587034+00:00 ACPI: FACP 0x000000007BF6D000 0000F4 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:06,587038+00:00 ACPI: DSDT 0x000000007BF6E000 0067CD (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:06,587041+00:00 ACPI: FACS 0x000000007BFD5000 000040
2026-10-10T11:00:06,587043+00:00 ACPI: WSMT 0x000000007BF75000 000028 (v01 INTEL  EDK2     00000002      01000013)
2026-10-10T11:00:06,587045+00:00 ACPI: APIC 0x000000007BF6C000 000080 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:06,587048+00:00 ACPI: SSDT 0x000000007BF6B000 0000CA (v01 BOCHS  VMGENID  00000001 BXPC 00000001)
2026-10-10T11:00:06,587050+00:00 ACPI: MCFG 0x000000007BF6A000 00003C (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:06,587052+00:00 ACPI: WAET 0x000000007BF69000 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2026-10-10T11:00:06,587055+00:00 ACPI: BGRT 0x000000007BF68000 000038 (v01 INTEL  EDK2     00000002      01000013)
2026-10-10T11:00:06,587056+00:00 ACPI: Reserving FACP table memory at [mem 0x7bf6d000-0x7bf6d0f3]
2026-10-10T11:00:06,587058+00:00 ACPI: Reserving DSDT table memory at [mem 0x7bf6e000-0x7bf747cc]
2026-10-10T11:00:06,587058+00:00 ACPI: Reserving FACS table memory at [mem 0x7bfd5000-0x7bfd503f]
2026-10-10T11:00:06,587059+00:00 ACPI: Reserving WSMT table memory at [mem 0x7bf75000-0x7bf75027]
2026-10-10T11:00:06,587060+00:00 ACPI: Reserving APIC table memory at [mem 0x7bf6c000-0x7bf6c07f]
2026-10-10T11:00:06,587060+00:00 ACPI: Reserving SSDT table memory at [mem 0x7bf6b000-0x7bf6b0c9]
2026-10-10T11:00:06,587061+00:00 ACPI: Reserving MCFG table memory at [mem 0x7bf6a000-0x7bf6a03b]
2026-10-10T11:00:06,587062+00:00 ACPI: Reserving WAET table memory at [mem 0x7bf69000-0x7bf69027]
2026-10-10T11:00:06,587062+00:00 ACPI: Reserving BGRT table memory at [mem 0x7bf68000-0x7bf68037]
2026-10-10T11:00:06,587553+00:00 No NUMA configuration found
2026-10-10T11:00:06,587555+00:00 Faking a node at [mem 0x0000000000000000-0x000000017fffffff]
2026-10-10T11:00:06,587568+00:00 NODE_DATA(0) allocated [mem 0x17ffd3280-0x17fffdfff]
2026-10-10T11:00:06,592288+00:00 ACPI: PM-Timer IO Port: 0x608
2026-10-10T11:00:06,592306+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2026-10-10T11:00:06,592348+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2026-10-10T11:00:06,592351+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2026-10-10T11:00:06,592353+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2026-10-10T11:00:06,592354+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2026-10-10T11:00:06,592355+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2026-10-10T11:00:06,592356+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2026-10-10T11:00:06,592360+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2026-10-10T11:00:06,592371+00:00 e820: update [mem 0x79ccd000-0x79cf0fff] System RAM ==> device reserved
2026-10-10T11:00:06,592384+00:00 TSC deadline timer available
2026-10-10T11:00:06,592387+00:00 CPU topo: Max. logical packages:   1
2026-10-10T11:00:06,592388+00:00 CPU topo: Max. logical nodes:      1
2026-10-10T11:00:06,592389+00:00 CPU topo: Num. nodes per package:  1
2026-10-10T11:00:06,592391+00:00 CPU topo: Max. logical dies:       1
2026-10-10T11:00:06,592391+00:00 CPU topo: Max. dies per package:   1
2026-10-10T11:00:06,592394+00:00 CPU topo: Max. threads per core:   1
2026-10-10T11:00:06,592395+00:00 CPU topo: Num. cores per package:     2
2026-10-10T11:00:06,592396+00:00 CPU topo: Num. threads per package:   2
2026-10-10T11:00:06,592396+00:00 CPU topo: Allowing 2 present CPUs plus 0 hotplug CPUs
2026-10-10T11:00:06,592414+00:00 kvm-guest: APIC: eoi() replaced with kvm_guest_apic_eoi_write()
2026-10-10T11:00:06,592434+00:00 kvm-guest: KVM setup pv remote TLB flush
2026-10-10T11:00:06,592437+00:00 kvm-guest: setup PV sched yield
2026-10-10T11:00:06,592448+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2026-10-10T11:00:06,592450+00:00 PM: hibernation: Registered nosave memory: [mem 0x00030000-0x0004ffff]
2026-10-10T11:00:06,592451+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x000fffff]
2026-10-10T11:00:06,592452+00:00 PM: hibernation: Registered nosave memory: [mem 0x00812000-0x00812fff]
2026-10-10T11:00:06,592453+00:00 PM: hibernation: Registered nosave memory: [mem 0x79ccd000-0x79cf0fff]
2026-10-10T11:00:06,592454+00:00 PM: hibernation: Registered nosave memory: [mem 0x7a1c4000-0x7a1c6fff]
2026-10-10T11:00:06,592456+00:00 PM: hibernation: Registered nosave memory: [mem 0x7bce6000-0x7bff7fff]
2026-10-10T11:00:06,592457+00:00 PM: hibernation: Registered nosave memory: [mem 0x7c000000-0xffffffff]
2026-10-10T11:00:06,592458+00:00 [gap 0x80000000-0xdfffffff] available for PCI devices
2026-10-10T11:00:06,592459+00:00 Booting paravirtualized kernel on KVM
2026-10-10T11:00:06,592461+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2026-10-10T11:00:06,592483+00:00 Zone ranges:
2026-10-10T11:00:06,592483+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2026-10-10T11:00:06,592485+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2026-10-10T11:00:06,592486+00:00   Normal   [mem 0x0000000100000000-0x000000017fffffff]
2026-10-10T11:00:06,592487+00:00   Device   empty
2026-10-10T11:00:06,592488+00:00 Movable zone start for each node
2026-10-10T11:00:06,592490+00:00 Early memory node ranges
2026-10-10T11:00:06,592490+00:00   node   0: [mem 0x0000000000001000-0x000000000002ffff]
2026-10-10T11:00:06,592491+00:00   node   0: [mem 0x0000000000050000-0x000000000009efff]
2026-10-10T11:00:06,592492+00:00   node   0: [mem 0x0000000000100000-0x0000000000811fff]
2026-10-10T11:00:06,592493+00:00   node   0: [mem 0x0000000000813000-0x000000007a1c3fff]
2026-10-10T11:00:06,592494+00:00   node   0: [mem 0x000000007a1c7000-0x000000007bce5fff]
2026-10-10T11:00:06,592494+00:00   node   0: [mem 0x000000007bff8000-0x000000007bffffff]
2026-10-10T11:00:06,592495+00:00   node   0: [mem 0x0000000100000000-0x000000017fffffff]
2026-10-10T11:00:06,592497+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000017fffffff]
2026-10-10T11:00:06,592664+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2026-10-10T11:00:06,592667+00:00 On node 0, zone DMA: 32 pages in unavailable ranges
2026-10-10T11:00:06,592674+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2026-10-10T11:00:06,592681+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2026-10-10T11:00:06,596793+00:00 On node 0, zone DMA32: 3 pages in unavailable ranges
2026-10-10T11:00:06,596799+00:00 On node 0, zone DMA32: 786 pages in unavailable ranges
2026-10-10T11:00:06,601226+00:00 On node 0, zone Normal: 16384 pages in unavailable ranges
2026-10-10T11:00:06,601243+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:2 nr_cpu_ids:2 nr_node_ids:1
2026-10-10T11:00:06,601579+00:00 percpu: Embedded 85 pages/cpu s225280 r8192 d114688 u1048576
2026-10-10T11:00:06,601586+00:00 pcpu-alloc: s225280 r8192 d114688 u1048576 alloc=1*2097152
2026-10-10T11:00:06,601589+00:00 pcpu-alloc: [0] 0 1 
2026-10-10T11:00:06,601627+00:00 kvm-guest: PV spinlocks enabled
2026-10-10T11:00:06,601629+00:00 PV qspinlock hash table entries: 256 (order: 0, 4096 bytes, linear)
2026-10-10T11:00:06,601632+00:00 Kernel command line: BOOT_IMAGE=/vmlinuz-7.0.0-38-generic root=UUID=747687d9-c20c-41f8-bfb8-7f4a57910c51 ro console=tty1 console=ttyS0
2026-10-10T11:00:06,601681+00:00 printk: log buffer data + meta data: 262144 + 1114112 = 1376256 bytes
2026-10-10T11:00:06,602192+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2026-10-10T11:00:06,602476+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2026-10-10T11:00:06,602531+00:00 software IO TLB: area num 2.
2026-10-10T11:00:06,616145+00:00 Fallback order for Node 0: 0 
2026-10-10T11:00:06,616151+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1031272
2026-10-10T11:00:06,616152+00:00 Policy zone: Normal
2026-10-10T11:00:06,616161+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2026-10-10T11:00:06,624361+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2026-10-10T11:00:06,629427+00:00 ftrace: allocating 63997 entries in 252 pages
2026-10-10T11:00:06,629430+00:00 ftrace: allocated 252 pages with 6 groups
2026-10-10T11:00:06,630005+00:00 Dynamic Preempt: lazy
2026-10-10T11:00:06,630223+00:00 rcu: Preemptible hierarchical RCU implementation.
2026-10-10T11:00:06,630224+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=2.
2026-10-10T11:00:06,630226+00:00 	Trampoline variant of Tasks RCU enabled.
2026-10-10T11:00:06,630226+00:00 	Rude variant of Tasks RCU enabled.
2026-10-10T11:00:06,630226+00:00 	Tracing variant of Tasks RCU enabled.
2026-10-10T11:00:06,630227+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2026-10-10T11:00:06,630228+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2026-10-10T11:00:06,630237+00:00 RCU Tasks: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1 rcu_task_cpu_ids=2.
2026-10-10T11:00:06,630239+00:00 RCU Tasks Rude: Setting shift to 1 and lim to 1 rcu_task_cb_adjust=1 rcu_task_cpu_ids=2.
2026-10-10T11:00:06,635086+00:00 NR_IRQS: 524544, nr_irqs: 440, preallocated irqs: 16
2026-10-10T11:00:06,635295+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2026-10-10T11:00:06,635303+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2026-10-10T11:00:06,635388+00:00 Console: colour dummy device 80x25
2026-10-10T11:00:06,635391+00:00 printk: legacy console [tty1] enabled
2026-10-10T11:00:06,635674+00:00 printk: console [ttyS0] enabled
2026-10-10T11:00:06,815631+00:00 ACPI: Core revision 20251212
2026-10-10T11:00:06,816399+00:00 APIC: Switch to symmetric I/O mode setup
2026-10-10T11:00:06,817464+00:00 x2apic enabled
2026-10-10T11:00:06,818185+00:00 APIC: Switched APIC routing to: physical x2apic
2026-10-10T11:00:06,819152+00:00 kvm-guest: APIC: send_IPI_mask() replaced with kvm_send_ipi_mask()
2026-10-10T11:00:06,820411+00:00 kvm-guest: APIC: send_IPI_mask_allbutself() replaced with kvm_send_ipi_mask_allbutself()
2026-10-10T11:00:06,821990+00:00 kvm-guest: setup PV IPIs
2026-10-10T11:00:06,823447+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0xb9fb05486c, max_idle_ns: 440795231721 ns
2026-10-10T11:00:06,825246+00:00 Calibrating delay loop (skipped) preset value.. 1612.80 BogoMIPS (lpj=806400)
2026-10-10T11:00:06,826242+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2026-10-10T11:00:06,826242+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2026-10-10T11:00:06,826242+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2026-10-10T11:00:06,826242+00:00 mitigations: Enabled attack vectors: user_kernel, user_user, guest_host, guest_guest, SMT mitigations: auto
2026-10-10T11:00:06,826242+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl
2026-10-10T11:00:06,826242+00:00 Spectre V2 : Mitigation: Enhanced / Automatic IBRS
2026-10-10T11:00:06,826242+00:00 Register File Data Sampling: Mitigation: Clear Register File
2026-10-10T11:00:06,826242+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2026-10-10T11:00:06,826242+00:00 Spectre V2 : Enabling IBPB for BPF
2026-10-10T11:00:06,826242+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2026-10-10T11:00:06,826242+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2026-10-10T11:00:06,826242+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2026-10-10T11:00:06,826242+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2026-10-10T11:00:06,826242+00:00 x86/fpu: Supporting XSAVE feature 0x200: 'Protection Keys User registers'
2026-10-10T11:00:06,826242+00:00 x86/fpu: Supporting XSAVE feature 0x800: 'Control-flow User registers'
2026-10-10T11:00:06,826242+00:00 x86/fpu: Supporting XSAVE feature 0x1000: 'Control-flow Kernel registers (KVM only)'
2026-10-10T11:00:06,826242+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2026-10-10T11:00:06,826242+00:00 x86/fpu: xstate_offset[9]:  832, xstate_sizes[9]:    8
2026-10-10T11:00:06,826242+00:00 x86/fpu: xstate_offset[11]:  840, xstate_sizes[11]:   16
2026-10-10T11:00:06,826242+00:00 x86/fpu: xstate_offset[12]:  856, xstate_sizes[12]:   24
2026-10-10T11:00:06,826242+00:00 x86/fpu: Enabled xstate features 0x1a07, context size is 880 bytes, using 'compacted' format.
2026-10-10T11:00:06,826242+00:00 Freeing SMP alternatives memory: 56K
2026-10-10T11:00:06,826242+00:00 pid_max: default: 32768 minimum: 301
2026-10-10T11:00:06,826242+00:00 landlock: Up and running.
2026-10-10T11:00:06,826242+00:00 Yama: becoming mindful.
2026-10-10T11:00:06,826242+00:00 AppArmor: AppArmor initialized
2026-10-10T11:00:06,826242+00:00 AppArmor: AppArmor secmark mediation reserved: ready to be enabled
2026-10-10T11:00:06,826242+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2026-10-10T11:00:06,826242+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2026-10-10T11:00:06,826242+00:00 VFS: Finished mounting rootfs on nullfs
2026-10-10T11:00:06,826242+00:00 smpboot: CPU0: Intel(R) N100 (family: 0x6, model: 0xbe, stepping: 0x0)
2026-10-10T11:00:06,826501+00:00 Performance Events: Gracemont events, full-width counters, Intel PMU driver.
2026-10-10T11:00:06,827256+00:00 ... version:                   2
2026-10-10T11:00:06,828050+00:00 ... bit width:                 48
2026-10-10T11:00:06,828260+00:00 ... generic counters:          6
2026-10-10T11:00:06,829051+00:00 ... generic bitmap:            000000000000003f
2026-10-10T11:00:06,829250+00:00 ... fixed-purpose counters:    3
2026-10-10T11:00:06,830024+00:00 ... fixed-purpose bitmap:      0000000000000007
2026-10-10T11:00:06,830249+00:00 ... value mask:                0000ffffffffffff
2026-10-10T11:00:06,831250+00:00 ... max period:                00007fffffffffff
2026-10-10T11:00:06,832254+00:00 ... global_ctrl mask:          000000070000003f
2026-10-10T11:00:06,833446+00:00 signal: max sigframe size: 3632
2026-10-10T11:00:06,834307+00:00 rcu: Hierarchical SRCU implementation.
2026-10-10T11:00:06,834311+00:00 rcu: 	Max phase no-delay instances is 400.
2026-10-10T11:00:06,835331+00:00 Timer migration: 1 hierarchy levels; 8 children per group; 1 crossnode level
2026-10-10T11:00:06,836640+00:00 smp: Bringing up secondary CPUs ...
2026-10-10T11:00:06,837423+00:00 smpboot: x86: Booting SMP configuration:
2026-10-10T11:00:06,837430+00:00 .... node  #0, CPUs:      #1
2026-10-10T11:00:06,838293+00:00 smp: Brought up 1 node, 2 CPUs
2026-10-10T11:00:06,838293+00:00 smpboot: Total of 2 processors activated (3225.60 BogoMIPS)
2026-10-10T11:00:06,840318+00:00 Memory: 3003388K/4125088K available (23836K kernel code, 4957K rwdata, 16776K rodata, 5304K init, 5840K bss, 1113676K reserved, 0K cma-reserved)
2026-10-10T11:00:06,841509+00:00 devtmpfs: initialized
2026-10-10T11:00:06,841517+00:00 x86/mm: Memory block size: 128MB
2026-10-10T11:00:06,843115+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x7bf78000-0x7bff7fff] (524288 bytes)
2026-10-10T11:00:06,843122+00:00 posixtimers hash table entries: 1024 (order: 2, 16384 bytes, linear)
2026-10-10T11:00:06,843122+00:00 futex hash table entries: 512 (32768 bytes on 1 NUMA nodes, total 32 KiB, linear).
2026-10-10T11:00:06,843122+00:00 PM: RTC time: 11:00:06, date: 2026-10-10
2026-10-10T11:00:06,844242+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2026-10-10T11:00:06,844242+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2026-10-10T11:00:06,844242+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2026-10-10T11:00:06,844242+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2026-10-10T11:00:06,844242+00:00 audit: initializing netlink subsys (disabled)
2026-10-10T11:00:06,844423+00:00 thermal_sys: Registered thermal governor 'fair_share'
2026-10-10T11:00:06,844425+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2026-10-10T11:00:06,844428+00:00 thermal_sys: Registered thermal governor 'step_wise'
2026-10-10T11:00:06,844430+00:00 thermal_sys: Registered thermal governor 'user_space'
2026-10-10T11:00:06,844432+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2026-10-10T11:00:06,844446+00:00 audit: type=2000 audit(1791630007.334:1): state=initialized audit_enabled=0 res=1
2026-10-10T11:00:06,845253+00:00 cpuidle: using governor ladder
2026-10-10T11:00:06,846254+00:00 cpuidle: using governor menu
2026-10-10T11:00:06,848694+00:00 efi: Freeing EFI boot services memory: 48376K
2026-10-10T11:00:06,848702+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2026-10-10T11:00:06,848965+00:00 PCI: ECAM [mem 0xe0000000-0xefffffff] (base 0xe0000000) for domain 0000 [bus 00-ff]
2026-10-10T11:00:06,848987+00:00 PCI: Using configuration type 1 for base access
2026-10-10T11:00:06,849296+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2026-10-10T11:00:06,855274+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2026-10-10T11:00:06,855283+00:00 HugeTLB: 16380 KiB vmemmap can be freed for a 1.00 GiB page
2026-10-10T11:00:06,855286+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2026-10-10T11:00:06,855288+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2026-10-10T11:00:06,870734+00:00 fbcon: Taking over console
2026-10-10T11:00:06,870764+00:00 ACPI: Added _OSI(Module Device)
2026-10-10T11:00:06,870767+00:00 ACPI: Added _OSI(Processor Device)
2026-10-10T11:00:06,870770+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2026-10-10T11:00:06,872242+00:00 ACPI: 2 ACPI AML tables successfully acquired and loaded
2026-10-10T11:00:06,875258+00:00 ACPI: \_SB_: platform _OSC: OS support mask [006e7eff]
2026-10-10T11:00:06,875645+00:00 ACPI: Interpreter enabled
2026-10-10T11:00:06,875657+00:00 ACPI: PM: (supports S0 S5)
2026-10-10T11:00:06,875660+00:00 ACPI: Using IOAPIC for interrupt routing
2026-10-10T11:00:06,875660+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2026-10-10T11:00:06,875660+00:00 PCI: Ignoring E820 reservations for host bridge windows
2026-10-10T11:00:06,875819+00:00 ACPI: Enabled 3 GPEs in block 00 to 3F
2026-10-10T11:00:06,880242+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2026-10-10T11:00:06,881242+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI EDR HPX-Type3]
2026-10-10T11:00:06,881242+00:00 acpi PNP0A08:00: _OSC: platform does not support [PCIeHotplug LTR DPC]
2026-10-10T11:00:06,881242+00:00 acpi PNP0A08:00: _OSC: OS now controls [SHPCHotplug PME AER PCIeCapability]
2026-10-10T11:00:06,881932+00:00 PCI host bridge to bus 0000:00
2026-10-10T11:00:06,881940+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2026-10-10T11:00:06,881945+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2026-10-10T11:00:06,881947+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:06,881950+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:06,881953+00:00 pci_bus 0000:00: root bus resource [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:06,881956+00:00 pci_bus 0000:00: root bus resource [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:06,881960+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2026-10-10T11:00:06,882087+00:00 pci 0000:00:00.0: [8086:29c0] type 00 class 0x060000 conventional PCI endpoint
2026-10-10T11:00:06,883247+00:00 pci 0000:00:01.0: [1234:1111] type 00 class 0x030000 conventional PCI endpoint
2026-10-10T11:00:06,884242+00:00 pci 0000:00:01.0: BAR 0 [mem 0x80000000-0x80ffffff pref]
2026-10-10T11:00:06,884242+00:00 pci 0000:00:01.0: BAR 2 [mem 0x8224b000-0x8224bfff]
2026-10-10T11:00:06,884242+00:00 pci 0000:00:01.0: ROM [mem 0xffff0000-0xffffffff pref]
2026-10-10T11:00:06,884242+00:00 pci 0000:00:01.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2026-10-10T11:00:06,891194+00:00 pci 0000:00:1a.0: [8086:2937] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:06,891242+00:00 pci 0000:00:1a.0: BAR 4 [io  0x8100-0x811f]
2026-10-10T11:00:06,891460+00:00 pci 0000:00:1a.1: [8086:2938] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:06,892358+00:00 pci 0000:00:1a.1: BAR 4 [io  0x80e0-0x80ff]
2026-10-10T11:00:06,892790+00:00 pci 0000:00:1a.2: [8086:2939] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:06,893347+00:00 pci 0000:00:1a.2: BAR 4 [io  0x80c0-0x80df]
2026-10-10T11:00:06,893895+00:00 pci 0000:00:1a.7: [8086:293c] type 00 class 0x0c0320 conventional PCI endpoint
2026-10-10T11:00:06,893895+00:00 pci 0000:00:1a.7: BAR 0 [mem 0x8224a000-0x8224afff]
2026-10-10T11:00:06,893895+00:00 pci 0000:00:1b.0: [8086:293e] type 00 class 0x040300 conventional PCI endpoint
2026-10-10T11:00:06,894879+00:00 pci 0000:00:1b.0: BAR 0 [mem 0x82240000-0x82243fff]
2026-10-10T11:00:06,895242+00:00 pci 0000:00:1c.0: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:06,896242+00:00 pci 0000:00:1c.0: BAR 0 [mem 0x82249000-0x82249fff]
2026-10-10T11:00:06,896242+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:06,896242+00:00 pci 0000:00:1c.0:   bridge window [mem 0x82000000-0x821fffff]
2026-10-10T11:00:06,896242+00:00 pci 0000:00:1c.0:   bridge window [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:06,896242+00:00 pci 0000:00:1c.0: enabling Extended Tags
2026-10-10T11:00:06,896242+00:00 pci 0000:00:1c.1: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:06,897271+00:00 pci 0000:00:1c.1: BAR 0 [mem 0x82248000-0x82248fff]
2026-10-10T11:00:06,897328+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:06,897424+00:00 pci 0000:00:1c.1:   bridge window [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:06,898242+00:00 pci 0000:00:1c.1:   bridge window [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:06,898242+00:00 pci 0000:00:1c.1: enabling Extended Tags
2026-10-10T11:00:06,898242+00:00 pci 0000:00:1c.2: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:06,900242+00:00 pci 0000:00:1c.2: BAR 0 [mem 0x82247000-0x82247fff]
2026-10-10T11:00:06,900242+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:06,900242+00:00 pci 0000:00:1c.2:   bridge window [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:06,900242+00:00 pci 0000:00:1c.2:   bridge window [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:06,900242+00:00 pci 0000:00:1c.2: enabling Extended Tags
2026-10-10T11:00:06,901839+00:00 pci 0000:00:1c.3: [1b36:000c] type 01 class 0x060400 PCIe Root Port
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1c.3: BAR 0 [mem 0x82246000-0x82246fff]
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1c.3:   bridge window [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1c.3:   bridge window [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1c.3: enabling Extended Tags
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1d.0: [8086:2934] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:06,903242+00:00 pci 0000:00:1d.0: BAR 4 [io  0x80a0-0x80bf]
2026-10-10T11:00:06,904315+00:00 pci 0000:00:1d.1: [8086:2935] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:06,905288+00:00 pci 0000:00:1d.1: BAR 4 [io  0x8080-0x809f]
2026-10-10T11:00:06,905946+00:00 pci 0000:00:1d.2: [8086:2936] type 00 class 0x0c0300 conventional PCI endpoint
2026-10-10T11:00:06,906242+00:00 pci 0000:00:1d.2: BAR 4 [io  0x8060-0x807f]
2026-10-10T11:00:06,907250+00:00 pci 0000:00:1d.7: [8086:293a] type 00 class 0x0c0320 conventional PCI endpoint
2026-10-10T11:00:06,908242+00:00 pci 0000:00:1d.7: BAR 0 [mem 0x82245000-0x82245fff]
2026-10-10T11:00:06,908242+00:00 pci 0000:00:1e.0: [8086:244e] type 01 class 0x060401 conventional PCI bridge
2026-10-10T11:00:06,908242+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09] (subtractive decode)
2026-10-10T11:00:06,908242+00:00 pci 0000:00:1e.0:   bridge window [io  0x6000-0x7fff]
2026-10-10T11:00:06,908242+00:00 pci 0000:00:1e.0:   bridge window [mem 0x81000000-0x818fffff]
2026-10-10T11:00:06,908934+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:06,909242+00:00 pci 0000:00:1f.0: [8086:2918] type 00 class 0x060100 conventional PCI endpoint
2026-10-10T11:00:06,909520+00:00 pci 0000:00:1f.0: quirk: [io  0x0600-0x067f] claimed by ICH6 ACPI/GPIO/TCO
2026-10-10T11:00:06,910242+00:00 pci 0000:00:1f.2: [8086:2922] type 00 class 0x010601 conventional PCI endpoint
2026-10-10T11:00:06,911242+00:00 pci 0000:00:1f.2: BAR 4 [io  0x8040-0x805f]
2026-10-10T11:00:06,911242+00:00 pci 0000:00:1f.2: BAR 5 [mem 0x82244000-0x82244fff]
2026-10-10T11:00:06,911242+00:00 pci 0000:00:1f.3: [8086:2930] type 00 class 0x0c0500 conventional PCI endpoint
2026-10-10T11:00:06,918242+00:00 pci 0000:00:1f.3: BAR 4 [io  0x8000-0x803f]
2026-10-10T11:00:06,918599+00:00 acpiphp: Slot [0] registered
2026-10-10T11:00:06,919089+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:06,919643+00:00 acpiphp: Slot [0-2] registered
2026-10-10T11:00:06,920105+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:06,920612+00:00 acpiphp: Slot [0-3] registered
2026-10-10T11:00:06,921084+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:06,921084+00:00 acpiphp: Slot [0-4] registered
2026-10-10T11:00:06,921114+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:06,921242+00:00 pci_bus 0000:05: extended config space not accessible
2026-10-10T11:00:06,922344+00:00 acpiphp: Slot [0-5] registered
2026-10-10T11:00:06,922381+00:00 acpiphp: Slot [5] registered
2026-10-10T11:00:06,922423+00:00 acpiphp: Slot [6] registered
2026-10-10T11:00:06,922458+00:00 acpiphp: Slot [7] registered
2026-10-10T11:00:06,922491+00:00 acpiphp: Slot [8] registered
2026-10-10T11:00:06,922527+00:00 acpiphp: Slot [9] registered
2026-10-10T11:00:06,922573+00:00 acpiphp: Slot [10] registered
2026-10-10T11:00:06,922614+00:00 acpiphp: Slot [11] registered
2026-10-10T11:00:06,922645+00:00 acpiphp: Slot [12] registered
2026-10-10T11:00:06,922687+00:00 acpiphp: Slot [13] registered
2026-10-10T11:00:06,922720+00:00 acpiphp: Slot [14] registered
2026-10-10T11:00:06,922751+00:00 acpiphp: Slot [15] registered
2026-10-10T11:00:06,922784+00:00 acpiphp: Slot [16] registered
2026-10-10T11:00:06,922828+00:00 acpiphp: Slot [17] registered
2026-10-10T11:00:06,922861+00:00 acpiphp: Slot [18] registered
2026-10-10T11:00:06,922905+00:00 acpiphp: Slot [19] registered
2026-10-10T11:00:06,922948+00:00 acpiphp: Slot [20] registered
2026-10-10T11:00:06,922982+00:00 acpiphp: Slot [21] registered
2026-10-10T11:00:06,923013+00:00 acpiphp: Slot [22] registered
2026-10-10T11:00:06,923055+00:00 acpiphp: Slot [23] registered
2026-10-10T11:00:06,923089+00:00 acpiphp: Slot [24] registered
2026-10-10T11:00:06,923133+00:00 acpiphp: Slot [25] registered
2026-10-10T11:00:06,923174+00:00 acpiphp: Slot [26] registered
2026-10-10T11:00:06,923206+00:00 acpiphp: Slot [27] registered
2026-10-10T11:00:06,923238+00:00 acpiphp: Slot [28] registered
2026-10-10T11:00:06,923242+00:00 acpiphp: Slot [29] registered
2026-10-10T11:00:06,923242+00:00 acpiphp: Slot [30] registered
2026-10-10T11:00:06,923242+00:00 acpiphp: Slot [31] registered
2026-10-10T11:00:06,923242+00:00 pci 0000:05:01.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:06,929242+00:00 pci 0000:05:01.0: BAR 0 [mem 0x81800000-0x818000ff 64bit]
2026-10-10T11:00:06,929242+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:06,929242+00:00 pci 0000:05:01.0:   bridge window [io  0x7000-0x7fff]
2026-10-10T11:00:06,929242+00:00 pci 0000:05:01.0:   bridge window [mem 0x81600000-0x817fffff]
2026-10-10T11:00:06,929242+00:00 pci 0000:05:01.0:   bridge window [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:06,929242+00:00 pci 0000:05:02.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:06,930242+00:00 pci 0000:05:02.0: BAR 0 [mem 0x81801000-0x818010ff 64bit]
2026-10-10T11:00:06,930242+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:06,930242+00:00 pci 0000:05:02.0:   bridge window [mem 0x81400000-0x815fffff]
2026-10-10T11:00:06,930242+00:00 pci 0000:05:02.0:   bridge window [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:06,931242+00:00 pci 0000:05:03.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:06,935242+00:00 pci 0000:05:03.0: BAR 0 [mem 0x81802000-0x818020ff 64bit]
2026-10-10T11:00:06,935242+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:06,935242+00:00 pci 0000:05:03.0:   bridge window [mem 0x81200000-0x813fffff]
2026-10-10T11:00:06,935242+00:00 pci 0000:05:03.0:   bridge window [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:06,935242+00:00 pci 0000:05:04.0: [1b36:0001] type 01 class 0x060400 conventional PCI bridge
2026-10-10T11:00:06,936242+00:00 pci 0000:05:04.0: BAR 0 [mem 0x81803000-0x818030ff 64bit]
2026-10-10T11:00:06,936242+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:06,936242+00:00 pci 0000:05:04.0:   bridge window [io  0x6000-0x6fff]
2026-10-10T11:00:06,936242+00:00 pci 0000:05:04.0:   bridge window [mem 0x81000000-0x811fffff]
2026-10-10T11:00:06,936298+00:00 pci 0000:05:04.0:   bridge window [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:06,946539+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09] (subtractive decode)
2026-10-10T11:00:06,946713+00:00 pci 0000:00:1e.0:   bridge window [io  0x0000-0x0cf7 window] (subtractive decode)
2026-10-10T11:00:06,946728+00:00 pci 0000:00:1e.0:   bridge window [io  0x0d00-0xffff window] (subtractive decode)
2026-10-10T11:00:06,946732+00:00 pci 0000:00:1e.0:   bridge window [mem 0x000a0000-0x000bffff window] (subtractive decode)
2026-10-10T11:00:06,946739+00:00 pci 0000:00:1e.0:   bridge window [mem 0x80000000-0xdfffffff window] (subtractive decode)
2026-10-10T11:00:06,946743+00:00 pci 0000:00:1e.0:   bridge window [mem 0xf0000000-0xfebfffff window] (subtractive decode)
2026-10-10T11:00:06,946746+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7000000000-0x77ffffffff window] (subtractive decode)
2026-10-10T11:00:06,947242+00:00 pci_bus 0000:06: extended config space not accessible
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [8-2] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [18-2] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [0-6] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [1] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [2] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [3] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [4] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [5-2] registered
2026-10-10T11:00:06,947242+00:00 acpiphp: Slot [6-2] registered
2026-10-10T11:00:06,947265+00:00 acpiphp: Slot [7-2] registered
2026-10-10T11:00:06,947301+00:00 acpiphp: Slot [9-2] registered
2026-10-10T11:00:06,947345+00:00 acpiphp: Slot [10-2] registered
2026-10-10T11:00:06,947381+00:00 acpiphp: Slot [11-2] registered
2026-10-10T11:00:06,947422+00:00 acpiphp: Slot [12-2] registered
2026-10-10T11:00:06,947466+00:00 acpiphp: Slot [13-2] registered
2026-10-10T11:00:06,947513+00:00 acpiphp: Slot [14-2] registered
2026-10-10T11:00:06,947548+00:00 acpiphp: Slot [15-2] registered
2026-10-10T11:00:06,947585+00:00 acpiphp: Slot [16-2] registered
2026-10-10T11:00:06,947630+00:00 acpiphp: Slot [17-2] registered
2026-10-10T11:00:06,947677+00:00 acpiphp: Slot [19-2] registered
2026-10-10T11:00:06,947731+00:00 acpiphp: Slot [20-2] registered
2026-10-10T11:00:06,947775+00:00 acpiphp: Slot [21-2] registered
2026-10-10T11:00:06,947812+00:00 acpiphp: Slot [22-2] registered
2026-10-10T11:00:06,947847+00:00 acpiphp: Slot [23-2] registered
2026-10-10T11:00:06,947892+00:00 acpiphp: Slot [24-2] registered
2026-10-10T11:00:06,947936+00:00 acpiphp: Slot [25-2] registered
2026-10-10T11:00:06,947984+00:00 acpiphp: Slot [26-2] registered
2026-10-10T11:00:06,948019+00:00 acpiphp: Slot [27-2] registered
2026-10-10T11:00:06,948056+00:00 acpiphp: Slot [28-2] registered
2026-10-10T11:00:06,948092+00:00 acpiphp: Slot [29-2] registered
2026-10-10T11:00:06,948129+00:00 acpiphp: Slot [30-2] registered
2026-10-10T11:00:06,948177+00:00 acpiphp: Slot [31-2] registered
2026-10-10T11:00:06,951003+00:00 pci 0000:06:08.0: [1af4:1003] type 00 class 0x078000 conventional PCI endpoint
2026-10-10T11:00:06,952242+00:00 pci 0000:06:08.0: BAR 0 [io  0x7040-0x707f]
2026-10-10T11:00:06,952242+00:00 pci 0000:06:08.0: BAR 1 [mem 0x81601000-0x81601fff]
2026-10-10T11:00:06,952242+00:00 pci 0000:06:08.0: BAR 4 [mem 0x7070004000-0x7070007fff 64bit pref]
2026-10-10T11:00:06,955507+00:00 pci 0000:06:12.0: [1af4:1000] type 00 class 0x020000 conventional PCI endpoint
2026-10-10T11:00:06,957242+00:00 pci 0000:06:12.0: BAR 0 [io  0x7000-0x703f]
2026-10-10T11:00:06,957242+00:00 pci 0000:06:12.0: BAR 1 [mem 0x81600000-0x81600fff]
2026-10-10T11:00:06,957242+00:00 pci 0000:06:12.0: BAR 4 [mem 0x7070000000-0x7070003fff 64bit pref]
2026-10-10T11:00:06,957242+00:00 pci 0000:06:12.0: ROM [mem 0xfffc0000-0xffffffff pref]
2026-10-10T11:00:06,961298+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:06,962242+00:00 pci_bus 0000:07: extended config space not accessible
2026-10-10T11:00:06,962250+00:00 acpiphp: Slot [0-7] registered
2026-10-10T11:00:06,962296+00:00 acpiphp: Slot [1-2] registered
2026-10-10T11:00:06,962341+00:00 acpiphp: Slot [2-2] registered
2026-10-10T11:00:06,962394+00:00 acpiphp: Slot [3-2] registered
2026-10-10T11:00:06,962439+00:00 acpiphp: Slot [4-2] registered
2026-10-10T11:00:06,962484+00:00 acpiphp: Slot [5-3] registered
2026-10-10T11:00:06,962521+00:00 acpiphp: Slot [6-3] registered
2026-10-10T11:00:06,962555+00:00 acpiphp: Slot [7-3] registered
2026-10-10T11:00:06,962591+00:00 acpiphp: Slot [8-3] registered
2026-10-10T11:00:06,962633+00:00 acpiphp: Slot [9-3] registered
2026-10-10T11:00:06,962678+00:00 acpiphp: Slot [10-3] registered
2026-10-10T11:00:06,962714+00:00 acpiphp: Slot [11-3] registered
2026-10-10T11:00:06,962750+00:00 acpiphp: Slot [12-3] registered
2026-10-10T11:00:06,962785+00:00 acpiphp: Slot [13-3] registered
2026-10-10T11:00:06,962829+00:00 acpiphp: Slot [14-3] registered
2026-10-10T11:00:06,962874+00:00 acpiphp: Slot [15-3] registered
2026-10-10T11:00:06,962920+00:00 acpiphp: Slot [16-3] registered
2026-10-10T11:00:06,962964+00:00 acpiphp: Slot [17-3] registered
2026-10-10T11:00:06,963012+00:00 acpiphp: Slot [18-3] registered
2026-10-10T11:00:06,963047+00:00 acpiphp: Slot [19-3] registered
2026-10-10T11:00:06,963083+00:00 acpiphp: Slot [20-3] registered
2026-10-10T11:00:06,963131+00:00 acpiphp: Slot [21-3] registered
2026-10-10T11:00:06,963167+00:00 acpiphp: Slot [22-3] registered
2026-10-10T11:00:06,963202+00:00 acpiphp: Slot [23-3] registered
2026-10-10T11:00:06,963238+00:00 acpiphp: Slot [24-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [25-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [26-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [27-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [28-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [29-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [30-3] registered
2026-10-10T11:00:06,963242+00:00 acpiphp: Slot [31-3] registered
2026-10-10T11:00:06,972703+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:06,973092+00:00 pci_bus 0000:08: extended config space not accessible
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [0-8] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [1-3] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [2-3] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [3-3] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [4-3] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [5-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [6-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [7-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [8-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [9-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [10-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [11-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [12-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [13-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [14-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [15-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [16-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [17-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [18-4] registered
2026-10-10T11:00:06,973242+00:00 acpiphp: Slot [19-4] registered
2026-10-10T11:00:06,973256+00:00 acpiphp: Slot [20-4] registered
2026-10-10T11:00:06,973295+00:00 acpiphp: Slot [21-4] registered
2026-10-10T11:00:06,973338+00:00 acpiphp: Slot [22-4] registered
2026-10-10T11:00:06,973375+00:00 acpiphp: Slot [23-4] registered
2026-10-10T11:00:06,973426+00:00 acpiphp: Slot [24-4] registered
2026-10-10T11:00:06,973462+00:00 acpiphp: Slot [25-4] registered
2026-10-10T11:00:06,973507+00:00 acpiphp: Slot [26-4] registered
2026-10-10T11:00:06,973546+00:00 acpiphp: Slot [27-4] registered
2026-10-10T11:00:06,973584+00:00 acpiphp: Slot [28-4] registered
2026-10-10T11:00:06,973629+00:00 acpiphp: Slot [29-4] registered
2026-10-10T11:00:06,973667+00:00 acpiphp: Slot [30-4] registered
2026-10-10T11:00:06,973706+00:00 acpiphp: Slot [31-4] registered
2026-10-10T11:00:06,982280+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:06,983242+00:00 pci_bus 0000:09: extended config space not accessible
2026-10-10T11:00:06,983242+00:00 acpiphp: Slot [1-4] registered
2026-10-10T11:00:06,983242+00:00 acpiphp: Slot [0-9] registered
2026-10-10T11:00:06,983254+00:00 acpiphp: Slot [2-4] registered
2026-10-10T11:00:06,983291+00:00 acpiphp: Slot [3-4] registered
2026-10-10T11:00:06,983328+00:00 acpiphp: Slot [4-4] registered
2026-10-10T11:00:06,983375+00:00 acpiphp: Slot [5-5] registered
2026-10-10T11:00:06,983412+00:00 acpiphp: Slot [6-5] registered
2026-10-10T11:00:06,983457+00:00 acpiphp: Slot [7-5] registered
2026-10-10T11:00:06,983504+00:00 acpiphp: Slot [8-5] registered
2026-10-10T11:00:06,983541+00:00 acpiphp: Slot [9-5] registered
2026-10-10T11:00:06,983578+00:00 acpiphp: Slot [10-5] registered
2026-10-10T11:00:06,983617+00:00 acpiphp: Slot [11-5] registered
2026-10-10T11:00:06,983663+00:00 acpiphp: Slot [12-5] registered
2026-10-10T11:00:06,983709+00:00 acpiphp: Slot [13-5] registered
2026-10-10T11:00:06,983746+00:00 acpiphp: Slot [14-5] registered
2026-10-10T11:00:06,983783+00:00 acpiphp: Slot [15-5] registered
2026-10-10T11:00:06,983832+00:00 acpiphp: Slot [16-5] registered
2026-10-10T11:00:06,983869+00:00 acpiphp: Slot [17-5] registered
2026-10-10T11:00:06,983907+00:00 acpiphp: Slot [18-5] registered
2026-10-10T11:00:06,983952+00:00 acpiphp: Slot [19-5] registered
2026-10-10T11:00:06,983999+00:00 acpiphp: Slot [20-5] registered
2026-10-10T11:00:06,984044+00:00 acpiphp: Slot [21-5] registered
2026-10-10T11:00:06,984089+00:00 acpiphp: Slot [22-5] registered
2026-10-10T11:00:06,984127+00:00 acpiphp: Slot [23-5] registered
2026-10-10T11:00:06,984167+00:00 acpiphp: Slot [24-5] registered
2026-10-10T11:00:06,984204+00:00 acpiphp: Slot [25-5] registered
2026-10-10T11:00:06,984242+00:00 acpiphp: Slot [26-5] registered
2026-10-10T11:00:06,984242+00:00 acpiphp: Slot [27-5] registered
2026-10-10T11:00:06,984242+00:00 acpiphp: Slot [28-5] registered
2026-10-10T11:00:06,984242+00:00 acpiphp: Slot [29-5] registered
2026-10-10T11:00:06,984242+00:00 acpiphp: Slot [30-5] registered
2026-10-10T11:00:06,984242+00:00 acpiphp: Slot [31-5] registered
2026-10-10T11:00:06,984242+00:00 pci 0000:09:01.0: [1af4:1004] type 00 class 0x010000 conventional PCI endpoint
2026-10-10T11:00:06,986242+00:00 pci 0000:09:01.0: BAR 0 [io  0x6000-0x603f]
2026-10-10T11:00:06,986242+00:00 pci 0000:09:01.0: BAR 1 [mem 0x81000000-0x81000fff]
2026-10-10T11:00:06,986242+00:00 pci 0000:09:01.0: BAR 4 [mem 0x7040000000-0x7040003fff 64bit pref]
2026-10-10T11:00:06,996829+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:07,007757+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2026-10-10T11:00:07,007936+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2026-10-10T11:00:07,008112+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 10
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 10
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 11
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 11
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIA configured for IRQ 16
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIB configured for IRQ 17
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIC configured for IRQ 18
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSID configured for IRQ 19
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIE configured for IRQ 20
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIF configured for IRQ 21
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIG configured for IRQ 22
2026-10-10T11:00:07,008242+00:00 ACPI: PCI: Interrupt link GSIH configured for IRQ 23
2026-10-10T11:00:07,009581+00:00 iommu: Default domain type: Translated
2026-10-10T11:00:07,009587+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2026-10-10T11:00:07,010462+00:00 SCSI subsystem initialized
2026-10-10T11:00:07,010524+00:00 libata version 3.00 loaded.
2026-10-10T11:00:07,010546+00:00 ACPI: bus type USB registered
2026-10-10T11:00:07,010562+00:00 usbcore: registered new interface driver usbfs
2026-10-10T11:00:07,010569+00:00 usbcore: registered new interface driver hub
2026-10-10T11:00:07,010578+00:00 usbcore: registered new device driver usb
2026-10-10T11:00:07,010610+00:00 pps_core: LinuxPPS API ver. 1 registered
2026-10-10T11:00:07,010613+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2026-10-10T11:00:07,010618+00:00 PTP clock support registered
2026-10-10T11:00:07,012284+00:00 EDAC MC: Ver: 3.0.0
2026-10-10T11:00:07,013048+00:00 efivars: Registered efivars operations
2026-10-10T11:00:07,014100+00:00 NetLabel: Initializing
2026-10-10T11:00:07,014107+00:00 NetLabel:  domain hash size = 128
2026-10-10T11:00:07,014109+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2026-10-10T11:00:07,014130+00:00 NetLabel:  unlabeled traffic allowed by default
2026-10-10T11:00:07,014201+00:00 mctp: management component transport protocol core
2026-10-10T11:00:07,014204+00:00 NET: Registered PF_MCTP protocol family
2026-10-10T11:00:07,014217+00:00 PCI: Using ACPI for IRQ routing
2026-10-10T11:00:07,193741+00:00 PCI: pci_cache_line_size set to 64 bytes
2026-10-10T11:00:07,194515+00:00 e820: register RAM buffer resource [mem 0x0009f000-0x0009ffff]
2026-10-10T11:00:07,194530+00:00 e820: register RAM buffer resource [mem 0x00812000-0x008fffff]
2026-10-10T11:00:07,194533+00:00 e820: register RAM buffer resource [mem 0x79ccd000-0x7bffffff]
2026-10-10T11:00:07,194536+00:00 e820: register RAM buffer resource [mem 0x7a1c4000-0x7bffffff]
2026-10-10T11:00:07,194538+00:00 e820: register RAM buffer resource [mem 0x7bce6000-0x7bffffff]
2026-10-10T11:00:07,194670+00:00 pci 0000:00:01.0: vgaarb: setting as boot VGA device
2026-10-10T11:00:07,194679+00:00 pci 0000:00:01.0: vgaarb: bridge control possible
2026-10-10T11:00:07,194682+00:00 pci 0000:00:01.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2026-10-10T11:00:07,194691+00:00 vgaarb: loaded
2026-10-10T11:00:07,195382+00:00 clocksource: Switched to clocksource kvm-clock
2026-10-10T11:00:07,195588+00:00 VFS: Disk quotas dquot_6.6.0
2026-10-10T11:00:07,195600+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2026-10-10T11:00:07,198035+00:00 AppArmor: AppArmor Filesystem Enabled
2026-10-10T11:00:07,198076+00:00 acpi PNP0C01:00: Reserved [mem 0xe0000000-0xefffffff]
2026-10-10T11:00:07,198142+00:00 pnp: PnP ACPI init
2026-10-10T11:00:07,198907+00:00 pnp: PnP ACPI: found 4 devices
2026-10-10T11:00:07,205030+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2026-10-10T11:00:07,205111+00:00 NET: Registered PF_INET protocol family
2026-10-10T11:00:07,205168+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2026-10-10T11:00:07,220830+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2026-10-10T11:00:07,220886+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:07,220918+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2026-10-10T11:00:07,221018+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2026-10-10T11:00:07,221070+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2026-10-10T11:00:07,221134+00:00 MPTCP token hash table entries: 4096 (order: 5, 98304 bytes, linear)
2026-10-10T11:00:07,221164+00:00 UDP hash table entries: 2048 (order: 5, 131072 bytes, linear)
2026-10-10T11:00:07,221185+00:00 UDP-Lite hash table entries: 2048 (order: 5, 131072 bytes, linear)
2026-10-10T11:00:07,221235+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2026-10-10T11:00:07,221244+00:00 NET: Registered PF_XDP protocol family
2026-10-10T11:00:07,221252+00:00 pci 0000:06:12.0: ROM [mem 0xfffc0000-0xffffffff pref]: can't claim; no compatible bridge window
2026-10-10T11:00:07,221262+00:00 pci 0000:00:1c.0: bridge window [io  0x1000-0x0fff] to [bus 01] add_size 1000
2026-10-10T11:00:07,221266+00:00 pci 0000:00:1c.1: bridge window [io  0x1000-0x0fff] to [bus 02] add_size 1000
2026-10-10T11:00:07,221270+00:00 pci 0000:00:1c.2: bridge window [io  0x1000-0x0fff] to [bus 03] add_size 1000
2026-10-10T11:00:07,221273+00:00 pci 0000:00:1c.3: bridge window [io  0x1000-0x0fff] to [bus 04] add_size 1000
2026-10-10T11:00:07,221284+00:00 pci 0000:00:1c.0: bridge window [io  0x1000-0x1fff]: assigned
2026-10-10T11:00:07,221288+00:00 pci 0000:00:1c.1: bridge window [io  0x2000-0x2fff]: assigned
2026-10-10T11:00:07,221290+00:00 pci 0000:00:1c.2: bridge window [io  0x3000-0x3fff]: assigned
2026-10-10T11:00:07,221293+00:00 pci 0000:00:1c.3: bridge window [io  0x4000-0x4fff]: assigned
2026-10-10T11:00:07,221298+00:00 pci 0000:00:1c.0: PCI bridge to [bus 01]
2026-10-10T11:00:07,221322+00:00 pci 0000:00:1c.0:   bridge window [io  0x1000-0x1fff]
2026-10-10T11:00:07,222959+00:00 pci 0000:00:1c.0:   bridge window [mem 0x82000000-0x821fffff]
2026-10-10T11:00:07,223979+00:00 pci 0000:00:1c.0:   bridge window [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:07,226064+00:00 pci 0000:00:1c.1: PCI bridge to [bus 02]
2026-10-10T11:00:07,226090+00:00 pci 0000:00:1c.1:   bridge window [io  0x2000-0x2fff]
2026-10-10T11:00:07,227644+00:00 pci 0000:00:1c.1:   bridge window [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:07,228700+00:00 pci 0000:00:1c.1:   bridge window [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:07,230908+00:00 pci 0000:00:1c.2: PCI bridge to [bus 03]
2026-10-10T11:00:07,230934+00:00 pci 0000:00:1c.2:   bridge window [io  0x3000-0x3fff]
2026-10-10T11:00:07,232593+00:00 pci 0000:00:1c.2:   bridge window [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:07,234530+00:00 pci 0000:00:1c.2:   bridge window [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:07,235773+00:00 pci 0000:00:1c.3: PCI bridge to [bus 04]
2026-10-10T11:00:07,235809+00:00 pci 0000:00:1c.3:   bridge window [io  0x4000-0x4fff]
2026-10-10T11:00:07,236732+00:00 pci 0000:00:1c.3:   bridge window [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:07,237547+00:00 pci 0000:00:1c.3:   bridge window [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:07,239198+00:00 pci 0000:06:12.0: ROM [mem 0x81640000-0x8167ffff pref]: assigned
2026-10-10T11:00:07,239207+00:00 pci 0000:05:01.0: PCI bridge to [bus 06]
2026-10-10T11:00:07,239241+00:00 pci 0000:05:01.0:   bridge window [io  0x7000-0x7fff]
2026-10-10T11:00:07,240568+00:00 pci 0000:05:01.0:   bridge window [mem 0x81600000-0x817fffff]
2026-10-10T11:00:07,241686+00:00 pci 0000:05:01.0:   bridge window [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:07,244412+00:00 pci 0000:05:02.0: PCI bridge to [bus 07]
2026-10-10T11:00:07,247072+00:00 pci 0000:05:02.0:   bridge window [mem 0x81400000-0x815fffff]
2026-10-10T11:00:07,247653+00:00 pci 0000:05:02.0:   bridge window [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:07,248885+00:00 pci 0000:05:03.0: PCI bridge to [bus 08]
2026-10-10T11:00:07,249891+00:00 pci 0000:05:03.0:   bridge window [mem 0x81200000-0x813fffff]
2026-10-10T11:00:07,250683+00:00 pci 0000:05:03.0:   bridge window [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:07,252153+00:00 pci 0000:05:04.0: PCI bridge to [bus 09]
2026-10-10T11:00:07,252181+00:00 pci 0000:05:04.0:   bridge window [io  0x6000-0x6fff]
2026-10-10T11:00:07,253269+00:00 pci 0000:05:04.0:   bridge window [mem 0x81000000-0x811fffff]
2026-10-10T11:00:07,254049+00:00 pci 0000:05:04.0:   bridge window [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:07,256193+00:00 pci 0000:00:1e.0: PCI bridge to [bus 05-09]
2026-10-10T11:00:07,256245+00:00 pci 0000:00:1e.0:   bridge window [io  0x6000-0x7fff]
2026-10-10T11:00:07,258142+00:00 pci 0000:00:1e.0:   bridge window [mem 0x81000000-0x818fffff]
2026-10-10T11:00:07,259476+00:00 pci 0000:00:1e.0:   bridge window [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:07,265672+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2026-10-10T11:00:07,265689+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2026-10-10T11:00:07,265693+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:07,265696+00:00 pci_bus 0000:00: resource 7 [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:07,265699+00:00 pci_bus 0000:00: resource 8 [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:07,265702+00:00 pci_bus 0000:00: resource 9 [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:07,265707+00:00 pci_bus 0000:01: resource 0 [io  0x1000-0x1fff]
2026-10-10T11:00:07,265709+00:00 pci_bus 0000:01: resource 1 [mem 0x82000000-0x821fffff]
2026-10-10T11:00:07,265712+00:00 pci_bus 0000:01: resource 2 [mem 0x7000000000-0x700fffffff 64bit pref]
2026-10-10T11:00:07,265716+00:00 pci_bus 0000:02: resource 0 [io  0x2000-0x2fff]
2026-10-10T11:00:07,265718+00:00 pci_bus 0000:02: resource 1 [mem 0x81e00000-0x81ffffff]
2026-10-10T11:00:07,265721+00:00 pci_bus 0000:02: resource 2 [mem 0x7010000000-0x701fffffff 64bit pref]
2026-10-10T11:00:07,265724+00:00 pci_bus 0000:03: resource 0 [io  0x3000-0x3fff]
2026-10-10T11:00:07,265727+00:00 pci_bus 0000:03: resource 1 [mem 0x81c00000-0x81dfffff]
2026-10-10T11:00:07,265729+00:00 pci_bus 0000:03: resource 2 [mem 0x7020000000-0x702fffffff 64bit pref]
2026-10-10T11:00:07,265733+00:00 pci_bus 0000:04: resource 0 [io  0x4000-0x4fff]
2026-10-10T11:00:07,265735+00:00 pci_bus 0000:04: resource 1 [mem 0x81a00000-0x81bfffff]
2026-10-10T11:00:07,265738+00:00 pci_bus 0000:04: resource 2 [mem 0x7030000000-0x703fffffff 64bit pref]
2026-10-10T11:00:07,265741+00:00 pci_bus 0000:05: resource 0 [io  0x6000-0x7fff]
2026-10-10T11:00:07,265744+00:00 pci_bus 0000:05: resource 1 [mem 0x81000000-0x818fffff]
2026-10-10T11:00:07,265746+00:00 pci_bus 0000:05: resource 2 [mem 0x7040000000-0x707fffffff 64bit pref]
2026-10-10T11:00:07,265749+00:00 pci_bus 0000:05: resource 4 [io  0x0000-0x0cf7 window]
2026-10-10T11:00:07,265752+00:00 pci_bus 0000:05: resource 5 [io  0x0d00-0xffff window]
2026-10-10T11:00:07,265755+00:00 pci_bus 0000:05: resource 6 [mem 0x000a0000-0x000bffff window]
2026-10-10T11:00:07,265757+00:00 pci_bus 0000:05: resource 7 [mem 0x80000000-0xdfffffff window]
2026-10-10T11:00:07,265760+00:00 pci_bus 0000:05: resource 8 [mem 0xf0000000-0xfebfffff window]
2026-10-10T11:00:07,265763+00:00 pci_bus 0000:05: resource 9 [mem 0x7000000000-0x77ffffffff window]
2026-10-10T11:00:07,265766+00:00 pci_bus 0000:06: resource 0 [io  0x7000-0x7fff]
2026-10-10T11:00:07,265769+00:00 pci_bus 0000:06: resource 1 [mem 0x81600000-0x817fffff]
2026-10-10T11:00:07,265771+00:00 pci_bus 0000:06: resource 2 [mem 0x7070000000-0x707fffffff 64bit pref]
2026-10-10T11:00:07,265775+00:00 pci_bus 0000:07: resource 1 [mem 0x81400000-0x815fffff]
2026-10-10T11:00:07,265777+00:00 pci_bus 0000:07: resource 2 [mem 0x7060000000-0x706fffffff 64bit pref]
2026-10-10T11:00:07,265781+00:00 pci_bus 0000:08: resource 1 [mem 0x81200000-0x813fffff]
2026-10-10T11:00:07,265783+00:00 pci_bus 0000:08: resource 2 [mem 0x7050000000-0x705fffffff 64bit pref]
2026-10-10T11:00:07,265786+00:00 pci_bus 0000:09: resource 0 [io  0x6000-0x6fff]
2026-10-10T11:00:07,265789+00:00 pci_bus 0000:09: resource 1 [mem 0x81000000-0x811fffff]
2026-10-10T11:00:07,265791+00:00 pci_bus 0000:09: resource 2 [mem 0x7040000000-0x704fffffff 64bit pref]
2026-10-10T11:00:07,266230+00:00 ACPI: \_SB_.GSIA: Enabled at IRQ 16
2026-10-10T11:00:07,267460+00:00 ACPI: \_SB_.GSIB: Enabled at IRQ 17
2026-10-10T11:00:07,268580+00:00 ACPI: \_SB_.GSIC: Enabled at IRQ 18
2026-10-10T11:00:07,269723+00:00 ACPI: \_SB_.GSID: Enabled at IRQ 19
2026-10-10T11:00:07,277137+00:00 PCI: CLS 0 bytes, default 64
2026-10-10T11:00:07,277242+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2026-10-10T11:00:07,277248+00:00 software IO TLB: mapped [mem 0x000000006e52a000-0x000000007252a000] (64MB)
2026-10-10T11:00:07,277300+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0xb9fb05486c, max_idle_ns: 440795231721 ns
2026-10-10T11:00:07,277386+00:00 Trying to unpack rootfs image as initramfs...
2026-10-10T11:00:07,282139+00:00 Initialise system trusted keyrings
2026-10-10T11:00:07,282154+00:00 Key type blacklist registered
2026-10-10T11:00:07,283919+00:00 workingset: timestamp_bits=36 max_order=20 bucket_order=0
2026-10-10T11:00:07,284563+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2026-10-10T11:00:07,284722+00:00 fuse: init (API version 7.45)
2026-10-10T11:00:07,305689+00:00 integrity: Platform Keyring initialized
2026-10-10T11:00:07,305700+00:00 integrity: Machine keyring initialized
2026-10-10T11:00:07,326359+00:00 Key type asymmetric registered
2026-10-10T11:00:07,326368+00:00 Asymmetric key parser 'x509' registered
2026-10-10T11:00:07,326413+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 242)
2026-10-10T11:00:07,330895+00:00 io scheduler mq-deadline registered
2026-10-10T11:00:07,334887+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2026-10-10T11:00:07,336625+00:00 pcieport 0000:00:1c.0: PME: Signaling with IRQ 24
2026-10-10T11:00:07,341888+00:00 pcieport 0000:00:1c.0: AER: enabled with IRQ 24
2026-10-10T11:00:07,459039+00:00 pcieport 0000:00:1c.1: PME: Signaling with IRQ 25
2026-10-10T11:00:07,461076+00:00 pcieport 0000:00:1c.1: AER: enabled with IRQ 25
2026-10-10T11:00:07,464727+00:00 pcieport 0000:00:1c.2: PME: Signaling with IRQ 26
2026-10-10T11:00:07,466454+00:00 pcieport 0000:00:1c.2: AER: enabled with IRQ 26
2026-10-10T11:00:07,469936+00:00 pcieport 0000:00:1c.3: PME: Signaling with IRQ 27
2026-10-10T11:00:07,472310+00:00 pcieport 0000:00:1c.3: AER: enabled with IRQ 27
2026-10-10T11:00:07,475670+00:00 shpchp 0000:05:01.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:07,477596+00:00 ACPI: \_SB_.GSIF: Enabled at IRQ 21
2026-10-10T11:00:07,481424+00:00 shpchp 0000:05:01.0: pci_hp_register failed with error -16
2026-10-10T11:00:07,481451+00:00 shpchp 0000:05:01.0: Slot initialization failed
2026-10-10T11:00:07,483349+00:00 Freeing initrd memory: 42828K
2026-10-10T11:00:07,486830+00:00 shpchp 0000:05:02.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:07,487113+00:00 ACPI: \_SB_.GSIG: Enabled at IRQ 22
2026-10-10T11:00:07,490509+00:00 shpchp 0000:05:02.0: pci_hp_register failed with error -16
2026-10-10T11:00:07,490529+00:00 shpchp 0000:05:02.0: Slot initialization failed
2026-10-10T11:00:07,494095+00:00 shpchp 0000:05:03.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:07,494387+00:00 ACPI: \_SB_.GSIH: Enabled at IRQ 23
2026-10-10T11:00:07,498563+00:00 shpchp 0000:05:03.0: pci_hp_register failed with error -16
2026-10-10T11:00:07,498582+00:00 shpchp 0000:05:03.0: Slot initialization failed
2026-10-10T11:00:07,502132+00:00 shpchp 0000:05:04.0: HPC vendor_id 1b36 device_id 1 ss_vid 0 ss_did 0
2026-10-10T11:00:07,502414+00:00 ACPI: \_SB_.GSIE: Enabled at IRQ 20
2026-10-10T11:00:07,505660+00:00 shpchp 0000:05:04.0: pci_hp_register failed with error -16
2026-10-10T11:00:07,505677+00:00 shpchp 0000:05:04.0: Slot initialization failed
2026-10-10T11:00:07,508480+00:00 input: Power Button as /devices/platform/LNXPWRBN:00/input/input0
2026-10-10T11:00:07,508571+00:00 ACPI: button: Power Button [PWRF]
2026-10-10T11:00:07,515427+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2026-10-10T11:00:07,542714+00:00 00:00: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2026-10-10T11:00:07,563631+00:00 Linux agpgart interface v0.103
2026-10-10T11:00:07,565961+00:00 loop: module loaded
2026-10-10T11:00:07,566591+00:00 virtio_scsi virtio2: 2/0/0 default/read/poll queues
2026-10-10T11:00:07,569574+00:00 scsi host0: Virtio SCSI HBA
2026-10-10T11:00:07,570416+00:00 ACPI: bus type drm_connector registered
2026-10-10T11:00:07,570737+00:00 tun: Universal TUN/TAP device driver, 1.6
2026-10-10T11:00:07,570872+00:00 scsi 0:0:0:0: Direct-Access     QEMU     QEMU HARDDISK    2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:07,576061+00:00 PPP generic driver version 2.4.2
2026-10-10T11:00:07,577188+00:00 uhci_hcd 0000:00:1a.0: UHCI Host Controller
2026-10-10T11:00:07,577201+00:00 uhci_hcd 0000:00:1a.0: new USB bus registered, assigned bus number 1
2026-10-10T11:00:07,577232+00:00 uhci_hcd 0000:00:1a.0: detected 2 ports
2026-10-10T11:00:07,577468+00:00 uhci_hcd 0000:00:1a.0: irq 16, io port 0x00008100
2026-10-10T11:00:07,577630+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:07,577637+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,577640+00:00 usb usb1: Product: UHCI Host Controller
2026-10-10T11:00:07,577643+00:00 usb usb1: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:07,577646+00:00 usb usb1: SerialNumber: 0000:00:1a.0
2026-10-10T11:00:07,577764+00:00 hub 1-0:1.0: USB hub found
2026-10-10T11:00:07,577774+00:00 hub 1-0:1.0: 2 ports detected
2026-10-10T11:00:07,579482+00:00 uhci_hcd 0000:00:1a.1: UHCI Host Controller
2026-10-10T11:00:07,579496+00:00 uhci_hcd 0000:00:1a.1: new USB bus registered, assigned bus number 2
2026-10-10T11:00:07,579537+00:00 uhci_hcd 0000:00:1a.1: detected 2 ports
2026-10-10T11:00:07,579718+00:00 uhci_hcd 0000:00:1a.1: irq 17, io port 0x000080e0
2026-10-10T11:00:07,580249+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:07,580256+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,580260+00:00 usb usb2: Product: UHCI Host Controller
2026-10-10T11:00:07,580262+00:00 usb usb2: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:07,580265+00:00 usb usb2: SerialNumber: 0000:00:1a.1
2026-10-10T11:00:07,580383+00:00 hub 2-0:1.0: USB hub found
2026-10-10T11:00:07,580394+00:00 hub 2-0:1.0: 2 ports detected
2026-10-10T11:00:07,581820+00:00 ehci-pci 0000:00:1d.7: EHCI Host Controller
2026-10-10T11:00:07,581831+00:00 ehci-pci 0000:00:1d.7: new USB bus registered, assigned bus number 3
2026-10-10T11:00:07,582289+00:00 ehci-pci 0000:00:1d.7: irq 19, io mem 0x82245000
2026-10-10T11:00:07,587940+00:00 ehci-pci 0000:00:1d.7: USB 2.0 started, EHCI 1.00
2026-10-10T11:00:07,588036+00:00 usb usb3: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 7.00
2026-10-10T11:00:07,588044+00:00 usb usb3: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,588048+00:00 usb usb3: Product: EHCI Host Controller
2026-10-10T11:00:07,588051+00:00 usb usb3: Manufacturer: Linux 7.0.0-38-generic ehci_hcd
2026-10-10T11:00:07,588053+00:00 usb usb3: SerialNumber: 0000:00:1d.7
2026-10-10T11:00:07,588170+00:00 hub 3-0:1.0: USB hub found
2026-10-10T11:00:07,588180+00:00 hub 3-0:1.0: 6 ports detected
2026-10-10T11:00:07,594541+00:00 sd 0:0:0:0: Attached scsi generic sg0 type 0
2026-10-10T11:00:07,594546+00:00 sd 0:0:0:0: Power-on or device reset occurred
2026-10-10T11:00:07,594648+00:00 sd 0:0:0:0: [sda] 68157440 512-byte logical blocks: (34.9 GB/32.5 GiB)
2026-10-10T11:00:07,594675+00:00 sd 0:0:0:0: [sda] Write Protect is off
2026-10-10T11:00:07,594679+00:00 sd 0:0:0:0: [sda] Mode Sense: 63 00 10 08
2026-10-10T11:00:07,594720+00:00 sd 0:0:0:0: [sda] Write cache: enabled, read cache: enabled, supports DPO and FUA
2026-10-10T11:00:07,602960+00:00  sda: sda1 sda13 sda14 sda15
2026-10-10T11:00:07,603137+00:00 sd 0:0:0:0: [sda] Attached SCSI disk
2026-10-10T11:00:07,631176+00:00 ehci-pci 0000:00:1a.7: EHCI Host Controller
2026-10-10T11:00:07,631197+00:00 ehci-pci 0000:00:1a.7: new USB bus registered, assigned bus number 4
2026-10-10T11:00:07,631624+00:00 ehci-pci 0000:00:1a.7: irq 19, io mem 0x8224a000
2026-10-10T11:00:07,636911+00:00 ehci-pci 0000:00:1a.7: USB 2.0 started, EHCI 1.00
2026-10-10T11:00:07,637021+00:00 usb usb4: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 7.00
2026-10-10T11:00:07,637028+00:00 usb usb4: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,637032+00:00 usb usb4: Product: EHCI Host Controller
2026-10-10T11:00:07,637034+00:00 usb usb4: Manufacturer: Linux 7.0.0-38-generic ehci_hcd
2026-10-10T11:00:07,637037+00:00 usb usb4: SerialNumber: 0000:00:1a.7
2026-10-10T11:00:07,637152+00:00 hub 4-0:1.0: USB hub found
2026-10-10T11:00:07,637165+00:00 hub 4-0:1.0: 6 ports detected
2026-10-10T11:00:07,658103+00:00 hub 1-0:1.0: USB hub found
2026-10-10T11:00:07,658125+00:00 hub 1-0:1.0: 2 ports detected
2026-10-10T11:00:07,679135+00:00 hub 2-0:1.0: USB hub found
2026-10-10T11:00:07,679164+00:00 hub 2-0:1.0: 2 ports detected
2026-10-10T11:00:07,679277+00:00 uhci_hcd 0000:00:1a.2: UHCI Host Controller
2026-10-10T11:00:07,679285+00:00 uhci_hcd 0000:00:1a.2: new USB bus registered, assigned bus number 5
2026-10-10T11:00:07,679318+00:00 uhci_hcd 0000:00:1a.2: detected 2 ports
2026-10-10T11:00:07,679537+00:00 uhci_hcd 0000:00:1a.2: irq 18, io port 0x000080c0
2026-10-10T11:00:07,679704+00:00 usb usb5: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:07,679712+00:00 usb usb5: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,679715+00:00 usb usb5: Product: UHCI Host Controller
2026-10-10T11:00:07,679718+00:00 usb usb5: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:07,679720+00:00 usb usb5: SerialNumber: 0000:00:1a.2
2026-10-10T11:00:07,679827+00:00 hub 5-0:1.0: USB hub found
2026-10-10T11:00:07,679835+00:00 hub 5-0:1.0: 2 ports detected
2026-10-10T11:00:07,681190+00:00 uhci_hcd 0000:00:1d.0: UHCI Host Controller
2026-10-10T11:00:07,681203+00:00 uhci_hcd 0000:00:1d.0: new USB bus registered, assigned bus number 6
2026-10-10T11:00:07,681246+00:00 uhci_hcd 0000:00:1d.0: detected 2 ports
2026-10-10T11:00:07,681376+00:00 uhci_hcd 0000:00:1d.0: irq 16, io port 0x000080a0
2026-10-10T11:00:07,681531+00:00 usb usb6: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:07,681537+00:00 usb usb6: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,681541+00:00 usb usb6: Product: UHCI Host Controller
2026-10-10T11:00:07,681543+00:00 usb usb6: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:07,681546+00:00 usb usb6: SerialNumber: 0000:00:1d.0
2026-10-10T11:00:07,681644+00:00 hub 6-0:1.0: USB hub found
2026-10-10T11:00:07,681653+00:00 hub 6-0:1.0: 2 ports detected
2026-10-10T11:00:07,682821+00:00 uhci_hcd 0000:00:1d.1: UHCI Host Controller
2026-10-10T11:00:07,682833+00:00 uhci_hcd 0000:00:1d.1: new USB bus registered, assigned bus number 7
2026-10-10T11:00:07,683306+00:00 uhci_hcd 0000:00:1d.1: detected 2 ports
2026-10-10T11:00:07,683449+00:00 uhci_hcd 0000:00:1d.1: irq 17, io port 0x00008080
2026-10-10T11:00:07,683599+00:00 usb usb7: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:07,683606+00:00 usb usb7: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,683609+00:00 usb usb7: Product: UHCI Host Controller
2026-10-10T11:00:07,683611+00:00 usb usb7: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:07,683614+00:00 usb usb7: SerialNumber: 0000:00:1d.1
2026-10-10T11:00:07,683717+00:00 hub 7-0:1.0: USB hub found
2026-10-10T11:00:07,683726+00:00 hub 7-0:1.0: 2 ports detected
2026-10-10T11:00:07,684852+00:00 uhci_hcd 0000:00:1d.2: UHCI Host Controller
2026-10-10T11:00:07,685122+00:00 uhci_hcd 0000:00:1d.2: new USB bus registered, assigned bus number 8
2026-10-10T11:00:07,685164+00:00 uhci_hcd 0000:00:1d.2: detected 2 ports
2026-10-10T11:00:07,685312+00:00 uhci_hcd 0000:00:1d.2: irq 18, io port 0x00008060
2026-10-10T11:00:07,685471+00:00 usb usb8: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 7.00
2026-10-10T11:00:07,685477+00:00 usb usb8: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2026-10-10T11:00:07,685480+00:00 usb usb8: Product: UHCI Host Controller
2026-10-10T11:00:07,685483+00:00 usb usb8: Manufacturer: Linux 7.0.0-38-generic uhci_hcd
2026-10-10T11:00:07,685485+00:00 usb usb8: SerialNumber: 0000:00:1d.2
2026-10-10T11:00:07,685581+00:00 hub 8-0:1.0: USB hub found
2026-10-10T11:00:07,685591+00:00 hub 8-0:1.0: 2 ports detected
2026-10-10T11:00:07,685820+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2026-10-10T11:00:07,687533+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2026-10-10T11:00:07,687548+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2026-10-10T11:00:07,687694+00:00 mousedev: PS/2 mouse device common for all mice
2026-10-10T11:00:07,688257+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2026-10-10T11:00:07,688611+00:00 rtc_cmos 00:03: RTC can wake from S4
2026-10-10T11:00:07,689746+00:00 rtc_cmos 00:03: registered as rtc0
2026-10-10T11:00:07,689943+00:00 rtc_cmos 00:03: setting system clock to 2026-10-10T11:00:07 UTC (1791630007)
2026-10-10T11:00:07,690060+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram
2026-10-10T11:00:07,690077+00:00 i2c_dev: i2c /dev entries driver
2026-10-10T11:00:07,690104+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2026-10-10T11:00:07,690131+00:00 device-mapper: uevent: version 1.0.3
2026-10-10T11:00:07,690190+00:00 device-mapper: ioctl: 4.50.0-ioctl (2025-04-28) initialised: dm-devel@lists.linux.dev
2026-10-10T11:00:07,690197+00:00 intel_pstate: CPU model not supported
2026-10-10T11:00:07,690428+00:00 simple-framebuffer simple-framebuffer.0: [drm] Registered 1 planes with drm panic
2026-10-10T11:00:07,690692+00:00 [drm] Initialized simpledrm 1.0.0 for simple-framebuffer.0 on minor 0
2026-10-10T11:00:07,695142+00:00 Console: switching to colour frame buffer device 160x50
2026-10-10T11:00:07,696211+00:00 simple-framebuffer simple-framebuffer.0: [drm] fb0: simpledrmdrmfb frame buffer device
2026-10-10T11:00:07,696335+00:00 drop_monitor: Initializing network drop monitor service
2026-10-10T11:00:07,696481+00:00 NET: Registered PF_INET6 protocol family
2026-10-10T11:00:07,697412+00:00 Segment Routing with IPv6
2026-10-10T11:00:07,697435+00:00 In-situ OAM (IOAM) with IPv6
2026-10-10T11:00:07,697459+00:00 NET: Registered PF_PACKET protocol family
2026-10-10T11:00:07,697571+00:00 Key type dns_resolver registered
2026-10-10T11:00:07,700943+00:00 IPI shorthand broadcast: enabled
2026-10-10T11:00:07,702978+00:00 sched_clock: Marking stable (934003716, 189939214)->(1444908313, -320965383)
2026-10-10T11:00:07,707443+00:00 registered taskstats version 1
2026-10-10T11:00:07,710695+00:00 Loading compiled-in X.509 certificates
2026-10-10T11:00:07,711382+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 6b2b0d62fc3a1216c49fda2b061b13d4dbf474bd'
2026-10-10T11:00:07,711966+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing 2025 Kmod: d541cef61dc7e793b7eb7e899970a2eef0b5dc8c'
2026-10-10T11:00:07,712533+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2026-10-10T11:00:07,713153+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing 2025 Kmod: 4627603d2357a2a3f81006370894c221175893e9'
2026-10-10T11:00:07,713722+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2026-10-10T11:00:07,713736+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2026-10-10T11:00:07,713764+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2026-10-10T11:00:07,713784+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2026-10-10T11:00:07,713805+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2026-10-10T11:00:07,713824+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2026-10-10T11:00:07,713844+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2026-10-10T11:00:07,713973+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2026-10-10T11:00:07,713997+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2026-10-10T11:00:07,714016+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2026-10-10T11:00:07,719565+00:00 Demotion targets for Node 0: null
2026-10-10T11:00:07,720417+00:00 Key type .fscrypt registered
2026-10-10T11:00:07,720652+00:00 Key type fscrypt-provisioning registered
2026-10-10T11:00:07,721414+00:00 Key type big_key registered
2026-10-10T11:00:07,810329+00:00 Key type encrypted registered
2026-10-10T11:00:07,810611+00:00 AppArmor: AppArmor sha256 policy hashing enabled
2026-10-10T11:00:07,810856+00:00 ima: No TPM chip found, activating TPM-bypass!
2026-10-10T11:00:07,811619+00:00 Loading compiled-in module X.509 certificates
2026-10-10T11:00:07,812923+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 6b2b0d62fc3a1216c49fda2b061b13d4dbf474bd'
2026-10-10T11:00:07,813183+00:00 ima: Allocated hash algorithm: sha256
2026-10-10T11:00:07,813458+00:00 ima: No architecture policies found
2026-10-10T11:00:07,813720+00:00 evm: Initialising EVM extended attributes:
2026-10-10T11:00:07,814464+00:00 evm: security.selinux
2026-10-10T11:00:07,814710+00:00 evm: security.SMACK64
2026-10-10T11:00:07,815437+00:00 evm: security.SMACK64EXEC
2026-10-10T11:00:07,815673+00:00 evm: security.SMACK64TRANSMUTE
2026-10-10T11:00:07,816399+00:00 evm: security.SMACK64MMAP
2026-10-10T11:00:07,816633+00:00 evm: security.apparmor
2026-10-10T11:00:07,816854+00:00 evm: security.ima
2026-10-10T11:00:07,817588+00:00 evm: security.capability
2026-10-10T11:00:07,817814+00:00 evm: HMAC attrs: 0x1
2026-10-10T11:00:07,819481+00:00 PM:   Magic number: 14:901:23
2026-10-10T11:00:07,820539+00:00 RAS: Correctable Errors collector initialized.
2026-10-10T11:00:07,821561+00:00 clk: Disabling unused clocks
2026-10-10T11:00:07,821780+00:00 PM: genpd: Disabling unused power domains
2026-10-10T11:00:07,829818+00:00 Freeing unused decrypted memory: 2028K
2026-10-10T11:00:07,830075+00:00 usb 3-1: new high-speed USB device number 2 using ehci-pci
2026-10-10T11:00:07,832040+00:00 Freeing unused kernel image (initmem) memory: 5304K
2026-10-10T11:00:07,832327+00:00 Write protecting the kernel read-only data: 43008k
2026-10-10T11:00:07,834814+00:00 Freeing unused kernel image (text/rodata gap) memory: 736K
2026-10-10T11:00:07,836151+00:00 Freeing unused kernel image (rodata/data gap) memory: 1656K
2026-10-10T11:00:07,876237+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2026-10-10T11:00:07,876493+00:00 Run /init as init process
2026-10-10T11:00:07,876692+00:00   with arguments:
2026-10-10T11:00:07,876694+00:00     /init
2026-10-10T11:00:07,876695+00:00   with environment:
2026-10-10T11:00:07,876696+00:00     HOME=/
2026-10-10T11:00:07,876697+00:00     TERM=linux
2026-10-10T11:00:07,960716+00:00 usb 3-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2026-10-10T11:00:07,960992+00:00 usb 3-1: New USB device strings: Mfr=1, Product=3, SerialNumber=10
2026-10-10T11:00:07,961185+00:00 usb 3-1: Product: QEMU USB Tablet
2026-10-10T11:00:07,961391+00:00 usb 3-1: Manufacturer: QEMU
2026-10-10T11:00:07,961572+00:00 usb 3-1: SerialNumber: 28754-0000:00:1d.7-1
2026-10-10T11:00:08,217276+00:00 systemd[1]: Inserted module 'autofs4'
2026-10-10T11:00:08,246618+00:00 systemd[1]: Successfully made /usr/ read-only.
2026-10-10T11:00:08,581930+00:00 systemd[1]: systemd 259.5-0ubuntu3.4 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +IPE +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +KMOD +LIBCRYPTSETUP +LIBCRYPTSETUP_PLUGINS +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK +BTF -XKBCOMMON -UTMP +SYSVINIT +LIBARCHIVE)
2026-10-10T11:00:08,582587+00:00 systemd[1]: Detected virtualization kvm.
2026-10-10T11:00:08,582855+00:00 systemd[1]: Detected architecture x86-64.
2026-10-10T11:00:08,583618+00:00 systemd[1]: Running in initrd.
2026-10-10T11:00:08,590389+00:00 systemd[1]: Hostname set to <ubuntu-2604>.
2026-10-10T11:00:08,642053+00:00 systemd[1]: bpf-restrict-fs: BPF LSM hook not enabled in the kernel, BPF LSM not supported.
2026-10-10T11:00:08,711063+00:00 systemd[1]: Queued start job for default target initrd.target.
2026-10-10T11:00:08,717543+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2026-10-10T11:00:08,721095+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-41A1\x2dDD67.device - /dev/disk/by-uuid/41A1-DD67...
2026-10-10T11:00:08,723997+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-618f4c04\x2d0edd\x2d49b3\x2d8ad5\x2d00a29af1f556.device - /dev/disk/by-uuid/618f4c04-0edd-49b3-8ad5-00a29af1f556...
2026-10-10T11:00:08,727560+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-747687d9\x2dc20c\x2d41f8\x2dbfb8\x2d7f4a57910c51.device - /dev/disk/by-uuid/747687d9-c20c-41f8-bfb8-7f4a57910c51...
2026-10-10T11:00:08,731168+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2026-10-10T11:00:08,733892+00:00 systemd[1]: Reached target paths.target - Path Units.
2026-10-10T11:00:08,735988+00:00 systemd[1]: Reached target slices.target - Slice Units.
2026-10-10T11:00:08,738222+00:00 systemd[1]: Reached target swap.target - Swaps.
2026-10-10T11:00:08,740240+00:00 systemd[1]: Reached target timers.target - Timer Units.
2026-10-10T11:00:08,742983+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2026-10-10T11:00:08,745970+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Sockets.
2026-10-10T11:00:08,748631+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Management Netlink Socket.
2026-10-10T11:00:08,751610+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2026-10-10T11:00:08,754412+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2026-10-10T11:00:08,757430+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2026-10-10T11:00:08,760656+00:00 systemd[1]: Starting dracut-cmdline-ask.service - dracut ask for additional cmdline parameters...
2026-10-10T11:00:08,765422+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2026-10-10T11:00:08,768319+00:00 systemd[1]: systemd-battery-check.service - Early Battery Level Check skipped, unmet condition check ConditionDirectoryNotEmpty=/sys/class/power_supply
2026-10-10T11:00:08,773796+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2026-10-10T11:00:08,782410+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2026-10-10T11:00:08,792433+00:00 systemd[1]: Starting systemd-network-generator.service - Generate Network Units from Kernel Command Line...
2026-10-10T11:00:08,795598+00:00 systemd[1]: systemd-pcrphase-initrd.service - TPM PCR Barrier (initrd) skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:08,800121+00:00 systemd-journald[123]: Collecting audit messages is disabled.
2026-10-10T11:00:08,800701+00:00 systemd[1]: Finished dracut-cmdline-ask.service - dracut ask for additional cmdline parameters.
2026-10-10T11:00:08,808412+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2026-10-10T11:00:08,818752+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2026-10-10T11:00:08,823991+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully...
2026-10-10T11:00:08,833005+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2026-10-10T11:00:08,837958+00:00 systemd[1]: Finished systemd-network-generator.service - Generate Network Units from Kernel Command Line.
2026-10-10T11:00:08,841797+00:00 systemd[1]: Reached target network-pre.target - Preparation for Network.
2026-10-10T11:00:08,846593+00:00 systemd[1]: Listening on systemd-networkd-resolve-hook.socket - Network Management Resolve Hook Socket.
2026-10-10T11:00:08,852295+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2026-10-10T11:00:08,862964+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev-early.service - Create Static Device Nodes in /dev gracefully.
2026-10-10T11:00:08,871117+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2026-10-10T11:00:08,877560+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2026-10-10T11:00:08,885114+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2026-10-10T11:00:08,886961+00:00 systemd[1]: Reached target local-fs-pre.target - Preparation for Local File Systems.
2026-10-10T11:00:08,888652+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2026-10-10T11:00:08,909552+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2026-10-10T11:00:09,292653+00:00 virtio_net virtio1 ens18: renamed from eth0
2026-10-10T11:00:09,491372+00:00 hid: raw HID events driver (C) Jiri Kosina
2026-10-10T11:00:09,497445+00:00 ahci 0000:00:1f.2: AHCI vers 0001.0000, 32 command slots, 1.5 Gbps, SATA mode
2026-10-10T11:00:09,497459+00:00 ahci 0000:00:1f.2: 6/6 ports implemented (port mask 0x3f)
2026-10-10T11:00:09,497465+00:00 ahci 0000:00:1f.2: flags: 64bit ncq only 
2026-10-10T11:00:09,501931+00:00 usbcore: registered new interface driver usbhid
2026-10-10T11:00:09,501939+00:00 usbhid: USB HID core driver
2026-10-10T11:00:09,503030+00:00 scsi host1: ahci
2026-10-10T11:00:09,504277+00:00 scsi host2: ahci
2026-10-10T11:00:09,507364+00:00 scsi host3: ahci
2026-10-10T11:00:09,511721+00:00 scsi host4: ahci
2026-10-10T11:00:09,512184+00:00 scsi host5: ahci
2026-10-10T11:00:09,513007+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2026-10-10T11:00:09,513575+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2026-10-10T11:00:09,516736+00:00 scsi host6: ahci
2026-10-10T11:00:09,516854+00:00 ata1: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244100 irq 38 lpm-pol 1
2026-10-10T11:00:09,516947+00:00 ata2: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244180 irq 38 lpm-pol 1
2026-10-10T11:00:09,516965+00:00 ata3: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244200 irq 38 lpm-pol 1
2026-10-10T11:00:09,516982+00:00 ata4: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244280 irq 38 lpm-pol 1
2026-10-10T11:00:09,516999+00:00 ata5: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244300 irq 38 lpm-pol 1
2026-10-10T11:00:09,517017+00:00 ata6: SATA max UDMA/133 abar m4096@0x82244000 port 0x82244380 irq 38 lpm-pol 1
2026-10-10T11:00:09,525188+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:1d.7/usb3/3-1/3-1:1.0/0003:0627:0001.0001/input/input5
2026-10-10T11:00:09,525526+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:1d.7-1/input0
2026-10-10T11:00:09,824224+00:00 ata1: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2026-10-10T11:00:09,824621+00:00 ata2: SATA link up 1.5 Gbps (SStatus 113 SControl 300)
2026-10-10T11:00:09,824917+00:00 ata4: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:09,825044+00:00 ata1.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2026-10-10T11:00:09,825049+00:00 ata1.00: applying bridge limits
2026-10-10T11:00:09,825341+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:09,825550+00:00 ata2.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2026-10-10T11:00:09,825557+00:00 ata2.00: applying bridge limits
2026-10-10T11:00:09,825707+00:00 ata2.00: configured for UDMA/100
2026-10-10T11:00:09,825993+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:09,826355+00:00 ata1.00: configured for UDMA/100
2026-10-10T11:00:09,826739+00:00 scsi 1:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:09,833603+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2026-10-10T11:00:09,838431+00:00 sr 1:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2026-10-10T11:00:09,863136+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2026-10-10T11:00:09,877992+00:00 sr 1:0:0:0: Attached scsi CD-ROM sr0
2026-10-10T11:00:09,878719+00:00 sr 1:0:0:0: Attached scsi generic sg1 type 5
2026-10-10T11:00:09,879067+00:00 scsi 2:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2026-10-10T11:00:09,902227+00:00 sr 2:0:0:0: [sr1] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2026-10-10T11:00:09,937052+00:00 sr 2:0:0:0: Attached scsi CD-ROM sr1
2026-10-10T11:00:09,937190+00:00 sr 2:0:0:0: Attached scsi generic sg2 type 5
2026-10-10T11:00:10,225576+00:00 EXT4-fs (sda1): orphan cleanup on readonly fs
2026-10-10T11:00:10,225905+00:00 EXT4-fs (sda1): mounted filesystem 747687d9-c20c-41f8-bfb8-7f4a57910c51 ro with ordered data mode. Quota mode: none.
2026-10-10T11:00:10,499477+00:00 systemd-journald[123]: Received SIGTERM from PID 1 (systemd).
2026-10-10T11:00:11,227954+00:00 systemd[1]: systemd 259.5-0ubuntu3.4 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +IPE +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +KMOD +LIBCRYPTSETUP +LIBCRYPTSETUP_PLUGINS +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK +BTF -XKBCOMMON -UTMP +SYSVINIT +LIBARCHIVE)
2026-10-10T11:00:11,227972+00:00 systemd[1]: Detected virtualization kvm.
2026-10-10T11:00:11,227989+00:00 systemd[1]: Detected architecture x86-64.
2026-10-10T11:00:11,235754+00:00 systemd[1]: Hostname set to <controlplane>.
2026-10-10T11:00:11,298705+00:00 systemd[1]: bpf-restrict-fs: BPF LSM hook not enabled in the kernel, BPF LSM not supported.
2026-10-10T11:00:11,362792+00:00 Guest personality initialized and is inactive
2026-10-10T11:00:11,363235+00:00 VMCI host device registered (name=vmci, major=10, minor=262)
2026-10-10T11:00:11,363246+00:00 Initialized host personality
2026-10-10T11:00:11,366948+00:00 NET: Registered PF_VSOCK protocol family
2026-10-10T11:00:11,567969+00:00 systemd[1]: /usr/lib/systemd/system/xfs_scrub_all.service:26: Support for option CPUAccounting= has been removed and it is ignored
2026-10-10T11:00:11,568670+00:00 systemd[1]: /usr/lib/systemd/system/system-xfs_scrub.slice:15: Support for option CPUAccounting= has been removed and it is ignored
2026-10-10T11:00:11,673910+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2026-10-10T11:00:11,674101+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2026-10-10T11:00:11,676694+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2026-10-10T11:00:11,677443+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2026-10-10T11:00:11,679617+00:00 systemd[1]: Created slice system-systemd\x2dfsck.slice - Slice /system/systemd-fsck.
2026-10-10T11:00:11,682079+00:00 systemd[1]: Created slice system-xfs_scrub.slice - xfs_scrub background service slice.
2026-10-10T11:00:11,684193+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2026-10-10T11:00:11,685625+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2026-10-10T11:00:11,687541+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2026-10-10T11:00:11,689314+00:00 systemd[1]: Expecting device dev-disk-by\x2dlabel-BOOT.device - /dev/disk/by-label/BOOT...
2026-10-10T11:00:11,690879+00:00 systemd[1]: Expecting device dev-disk-by\x2dlabel-UEFI.device - /dev/disk/by-label/UEFI...
2026-10-10T11:00:11,692441+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2026-10-10T11:00:11,693726+00:00 systemd[1]: Reached target imports.target - Image Downloads.
2026-10-10T11:00:11,695156+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2026-10-10T11:00:11,696680+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2026-10-10T11:00:11,698156+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2026-10-10T11:00:11,699805+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2026-10-10T11:00:11,701608+00:00 systemd[1]: Reached target slices.target - Slice Units.
2026-10-10T11:00:11,702939+00:00 systemd[1]: Reached target snapd.mounts-pre.target - Mounting snaps.
2026-10-10T11:00:11,704458+00:00 systemd[1]: Reached target snapd.mounts.target - Mounted snaps.
2026-10-10T11:00:11,705944+00:00 systemd[1]: Reached target swap.target - Swaps.
2026-10-10T11:00:11,707200+00:00 systemd[1]: Reached target time-set.target - System Time Set.
2026-10-10T11:00:11,708688+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2026-10-10T11:00:11,710541+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2026-10-10T11:00:11,712392+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2026-10-10T11:00:11,723635+00:00 systemd[1]: Listening on rpcbind.socket - RPCbind Server Activation Socket.
2026-10-10T11:00:11,726348+00:00 systemd[1]: Listening on syslog.socket - Syslog Socket.
2026-10-10T11:00:11,733195+00:00 systemd[1]: Listening on systemd-ask-password.socket - Query the User Interactively for a Password.
2026-10-10T11:00:11,738771+00:00 systemd[1]: Listening on systemd-creds.socket - Credential Encryption/Decryption.
2026-10-10T11:00:11,742364+00:00 systemd[1]: Listening on systemd-factory-reset.socket - Factory Reset Management.
2026-10-10T11:00:11,748981+00:00 systemd[1]: Listening on systemd-mute-console.socket - Console Output Muting Service Socket.
2026-10-10T11:00:11,751036+00:00 systemd[1]: Listening on systemd-networkd-varlink.socket - Network Management Varlink Socket.
2026-10-10T11:00:11,752974+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Management Netlink Socket.
2026-10-10T11:00:11,754781+00:00 systemd[1]: systemd-pcrextend.socket - TPM PCR Measurements skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:11,754826+00:00 systemd[1]: systemd-pcrlock.socket - Make TPM PCR Policy skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:11,754956+00:00 systemd[1]: Listening on systemd-resolved-monitor.socket - Resolve Monitor Varlink Socket.
2026-10-10T11:00:11,756814+00:00 systemd[1]: Listening on systemd-resolved-varlink.socket - Resolve Service Varlink Socket.
2026-10-10T11:00:11,758706+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2026-10-10T11:00:11,761202+00:00 systemd[1]: Listening on systemd-udevd-varlink.socket - udev Varlink Socket.
2026-10-10T11:00:11,764469+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2026-10-10T11:00:11,772895+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2026-10-10T11:00:11,778994+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2026-10-10T11:00:11,791223+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2026-10-10T11:00:11,799362+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2026-10-10T11:00:11,804977+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2026-10-10T11:00:11,806636+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS skipped, unmet condition check ConditionPathExists=/etc/krb5.keytab
2026-10-10T11:00:11,816644+00:00 systemd[1]: Starting keyboard-setup.service - Set the console keyboard layout...
2026-10-10T11:00:11,819806+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2026-10-10T11:00:11,826715+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2026-10-10T11:00:11,835043+00:00 systemd[1]: modprobe@configfs.service - Load Kernel Module configfs skipped, unmet condition check ConditionKernelModuleLoaded=!configfs
2026-10-10T11:00:11,839501+00:00 systemd[1]: Starting modprobe@dm_multipath.service - Load Kernel Module dm_multipath...
2026-10-10T11:00:11,843132+00:00 systemd[1]: modprobe@drm.service - Load Kernel Module drm skipped, unmet condition check ConditionKernelModuleLoaded=!drm
2026-10-10T11:00:11,845082+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2026-10-10T11:00:11,850246+00:00 systemd[1]: modprobe@fuse.service - Load Kernel Module fuse skipped, unmet condition check ConditionKernelModuleLoaded=!fuse
2026-10-10T11:00:11,852987+00:00 systemd[1]: Mounting sys-fs-fuse-connections.mount - FUSE Control File System...
2026-10-10T11:00:11,857032+00:00 systemd[1]: netplan-ovs-cleanup.service - OpenVSwitch configuration for cleanup skipped, unmet condition check ConditionFileIsExecutable=/usr/bin/ovs-vsctl
2026-10-10T11:00:11,857320+00:00 systemd[1]: systemd-hibernate-clear.service - Clear Stale Hibernate Storage Info skipped, unmet condition check ConditionPathExists=/sys/firmware/efi/efivars/HibernateLocation-8cf2644b-4b0b-428f-9387-6d876050dc67
2026-10-10T11:00:11,864200+00:00 pstore: Using crash dump compression: deflate
2026-10-10T11:00:11,865190+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2026-10-10T11:00:11,870657+00:00 systemd[1]: systemd-pcrmachine.service - TPM PCR Machine ID Measurement skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:11,870721+00:00 systemd[1]: systemd-pcrproduct.service - TPM NvPCR Product ID Measurement skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:11,879252+00:00 systemd[1]: Starting systemd-remount-fs.service - Remount Root and Kernel File Systems...
2026-10-10T11:00:11,881361+00:00 systemd[1]: systemd-tpm2-setup-early.service - Early TPM SRK Setup skipped, unmet condition check ConditionSecurity=measured-uki
2026-10-10T11:00:11,886696+00:00 systemd[1]: Starting systemd-udev-load-credentials.service - Load udev Rules from Credentials...
2026-10-10T11:00:11,892297+00:00 systemd-journald[489]: Collecting audit messages is disabled.
2026-10-10T11:00:11,897117+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2026-10-10T11:00:11,903516+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2026-10-10T11:00:11,903798+00:00 pstore: Registered efi_pstore as persistent store backend
2026-10-10T11:00:11,906212+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2026-10-10T11:00:11,908425+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2026-10-10T11:00:11,910580+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2026-10-10T11:00:11,912821+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2026-10-10T11:00:11,919448+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2026-10-10T11:00:11,973063+00:00 EXT4-fs (sda1): re-mounted 747687d9-c20c-41f8-bfb8-7f4a57910c51 r/w.
2026-10-10T11:00:12,218510+00:00 systemd-journald[489]: Received client request to flush runtime journal.
2026-10-10T11:00:13,383419+00:00 Console: switching to colour dummy device 80x25
2026-10-10T11:00:13,390684+00:00 bochs-drm 0000:00:01.0: vgaarb: deactivate vga console
2026-10-10T11:00:13,390820+00:00 [drm] Found bochs VGA, ID 0xb0c5.
2026-10-10T11:00:13,390831+00:00 [drm] Framebuffer size 16384 kB @ 0x80000000, mmio @ 0x8224b000.
2026-10-10T11:00:13,394481+00:00 bochs-drm 0000:00:01.0: [drm] Registered 1 planes with drm panic
2026-10-10T11:00:13,399072+00:00 [drm] Initialized bochs-drm 1.0.0 for 0000:00:01.0 on minor 0
2026-10-10T11:00:13,405469+00:00 fbcon: bochs-drmdrmfb (fb0) is primary device
2026-10-10T11:00:13,444793+00:00 Console: switching to colour frame buffer device 160x50
2026-10-10T11:00:13,449762+00:00 bochs-drm 0000:00:01.0: [drm] fb0: bochs-drmdrmfb frame buffer device
2026-10-10T11:00:13,714711+00:00 lpc_ich 0000:00:1f.0: I/O space for GPIO uninitialized
2026-10-10T11:00:13,773297+00:00 EXT4-fs (sda13): mounted filesystem 618f4c04-0edd-49b3-8ad5-00a29af1f556 r/w with ordered data mode. Quota mode: none.
2026-10-10T11:00:13,805311+00:00 snd_hda_intel 0000:00:1b.0: no codecs found!
2026-10-10T11:00:13,831782+00:00 i801_smbus 0000:00:1f.3: Enabling SMBus device
2026-10-10T11:00:13,831829+00:00 i801_smbus 0000:00:1f.3: SMBus using PCI interrupt
2026-10-10T11:00:13,835790+00:00 i2c i2c-0: Memory type 0x07 not supported yet, not instantiating SPD
2026-10-10T11:00:13,968730+00:00 RAPL PMU: API unit is 2^-32 Joules, 0 fixed counters, 10737418240 ms ovfl timer
2026-10-10T11:00:14,055288+00:00 audit: type=1400 audit(1791630013.864:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="1password" pid=698 comm="apparmor_parser"
2026-10-10T11:00:14,055633+00:00 audit: type=1400 audit(1791630013.864:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Discord" pid=699 comm="apparmor_parser"
2026-10-10T11:00:14,061513+00:00 audit: type=1400 audit(1791630013.870:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name=4D6F6E676F444220436F6D70617373 pid=700 comm="apparmor_parser"
2026-10-10T11:00:14,062891+00:00 audit: type=1400 audit(1791630013.871:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="QtWebEngineProcess" pid=701 comm="apparmor_parser"
2026-10-10T11:00:14,076560+00:00 audit: type=1400 audit(1791630013.884:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="alsamixer" pid=703 comm="apparmor_parser"
2026-10-10T11:00:14,081485+00:00 audit: type=1400 audit(1791630013.890:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="babeld" pid=704 comm="apparmor_parser"
2026-10-10T11:00:14,084972+00:00 audit: type=1400 audit(1791630013.893:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="balena-etcher" pid=705 comm="apparmor_parser"
2026-10-10T11:00:14,090281+00:00 audit: type=1400 audit(1791630013.899:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="bfdd" pid=706 comm="apparmor_parser"
2026-10-10T11:00:14,091432+00:00 audit: type=1400 audit(1791630013.900:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Xorg" pid=702 comm="apparmor_parser"
2026-10-10T11:00:14,091440+00:00 audit: type=1400 audit(1791630013.900:11): apparmor="STATUS" operation="profile_load" profile="unconfined" name="Xorg_wrap" pid=702 comm="apparmor_parser"
2026-10-10T11:00:14,264031+00:00 intel_rapl_msr: PL4 support detected.
2026-10-10T11:00:14,755976+00:00 RPC: Registered named UNIX socket transport module.
2026-10-10T11:00:14,755985+00:00 RPC: Registered udp transport module.
2026-10-10T11:00:14,755993+00:00 RPC: Registered tcp transport module.
2026-10-10T11:00:14,755994+00:00 RPC: Registered tcp-with-tls transport module.
2026-10-10T11:00:14,755996+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2026-10-10T11:00:14,777312+00:00 ISO 9660 Extensions: Microsoft Joliet Level 3
2026-10-10T11:00:14,777818+00:00 ISO 9660 Extensions: RRIP_1991A
2026-10-10T11:00:14,957004+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2026-10-10T11:00:14,957303+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2026-10-10T11:00:14,957476+00:00 Loaded X.509 cert 'wens: 61c038651aabdcf94bd0ac7ff06c7248db18c600'
2026-10-10T11:00:15,977251+00:00 NET: Registered PF_QIPCRTR protocol family
2026-10-10T11:00:16,131358+00:00 loop0: detected capacity change from 0 to 8
2026-10-10T11:00:27,919064+00:00 Loading iSCSI transport class v2.0-870.
2026-10-10T11:00:30,947995+00:00 kauditd_printk_skb: 174 callbacks suppressed
2026-10-10T11:00:30,948019+00:00 audit: type=1400 audit(1791630030.757:186): apparmor="STATUS" operation="profile_load" profile="unconfined" name="cri-containerd.apparmor.d" pid=1473 comm="apparmor_parser"
2026-10-10T11:00:30,983241+00:00 audit: type=1400 audit(1791630030.792:187): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="cri-containerd.apparmor.d" pid=1472 comm="apparmor_parser"
2026-10-10T11:41:14,929321+00:00 clocksource: Long readout interval, skipping watchdog check: cs_nsec: 2604395751 wd_nsec: 504400087
2026-10-10T11:47:34,967797+00:00 audit: type=1400 audit(1791632857.796:188): apparmor="DENIED" operation="open" class="file" profile="who" name="/etc/nsswitch.conf" pid=2740 comm="who" requested_mask="r" denied_mask="r" fsuid=0 ouid=0
2026-10-10T11:47:34,967823+00:00 audit: type=1400 audit(1791632857.797:189): apparmor="DENIED" operation="open" class="file" profile="who" name="/etc/passwd" pid=2740 comm="who" requested_mask="r" denied_mask="r" fsuid=0 ouid=0
2026-10-10T11:47:34,967985+00:00 audit: type=1400 audit(1791632857.797:190): apparmor="DENIED" operation="open" class="file" profile="who" name="/etc/nsswitch.conf" pid=2740 comm="who" requested_mask="r" denied_mask="r" fsuid=0 ouid=0
2026-10-10T11:47:34,967992+00:00 audit: type=1400 audit(1791632857.797:191): apparmor="DENIED" operation="open" class="file" profile="who" name="/etc/passwd" pid=2740 comm="who" requested_mask="r" denied_mask="r" fsuid=0 ouid=0
