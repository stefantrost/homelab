192.168.178.115 dev ens18 lladdr bc:24:11:3c:bf:be REACHABLE 
192.168.178.25 dev ens18 lladdr a4:fc:14:04:a3:e9 REACHABLE 
192.168.178.114 dev ens18 lladdr bc:24:11:de:cb:0c REACHABLE 
192.168.178.23 dev ens18 lladdr 14:59:c0:ca:d9:e8 STALE 
192.168.178.1 dev ens18 lladdr 34:e1:a9:62:6b:e6 STALE 
