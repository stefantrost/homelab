error dumping contents of map: loading pinned map /sys/fs/bpf/tc/globals/cilium_ipcache_v2: no such file or directory
> Error while running 'cilium-dbg bpf ipcache list':  exit status 1

