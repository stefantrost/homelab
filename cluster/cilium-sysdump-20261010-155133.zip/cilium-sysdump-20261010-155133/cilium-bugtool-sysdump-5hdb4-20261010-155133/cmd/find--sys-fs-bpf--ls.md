        1      0 drwx-----T   2 root     root            0 Oct 10 11:00 /sys/fs/bpf
