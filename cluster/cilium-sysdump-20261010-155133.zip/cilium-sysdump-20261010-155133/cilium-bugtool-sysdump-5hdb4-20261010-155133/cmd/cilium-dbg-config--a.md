Error: Error while retrieving configuration: Get "http://localhost/v1/config": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium-dbg config -a':  exit status 1

