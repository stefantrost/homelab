Node 0, zone      DMA      2      2      2      2      1      2      2      3      2      3      1 
Node 0, zone    DMA32    820    569    244    184    160     86     43     24     10      8    421 
Node 0, zone   Normal      3     16      9      5      9      5      9      6      6      4      5 
