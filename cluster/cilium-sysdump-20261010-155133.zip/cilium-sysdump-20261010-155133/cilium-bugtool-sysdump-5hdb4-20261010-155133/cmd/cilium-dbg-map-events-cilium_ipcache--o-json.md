Error: could not get map name events: Get "http://localhost/v1/map/cilium_ipcache/events?follow=false": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium-dbg map events cilium_ipcache -o json':  exit status 1

