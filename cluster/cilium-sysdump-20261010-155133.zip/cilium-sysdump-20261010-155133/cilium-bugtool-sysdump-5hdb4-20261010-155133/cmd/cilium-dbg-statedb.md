Error: Get(dump): Get "http://localhost/statedb/dump": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium-dbg statedb':  exit status 1

