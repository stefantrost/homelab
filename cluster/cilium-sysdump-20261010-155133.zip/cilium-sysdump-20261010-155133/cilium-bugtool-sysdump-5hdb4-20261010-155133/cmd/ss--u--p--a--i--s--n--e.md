Total: 495
TCP:   345 (estab 203, closed 120, orphaned 0, timewait 120)

Transport Total     IP        IPv6
RAW	  1         0         1        
UDP	  8         5         3        
TCP	  225       197       28       
INET	  234       202       32       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                     Local Address:Port Peer Address:PortProcess                                                       
UNCONN 0      0                             127.0.0.54:53        0.0.0.0:*           uid:989 ino:6775 sk:1001 cgroup:unreachable:be6 <->   
UNCONN 0      0                          127.0.0.53%lo:53        0.0.0.0:*           uid:989 ino:6773 sk:1002 cgroup:unreachable:be6 <->   
UNCONN 0      0                  192.168.178.113%ens18:68        0.0.0.0:*           uid:998 ino:16205 sk:1003 cgroup:unreachable:10eb <-> 
UNCONN 0      0                                0.0.0.0:111       0.0.0.0:*           ino:7169 sk:1004 cgroup:unreachable:678 <->           
UNCONN 0      0                              127.0.0.1:323       0.0.0.0:*           ino:13744 sk:1005 cgroup:unreachable:125f <->         
UNCONN 0      0                                   [::]:111          [::]:*           ino:7171 sk:1006 cgroup:unreachable:678 v6only:1 <->  
UNCONN 0      0                                  [::1]:323          [::]:*           ino:13745 sk:1007 cgroup:unreachable:125f v6only:1 <->
UNCONN 0      0      [fe80::be24:11ff:fe48:8fe6]%ens18:546          [::]:*           uid:998 ino:14000 sk:1008 cgroup:unreachable:10eb v6only:1 <->
