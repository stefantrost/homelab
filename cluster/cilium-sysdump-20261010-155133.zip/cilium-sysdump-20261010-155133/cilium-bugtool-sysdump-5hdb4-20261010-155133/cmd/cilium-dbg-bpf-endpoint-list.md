> Error while running 'cilium-dbg bpf endpoint list':  exit status 1

