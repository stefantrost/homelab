22: cgroup_array  name cgroup_map  flags 0x0
	key 4B  value 4B  max_entries 1  memlock 320B
23: ringbuf  name written_sysctls  flags 0x0
	key 0B  value 0B  max_entries 262144  memlock 275784B
25: array  name .rodata.str1.1  flags 0x80
	key 4B  value 5B  max_entries 1  memlock 320B
	frozen
