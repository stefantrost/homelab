Get "http://localhost/v1/healthz": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium-dbg status --verbose':  exit status 1

