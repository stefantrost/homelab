46: cgroup_device  name sd_devices  tag 9f0126175d483e7a  gpl
	loaded_at 2026-10-10T11:00:11+0000  uid 0
	xlated 504B  jited 311B  memlock 4096B
47: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:11+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
48: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:11+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
49: cgroup_device  name sd_devices  tag 99aee04c1c96cc7e  gpl
	loaded_at 2026-10-10T11:00:12+0000  uid 0
	xlated 464B  jited 290B  memlock 4096B
50: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:12+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
51: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:12+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
52: cgroup_device  name sd_devices  tag 9f0126175d483e7a  gpl
	loaded_at 2026-10-10T11:00:14+0000  uid 0
	xlated 504B  jited 311B  memlock 4096B
58: cgroup_sysctl  name sysctl_monitor  tag 2953fbb83d3292b5  gpl
	loaded_at 2026-10-10T11:00:14+0000  uid 998
	xlated 1240B  jited 781B  memlock 4096B  map_ids 22,25,23
	btf_id 110
60: cgroup_device  name sd_devices  tag 925aa739a35aee81  gpl
	loaded_at 2026-10-10T11:00:14+0000  uid 0
	xlated 560B  jited 353B  memlock 4096B
61: cgroup_device  name sd_devices  tag 470479e7b2a42bb5  gpl
	loaded_at 2026-10-10T11:00:14+0000  uid 0
	xlated 184B  jited 103B  memlock 4096B
62: cgroup_device  name sd_devices  tag d82bf1294d9d3136  gpl
	loaded_at 2026-10-10T11:00:15+0000  uid 0
	xlated 792B  jited 482B  memlock 4096B
63: cgroup_skb  name sd_fw_egress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:15+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
64: cgroup_skb  name sd_fw_ingress  tag 772db7720b2728e9  gpl
	loaded_at 2026-10-10T11:00:15+0000  uid 0
	xlated 64B  jited 56B  memlock 4096B
68: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
72: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
73: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
77: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
78: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
82: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
83: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
87: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
88: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
92: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
98: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
102: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
103: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
107: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:30+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
108: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:41+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
112: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:41+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
113: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:48+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
117: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:48+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
118: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
122: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
123: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
127: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
133: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
137: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
138: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
142: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:49+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
143: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
147: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
150: cgroup_device  tag b1e4e8bab2078b38
	loaded_at 2026-10-10T11:00:50+0000  uid 0
	xlated 64B  jited 42B  memlock 4096B
305: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T13:52:39+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
309: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T13:52:39+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
310: cgroup_device  name sd_devices  tag fdbddde2d88502e1  gpl
	loaded_at 2026-10-10T13:52:39+0000  uid 0
	xlated 440B  jited 273B  memlock 4096B
314: cgroup_device  tag b2c0b2c5432dcbd0
	loaded_at 2026-10-10T13:52:39+0000  uid 0
	xlated 512B  jited 330B  memlock 4096B
