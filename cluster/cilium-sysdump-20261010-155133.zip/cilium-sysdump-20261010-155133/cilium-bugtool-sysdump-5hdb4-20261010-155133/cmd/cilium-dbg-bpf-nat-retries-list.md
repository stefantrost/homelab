Error: Unable to open /sys/fs/bpf/tc/globals/cilium_snat_v4_alloc_retries: loading pinned map /sys/fs/bpf/tc/globals/cilium_snat_v4_alloc_retries: no such file or directory
> Error while running 'cilium-dbg bpf nat retries list':  exit status 1

